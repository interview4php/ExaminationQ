<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//系统配置
class HtmlSystemSetupModel extends RelationModel {
   
	//创建一个学生编号
	public function createStudentNumber(){
		$data = $this->getStudentNumberPrefix();
		//检查Id长度是否符号最小长度，如果不则在前面增加0
		$lastId = D('student')->getLastSchoolStudentId();
		$lastId = $this->checkMinLength($lastId+1,$data['student_number_min_length']);
		return $data['student_number_prefix'].$lastId;
	}
	
	
	//查询用户配置的学生编号前缀和最小长度
	public function getStudentNumberPrefix(){
		$field = 'student_number_prefix,student_number_min_length';
		$order = 'system_id desc';
		$data = $this->field($field)->order($order)->find();
		return $data;
	}
	//检查Id长度是否符号最小长度，如果不则在前面增加0
	private function checkMinLength($lastId,$minLen){	
		$strlen = strlen($lastId);
		$c = $minLen-$strlen;
		if($c>0){
			for($i=0;$i<$c;$i++){
				$lastId = '0'.$lastId;
			}
		}
		return $lastId;
		
	}
   
}