<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//社员表
class StudentModel extends RelationModel
{

    //社员登录
    public function login($POST, $otherArray)
    {
        if (!is_array($POST)) {
            return array('ret' => 'false', 'msg' => '数据错误');
        }

        //检查数据库中是否有该条社员信息如果没有则新建
        $userData = $this->getOne($POST, $otherArray);

        //设置用户session
        $this->setLoginSession($userData);
    }

    //退出，清除SESSION
    public function logout()
    {
        $_SESSION = array(); //清除SESSION值.
        if (isset($_COOKIE[session_name()])) {  //判断客户端的cookie文件是否存在,存在的话将其设置为过期.
            setcookie(session_name(), '', time() - 1, '/');
        }
        session_destroy();  //清除服务器的sesion文件
    }

    //查询一条记录
    public function getOne($data, $otherArray)
    {
        $where['mobile_phone'] = $data['mobile_phone'];
        $ret = $this->where($where)->find();

        //该用户不存在，新建该用户
        if (!$ret) {
            $new = $this->createOne($data, $otherArray);
            $ret = $this->where(array('id' => $new))->find();

        } //存在，名字已改变则修改数据库
        else {
            $new = $this->updateOne($ret['id'], $data, $otherArray);
            $ret = $this->where(array('id' => $ret['id']))->find();
        }

        return $ret;
    }

    //保存登录成功的SESSION
    public function setLoginSession($data)
    {
//        session("headImgUrl","");
//        session("openid","")

      
        session('act_sign_up_student_id', $data['id']);
        session("mobile_phone",$data['mobile_phone']);
        session('renew_student_id', $data['id']);
        session('student_id',$data['id']);
        session('student_mobile_phone', $data['mobile_phone']);
        session('account_binding_wxid', $data['account_binding_wxid']);

    }

    //新建用户
    protected function createOne($array, $otherArray)
    {
        $data['user_name'] = $array['user_name'];
        $data['true_name'] = $array['user_name'];
        $data['mobile_phone'] = $array['mobile_phone'];
        $data['apply_type_id'] = $otherArray['apply_type_id'];
        $data['end_time'] = $otherArray['expireday'];
        $data['school_student_number'] = D('HtmlSystemSetup')->createStudentNumber();
        $data['time'] = time();

        return $this->add($data);
    }

//更新成长值--线下的
    public function updateGrowthValue($id, $courseId)
    {
        $where['id'] = $id;
        $student = $this->where($where)->field('growth_value')->find();;
        $courseWhere['id'] = $courseId;
        $growthValue = D('SchoolCourse')->where($courseWhere)->field('growth_value')->find();
        $student['growth_value']=$student['growth_value']+$growthValue['growth_value']*60;
        return $this->where($where)->save($student);
    }

    //修改用户名
    protected function updateOne($id, $array, $otherArray)
    {
        $save['user_name'] = $array['user_name'];
        $save['true_name'] = $array['user_name'];
        $save['apply_type_id'] = $otherArray['apply_type_id'];
        $save['end_time'] = $otherArray['expireday'];
        $save['update_time'] = time();
        $where['id'] = array('eq', $id);
        return $this->where($where)->save($save);
    }


    //查询大学申请需要的默认字段
    public function getApplySchoolNeedField($student_id = 0)
    {
        $where['id'] = $student_id;
        $field = 'student_wx,company_vocation_id,company_position_id';
        return $this->field($field)->where($where)->find();

    }

    //查询某个手机号是否已经存在
    public function getRepeat($mobile_phone, $field = '*')
    {
        $where['mobile_phone'] = $mobile_phone;
        return $this->field($field)->where($where)->find();
    }

    //根据微信opeinid查询用户信息
    public function getUserInfoByOpenid($openid, $field = '*')
    {
        $where['account_binding_wxid'] = $openid;
        $where['is_disable'] = 0;
        return $this->field($field)->where($where)->find();
    }

    public function getUserInfoByPhone($mobile_phone)
    {

        $where['mobile_phone'] = $mobile_phone;

//		C5QEjGDtiwBjLpkYIEQ35XaX6og=
        $data = M('student')->where($where)->find();

        return $data;


    }

    /**
     *    查询一个学生的详细信息
     * @param mixed $field 可填 student_id,school_student_number,mobile_phone 等唯一的字段的值
     * @param type $type 可填 student_id,school_student_number,mobile_phone 等唯一的字段的名字
     */
    public function getStudentInfo($field, $type = 'id')
    {
        $where[$type] = $field;
        $info= $this->where($where)->find();

        $info['student_head_img']=session("headImgUrl");
        return $info;
    }

    public function SetJoinSucceed($apply_type_id, $end_time, $mobile_phone)
    {


        $ret = M('student')->where(array('mobile_phone' => $mobile_phone))->save(array('apply_type_id' => $apply_type_id, 'end_time' => $end_time));
      
      
        return $ret;

    }

    public function SetOnlineTimeStr(&$student_data)
    {
        //头像
        $student_data['student_head_img'] = session('headImgUrl');

        //成长 school_student_onlinetime
        $growth_value_offline = $student_data['growth_value'];
        $growth_value_online = $student_data['growth_value_online'];
        //计算成长值字符串
        $school_student_offlinetime = $this->Sec2Time($growth_value_offline);
        $school_student_onlinetime = $this->Sec2Time($growth_value_online);


        $student_data['school_student_onlinetime'] = $school_student_onlinetime;
        $student_data['school_student_offlinetime'] = $school_student_offlinetime;
    }

    function Sec2Time($time)
    {

        if (is_numeric($time)) {
            $value = array(
                "years" => 0, "days" => 0, "hours" => 0,
                "minutes" => 0, "seconds" => 0,
            );
            if ($time >= 31556926) {
                $value["years"] = floor($time / 31556926);

                $time = ($time % 31556926);
            }
            if ($time >= 86400) {
                $value["days"] = floor($time / 86400);
                $time = ($time % 86400);
            }
            if ($time >= 3600) {
                $value["hours"] = floor($time / 3600);
                $time = ($time % 3600);
            }
            if ($time >= 60) {
                $value["minutes"] = floor($time / 60);
                $time = ($time % 60);
            }
            $value["seconds"] = floor($time);

            // var_dump($value);
            //return (array) $value;
            //$t=$value["minutes"] ."分";
            $t = "";
            if ($value["years"] != "0") {
                $t = $value["years"] . "年" . $value["days"] . "天" . $value["hours"] . "小时" . $value["minutes"] . "分";

            } else {
                if ($value["days"] != "0") {
                    $t = $value["days"] . "天" . $value["hours"] . "小时" . $value["minutes"] . "分";

                } else {
                    if ($value["hours"] != "0") {
                        $t = $value["hours"] . "小时" . $value["minutes"] . "分";

                    } else {
                        $t = $value["minutes"] . "分";
                    }

                }

            }


            Return $t;

        } else {
            return (bool)FALSE;
        }
    }

    /**
     * 入社支付成功，创建用户
     *
     * @param $array
     * @return bool|mixed
     */
    public function createApplyOne($array)
    {
        $type = $array['student_type'];
        $data['pwd'] = $array['pwd'];
        $data['true_name'] = $array['true_name'];
        //可能不为空（试用会员）
        $data['student_type'] = $type == null || $type == "" ? '会员' : $type;
        $data['student_wx'] = $array['student_wx'];
        $data['company_name'] = $array['company_name'];
        $data['company_vocation_id'] = $array['company_vocation_id'];
        $data['company_position_id'] = $array['company_position_id'];
        $data['apply_type_id'] = $array['apply_type_id'];
        $data['end_time'] = $array['end_time'];
        $data['update_time'] = time();
        $data['school_student_number'] = $array['school_student_number'];
        $data['student_group'] = $array['student_group'];
        $data['recommend_from'] = $array['recommend_from'];

        if ($this->getRepeat($array['mobile_phone'])) {
            //D('student')->where(array('mobile_phone' => $array['mobile_phone']))->save($data);
            //return M('student')->where(array('mobile_phone' => $array['mobile_phone']))->getField('id');
            return false;
        }

        $data['mobile_phone'] = $array['mobile_phone'];
        $data['time'] = time();

        return D('student')->add($data);
    }


    //查询学生类型（支持现场还是支持线上）
    public function getStudentType($student_id)
    {
        $where['id'] = $student_id;
        $data = $this->where($where)->getField('apply_type_id');
        switch ($data) {
            case '1':
                return '直播';
            case '2':
                return '现场';
        }
        return false;
    }

    //查询最后一个学员的ID
    public function getLastSchoolStudentId()
    {
        $field = 'id';
        $order = 'id desc';
        $data = $this->field($field)->order($order)->find();
        return $data['id'];
    }

    //查询一个学生的编号
    public function getStudentNumber($mobile_phone)
    {
        $where['mobile_phone'] = $mobile_phone;
        return $this->where($where)->getField('school_student_number');
    }


    /**用户续费
     * @param int $student_id 需要续费的用户ID
     * @param string $end_time 需要更新的有效期
     */
    public function incEndTime($student_id, $end_time, $apply_type_id = 1)
    {
        $where['id'] = $student_id;

        $save['end_time'] = $end_time;
        $save['apply_type_id'] = $apply_type_id;

        return $this->where($where)->save($save);
    }

    //返回续费多少年以后的时间戳
    public function getNewEndTime($old_end_time, $year)
    {
        $old_year = date('Y', $old_end_time);
        $old_month = date('m-d H:i:s', $old_end_time);
        $new_year = $old_year + $year;

        return strtotime($new_year . '-' . $old_month);
    }

    //创建一条假会员。没有入社类型、没有有效期
    public function getNewFalseStudent($true_name, $mobile_phone)
    {
        //$student_info = $this->getRepeat($mobile_phone);

        $data['true_name'] = $true_name;
        $data['user_name'] = $true_name;
        $data['mobile_phone'] = $mobile_phone;
        $data['student_type'] = '非会员';
        $data['time'] = time();

        //if (empty($student_info)) {
        $this->add($data);
        //} else {
        //	$this->where(array('mobile_phone' => $mobile_phone))->save($data);
        //}

        return $this->getRepeat($mobile_phone);
    }

    //绑定微信
    public function bindingWx($mobile_phone, $openid, $nick_name, $headimgurl, $province, $city)
    {
        $where['mobile_phone'] = $mobile_phone;

        $save['account_binding_wxid'] = $openid;
        $save['wx_nick_name'] = $nick_name;
        $save['wx_province_name'] = $province;
        $save['wx_city_name'] = $city;
        $save['student_head_img'] = $headimgurl;

        $save['update_time'] = time();

        return $this->where($where)->save($save);
    }

    /**
     * 返回用户升级需要的金额
     *
     * @param $end_time
     * @return array
     */
    public function getUpgradeMoney($end_time)
    {
        //剩余时间
        $have_time = $end_time - time();
        $year = 31536000;

        //查询升级费用信息
        $moneydata = D('system_online_to_scence_setup')->getOne();
        if (!$moneydata['number']) {
            return array('ret' => 'false', 'msg' => $moneydata['number_is_null']);
        }

        if ($have_time > $year * 2) {
            //您的社员有效期在两年以上，暂不支持系统升级，请联系管理员
            return array('ret' => 'false', 'msg' => $moneydata['gt_two_year']);
        } else if ($have_time > $year) {
            //大于1年且小于或等于2年升级
            return array('ret' => 'true',
                'msg' => '大于1年且小或等于2年升级',
                'money' => $moneydata['gt_year'],
                'type' => 'two'
            );
        } else if ($have_time > 0) {
            //小或等于1年升级
            return array('ret' => 'true',
                'msg' => '小或等于1年升级',
                'money' => $moneydata['elt_one_year'],
                'type' => 'one'
            );
        } else {
            //账号已过期
            return array('ret' => 'false', 'msg' => '账号已过期');
        }
    }

    //用户升级(回调里面的处理)
    public function upgrade($student_id, $type)
    {
        //查询支付的金额对应的升级方式
        switch ($type) {
            case 'two':
                $end_time = strtotime("+2 year");
            case 'one':
                $end_time = strtotime("+1 year");
        }

        $where['id'] = $student_id;
        $save['apply_type_id'] = 1;
        $save['end_time'] = $end_time;
        $save['update_time'] = time();

        return $this->where($where)->save($save);
    }


}