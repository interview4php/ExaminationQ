<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//学生提交的音响问题
class StudentCourseQuestionMusicModel extends RelationModel {
   
	//查询某个学生是否已经投票过了
	public function isHave($courseId,$studentId){	
		$where['course_id'] = $courseId;
		$where['student_id']= $studentId;
		return $this->where($where)->count();
	}
	
	//设置某个学生已经投票
	public function createOne($courseId,$studentId,$type,$seatNumber){
		$data['course_id'] 	= $courseId;
		$data['student_id']	= $studentId;
		$data['type']	  	= $type;
		$data['seat_number']= $seatNumber;
		$data['time']		= time();
		return $this->add($data);
	}
	
	
   
}