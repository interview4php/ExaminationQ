<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//申请入社表
class StudentApplyModel extends RelationModel {
   
	
	//新增一个待审核的入社申请
	public function createOneApply($student_id=0){
		//由于敏感字段，手动组数据
		$data['apply_student_id'] 			= $student_id;
		$data['apply_student_name']			= session('apply_student_name_input');
		$data['apply_student_mobile_phone'] = session('apply_student_mobile_phone_input');
		$data['apply_student_wx']			= session('apply_student_wx_input');
		$data['apply_student_vocation']		= session('apply_student_vocation_input');
		$data['apply_student_position']		= session('apply_student_position_input');
		$data['apply_need_price']			= session('apply_need_price_input');
		$data['apply_true_price']			= session('apply_true_price_input');
		$data['apply_type_id']				= session('apply_type_id_input');
		$data['apply_type_name']			= session('apply_type_name_input');
		$data['status']						= 1;
		$data['time'] 						= time();
		return $this->add($data);
	}

	
}