<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//学生所属职业
class StudentPositionModel extends RelationModel {
   
	//查询所有职业下拉需要的数据
	public function getSelectData(){
		$field = 'student_position_id,student_position_name';
		$order = 'sort desc,student_position_id asc';
		$where['status'] = 1;
		return $this->field($field)->where($where)->order($order)->select();
	}
	
	//获取标题
	public function getTitle($id){
		$where['student_position_id'] = $id;
		return $this->where($where)->getField('student_position_name');
	}
	
   
}