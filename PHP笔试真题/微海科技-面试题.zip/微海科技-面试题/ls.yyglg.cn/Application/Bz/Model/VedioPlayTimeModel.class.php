<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//
class VedioPlayTimeModel extends RelationModel
{
    public function getStudentStudyRecord($student_id,$limit)
    {
        $db_prefix = GetDbPrefix();
        $field = ' course.name,this.play_datetime as begin_time';
        $join = 'as this inner join ' . $db_prefix . 'school_course as course on this.course_id = course.id';
        $where['this.student_id'] = $student_id;
        $order = 'this.play_datetime desc';
        $student_course = $this->field($field)->join($join)->where($where)->order($order)->limit($limit)->select();
return $student_course;
//        var_dump($student_course);
//        die();
    }




}