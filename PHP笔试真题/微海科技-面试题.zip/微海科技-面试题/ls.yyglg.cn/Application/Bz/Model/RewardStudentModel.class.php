<?php
namespace Bz\Model;

use Think\Model;

/**
 * 打赏学生姓名
 *
 * Class RewardStudentModel
 * @package Bz\Model
 */
class RewardStudentModel extends Model
{
	/**
	 * 初始化一条打赏学生信息
	 *
	 * @param $course_id
	 * @param $mobile_phone
	 * @param $true_name
	 * @return bool|mixed
	 */
	public function initRewardStudent($course_id, $mobile_phone, $true_name)
	{
		$cond = array(
			'course_id' => $course_id,
			'mobile_phone' => $mobile_phone,
		);
		$rcd_info = $this->where($cond)->find();
		if (!empty($rcd_info)) {
			return true;
		}

		$data = array(
			'course_id' => $course_id,
			'mobile_phone' => $mobile_phone,
			'add_time' => time(),
			'true_name' => $true_name,
		);

		$ret = $this->add($data);
		if ($ret) {
			return $ret;
		} else {
			return false;
		}
	}

	//查询一条信息
	public function getTrueName($course_id, $mobile_phone)
	{
		$cond = array(
			'course_id' => $course_id,
			'mobile_phone' => $mobile_phone,
		);

		return $this->where($cond)->getField('true_name');
	}
}