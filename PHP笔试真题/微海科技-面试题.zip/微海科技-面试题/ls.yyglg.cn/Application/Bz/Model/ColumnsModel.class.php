<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/10/3 0003
 * Time: 下午 9:43
 */
namespace Bz\Model;

use Think\Model\RelationModel;

class ColumnsModel extends RelationModel {

    protected $_link = array(
        'Columnist' => array(
            'mapping_type' =>self::BELONGS_TO,
            'foreign_key'  =>'columnist_id',
            'mapping_fields'=>'columnist_name,columnist_head_img',
            'as_fields'    =>'columnist_name:columnist_name,columnist_head_img:columnist_head_img',
        ),
        'ColumnsArticle' => array(
            'mapping_type' =>self::HAS_MANY,
            'foreign_key'  =>'columns_id',
            'mapping_name'=>'article',
            'mapping_order' => 'time desc',
        ),
    );



}