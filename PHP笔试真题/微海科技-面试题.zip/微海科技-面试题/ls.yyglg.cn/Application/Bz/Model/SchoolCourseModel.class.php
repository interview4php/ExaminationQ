<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//学院课程
class SchoolCourseModel extends RelationModel
{
	protected $_link = array(//连表
		//学院
		'school' => array(
			'mapping_type' => self::BELONGS_TO,
			'class_name' => 'School',
			'foreign_key' => 'school_id',
			'mapping_fields' => 'school_name',
			'as_fields' => 'school_name:school_name',
		),

	);

	//查询课程信息
	public function getOne($course_id, $field = '*')
	{
		$where['id'] = $course_id;
		return $this->field($field)->where($where)->find();
	}

	//根据学院选择
	public function getAllBySchool($student_id = 0, $begin = 5, $number = 100)
	{
		$ralation = array('school');
		$field = 'id,school_id';
		$order = 'sort desc,id desc';
		$group = 'school_id';
		$limit = "$begin,$number";

		$where['school_course_status'] = array('neq', 3);
		$where['type'] = 0;
		$data = $this->field($field)->relation($ralation)->where($where)->group($group)->order($order)->limit($limit)->select();
		if (!$data) {
			return array('ret' => 'false', 'msg' => '没有数据');
		}

		foreach ($data as $k => $v) {
			//查询某个学院的课程
			$data[$k]['course_list'] = $this->getOneSchoolCourse($data[$k]['school_id']);
			unset($data[$k]['school_id']);
			foreach ($data[$k]['course_list'] as $kk => $vv) {
				//组合开始时间和结束时间
				$data[$k]['course_list'][$kk]['day'] = $this->setBeginAndEndTimeToDay($vv['begin_time'], $vv['end_time']);
				unset($data[$k]['course_list'][$kk]['begin_time']);
				unset($data[$k]['course_list'][$kk]['end_time']);
				//查看当前用户对该课程的状态
				$student_data_a = D('student_course')->getStatus($vv['id'], $student_id);
				$data[$k]['course_list'][$kk]['student_status'] = $student_data_a['status'];
				$data[$k]['course_list'][$kk]['student_see_type'] = $student_data_a['see_type'];

				//查询该课程的老师
				$data[$k]['course_list'][$kk]['teacher_list'] = D('SchoolCourseTeacher')->getTeacherByCourseId($vv['id']);
			}
		}

		return array('ret' => 'true', 'data' => $data);

	}

	//根据日期选择
	public function getAllByTime($student_id = 0, $begin = 5, $number = 100)
	{
		$field = 'FROM_UNIXTIME(begin_time,"%Y-%m")as months,FROM_UNIXTIME(begin_time,"%m")as months2,begin_time';
		$order = 'months asc';
		$group = 'months';
		$limit = "$begin,15";

		$where['school_course_status'] = array('neq', 3);
		$where['type'] = 0;

		$data = $this->field($field)->where($where)->group($group)->order($order)->limit($limit)->select();
		if (!$data) {
			return array('ret' => 'false', 'msg' => '没有数据');
		}

		foreach ($data as $k => $v) {
			//查询该月的
			$lastandfirst = $this->mFristAndLastDay(date('Y', $v['begin_time']), date('m', $v['begin_time']));
			$where2['sc_c.school_course_status'] = array('neq', 3);
			$where2['sc_c.type'] = 0;
			$where2['sc_c.begin_time'] = array('between', array($lastandfirst['firstday'], $lastandfirst['lastday']));

			$data[$k]['list'] = $this->getAllOrderByTime($where2, $student_id);
			$data[$k]['months2'] = $this->returnMonths($v['months2']);
		}
		//dump(array('ret'=>'true','data'=>$data));die;
		return array('ret' => 'true', 'data' => $data);
	}

	//根据条件查询 根据时间排序
	public function getAllOrderByTime($where, $student_id)
	{
		$join = 'as sc_c left join ' . C('DB_PREFIX') . 'school as sc on sc_c.school_id = sc.id ';
		$field = 'sc_c.id,sc_c.name,sc_c.address,sc_c.school_id,sc_c.begin_time,sc_c.end_time,sc_c.school_course_status,sc.school_name,sc_c.is_scene,sc_c.is_online,sc_c.all_number,sc_c.use_number';
		$order = 'sc_c.begin_time asc';

		$data = $this->field($field)->join($join)->where($where)->order($order)->select();
		if (!$data) {
			return false;
		}

		foreach ($data as $k => $v) {
			//查看当前用户对该课程的状态
			$student_data_a = D('student_course')->getStatus($v['id'], $student_id);
			$data[$k]['student_status'] = $student_data_a['status'];
			$data[$k]['student_see_type'] = $student_data_a['see_type'];

			//组合开始时间和结束时间
			$data[$k]['day'] = D('school_course')->setBeginAndEndTimeToDay($v['begin_time'], $v['end_time']);
			unset($data[$k]['begin_time']);
			unset($data[$k]['end_time']);

			//剩余名额
			$data[$k]['over_number'] = $v['all_number'] - $v['use_number'];
			//查询该课程的老师
			$data[$k]['teacher_list'] = D('SchoolCourseTeacher')->getTeacherByCourseId($v['id']);
		}

		return $data;
	}


	//查询某个学院的课程
	public function getOneSchoolCourse($school_id)
	{
		$where['school_id'] = $school_id;
		$order = 'sort desc,id desc';
		$field = 'id,name,address,begin_time,end_time,school_course_status,is_scene,is_online';
		$where['school_course_status'] = array('neq', 3);
		return $this->field($field)->where($where)->order($order)->select();
	}

	//重新组合课程开始时间和结束时间
	public function setBeginAndEndTimeToDay($begin, $end)
	{
		$begin_y = date('Y', $begin);
		$begin_m = date('m', $begin);
		$begin_d = date('d', $begin);
		$begin_h = date('H:i', $begin);
		$end_y = date('Y', $end);
		$end_m = date('m', $end);
		$end_d = date('d', $end);
		$end_H = date('H:i', $end);
		$time_y = date('Y');
		return date('m', $begin) . '月' . date('d', $begin) . '-' . date('d', $end) . '日';

		if ($begin_y . $begin_m . $begin_d == $end_y . $end_m . $end_d && $time_y == $end_y) {
			//同一天显示分
			return date('m', $begin) . '月' . date('d', $begin) . '日' . $begin_h . '-' . $end_H;
		} else if ($begin_y . $begin_m == $end_y . $end_m && $time_y == $end_y) {
			//同一个月显示日
			return date('m', $begin) . '月' . date('d', $begin) . '-' . date('d', $end) . '日';
		} else if ($begin_y == $end_y && $time_y == $end_y) {
			//同一年
			return date('m', $begin) . '月' . date('d', $begin) . '-' . date('m', $end) . '月' . date('d', $end) . '日';
		} else {
			return date('Y年m月d日H:i', $begin) . '-' . date('Y年m月d日H:i', $end);
		}


	}

	/**
	 * 获取指定月份的第一天开始和最后一天结束的时间戳
	 *
	 * @param int $y 年份 $m 月份
	 * @return array(本月开始时间，本月结束时间)
	 */
	function mFristAndLastDay($y = "", $m = "")
	{
		if ($y == "") $y = date("Y");
		if ($m == "") $m = date("m");
		$m = sprintf("%02d", intval($m));
		$y = str_pad(intval($y), 4, "0", STR_PAD_RIGHT);

		$m > 12 || $m < 1 ? $m = 1 : $m = $m;
		$firstday = strtotime($y . $m . "01000000");
		$firstdaystr = date("Y-m-01", $firstday);
		$lastday = strtotime(date('Y-m-d 23:59:59', strtotime("$firstdaystr +1 month -1 day")));
		return array("firstday" => $firstday, "lastday" => $lastday);
	}

	//阿拉伯数字的月份转为一月二月等
	function returnMonths($months)
	{

		switch ($months) {
			case 1:
				return '一';
			case 2:
				return '二';
			case 3:
				return '三';
			case 4:
				return '四';
			case 5:
				return '五';
			case 6:
				return '六';
			case 7:
				return '七';
			case 8:
				return '八';
			case 9:
				return '九';
			case 10:
				return '十';
			case 11:
				return '十一';
			case 12:
				return '十二';
		}

	}

	/**
	 *    查询我签到需要显示的字段
	 *    t        为school_course表
	 *    s        为school表
	 */
	public function getSignField($courseId)
	{
		$field = 't.id,t.name as course_name,s.school_name,t.one_see_type,t.one_money';
		$where['t.id'] = $courseId;
		$join = 'as t left join ' . C('DB_PREFIX') . 'school as s on s.id = t.school_id ';
		return $this->field($field)->join($join)->where($where)->find();
	}

	/**
	 *    查询课程与学校的连表数据
	 *    t        为school_course表
	 *    s        为school表
	 */
	public function getCourseField($courseId, $field)
	{
		$where['t.id'] = $courseId;
		$join = 'as t left join ' . C('DB_PREFIX') . 'school as s on s.id = t.school_id ';

		return $this->field($field)->join($join)->where($where)->find();
	}

	//现场名额自增
	public function setIncUseNumber($id)
	{
		return D('SchoolCourse')->where(array('id' => $id))->setInc('use_number');
	}

	//现场名额自减
	public function setDecUseNumber($id)
	{
		return D('SchoolCourse')->where(array('id' => $id))->setDec('use_number');
	}


}