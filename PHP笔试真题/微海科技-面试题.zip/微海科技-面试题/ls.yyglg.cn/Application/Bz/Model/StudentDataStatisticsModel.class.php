<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//学员数据统计
class StudentDataStatisticsModel extends RelationModel {
   
	//累加打赏数据
	public function incSCount($field,$student_id,$number){
		$this->isHave($student_id);
		
		$where['student_id'] = $student_id;
		return $this->where($where)->setInc($field,$number);
	}
	//查询某条数据是否存在，不存在则创建
	public function isHave($student_id){
		$data = array('student_id'=>$student_id);
		if(!$this->where($data)->find()){
			$this->add($data);
		}
	}

   
}