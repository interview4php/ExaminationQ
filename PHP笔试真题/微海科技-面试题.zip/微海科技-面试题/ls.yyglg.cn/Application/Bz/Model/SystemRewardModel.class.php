<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//打赏
class SystemRewardModel extends RelationModel
{
	/**
	 * 查询某条打赏信息
	 *
	 * @param $id
	 * @param string $field
	 * @return mixed
	 */
	public function getRewardInfo($id, $field = '*')
	{
		$where['id'] = $id;
		return $this->field($field)->where($where)->find();
	}

	/**
	 * 查询某条打赏信息（根据课程）
	 *
	 * @param $courseID
	 * @param string $field
	 * @return mixed
	 */
	public function getRewardByCourseId($courseID, $field = '*')
	{
		$where['other_id'] = $courseID;
		return $this->field($field)->where($where)->find();
	}


	//打赏推送
	public function cnlSocketNewReward($this_msg, $reward_id)
	{
	
		$client = stream_socket_client('tcp://' . get_server_ip() . ':7273');
		if (!$client) {
			A('Public')->LogInfo("can not connect 7273端口". get_server_ip());
			exit("can not connect");
		}

		$system_reward_id = 'NewReward_' . $reward_id;

		fwrite($client, '{"type":"send","course_id":"' . $system_reward_id . '","content":"{ \"type\":\"cnlNewRewardPeople\",\"course_id\":\"'.$reward_id.'\",\"price\":\"'.$this_msg['price'] .'\" ,\"name\":\"' . $this_msg['name'] . '\",\"msg\":\"' . $this_msg['msg'] . '\",\"time\":\"' . $this_msg['time'] . '\"}"}' . "\n");
		fclose($client);
	}


}