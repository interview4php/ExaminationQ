<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//用户升级待付款
class StudentNoPayUpgradeModel extends RelationModel
{


	//增加一条信息
	public function createOne($data)
	{
		$data['time'] = time();

		$ret = $this->add($data);
		if ($ret) {
			session('upgrade_pay_id', $ret);
			session('pay_id', $ret);
			session('pay_money', $data['money']);

			return $ret;
		} else {
			return false;
		}
	}

	//查询一条信息
	public function getOne($id)
	{
		$where['id'] = $id;
		return $this->where($where)->find();
	}

	//删除一条数据
	public function deleteOne($id)
	{
		if (!$id) {
			return false;
		}
		$where['id'] = $id;
		return $this->where($where)->delete();
	}

}