<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//学生电子票
class StudentCourseSeatModel extends RelationModel {
   
	//新增学生电子票
	public function createOne($studentId,$courseId,$seatAddress){
		
		$data['student_id'] 	= $studentId;
		$data['course_id']  	= $courseId;
		$data['seat_address']	= $seatAddress;
		$data['time']			= time();
		return $this->add($data);
		
	}

	public function createOneWithPlaceIdMobile($studentId,$courseId,$seatAddress,$placeId,$mobile){

	$data['student_id'] 	= $studentId;
	$data['course_id']  	= $courseId;
	$data['seat_address']	= $seatAddress;
	$data['time']			= time();
		$data['activity_place_id']			= $placeId;
		$data['mobile']			= $mobile;
	return $this->add($data);

}

	public function createOneWithPlaceId($studentId,$courseId,$seatAddress,$placeId){

		$data['student_id'] 	= $studentId;
		$data['course_id']  	= $courseId;
		$data['seat_address']	= $seatAddress;
		$data['time']			= time();
		$data['activity_place_id']			= $placeId;
		return $this->add($data);

	}
	//查看学生是否已经选了座位
	public function isHaveByMobile($studentId,$courseId,$mobile){
		$where['course_id'] = $courseId;
		$where['student_id']= $studentId;
		$where['mobile']= $mobile;
		return $this->where($where)->count();
	}
	//查看学生是否已经选了座位
	public function isHave($studentId,$courseId){
		$where['course_id'] = $courseId;
		$where['student_id']= $studentId;
		return $this->where($where)->count();
	}
	
	//展示电子票
	public function getOne($courseId,$studentId){
		$join = 'as t left join '.C('DB_PREFIX').'school_course as sc_c on sc_c.id = t.course_id ';
		$join .= 'inner join '.C('DB_PREFIX').'student as st on st.id = t.student_id ';
		$field = 't.seat_address,t.time,t.activity_place_id,';
		$field .= 'sc_c.name,';
		$field .= 'st.user_name,st.mobile_phone';
		$where['course_id'] = $courseId;
		$where['student_id'] = $studentId;
		
		return $this->field($field)->join($join)->where($where)->find();
	}
	public function getOneWithMobile($courseId,$studentId,$mobile){
		$join = 'as t left join '.C('DB_PREFIX').'school_course as sc_c on sc_c.id = t.course_id ';

		$field = 't.seat_address,t.time,t.activity_place_id,';
		$field .= 'sc_c.name';

		$where['course_id'] = $courseId;

		$where['mobile'] = $mobile;
		return $this->field($field)->join($join)->where($where)->find();
	}
}