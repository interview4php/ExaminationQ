<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//饮水问题
class SchoolCourseQuestionWaterModel extends RelationModel {
	//查询某个课程的饮水
	public function getOneCourse($courseId,$field='content,default_title,default_description,default_img'){
		$this->isHave($courseId);
		$where['course_id'] = $courseId;
		return $this->field($field)->where($where)->find();
	}
	
	//检查是否有该条数据
	public function isHave($courseId){
		$where['course_id'] = $courseId;
		if(!$this->where($where)->count()){
			$this->add(array('course_id'=>$courseId,'time'=>time()));
		}
	}
}