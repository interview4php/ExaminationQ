<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//打赏对象（老师）
class SystemRewardTeacherModel extends RelationModel
{


	//查询该打赏对象的打赏页面信息
	public function getRewardTeacherInfo($id)
	{
		//查询打赏对象信息
		$reward_teacher = $this->getOne($id, 'system_reward_id,teacher_id,status,reward_type,description');
		//查询不到该打赏对象或者该打赏对象不允许被打赏
		if (!$reward_teacher || !$reward_teacher['status']) {
			return false;
		}

		//查询打赏信息
		$reward = D('system_reward')->getRewardInfo($reward_teacher['system_reward_id']);
		//查询不到该打赏信息或者该打赏不允许被打赏或者该打赏不是用来打赏老师的
		if (!$reward || !$reward['status'] || $reward['other_type'] != '课程打赏') {
			return false;
		}

		//查询该老师信息
		$field_teacher_data = 'teacher_name,teacher_head_img';
		$teacher_data = D('school_teacher')->getOne($reward_teacher['teacher_id'], $field_teacher_data);

		//查询该课程名字和所属学院
		$field_course_data = 't.name as course_name,s.school_name';
		$course_data = D('school_course')->getCourseField($reward['other_id'], $field_course_data);

		$data['teacher_data'] = $teacher_data;
		$data['reward'] = $reward;
		$data['reward_teacher'] = $reward_teacher;
		$data['course_data'] = $course_data;

		return $data;
	}

	//查询打赏的对象的课程的信息和学院信息
	public function getRewardTeacherInfoClose($id)
	{
		$reward_teacher = $this->getOne($id, 'system_reward_id');

		//查询打赏信息
		$reward = D('system_reward')->getRewardInfo($reward_teacher['system_reward_id']);

		//查询该课程名字和所属学院
		$field_course_data = 't.name as course_name,s.school_name';
		$course_data = D('school_course')->getCourseField($reward['other_id'], $field_course_data);

		return $course_data;
	}

	//查询一条打赏对象
	public function getOne($id, $field = '*')
	{
		$where['id'] = $id;
		return $this->field($field)->where($where)->find();
	}


	//累加打赏数据
	public function incSCount($field, $reward_teacher_id, $number)
	{
		$where['id'] = $reward_teacher_id;
		return $this->where($where)->setInc($field, $number);
	}

	public function getObjByCourse_Id($course_id){
		$where['status'] = 1;
		$where['course_id'] = $course_id;
		return $this->where($where)->find();
	}
	
	//查询当前打赏对象ID
	public function getOneId($course_id)
	{
		$where['status'] = 1;
		$where['course_id'] = $course_id;

		return $this->where($where)->getField('id');
	}


}