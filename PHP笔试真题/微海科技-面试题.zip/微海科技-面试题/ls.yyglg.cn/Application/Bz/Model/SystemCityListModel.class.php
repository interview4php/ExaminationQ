<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//地区
class SystemCityListModel extends RelationModel {

	
	//获取标题
	public function getTitle($id){
		if (empty($id)) {
			return '';
		}

		$where['id'] = $id;
		return $this->where($where)->getField('name');
	}
	
   
}