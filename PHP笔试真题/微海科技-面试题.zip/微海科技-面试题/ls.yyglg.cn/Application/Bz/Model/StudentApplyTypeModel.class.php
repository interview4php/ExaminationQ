<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//入社模式
class StudentApplyTypeModel extends RelationModel
{


    //查询入社模式需要的字段
    public function getSelectData()
    {
        $field = 'student_apply_type_id,student_apply_type_name,student_apply_type_price,booked_up';
        $order = 'sort desc,student_apply_type_id asc';
        $where['status'] = 1;
        return $this->field($field)->where($where)->order($order)->select();
    }

    //查询某个入社模式需要的字段
    public function getOneData($id)
    {
        $field = 'student_apply_type_id,student_apply_type_name,student_apply_type_price';
        $where['status'] = 1;
        $where['student_apply_type_id'] = $id;
        return $this->field($field)->where($where)->find();
    }

    //查询某个入社模式需要的字段  id是apply id
    public function getOneData2($student_info)
    {
        $apply_type_id = $student_info['apply_type_id'];
        if (empty($student_info['end_time']) || $student_info['end_time'] < time()) {
			$apply_type_id = -1;

		}
        $field = 'student_apply_type_id,student_apply_type_name,student_apply_type_price,booked_up';
        $where['status'] = 1;
        //$where['student_apply_type_id'] = $id;

        //$apply_type_id -1是临时会员，1是线下，2是线上


        if ($apply_type_id == 1) {//如果是线下会员，就只能续费线下
            $where['student_apply_type_id'] = 1;

        }

        $ret = $this->field($field)->where($where)->select();

        foreach ($ret as $index => $item) {
            if ($apply_type_id == -1) {
                $ret[$index]['student_apply_type_name'] = $ret[$index]['student_apply_type_name'] . "(升级)";
//                $ret[$index]['is_upgrade']=1;
                $ret[$index]['url']=     "/Bz/StudentRenew/studentRenewSelectPayType";
            }
            if ($apply_type_id == 1) {
                $ret[$index]['student_apply_type_name'] = $ret[$index]['student_apply_type_name'] . "(续费)";
//                $ret[$index]['is_upgrade']=0;
                $ret[$index]['url']=   "/Bz/StudentRenew/studentRenewSelectPayType";
            }
            if ($apply_type_id == 2) {
                if ( $ret[$index]['student_apply_type_id']==2  )
                {
                    $ret[$index]['student_apply_type_name'] = $ret[$index]['student_apply_type_name'] . "(续费)";
//                    $ret[$index]['is_upgrade']=0;
                    $ret[$index]['url']=   "/Bz/StudentRenew/studentRenewSelectPayType";
                }else
                {
//                    $ret[$index]['is_upgrade']=1;
                    $ret[$index]['student_apply_type_name'] = $ret[$index]['student_apply_type_name'] . "(升级)";
                    $ret[$index]['url']=     "/Bz/Student/studentUpgradeSelectPayType/";
                }
            }
        }

//        var_dump($ret);
        return $ret;
    }


}