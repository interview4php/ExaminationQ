<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//课程座位
class SchoolCourseSeatModel extends RelationModel {
   

	//查询一个课程的座位
	public function getOne($course_id,$field='course_id,seat_array'){
		
		$where['course_id'] = $course_id;
		//$where['status']	= 1;
		return $this->field($field)->where($where)->find();
		
	}
	public function getByCourseAndPlace($course_id,$placeId){
		$field='school_course_seat_id,course_id,address,address_time,status';
		$where['course_id'] = $course_id;
		$where['activity_place_id'] = $placeId;
		//$where['status']	= 1;
		return $this->field($field)->where($where)->find();

	}

	//非会员报名签到设置座位
	public function setStudentSeatByCourseAndPlaceByMobile($courseId,$placeId,$seatOne,$seatTwo,$studentId,$mobile){
		//查询该用户是否已经签到了该课程
		if(session('user_is_false_sign')!='yes'.$courseId.(session('sign_student_id'))){
			return array('ret'=>'false1','msg'=>'未签到','button'=>'去签到','href'=>'/Bz/Kcqd/index/courseId/'.$courseId);
		}

		//查询该用户是否已经选了座位
		if(D('StudentCourseSeat')->isHaveByMobile($studentId,$courseId,$mobile)){
			return array('ret'=>'false2','msg'=>'在本场地或其他场地已有位置','button'=>'确定','href'=>'');
		}



		//查询该课程的座位
		$seatData = $this->getByCourseAndPlace($courseId,$placeId,'school_course_seat_id',$mobile);



		//该座位的详细信息
		$seatInfo = M('SchoolCourseSeatList')->where(array(
			'school_course_seat_id'=>$seatData['school_course_seat_id'],
			'one'=>$seatOne,
			'two'=>$seatTwo
		))->find();


		//查看当前用户是否有资格抢位置
		if(D('student_course')->isRewardVip($courseId,$studentId)){
			if($seatInfo['status'] != '3'){
				return array('ret'=>'false4','msg'=>'您只可以选座打赏专用座位','button'=>'继续选座','href'=>'');
			}
		}else{
			if($seatInfo['status'] != '1'){
				return array('ret'=>'false5','msg'=>'您只可以选座普通座位','button'=>'继续选座','href'=>'');
			}
		}


		//查看该位置是否有人
		if($seatInfo['student_id']){
			return array('ret'=>'false3','msg'=>'手慢了，座位已被占用','button'=>'继续选座','href'=>'');
		}


		$save['student_id'] 	= $studentId;
		$save['update_time'] 	= time();
		$save['mobile'] 	= $mobile;

		D()->startTrans();//开启事务
		//更新座位
		$ret1 = D('SchoolCourseSeat')->updateSeatList($seatInfo['id'],$save);


		//增加学生座位
		$ret2 = D('StudentCourseSeat')->createOneWithPlaceIdMobile($studentId,$courseId,$seatInfo['address'],$placeId,$mobile);
		
		//执行签到
		$ret3 = D('StudentCourseSign')->createOneWithPlaceIdMobile($studentId,$courseId,$placeId,$mobile);





//增加学生成长值
//		$ret4= D('Student')->updateGrowthValue($studentId,$courseId);



		if($ret1 && $ret2 && $ret3){
			D()->commit();
			$this->cnlSocketCourseSeat($courseId,$seatOne,$seatTwo);

			return array('ret'=>'true','msg'=>'选位成功','address'=>$seatInfo['address'],'href'=>'');
		}else{
			D()->rollback();
			return array('ret'=>'false','msg'=>'服务器繁忙','button'=>'重新选座','href'=>'');
		}


	}


	public function setStudentSeatByCourseAndPlace($courseId,$placeId,$seatOne,$seatTwo,$studentId){
		//查询该用户是否已经签到了该课程
		if(session('user_is_false_sign')!='yes'.$courseId.(session('sign_student_id'))){
			return array('ret'=>'false1','msg'=>'未签到','button'=>'去签到','href'=>'/Bz/Kcqd/index/courseId/'.$courseId);
		}
		
		//查询该用户是否已经选了座位
		if(D('StudentCourseSeat')->isHave($studentId,$courseId)){
			return array('ret'=>'false2','msg'=>'在本场地或其他场地已有位置','button'=>'确定','href'=>'');
		}



		//$data = serialize($data);
		//$data = unserialize($data);
		//查询该课程的座位
		$seatData = $this->getByCourseAndPlace($courseId,$placeId,'school_course_seat_id');


	
		//该座位的详细信息
		$seatInfo = M('SchoolCourseSeatList')->where(array(
			'school_course_seat_id'=>$seatData['school_course_seat_id'],
			'one'=>$seatOne,
			'two'=>$seatTwo
		))->find();

		//查看当前用户是否有资格抢位置
		if(D('student_course')->isRewardVip($courseId,$studentId)){
			if($seatInfo['status'] != '3'){
				return array('ret'=>'false4','msg'=>'您只可以选座打赏专用座位','button'=>'继续选座','href'=>'');
			}
		}else{
			if($seatInfo['status'] != '1'){
				return array('ret'=>'false5','msg'=>'您只可以选座普通座位','button'=>'继续选座','href'=>'');
			}
		}


		//查看该位置是否有人
		if($seatInfo['student_id']){
			return array('ret'=>'false3','msg'=>'手慢了，座位已被占用','button'=>'继续选座','href'=>'');
		}

		$save['student_id'] 	= $studentId;
		$save['update_time'] 	= time();


		D()->startTrans();//开启事务
		//更新座位
		$ret1 = D('SchoolCourseSeat')->updateSeatList($seatInfo['id'],$save);
		//增加学生座位
		$ret2 = D('StudentCourseSeat')->createOneWithPlaceId($studentId,$courseId,$seatInfo['address'],$placeId);
		
		//执行签到
		$ret3 = D('StudentCourseSign')->createOneWithPlaceId($studentId,$courseId,$placeId);



//增加学生成长值
		$ret4= D('Student')->updateGrowthValue($studentId,$courseId);

		

		if($ret1 && $ret2 && $ret3&&$ret4){
			D()->commit();
			$this->cnlSocketCourseSeat($courseId,$seatOne,$seatTwo);

			return array('ret'=>'true','msg'=>'选位成功','address'=>$seatInfo['address'],'href'=>'');
		}else{
			D()->rollback();
			return array('ret'=>'false','msg'=>'服务器繁忙','button'=>'重新选座','href'=>'');
		}


	}

	//学生选位置（普通位置 statsu为1）
	public function setStudentSeat($courseId,$seatOne,$seatTwo,$studentId){
		//查询该用户是否已经签到了该课程
		if(session('user_is_false_sign')!='yes'.$courseId.(session('sign_student_id'))){
			return array('ret'=>'false1','msg'=>'未签到','button'=>'去签到','href'=>'/Bz/Kcqd/index/courseId/'.$courseId);
		}
		//查询该用户是否已经选了座位
		if(D('StudentCourseSeat')->isHave($studentId,$courseId)){
			return array('ret'=>'false2','msg'=>'已经选择了座位','button'=>'确定','href'=>'');
		}
		
	
		//$data = serialize($data);
		//$data = unserialize($data);
		//查询该课程的座位
		$seatData = $this->getOne($courseId,'school_course_seat_id');
		//该座位的详细信息
		$seatInfo = M('SchoolCourseSeatList')->where(array(
					'school_course_seat_id'=>$seatData['school_course_seat_id'],
					'one'=>$seatOne,
					'two'=>$seatTwo
					))->find();
		
		//查看当前用户是否有资格抢位置
		if(D('student_course')->isRewardVip($courseId,$studentId)){
			if($seatInfo['status'] != '3'){
				return array('ret'=>'false4','msg'=>'您只可以选座打赏专用座位','button'=>'继续选座','href'=>'');
			}
		}else{
			if($seatInfo['status'] != '1'){
				return array('ret'=>'false5','msg'=>'您只可以选座普通座位','button'=>'继续选座','href'=>'');
			}
		}
		
		
		//查看该位置是否有人
		if($seatInfo['student_id']){
			return array('ret'=>'false3','msg'=>'手慢了，座位已被占用','button'=>'继续选座','href'=>'');
		}
		
		$save['student_id'] 	= $studentId;
		$save['update_time'] 	= time();
	
		
		D()->startTrans();//开启事务
		//更新座位 
		$ret1 = D('SchoolCourseSeat')->updateSeatList($seatInfo['id'],$save);
		//增加学生座位
		$ret2 = D('StudentCourseSeat')->createOne($studentId,$courseId,$seatInfo['address']);
		//执行签到
		$ret3 = D('StudentCourseSign')->createOne($studentId,$courseId);



		if($ret1 && $ret2 && $ret3){
			D()->commit();
			$this->cnlSocketCourseSeat($courseId,$seatOne,$seatTwo);
			
			return array('ret'=>'true','msg'=>'选位成功','address'=>$seatInfo['address'],'href'=>'');
		}else{
			D()->rollback();
			return array('ret'=>'false','msg'=>'服务器繁忙','button'=>'重新选座','href'=>'');
		}
		
		
	}
	//更新单条座位
	public function updateSeatList($id,$save){
		$where['id'] = $id;
		return D('SchoolCourseSeatList')->where($where)->save($save);
	}
	
	
	//更新座位
	public function updateSeatArray($courseId,$seatArray){
		$save['seat_array']  = $seatArray;
		$save['update_time'] = time();
		$where['course_id'] = $courseId;
		return $this->where($where)->save($save);
	}
	
	//选座成功推送
	public function cnlSocketCourseSeat($course_id,$one,$two){
		return ;
		$client = stream_socket_client('tcp://'.get_server_ip().':7273');
		if(!$client)exit("can not connect");
		$course_id = 'cnlSocketCourseSeat_'.$course_id;//测试
		fwrite($client, '{"type":"send","course_id":"'.$course_id.'","content":"{ \"type\":\"cnlCourseSeat\",\"one\":\"'.$one.'\",\"two\":\"'.$two.'\",\"time\":\"'.time().'\"}"}'."\n");
		fclose($client);
	}
   
}