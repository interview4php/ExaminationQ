<?php
namespace Bz\Model;
use Think\Model;
use Think\Model\RelationModel;

class OrderModel extends Model {
	/**
	 * update pay status when user pay success
	 *
	 * @param $out_trade_no
	 * @param $total_fee_in_cent
	 * @param $pay_trade_no
	 *
	 * @return string
	 */
	public function update_pay_status($out_trade_no, $total_fee_in_cent, $pay_trade_no)
	{
		$curTime = time();

		$cond = array('order_number' => $out_trade_no);

		//echo  'order_number'.$out_trade_no;

		$order_data = $this->where($cond)->find();
		if (empty($order_data) || empty($order_data['order_type'])
		 || empty($order_data['relate_id']) || $order_data['money'] * 100 != $total_fee_in_cent)
		{
			return 'fail';
		}
		if ($order_data['pay_status'] == 1) {
			return 'success';
		}

		switch ($order_data['order_type']) {
			case 1:
				return $this->handle_apply_pay($order_data['relate_id'], $out_trade_no, $total_fee_in_cent, $pay_trade_no);
				break;
			case 2: // one course
				return $this->handle_one_course_pay($order_data['relate_id'], $out_trade_no, $total_fee_in_cent, $pay_trade_no);
				break;
			case 3: // renew
				return $this->handle_renew_pay($order_data['relate_id'], $out_trade_no, $total_fee_in_cent, $pay_trade_no);
				break;
			case 4: // upgrade
				return $this->handle_upgrade_pay($order_data['relate_id'], $out_trade_no, $total_fee_in_cent, $pay_trade_no);
				break;
			case 5:
				return $this->handle_reward_pay($order_data['relate_id'], $out_trade_no, $total_fee_in_cent, $pay_trade_no);
				break;
			case 6:
				return $this->handle_activity_sign_up_pay($order_data, $out_trade_no, $total_fee_in_cent, $pay_trade_no);
				break;
			case 7:
				return $this->handle_reward_pay_video($order_data['relate_id'], $out_trade_no, $total_fee_in_cent, $pay_trade_no);
				break;
			default:
				return 'fail';
				break;
		}
	}

	/**
	 * handle apply pay notify
	 *
	 * @param $relate_id
	 *
	 * @return string fail|success
	 */
	public function handle_apply_pay($relate_id, $out_trade_no, $total_fee_in_cent, $pay_trade_no) {
		$nopaydata = D('student_no_pay')->getOne($relate_id);
		if (!$nopaydata) {
			return 'fail';
		}

		$this->startTrans();

//		//创建一个会员
//		$nopaydata['apply_type_id'] = $nopaydata['apply_type_id'];
//		$nopaydata['end_time'] = strtotime("+" . $nopaydata['apply_year_number'] . " year");
//		$nopaydata['school_student_number'] = D('HtmlSystemSetup')->createStudentNumber();
//
//		$ret1 = D('Student')->createApplyOne($nopaydata);

		//修改会员信息
		$nopaydata['apply_type_id'] = $nopaydata['apply_type_id'];
		$nopaydata['end_time'] = strtotime("+" . $nopaydata['apply_year_number'] . " year");
		//学号已经生成
		//$nopaydata['school_student_number'] = D('HtmlSystemSetup')->createStudentNumber();

		$ret1 = D('Student')->SetJoinSucceed($nopaydata['apply_type_id'], $nopaydata['end_time'], $nopaydata['mobile_phone']);


		//保存用户的入社交易记录
		$ret2 = D('student_pay_record')->createApplyOne($ret1, ($total_fee_in_cent) / 100, $out_trade_no, '入社费',
			'支付宝支付', 0, $pay_trade_no, $nopaydata['true_name'], $nopaydata['mobile_phone'], $nopaydata['school_student_number']);

		if ($ret1 && $ret2) {
			$this->commit();
			$where['mobile_phone'] = $nopaydata['mobile_phone'];

			$student_number = M('student')->where($where)->getField('school_student_number');
			//发送短信

			$content = "尊敬的{$nopaydata['true_name']}，欢迎加入抱柱大学！您的专属社员编号为：{$student_number}；请在微信搜索关注“抱柱大学社服务号”,在菜单右侧绑定手机号码可查看个人信息以及报名课程，查看学习资料。谢谢！";
			A('Public')->sendShortMsg($nopaydata['mobile_phone'], $content);

			$content = "尊敬的{$nopaydata['true_name']}，加入抱柱大学第一天，送您一份“抱柱大学往期课堂学习笔记”大礼包，点击链接http://dwz.cn/2WHKF7，进入学习，关注微信“".$this-> nameConfig['WECHAT_SERVICE_NAME']."”获得更多课程信息。";
			A('Public')->sendShortMsg($nopaydata['mobile_phone'], $content);

//			//发送短信
//			$content = "尊敬的{$nopaydata['true_name']}，欢迎加入抱柱大学！您的专属社员编号为：{$nopaydata['school_student_number']}；请在微信搜索关注" . $this->nameConfig['WECHAT_SERVICE_NAME'] . ",绑定手机号码可以查看个人信息以及报名课程。";
//			A('Public')->sendShortMsg('18682157284', $nopaydata['mobile_phone'].$nopaydata['true_name'].$nopaydata['school_student_number']);
//			A('Public')->sendShortMsg($nopaydata['mobile_phone'], $content);

			return 'success';
		} else {
			$this->rollback();
			//发送邮件
			$content = '尊敬的' . $nopaydata['true_name'] . '，欢迎加入抱柱大学，系统错误导致入社失败，请联系客服，对您造成的不便深感抱歉。';
		//	A('Public')->sendShortMsg($nopaydata['mobile_phone'], $content);
			\Think\Log::Write($content . '手机号：' . $nopaydata['mobile_phone']);

			return 'fail';
		}
	}

	/**
	 * handle one course pay
	 *
	 * @param $relate_id
	 * @param $out_trade_no
	 * @param $total_fee_in_cent
	 * @param $pay_trade_no
	 */
	public function handle_one_course_pay($relate_id, $out_trade_no, $total_fee_in_cent, $pay_trade_no) {
		$nopaydata = D('student_no_pay_one_course')->getOne($relate_id);
		if (!$nopaydata) {
			return 'fail';
		}

		//查询用户信息
		$userdata = M('student')->where(array('id' => $nopaydata['student_id']))->find();

		//查询课程信息
		$coursedata = M('school_course')->where(array('id' => $nopaydata['course_id']))->find();

		D('student_no_pay_one_course')->deleteOne($nopaydata['id']);

		$ret1 = D('StudentCourse')->addOnePayCourse($nopaydata['student_id'], $nopaydata['course_id'], ($total_fee_in_cent) / 100);
		D('student_pay_record')->createApplyOne($nopaydata['student_id'], ($total_fee_in_cent) / 100, $pay_trade_no,
			'单场课程费', '支付宝支付', 0, $pay_trade_no,
			$userdata['true_name'], $userdata['mobile_phone'], $userdata['school_student_number']);

		if ($ret1) {
			//发送邮件
			$content = '亲爱的' . $userdata['true_name'] . '，您已成功购买课程“' . $coursedata['name'] . '”(' . $coursedata['one_see_type'] . '),请记得参加哦。';
			A('Public')->sendShortMsg($userdata['mobile_phone'], $content);

			return 'success';
		} else {
			//发送邮件
			$content = '亲爱的' . $userdata['true_name'] . '，系统错误导致购买失败，请联系客服，对您造成的不便深感抱歉。';
			//A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
			\Think\Log::Write($content . '手机号：' . $userdata['mobile_phone']);

			return 'fail';
		}
	}

	/**
	 * handle renew pay
	 *
	 * @param $relate_id
	 * @param $out_trade_no
	 * @param $total_fee_in_cent
	 * @param $pay_trade_no
	 */
	public function handle_renew_pay($relate_id, $out_trade_no, $total_fee_in_cent, $pay_trade_no) {
		$nopaydata = D('student_no_pay_renew')->getOne($relate_id);
		if (!$nopaydata) {
			return 'fail';
		}

		D('student_no_pay_renew')->deleteOne($nopaydata['id']);

		$cur_time = time();

		//查询用户信息
		$userdata = M('student')->where(array('id' => $nopaydata['student_id']))->find();
		//为用户续费（延长到期时间）
		if ($userdata['end_time'] < $cur_time) {
			$userdata['end_time'] = $cur_time;
		}
		$end_time = D('student')->getNewEndTime($userdata['end_time'], $nopaydata['apply_type_year']);

		$ret1 = D('student')->incEndTime($nopaydata['student_id'], $end_time, $nopaydata['apply_type_id']);

		$ret2 = D('student_pay_record')->createApplyOne($nopaydata['student_id'], ($total_fee_in_cent) / 100,
			$pay_trade_no, '续费', '支付宝支付', 0, $pay_trade_no,
			$userdata['true_name'], $userdata['mobile_phone'], $userdata['school_student_number']);

		if ($ret1) {
			//发送邮件

			$str_end_time = date('Y年m月d日', $end_time);
			$content = "亲爱的{$userdata['true_name']}，您已续费成功，社员有效期延长至{$str_end_time}，了解最新课程、报名课程请在".$this-> nameConfig['WECHAT_SERVICE_NAME']."查询。";
			A('Public')->sendShortMsg($userdata['mobile_phone'], $content);

			return 'success';
		} else {
			//发送邮件
			$content = '亲爱的' . $userdata['true_name'] . '，系统错误导致续费失败，请联系客服，对您造成的不便深感抱歉。';
		//	A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
			\Think\Log::Write($content . '手机号：' . $userdata['mobile_phone']);

			return 'fail';
		}
	}

	/**
	 *
	 * @param $relate_id
	 * @param $out_trade_no
	 * @param $total_fee_in_cent
	 * @param $pay_trade_no
	 * @return string
	 */
	public function handle_upgrade_pay($relate_id, $out_trade_no, $total_fee_in_cent, $pay_trade_no) {
		$nopaydata = D('student_no_pay_upgrade')->getOne($relate_id);
		if (!$nopaydata) {
			return 'fail';
		}


		//查询用户信息
		$userdata = M('student')->where(array('id' => $nopaydata['student_id']))->find();

		D()->startTrans();

		D('student_no_pay_upgrade')->deleteOne($nopaydata['id']);

		//保存用户的入社交易记录
		$pay_money = ($total_fee_in_cent) / 100;
		$ret1 = D('student_pay_record')->createApplyOne($userdata['id'], $pay_money, $pay_trade_no,
			'升级费', '支付宝支付', 0, $pay_trade_no,
			$userdata['true_name'], $userdata['mobile_phone'], $userdata['school_student_number']);

		//用户升级
		$ret2 = D('student')->upgrade($nopaydata['student_id'], $nopaydata['type']);

		if ($ret1 && $ret2) {
			D()->commit();
			//发送短信
			if ($nopaydata['is_temp']) {
				if ($nopaydata['is_new']) {
					$content = "尊敬的{$userdata['true_name']}，欢迎加入抱柱大学！您的专属社员编号为：{$userdata['school_student_number']}；请在微信搜索关注“".$this-> nameConfig['WECHAT_SERVICE_NAME']."”,在菜单右侧绑定手机号码可查看个人信息以及报名课程，查看学习资料。谢谢！";
				} else {
					$str_end_time = date('Y年n月j日', $userdata['end_time']);
					$content = "尊敬的{$userdata['true_name']}，恭喜您已成功升级铁杆！您的专属社员编号为：{$userdata['school_student_number']}，有效期至{$str_end_time}，可在有效期内报名抱柱大学所有现场及网络直播课程，请在微信搜索关注“".$this-> nameConfig['WECHAT_SERVICE_NAME']."”，绑定手机号码可以查看个人信息以及报名课程。并加" .$this-> nameConfig['ADMIN_NAME']."咨询.添加时请告知“社员编号-姓名-城市”，以便识别。谢谢！";
				}
			} else {
				$str_end_time = date('Y年n月j日', $userdata['end_time']);
				$content = "亲爱的{$userdata['true_name']}，恭喜您已成功升级铁杆！您的专属社员编号为：{$userdata['school_student_number']}，有效期至{$str_end_time}，可在有效期内报名抱柱大学所有现场及网络直播课程，请在微信搜索关注“".$this-> nameConfig['WECHAT_SERVICE_NAME']."”，绑定手机号码可以查看个人信息以及报名课程。并加" .$this-> nameConfig['ADMIN_NAME']."咨询.添加时请告知“社员编号-姓名-城市”，以便识别。谢谢！";
			}

			A('Public')->sendShortMsg($userdata['mobile_phone'], $content);

			if ($nopaydata['is_temp'] && $nopaydata['is_new']) {
				$content = "尊敬的{$userdata['true_name']}，加入抱柱大学第一天，送您一份“抱柱大学往期课堂学习笔记”大礼包，点击链接http://dwz.cn/2WHKF7，进入学习，关注微信“".$this-> nameConfig['WECHAT_SERVICE_NAME']."”获得更多课程信息。";
				A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
			}

			return 'success';
		} else {
			D()->rollback();
			//发送邮件
			$content = '尊敬的' . $userdata['true_name'] . '，系统错误导致升级失败，请联系客服，对您造成的不便深感抱歉。';
			//A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
			\Think\Log::Write($content . '手机号：' . $userdata['mobile_phone']);

			return 'fail';
		}
	}

	/**
	 *
	 * @param $relate_id
	 * @param $out_trade_no
	 * @param $total_fee_in_cent
	 * @param $pay_trade_no
	 * @return string
	 */
	public function handle_reward_pay($relate_id, $out_trade_no, $total_fee_in_cent, $pay_trade_no) {
		$nopaydata = D('student_no_pay_reward')->getOne($relate_id);
		if (!$nopaydata) {
			return 'fail';
		}

		//D('student_no_pay_reward')->deleteOne($nopaydata['id']);
		$this->startTrans();

		//查询用户信息
		$userdata = M('student')->where(array('id' => $nopaydata['student_id']))->find();
		if(!$userdata['true_name']){
			$userdata['true_name'] = '匿名';
		}
		if(!$userdata['school_student_number']){
			$userdata['school_student_number'] = '临时会员';
		}
		$reward_id = D('school_course_reward')->rewardTeacherSuccess($nopaydata, $userdata, '支付宝支付');
		if ($reward_id) {
			//保存交易记录
			D('student_pay_record')->createApplyOne($userdata['id'], $nopaydata['money'], $out_trade_no,
				'打赏老师', '支付宝支付', $reward_id, $pay_trade_no,
				$userdata['true_name'], $userdata['mobile_phone'], $userdata['school_student_number']);

			//发送邮件
			$content = '尊敬的' . $userdata['true_name'] . '，您已成功打赏。';
			//A('Public')->sendShortMsg($userdata['mobile_phone'], $content);

			$this_msg['name'] = D('reward_student')->getTrueName($nopaydata['course_id'], $userdata['mobile_phone']);
			if (empty($this_msg['name'])) {
				$this_msg['name'] = $userdata['true_name'];
			}

			$this_msg['msg'] = msubstr($nopaydata['static_msg'], 0, 20, 'utf-8', false);
			$this_msg['time'] = date('H:i');
			D('system_reward')->cnlSocketNewReward($this_msg, 11);

			$order_cond = array(
				'order_number' => $out_trade_no,
				'pay_status' => array('neq', 1),
			);
			$order_data = array(
				'pay_status' => 1,
				'trade_no' => $pay_trade_no,
				'update_time' => time(),
			);
			$this->where($order_cond)->save($order_data);

			$this->commit();

			return 'success';
		} else {
			$this->rollback();

			//发送邮件
			$content = '尊敬的' . $userdata['true_name'] . '，系统错误导致打赏失败，请联系客服，对您造成的不便深感抱歉。';
			//A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
			\Think\Log::Write($content . '手机号：' . $userdata['mobile_phone']);

			return 'fail';
		}
	}

//
	public function handle_reward_pay_video($relate_id, $out_trade_no, $total_fee_in_cent, $pay_trade_no) {
		$nopaydata = D('student_no_pay_reward')->getOne($relate_id);
		if (!$nopaydata) {
			return 'fail';
		}

		//D('student_no_pay_reward')->deleteOne($nopaydata['id']);
		$this->startTrans();

		//查询用户信息
		$userdata = M('student')->where(array('id' => $nopaydata['student_id']))->find();
		if(!$userdata['true_name']){
			$userdata['true_name'] = '匿名';
		}
		if(!$userdata['school_student_number']){
			$userdata['school_student_number'] = '临时会员';
		}
		$reward_id = D('school_course_reward')->rewardTeacherSuccess($nopaydata, $userdata, '支付宝支付');
		$courseInfo = D('school_course')->where(array('id' => $nopaydata['course_id']))->field('name')->find();
		echo '$reward_id='.$reward_id;
		if ($reward_id) {
			//保存交易记录
			D('student_pay_record')->createApplyOne($userdata['id'], $nopaydata['money'], $out_trade_no,
				'打赏视频-'.$courseInfo['name'], '支付宝支付', $reward_id, $pay_trade_no,
				$userdata['true_name'], $userdata['mobile_phone'], $userdata['school_student_number']);

			//发送邮件
			$content = '尊敬的' . $userdata['true_name'] . '，您已成功打赏。';
			//A('Public')->sendShortMsg($userdata['mobile_phone'], $content);

			$this_msg['name'] = D('reward_student')->getTrueName($nopaydata['course_id'], $userdata['mobile_phone']);
			if (empty($this_msg['name'])) {
				$this_msg['name'] = $userdata['true_name'];
			}

			$this_msg['msg'] = msubstr($nopaydata['static_msg'], 0, 20, 'utf-8', false);
			$this_msg['time'] = date('H:i');
			D('system_reward')->cnlSocketNewReward($this_msg, 11);

			$order_cond = array(
				'order_number' => $out_trade_no,
				'pay_status' => array('neq', 1),
			);
			$order_data = array(
				'pay_status' => 1,
				'trade_no' => $pay_trade_no,
				'update_time' => time(),
			);
			$this->where($order_cond)->save($order_data);

			$this->commit();

			return 'success';
		} else {
			$this->rollback();

			//发送邮件
			$content = '尊敬的' . $userdata['true_name'] . '，系统错误导致打赏失败，请联系客服，对您造成的不便深感抱歉。';
			//A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
			\Think\Log::Write($content . '手机号：' . $userdata['mobile_phone']);

			return 'fail';
		}
	}

	/**
	 *
	 *
	 * @param $order_info
	 * @param $out_trade_no
	 * @param $total_fee_in_cent
	 * @param $pay_trade_no
	 */
	public function handle_activity_sign_up_pay($order_info, $out_trade_no, $total_fee_in_cent, $pay_trade_no) {
		$student_id = $order_info['student_id'];

		$act_data = M('school_course')->find($order_info['relate_id']);

		//查询用户信息
		$user_data = M('student')->where(array('id' => $student_id))->find();

		// update can buy more
		$cond = array('activity_id' => $order_info['relate_id'], 'can_buy_more' => 0);
		$arr_single_ids = M('activity_place')->field('id')->where($cond)->select();

		$arr_single_activity_place_ids = array();
		foreach ($arr_single_ids as $value) {
			if (!empty($value['id'])) {
				$arr_single_activity_place_ids[] = $value['id'];
			}
		}

		$cond = array(
			'student_id' => $student_id,
			'school_course_id' => $order_info['relate_id'],
			'order_number' => array('neq', $out_trade_no),
			'activity_place_id' => array('in', $arr_single_activity_place_ids)
		);

		D()->startTrans();

		//M('student_course')->where($cond)->save(array('status' => 0, 'msg' => '已切换会场',
//			'update_time' => time()));

		// 更新活动报名的支付情况
		$cond = array(
			'order_number' => $out_trade_no,
		);

		$data = array(
			'status' => 1,
			'pay_status' => 1,
			'trade_no' => $pay_trade_no,
			'update_time' => time(),
		);
		$ret1 = M('student_course')->where($cond)->save($data);
		if (!$ret1) {
			D()->rollback();
			//发送邮件
			$content = '亲爱的' . $user_data['true_name'] . '，系统错误导致购买失败，请联系客服，对您造成的不便深感抱歉。';
			//A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
			\Think\Log::Write($content . '手机号：' . $user_data['mobile_phone']);
		}

		//保存用户的入社交易记录
		$ret2 = D('student_pay_record')->createApplyOne($user_data['id'], ($total_fee_in_cent) / 100,
			$out_trade_no, $order_info['remark'], '微信支付', 0, $pay_trade_no,
			$user_data['true_name'], $user_data['mobile_phone'], $user_data['school_student_number']);

		if (!$ret2) {
			D()->rollback();
			//发送邮件
			$content = '亲爱的' . $user_data['true_name'] . '，系统错误导致购买失败，请联系客服，对您造成的不便深感抱歉。';
			//A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
			\Think\Log::Write($content . '手机号：' . $user_data['mobile_phone']);
		}

		D()->commit();

		$str_place_type = '';
		$arr_single_ids = M('student_course')->field('activity_place_id')->where($cond)->select();

		$arr_ids = array();
		foreach ($arr_single_ids as $value) {
			$arr_ids[] = $value['activity_place_id'];
		}
		$cond = array(
			'activity_id' => $act_data['id'],
			'id' => array('in', $arr_ids)
		);
		$arr_place_name = M('activity_place')->field('name')->where($cond)->select();

		foreach ($arr_place_name as $value) {
			$str_place_type .= "{$value['name']} ";
		}

		//发送短信
		if ($order_info['is_check']) {
			if ($act_data['is_sign_up_sms_msg']) {
				// send sms msg
				$content = str_replace('{姓名}', $user_data['true_name'], $act_data['sign_up_sms_msg']);
				$content = str_replace('{课程名称}', $act_data['name'], $content);
				$content = str_replace('{活动名称}', $act_data['name'], $content);
				$content = str_replace('{会场类型}', trim($str_place_type), $content);
				$str_time = date('n月j日', $act_data['begin_time']);
				$content = str_replace('{活动时间}', $str_time, $content);

				A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
			}
		} else {
			if ($act_data['is_audit_sms_msg']) {
				// send sms msg
				$content = str_replace('{姓名}', $user_data['true_name'], $act_data['audit_sms_msg']);
				$content = str_replace('{课程名称}', $act_data['name'], $content);
				$content = str_replace('{活动名称}', $act_data['name'], $content);
				$content = str_replace('{会场类型}', trim($str_place_type), $content);
				$str_time = date('n月j日', $act_data['begin_time']);
				$content = str_replace('{活动时间}', $str_time, $content);

				A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
			}
		}
	}
}