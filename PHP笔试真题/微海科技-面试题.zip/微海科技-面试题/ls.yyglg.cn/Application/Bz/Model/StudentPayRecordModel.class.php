<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//交易记录
class StudentPayRecordModel extends RelationModel
{

	/**保存交易记录
	 *
	 * @param int $student_id 用户ID
	 * @param money $pay_money 支付的金额 0.00
	 * @param string $pay_number 订单号
	 * @param string $pay_status 支付类型如：入社费，续费，升级费，单场课程费，打赏抢座，打赏老师
	 * @param string $pay_type 支付方式 如：微信支付，支付宝支付，线下汇款
	 * @param string $pay_reward_id 如果该记录为打赏，则该id为打赏列表的ID， 关联school_course_reward
	 * @param string $transaction_id 支付交易单、支付接口回调的
	 */
	public function createApplyOne($student_id, $pay_money, $pay_number, $pay_status,
		$pay_type = '微信支付', $pay_reward_id = 0, $transaction_id, $true_name, $mobile_phone, $student_number)
	{
		$data['pay_student_id'] = $student_id;
		$data['pay_money'] = $pay_money;
		$data['pay_status'] = $pay_status;
		$data['pay_type'] = $pay_type;
		$data['pay_time'] = time();
		$data['pay_number'] = $pay_number;
		$data['pay_info_id'] = $pay_reward_id;
		$data['transaction_id'] = $transaction_id;
		$data['true_name'] = $true_name;
		$data['mobile_phone'] = $mobile_phone;
		$data['student_number'] = $student_number;

		return $this->add($data);
	}
}