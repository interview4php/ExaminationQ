<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//支付方式
class StudentPayTypeModel extends RelationModel {
   
	
	//查询入社模式需要的字段
	public function getSelectData($iscanxianxia=true){
		$field = 'student_pay_type_id,student_pay_type_name,student_pay_type_href,student_pay_type_description,student_pay_type_img';
		$order = 'sort desc,student_pay_type_id asc';
		$where['status'] = 1;
		if(!$iscanxianxia){
			$where['student_pay_type_id'] = array('neq',3);
		}
		return $this->field($field)->where($where)->order($order)->select();
	}
	
	
}