<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//申请入社，待支付
class StudentNoPayModel extends RelationModel
{
	//增加一条信息
	public function createOne($apply_type_id, $apply_type_count, $money)
	{
		$data['true_name'] = session('apply_true_name');
		$data['mobile_phone'] = session('apply_mobile_phone');
		$data['student_wx'] = session('apply_wx');
		$data['company_name'] = session('apply_company');
		$data['company_vocation_id'] = session('apply_vocation_id');
		$data['company_position_id'] = session('apply_position_id');
		$data['money'] = $money;
		$data['time'] = time();
		$data['apply_type_id'] = $apply_type_id;
		$data['apply_year_number'] = $apply_type_count;
		if (cookie('apply_channel_id') == 'chanpin') {
			$data['student_group'] = 1;
		} else {
			$data['student_group'] = 0;
		}
		$data['recommend_from'] = cookie('recommand_info');

		$ret = $this->add($data);
		if (!$ret) {
			return false;
		}

		session('pay_id', $ret);
		session('apply_pay_id', $ret);

		return true;
	}

	//查询一条信息
	public function getOne($id)
	{
		$where['id'] = $id;

		return $this->where($where)->find();
	}

	//删除一条数据
	public function deleteOne($id)
	{
		if (!$id) {
			return false;
		}

		$where['id'] = $id;

		return $this->where($where)->delete();
	}

}