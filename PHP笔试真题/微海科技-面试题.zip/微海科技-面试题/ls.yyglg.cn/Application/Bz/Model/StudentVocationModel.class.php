<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//学生所属行业
class StudentVocationModel extends RelationModel {
   
	//查询所有行业下拉需要的数据
	public function getSelectData(){
		$field = 'student_vocation_id,student_vocation_name';
		$order = 'sort desc,student_vocation_id asc';
		$where['status'] = 1;
		return $this->field($field)->where($where)->order($order)->select();
	}
	
	//获取标题
	public function getTitle($id){
		$where['student_vocation_id'] = $id;
		return $this->where($where)->getField('student_vocation_name');
	}
	
   
}