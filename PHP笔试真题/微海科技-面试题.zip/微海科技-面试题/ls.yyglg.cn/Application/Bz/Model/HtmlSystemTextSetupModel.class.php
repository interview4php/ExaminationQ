<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//除了以前的文字配置以为，以后不是特殊的配置都在此
class HtmlSystemTextSetupModel extends RelationModel {
   
	//查询签到页面的查询不到该手机已经报名的文字提醒
	public function getCourseSignIndexError(){
		return $this->getOne('CourseSignIndexError','content,img');
	}
	//查询签到页面的重复签到错误提示
	public function getCourseSignIndexErrorRepeat(){
		return $this->getOne('CourseSignIndexErrorRepeat','content,img');
	}
	
	//统一查询接口
	private function getOne($type,$field){
		$where['type'] = $type;
		return $this->field($field)->where($where)->find();
	}
	
	

   
}