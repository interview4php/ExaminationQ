<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//课程模式聊天待发送记录
class SchoolCourseSendMsgModel extends RelationModel {
   
	
	//添加一条待发送记录
	public function addMsg($course_id,$student_id,$head_img,$msg){
		$data['course_id'] 	= $course_id;
		$data['student_id']	= $student_id;	
		$data['head_img']	= $head_img;	
		$data['msg']		= $msg;	
		$data['time']		= time();	
		return $this->add($data);
		
	}
   
}