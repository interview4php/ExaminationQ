<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//课程PPT
class SchoolCoursePptModel extends RelationModel {
   
	//查询某个课程的PPT
	public function getOneCourseAll($course_id){
		
		$where['course_id'] = $course_id;
		$order = 'sort desc,id asc';
		$field = 'id,img';
		return $this->field($field)->where($where)->order($order)->select();
		
	}

   
}