<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//学生F码
class StudentCourseFcodeModel extends RelationModel {
   
	//查询某个学生的F码信息
	public function getOne($student_id,$course_id,$field='f_code,time'){
		$where['student_id'] = $student_id;
		$where['course_id'] = $course_id;
		return $this->field($field)->where($where)->find();
		
	}

   
}