<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//课程老师表
class SchoolCourseTeacherModel extends RelationModel {
	protected $_link = array(//连表
		//老师
		  'teacher'=>array(
			'mapping_type' =>self::BELONGS_TO,
			'class_name'   =>'School_teacher',
			'foreign_key'  =>'teacher_id',
			'mapping_fields'=>'teacher_name,teacher_description',
			'as_fields'    =>'teacher_name:teacher_name,teacher_description:teacher_description',
		 ),
		 
	);
	//根据课程ID查该课程所有老师
	public function getTeacherByCourseId($courseId){
		$field = 'teacher_id';
		$where['course_id'] = $courseId;
		$order = 'sort desc,id desc';
		$relation = array('teacher');
		$data =  $this->field($field)->relation($relation)->where($where)->order($order)->select();
		foreach($data as $k=>$v){
			if(!empty($v['teacher_description'])){
				$data[$k]['teacher_description'] = '（'.$v['teacher_description'].'）';
			}
		}
		return $data;
		
	}

   
}