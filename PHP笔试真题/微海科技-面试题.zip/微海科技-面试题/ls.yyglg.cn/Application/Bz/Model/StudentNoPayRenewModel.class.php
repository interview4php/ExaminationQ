<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//用户续费
class StudentNoPayRenewModel extends RelationModel
{


	//增加一条信息
	public function createOne($student_id, $aid, $ayear, $amoney)
	{
		$data['student_id'] = $student_id;
		$data['apply_type_id'] = $aid;
		$data['apply_type_year'] = $ayear;
		$data['money'] = $amoney;
		$data['time'] = time();

		$ret = $this->add($data);
		if ($ret) {
			session('renew_pay_id', $ret);
			session('pay_id', $ret);
			session('pay_money', $amoney);

			return true;
		} else {
			return false;
		}


	}

	//查询一条信息
	public function getOne($id)
	{
		$where['id'] = $id;
		return $this->where($where)->find();
	}

	//删除一条数据
	public function deleteOne($id)
	{
		if (!$id) {
			return false;
		}
		$where['id'] = $id;
		return $this->where($where)->delete();
	}

}