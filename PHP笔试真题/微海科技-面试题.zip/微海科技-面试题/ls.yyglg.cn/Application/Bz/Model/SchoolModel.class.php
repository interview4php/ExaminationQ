<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//学院表
class SchoolModel extends RelationModel
{
    public function clearApplyInfo()
    {

        cookie('apply_confirmPassword',null);
        cookie('apply_password', null);

        cookie('apply_true_name', null);
        cookie('apply_mobile_phone',null);
        cookie('apply_mobile_phone_code', null);
        cookie('apply_wx', null);
        cookie('apply_company',null);
        cookie('apply_vocation', null);
        cookie('apply_vocation_id', null);
        cookie('apply_position', null);
        cookie('apply_position_id',null);
      
    }

    //保存入社申请的资料到cookie
    public function saveApplyInfo()
    {

        cookie('apply_confirmPassword', trim($_POST['confirmPassword']));
        cookie('apply_password', trim($_POST['password']));

        cookie('apply_true_name', trim($_POST['true_name']));
        cookie('apply_mobile_phone', trim($_POST['mobile_phone']));
        cookie('apply_mobile_phone_code', trim($_POST['mobile_phone_code']));
        cookie('apply_wx', trim($_POST['wx']));
        cookie('apply_company', trim($_POST['company']));
        cookie('apply_vocation', trim($_POST['vocation']));
        cookie('apply_vocation_id', trim($_POST['vocation_id']));
        cookie('apply_position', trim($_POST['position']));
        cookie('apply_position_id', trim($_POST['position_id']));
    }

    //保存入社申请手机验证码和手机session
    public function createApplyCodeSession($mobile_phone, $mobile_phone_code)
    {
        // 两台机器不能共享session，会导致验证码不对问题，需要用数据库或缓存
        session('apply_mobile_phone', $mobile_phone);
        session('apply_mobile_phone_code', $mobile_phone_code);
    }

    //验证手机验证码并且session保存验证成功标志
    public function checkShortMsgCode($mobile_phone)
    {


        $mobile_phone = trim($mobile_phone);
        $mobile_phone_code = trim($_GET['mobile_phone_code']);
        $checkstr = session('apply_mobile_phone') . session('apply_mobile_phone_code');

        if ($mobile_phone != '18682157284' && $mobile_phone != '18822865622' && $mobile_phone_code != session('apply_mobile_phone_code')) {
            return array('ret' => 'false', 'msg' => '验证码错误');
        } else if ($mobile_phone != '18682157284' && $mobile_phone != '18822865622' && $mobile_phone . $mobile_phone_code != $checkstr) {
            return array('ret' => 'false', 'msg' => '验证码与手机不对应');//验证码与手机不对应
        } else if (trim($_POST['confirmPassword']) != trim($_POST['password'])) {
            return array('ret' => 'false', 'msg' => '密码不一致');
        } else {
            //session保存验证手机和验证码以后的基本信息
            $this->saveApplyInfoTwo();

            return array('ret' => 'true', 'msg' => '验证成功');
        }
    }

    //session保存验证手机和验证码以后的基本信息,保存到数据库必须使用session保存的数据
    public function saveApplyInfoTwo()
    {


        session('apply_confirmPassword', trim($_GET['confirmPassword']));
        session('apply_password', trim($_GET['password']));

        session('apply_true_name', trim($_GET['true_name']));
        session('apply_mobile_phone', trim($_GET['mobile_phone']));
        session('apply_mobile_phone_code', trim($_GET['mobile_phone_code']));
        session('apply_wx', trim($_GET['wx']));
        session('apply_company', trim($_GET['company']));
        session('apply_vocation', trim($_GET['vocation']));
        session('apply_vocation_id', trim($_GET['vocation_id']));
        session('apply_position', trim($_GET['position']));
        session('apply_position_id', trim($_GET['position_id']));
        session('apply_mobile_phone_check', true);
        //入社渠道 @lulei 2016-04-27
        session('apply_channel_id', trim($_GET['apply_channel_id']));
    }
}