<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//登录需要的字段
class HtmlLoginInputModel extends RelationModel {
   
	//查询当前需要的字段
	public function getLoginInput(){
		
		$field = 'name_and_id';
		$where['is_show'] = 1;
		$order = 'sort desc,id desc';
		$data = $this->field($field)->where($where)->order($order)->select();
		if(!$data){
			return false;
		}
		$arr = array();
		foreach($data as $k=>$v){
			$arr[] = $v['name_and_id'];
		}
		return $arr;
		
	}
	
   
   
   

   
}