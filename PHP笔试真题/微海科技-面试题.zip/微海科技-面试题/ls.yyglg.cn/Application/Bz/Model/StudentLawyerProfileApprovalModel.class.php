<?php
namespace Bz\Model;

use Think\Model\RelationModel;

class StudentLawyerProfileApprovalModel extends RelationModel
{

    //是否存在正在审批的
    public function existsApprovaling()
    {
        $mobile_phone =session('student_mobile_phone');

        $where['mobile_phone'] = $mobile_phone;
        $where['approval_status'] = "待审批";
        $existed = $this->where($where)->find();

        if (empty($existed)) {

            return false;
        } else {

            return true;
        }
 
    }
}