<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//用户升级配置
class SystemOnlineToScenceSetupModel extends RelationModel {
   
	//查询一条信息
	public function getOne($where=1,$field='*'){
		
		return $this->field($field)->where($where)->find();
		
	}
	
	//自减剩余铁杆社员名额
	public function decNumber(){
		$where['id'] = 1;
		return $this->where($where)->setDec('number');
	}
   
   
}