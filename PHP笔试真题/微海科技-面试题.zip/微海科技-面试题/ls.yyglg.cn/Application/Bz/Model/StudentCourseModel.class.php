<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//学生报名的课程
class StudentCourseModel extends RelationModel
{
	protected $_link = array(//连表
		//学院
		'school' => array(
			'mapping_type' => self::BELONGS_TO,
			'class_name' => 'School',
			'foreign_key' => 'school_id',
			'mapping_fields' => 'school_name',
			'as_fields' => 'school_name:school_name',
		),
		//课程
		'school_course' => array(
			'mapping_type' => self::BELONGS_TO,
			'class_name' => 'School_course',
			'foreign_key' => 'school_course_id',
			'mapping_fields' => 'name',
			'as_fields' => 'name:course_name',
		),
	);

	//查询该学生对某个课程的报名状态
	public function getStatus($course_id, $student_id = 0)
	{
		$where['school_course_id'] = $course_id;
		$where['student_id'] = $student_id;
		$field = 'status,see_type';
		$data = $this->field($field)->where($where)->find();
		if (!$data) {
			return '0';
		}

		return $data;

	}

	//学生支付购买单场线下课程
	public function addOnePayCourse($student_id, $course_id, $money, $see_type = '现场')
	{
		$data['student_id'] = $student_id;
		$data['school_course_id'] = $course_id;
		$data['see_type'] = $see_type;
		$data['time'] = time();
		$data['auth_type'] = '购买';
		$data['auth_type_pay_money'] = $money;

		D()->startTrans();
		$id = D('student_course')->add($data);
		if ($see_type === '现场') {
			$ret = D('SchoolCourse')->setIncUseNumber($course_id);
		} else {
			$ret = true;
		}

		if ($id && $ret) {
			D()->commit();
			return true;
		} else {
			D()->rollback();
			return false;
		}
	}

	//学生报名课程
	public function addOne($student_id, $course_id, $see_type)
	{
		$place_id = 0;
		return $this->user_sign_up_one_course($student_id, $course_id, $place_id, $see_type);

	}

	/**
	 * user sign up one course
	 *
	 * @param $student_id
	 * @param $course_id
	 * @param $place_id
	 * @param $see_type
	 *
	 * @return array
	 */
	public function user_sign_up_one_course($student_id, $course_id, $place_id, $see_type)
	{
		//查询该学生是否已经报名过了，防止重复报名
		$countwhere['school_course_id'] = $course_id;
		if (!empty($place_id)) {
			$countwhere['activity_place_id'] = $place_id;
		}
		$countwhere['student_id'] = $student_id;

		$data = $this->field('status')->where($countwhere)->find();
		if (!$data) {
			$save['school_course_id'] = $course_id;
			$save['activity_place_id'] = $place_id;
			$save['see_type'] = $see_type;
			$save['student_id'] = $student_id;
			$save['time'] = time();

			//使用名额自增
			if ($see_type === '现场') {
				$ret = D('SchoolCourse')->setIncUseNumber($course_id);
			}

			if (!empty($place_id)) {
				$ret = M('activity_place')->where(array('id' => $place_id))->save(array('signed_number' => array('exp', 'signed_number+1')));
			}
		} //已经请假了则删除原报名新建报名
		else if ($data['status'] == '2') {
			$this->where($countwhere)->delete();
			$save['school_course_id'] = $course_id;
			$save['activity_place_id'] = $place_id;
			$save['see_type'] = $see_type;
			$save['student_id'] = $student_id;
			$save['time'] = time();

			//使用名额自增
			if ($see_type === '现场') {
				$ret = D('SchoolCourse')->setIncUseNumber($course_id);
			}
			if (!empty($place_id)) {
				$ret = M('activity_place')->where(array('id' => $place_id))->save(array('signed_number' => array('exp', 'signed_number+1')));
			}
		} else {
			return array('ret' => 'true', ',msg' => '已报名');
		}

		$id = $this->add($save);

		if ($id) {
			// 发送短信
			$userdata = M('student')->find($student_id);
			$coursedata = M('school_course')->find($course_id);

			$str_begin_time = date('Y年m月d日', $coursedata['begin_time']);
			if ($see_type === '现场') {
				$content = "亲爱的{$userdata['true_name']}，您已成功报名{$str_begin_time}{$coursedata['name']}{$coursedata['address']}主会场，请到".$this-> nameConfig['WECHAT_SERVICE_NAME']."右侧菜单查看报名状态或请假。";

				A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
			} else {
				$content = "亲爱的{$userdata['true_name']}，您已成功报名{$str_begin_time}{$coursedata['name']}直播课。";

				A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
			}

			return array('ret' => 'true', ',msg' => '报名成功', 'student_course_id' => $id);
		} else {
			return array('ret' => 'false2', ',msg' => '报名失败');
		}
	}

	/**
	 * 学生报名课程多个
	 *
	 * @param $student_id
	 * @param $course_id_str
	 * @param $mobile_phone
	 * @return array
	 */
	public function addMore($student_id, $course_id_str, $mobile_phone)
	{
		$course_id_arr = explode(',', $course_id_str);
		$num = 0;
		//学生报名方式，false则为还没入社
		$student_type = D('Student')->getStudentType($student_id);
		if (!$student_type) {
			return array('ret' => 'false1', 'msg' => '你还没入社');
		}

		$error_msg = '';

		$userdata = M('student')->find($student_id);
		$sms_contents = array();

		D()->startTrans();

		foreach ($course_id_arr as $k => $v) {
			$arrayD = explode('||', $v);
			//非法报名强制终止流程
			if ($student_type === '直播' && $arrayD[1] === '现场') {
				return array('ret' => 'false2', 'msg' => '你只能选择直播课程');
			}

			//查询该课程是否为正常可报名状态
			$school_course_data = M('school_course')->field('school_course_status,all_number,use_number,name,is_scene,is_online,black_list')->where(array('id' => $arrayD[0]))->find();
			$over_number = $school_course_data['all_number'] - $school_course_data['use_number'];
			//如果为现场则判断是否有名额
			if ($arrayD[1] === '现场') {
				//查看该用户是否存在于该课程黑名单中
				if ($this->isInBlackList($school_course_data['black_list'], $mobile_phone)) {
					$over_number_boolean = false;

					$error_msg .= "由于您之前未请假缺课，无法报名该课程，如有疑问请至“".$this-> nameConfig['WECHAT_SERVICE_NAME']."”咨询";

					\Think\Log::record('signupmorecouse ERR:' . "学生{$student_id},课程{$arrayD[1]} {$arrayD[1]} 之前未请假缺课，不能报名", 'ERR');
				} else {
					//查看该课程是否开启现场
					if (!$school_course_data['is_scene']) {
						$error_msg .= '课程"' . $school_course_data['name'] . '"暂未开启现场报名。';
						$over_number_boolean = false;

						\Think\Log::record('signupmorecouse ERR:' . "学生{$student_id},课程{$arrayD[1]} {$arrayD[1]} 暂未开启现场报名，不能报名", 'ERR');
					} else {
						if ($over_number > 0) {
							$over_number_boolean = true;
						} else {
							$error_msg .= '课程"' . $school_course_data['name'] . '"现场名额已被抢光。';
							$over_number_boolean = false;

							\Think\Log::record('signupmorecouse ERR:' . "学生{$student_id},课程{$arrayD[1]} {$arrayD[1]} 现场名额已被抢光，不能报名", 'ERR');
						}
					}
				}
			} else {
				//查看该课程是否开启直播
				if (!$school_course_data['is_online']) {
					$error_msg .= '课程"' . $school_course_data['name'] . '"暂未开启直播报名。';
					$over_number_boolean = false;

					\Think\Log::record('signupmorecouse ERR:' . "学生{$student_id},课程{$arrayD[1]} {$arrayD[1]} 暂未开启直播报名，不能报名", 'ERR');
				} else {
					$over_number_boolean = true;
				}
			}


			if ($school_course_data['school_course_status'] == '1' && $over_number_boolean) {
				//查询该学生是否已经报名过了，防止重复报名
				$countwhere['school_course_id'] = $arrayD[0];
				$countwhere['student_id'] = $student_id;
				$data = $this->field('status')->where($countwhere)->find();
				if ($data && $data['status'] != '2') {
					\Think\Log::record('signupmorecouse ERR:' . "学生{$student_id},课程{$arrayD[1]} {$arrayD[1]} 已报名，不能报名", 'ERR');

					continue;
				}

				if (!$data) {
					$save[$num]['school_course_id'] = $arrayD[0];
					$save[$num]['see_type'] = $arrayD[1];
					$save[$num]['student_id'] = $student_id;
					$save[$num]['pay_status'] = 1;
					$save[$num]['is_check'] = 1;
					$save[$num]['time'] = time();

					//使用名额自增
					if ($arrayD[1] === '现场') {
						$ret[$num] = D('SchoolCourse')->setIncUseNumber($arrayD[0]);
					}

					$num++;
				} //已经请假了则删除原报名新建报名
				else if ($data['status'] == '2') {
					$this->where($countwhere)->delete();
					$save[$num]['school_course_id'] = $arrayD[0];
					$save[$num]['see_type'] = $arrayD[1];
					$save[$num]['student_id'] = $student_id;
					$save[$num]['pay_status'] = 1;
					$save[$num]['is_check'] = 1;
					$save[$num]['time'] = time();
					//使用名额自增
					if ($arrayD[1] === '现场') {
						$ret[$num] = D('SchoolCourse')->setIncUseNumber($arrayD[0]);
					}

					$num++;
				}

				$coursedata = M('school_course')->find($arrayD[0]);

				$str_begin_time = date('Y年m月d日', $coursedata['begin_time']);
				if ($arrayD[1] === '现场') {
					$content = "亲爱的{$userdata['true_name']}，您已成功报名{$str_begin_time}{$coursedata['name']}{$coursedata['address']}主会场，请到".$this-> nameConfig['WECHAT_SERVICE_NAME']."右侧菜单查看报名状态或请假。";
				} else {
					$content = "亲爱的{$userdata['true_name']}，您已成功报名{$str_begin_time}{$coursedata['name']}直播课。";
				}
				$sms_contents[] = $content;
			} else {
				\Think\Log::record('signupmorecouse ERR:' . "学生{$student_id},课程{$arrayD[1]} {$arrayD[1]} 课程状态不对，不能报名", 'ERR');
			}
		}

		$ret1 = true;
		if (is_array($ret)) {
			foreach ($ret as $k => $v) {
				if (!$v) {
					$ret1 = false;
				}
			}
		}

		$ret2 = D('StudentCourse')->addAll($save);
		if ($ret1 && $ret2) {
			D()->commit();

			// 发送短信
			foreach ($sms_contents as $value) {
				A('Public')->sendShortMsg($userdata['mobile_phone'], $value);
			}

			if ($error_msg) {
				return array('ret' => 'false3', 'msg' => $error_msg);
			} else {
				return array('ret' => 'true', 'msg' => '全部报名成功');
			}
		} else {
			D()->rollback();
			if ($error_msg) {
				return array('ret' => 'false3', 'msg' => $error_msg);
			} else {
				return array('ret' => 'false4', 'msg' => '添加失败');
			}
		}

	}

	//学生课程请假
	public function delOne($student_id, $course_id, $msg = '')
	{

		$where['school_course_id'] = $course_id;
		$where['student_id'] = $student_id;
		//查询学生该课程是直播还是现场
		$see_type = $this->where($where)->getField('see_type');

		$data['status'] = 2;
		$data['update_time'] = time();
		$data['msg'] = $msg;
		D()->startTrans();
		$ret1 = D('StudentCourse')->where($where)->save($data);
		//如果为现场则自减已使用的座位
		if ($see_type == '现场') {
			$ret2 = D('SchoolCourse')->setDecUseNumber($course_id);
		} else {
			$ret2 = true;
		}
		if ($ret1 && $ret2) {
			D()->commit();
			return true;
		} else {
			D()->rollback();
			return false;
		}

	}


	//学生查询自己报名的课程
	public function getAllBySchool($student_id = 0, $begin = 5, $number = 100, $where = false)
	{
		//关联
		$field = 's.id as school_id,s.school_name';
		$order = 's.sort desc,s.id desc';
		$group = 'school_id';
		$limit = "$begin,$number";
		$join = 'as t left join ' . C('DB_PREFIX') . 'school_course as sc on t.school_course_id = sc.id left join ' . C('DB_PREFIX') . 'school as s on s.id = sc.school_id ';
		$where['t.student_id'] = $student_id;
		$data = $this->field($field)->join($join)->where($where)->group($group)->order($order)->limit($limit)->select();
		if (!$data) {
			return array('ret' => 'false', 'msg' => '没有数据');
		}
		foreach ($data as $k => $v) {
			//查询该学院我预报名的课程
			$data[$k]['course_list'] = $this->getOneSchoolCourse($data[$k]['school_id'], $student_id);
			unset($data[$k]['school_id']);
			foreach ($data[$k]['course_list'] as $kk => $vv) {
				//组合开始时间和结束时间
				$data[$k]['course_list'][$kk]['day'] = D('SchoolCourse')->setBeginAndEndTimeToDay($vv['begin_time'], $vv['end_time']);
				unset($data[$k]['course_list'][$kk]['begin_time']);
				unset($data[$k]['course_list'][$kk]['end_time']);
				//查询该课程的老师
				$data[$k]['course_list'][$kk]['teacher_list'] = D('SchoolCourseTeacher')->getTeacherByCourseId($vv['id']);
			}
		}

		return array('ret' => 'true', 'data' => $data);

	}

	/**
	 * 根据日期查询自己报名的课程
	 *
	 * @param int $student_id
	 * @param int $begin
	 * @param int $number
	 * @return array
	 */
	public function getAllByTime($student_id = 0, $begin = 5, $number = 100)
	{
		$field = 'FROM_UNIXTIME(begin_time,"%Y-%m")as months,FROM_UNIXTIME(begin_time,"%m")as months2,begin_time';
		$order = 'months asc';
		$group = 'months';
		$limit = "$begin,$number";
		$join = 'as t left join ' . C('DB_PREFIX') . 'school_course as sc on t.school_course_id = sc.id left join ' . C('DB_PREFIX') . 'school as s on s.id = sc.school_id ';
		$where1['t.student_id'] = $student_id;
		$data = $this->field($field)->join($join)->where($where1)->group($group)->order($order)->limit($limit)->select();
		if (!$data) {
			return array('ret' => 'false', 'msg' => '没有数据');
		}

		foreach ($data as $k => $v) {
			//查询该月的
			$lastandfirst = D('SchoolCourse')->mFristAndLastDay(date('Y', $v['begin_time']), date('m', $v['begin_time']));
			$where['st_c.student_id'] = $student_id;
			$where['sc_c.begin_time'] = array('between', array($lastandfirst['firstday'], $lastandfirst['lastday']));
			$data[$k]['list'] = $this->getAllOrderByTime($where);
			$data[$k]['months2'] = $this->returnMonths($v['months2']);
		}
		return array('ret' => 'true', 'data' => $data);

	}


	//根据条件查询 根据时间排序
	public function getAllOrderByTime($where)
	{
		$join = 'as st_c left join ' . C('DB_PREFIX') . 'school_course as sc_c on st_c.school_course_id = sc_c.id ';
		$join .= 'left join ' . C('DB_PREFIX') . 'school as sc on sc_c.school_id = sc.id';
		$field = 'sc_c.id,sc_c.name,sc_c.address,sc_c.school_id,sc_c.begin_time,sc_c.end_time,st_c.student_id,sc_c.school_course_status,st_c.status as student_status,st_c.see_type as student_see_type,sc.school_name';
		$order = 'sc_c.begin_time asc';
		$data = $this->field($field)->join($join)->where($where)->order($order)->select();
		foreach ($data as $k => $v) {
			//组合开始时间和结束时间
			$data[$k]['day'] = D('school_course')->setBeginAndEndTimeToDay($v['begin_time'], $v['end_time']);
			unset($data[$k]['begin_time']);
			unset($data[$k]['end_time']);
			//查询该课程的老师
			$data[$k]['teacher_list'] = D('SchoolCourseTeacher')->getTeacherByCourseId($v['id']);
		}

		return $data;
	}

	//查询某个学院的我报名的课程
	public function getOneSchoolCourse($school_id, $student_id)
	{
		$where['sc.school_id'] = $school_id;
		$where['t.student_id'] = $student_id;
		$order = 'sc.sort desc,sc.id desc';
		$field = 'sc.id,sc.name,sc.address,sc.begin_time,sc.end_time,sc.school_id,sc.school_course_status,t.status as student_status';
		$join = 'as t left join ' . C('DB_PREFIX') . 'school_course as sc on t.school_course_id = sc.id left join ' . C('DB_PREFIX') . 'school as s on s.id = sc.school_id ';
		return $this->field($field)->join($join)->where($where)->order($order)->select();
	}

	//阿拉伯数字的月份转为一月二月等
	function returnMonths($months)
	{

		switch ($months) {
			case 1:
				return '一';
			case 2:
				return '二';
			case 3:
				return '三';
			case 4:
				return '四';
			case 5:
				return '五';
			case 6:
				return '六';
			case 7:
				return '七';
			case 8:
				return '八';
			case 9:
				return '九';
			case 10:
				return '十';
			case 11:
				return '十一';
			case 12:
				return '十二';
		}

	}

	//查询该手机号是否有报名该课程
	public function isHave($course_id, $mobile_phone)
	{
		$where['t.school_course_id'] = $course_id;
		$where['st.mobile_phone'] = $mobile_phone;

		$join = 'as t inner join ' . C('DB_PREFIX') . 'student as st on t.student_id = st.id';

		return $this->join($join)->where($where)->count();
	}

	/**
	 * 查询学生是否报名了该课程
	 *
	 * @param $student_id
	 * @param $course_id
	 */
	public function is_sign_up($student_id, $course_id) {
		$cond = array('student_id' => $student_id, 'school_course_id' => $course_id, 'status' => 1);
		return $this->where($cond)->getField('id');
	}

	//查询该手机号是否存在于该课程的黑名单中
	public function isInBlackList($black_list_str, $mobile_phone)
	{
		if (strpos($black_list_str, $mobile_phone) !== FALSE) {
			//存在黑名单中
			return true;
		} else {
			return false;
		}
	}

	//查询某个用户是否为某个课程的打赏VIP
	public function isRewardVip($course_id, $student_id)
	{
		$where['school_course_id'] = $course_id;
		$where['student_id'] = $student_id;
		return $this->where($where)->getField('is_reward_vip');
	}
}