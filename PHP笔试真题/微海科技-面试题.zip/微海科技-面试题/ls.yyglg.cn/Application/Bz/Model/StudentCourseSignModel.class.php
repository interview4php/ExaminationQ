<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//签到
class StudentCourseSignModel extends RelationModel
{
    /**
     * 签到处理
     *
     * @para string $student_id 学生ID
     * @para string $course_id 课程ID
     * @para string $student_mobile_phone 学生的填写的手机号
     */
    public function studentSign($student_id, $course_id, $student_mobile_phone)
    {
        if ($student_id==-1)
        {
            //-1标记为非会员报名来签到

            //进到这里，说明已经报名了，故不再验证是否报名了课程

            //查询是否已经签名了
            if ($this->isSignByMobile($student_id, $course_id,$student_mobile_phone)) {
                // 如果有座位，但未选座，要返回成功
                if (D('StudentCourseSeat')->isHaveByMobile($student_id, $course_id)) {
                    return array('ret' => 'false', 'msg' => '已签到');
                }

            }

            session('user_is_false_sign', 'yes' . $course_id . $student_id);
            return array('ret' => 'true', 'msg' => '验证成功');
        }else
        {
            //非-1为普通学生签到
            
            //查询该手机号是否报名了该课程
            if (!D('student_course')->is_sign_up($student_id, $course_id)) {
                return array('ret' => 'false', 'msg' => '未报名');
            }

            //查询是否已经签名了
            if ($this->isSign($student_id, $course_id)) {
                // 如果有座位，但未选座，要返回成功
                if (D('StudentCourseSeat')->isHave($student_id, $course_id)) {
                    return array('ret' => 'false', 'msg' => '已签到');
                }
            }

            session('user_is_false_sign', 'yes' . $course_id . $student_id);

            //验证成功，可以选座
            return array('ret' => 'true', 'msg' => '验证成功');
        }

    }

    //查看是否已经签名了
    public function isSignByMobile($student_id, $course_id,$mobile)
    {
        $where['course_id'] = $course_id;
        $where['student_id'] = $student_id;
        $where['mobile'] = $mobile;
        return $this->where($where)->count();
    }

    //查看是否已经签名了
    public function isSign($student_id, $course_id)
    {
        $where['course_id'] = $course_id;
        $where['student_id'] = $student_id;

        return $this->where($where)->count();
    }

    //新增签名（执行签名）
    public function createOne($student_id, $course_id)
    {
        $data['student_id'] = $student_id;
        $data['course_id'] = $course_id;
        $data['time'] = time();

        return $this->add($data);
    }
    public function createOneWithPlaceId($student_id, $course_id,$placeId)
    {
        $data['student_id'] = $student_id;
        $data['course_id'] = $course_id;
        $data['time'] = time();
        
         $data['activity_place_id'] = $placeId;
        return $this->add($data);
    }
    public function createOneWithPlaceIdMobile($student_id, $course_id,$placeId,$mobile)
    {
        $data['student_id'] = $student_id;
        $data['course_id'] = $course_id;
        $data['time'] = time();
        $data['mobile'] = $mobile;
        $data['activity_place_id'] = $placeId;
        return $this->add($data);
    }
    //获取学习记录
    public function getStudentStudyRecord($student_id,$limit)
    {

        $db_prefix = GetDbPrefix();

        $field = 'this.id,this.school_course_id,this.activity_place_id,this.status,this.see_type,course.name,
		course.begin_time,course.relate_course_id,course.is_can_false,course.video_status';
        // ,sign.time

        $join = 'as this inner join ' . $db_prefix . 'school_course as course on this.school_course_id = course.id';

        $where = array();

        $where['this.student_id'] = $student_id;

        $where['this.pay_status'] = '1';

        //视频回看状态的才是学习记录
       // $where['course.video_status'] = '4';


        $where['course.type'] = 1;


        $where['this.status'] = array('gt', 0);


      //  $where['this.see_type'] = array('neq', '其他');

        $order = 'course.begin_time desc';

        //学生报名的活动
        $student_course = D('student_course')->field($field)->join($join)->where($where)->order($order)->limit($limit)->select();


        if (!$student_course) {
            return $student_course;
        }

        $arr_rtn = array();


        $obj_sc_sign = M('student_course_sign');

        //报名记录
        // “X未签到”“√已签到”“ √已报名”“ √已请假”
        foreach ($student_course as $k => $v) {


            //学生签到的时间
            $v['time'] = $obj_sc_sign->where(array('student_id' => $student_id, 'course_id' => $v['school_course_id']))->getField('time');

            //请假的不计入其中
            if (2 == $v['status']) {
                continue;
            }

            $ifSigned=false;
            if ($v['time']) {
                //如果学生签到了
                $ifSigned=true;
            }

            $has_repeat = false;
            foreach ($arr_rtn as $key1 => $value1) {
                if (trim($student_course[$k]['name']) == trim($value1['name'])
                    || $v['school_course_id'] == $value1['school_course_id']
                    || $v['relate_course_id'] == $value1['school_course_id']
                ) {
                    $has_repeat = true;
                    break;
                }
            }

            if ($has_repeat||(!$ifSigned)) {
                continue;
            } else {

                $arr_rtn[] = $student_course[$k];
            }
        }

  
        return $arr_rtn;
    }

    /**
     * 签到记录
     *
     * @param $student_id
     * @param $limit
     * @return mixed
     */
    public function getStudentCourseSignRecord($student_id, $limit)
    {

        $db_prefix = GetDbPrefix();

        $field = 'this.id,this.school_course_id,this.activity_place_id,this.status,this.see_type,course.name,
		course.begin_time,course.end_time,course.relate_course_id,course.is_can_false';
        // ,sign.time

        $join = 'as this inner join ' . $db_prefix . 'school_course as course on this.school_course_id = course.id';
        //$join .= ' left join ' . $db_prefix . 'student_course_sign as sign on (this.student_id = sign.student_id and this.school_course_id = sign.course_id)';

        $where = array();
        $where['this.student_id'] = $student_id;
        $where['this.pay_status'] = '1';
        $where['course.type'] = 1;//1是活动
        $where['this.status'] = array('gt', 0);
        //$where['this.see_type'] = array('neq', '其他');

        $order = 'course.begin_time desc';

        //学生报名的活动
        $student_course = D('student_course')->field($field)->join($join)->where($where)->order($order)->limit($limit)->select();


        if (!$student_course) {
            return false;
        }

        $arr_rtn = array();

        $obj_act_place = M('activity_place');
        $obj_sc_sign = M('student_course_sign');

        //报名记录
        // “X未签到”“√已签到”“ √已报名”“ √已请假”
        foreach ($student_course as $k => $v) {

         
            if ($v['activity_place_id'] > 0) {

                $act_place_info = $obj_act_place->field('name , type ')->where(array('id' => $v['activity_place_id']))->find();
                $act_place_name=$act_place_info['name'];

                if (!empty($act_place_name)) {
                    $student_course[$k]['name'] .= "($act_place_name)";
                }
            } else {
                if ($v['see_type'] == '现场') {
                    $student_course[$k]['name'] .= "(主会场)";
                } else {
                    $student_course[$k]['name'] .= "(直播)";
                }
            }

            //学生签到的时间
            $v['time'] = $obj_sc_sign->where(array('student_id' => $student_id, 'course_id' => $v['school_course_id']))->getField('time');

            if (2 == $v['status']) {
                $student_course[$k]['act_status'] = '4';  // 已请假
            }
            $student_course[$k]['is_sign'] = '0';//默认为灰色的

            if ($v['time']) {
                //如果学生签到了
                $student_course[$k]['is_sign'] = '1';  // 已签到的小圆球

                $student_course[$k]['time_year'] = date('Y年m月d日', $v['time']);
                $student_course[$k]['time_hour'] = date('H时i分', $v['time']);


//                if ((date('H', $v['time'])) >= 14) {
//                    $student_course[$k]['time_type'] = '下午';
//                } else if ((date('H', $v['time'])) >= 12) {
//                    $student_course[$k]['time_type'] = '中午';
//                } else if ((date('H', $v['time'])) >= 6) {
//                    $student_course[$k]['time_type'] = '上午';
//                } else {
//                    $student_course[$k]['time_type'] = '凌晨';
//                }

                $student_course[$k]['act_status'] = '2';

            } else {
                //如果学生没签到
                $student_course[$k]['is_sign'] = '0'; // // 已签到的小圆球显示为灰色

                $student_course[$k]['time_year'] = '';
                $student_course[$k]['time_hour'] = '';
                $student_course[$k]['time_type'] = '';


                if (time() > $v['begin_time']) {
                    //课程已经开始了
                    if (strpos($student_course[$k]['name'], '(直播)')) {
                        $student_course[$k]['act_status'] = '5';  // 直播不显示未签到
                    } else {
                        $student_course[$k]['act_status'] = '1';  // 未签到
                    }

                } else {

                    //课程还没开始
                    $student_course[$k]['act_status'] = '3';  // 已报名（看是不是能够请假）
                }

                $student_course[$k]['is_sign'] = '0';  // 未签到
            }
            $has_repeat = false;
            foreach ($arr_rtn as $key1 => $value1) {
                if (trim($student_course[$k]['name']) == trim($value1['name'])
                    || $v['school_course_id'] == $value1['school_course_id']
                    || $v['relate_course_id'] == $value1['school_course_id']
                ) {
                    $has_repeat = true;
                    break;
                }
            }

            if ($has_repeat) {
                continue;
            } else {
                if ($act_place_info['type'] != 4)
                {
                    $arr_rtn[] = $student_course[$k];
                }


            }
        }
//        var_dump($arr_rtn);
        return $arr_rtn;
    }
}