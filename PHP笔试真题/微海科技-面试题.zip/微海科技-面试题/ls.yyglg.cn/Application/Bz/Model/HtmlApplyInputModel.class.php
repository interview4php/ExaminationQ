<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//大学申请需要的字段查询
class HtmlApplyInputModel extends RelationModel {
   
	//查询大学申请需要的字段
	public function getApplySchoolNeedField(){
	
		$field = 'wx,vocation,position';
		return $this->field($field)->order('apply_html_id desc')->find();
	
	}

   
}