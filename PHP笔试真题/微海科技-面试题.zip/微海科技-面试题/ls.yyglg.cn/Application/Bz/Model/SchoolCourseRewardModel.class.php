<?php
namespace Bz\Model;

use Think\Model\RelationModel;

//打赏列表
class SchoolCourseRewardModel extends RelationModel
{


	//创建打赏记录并类型加被打赏对象的打赏次数和金额
	public function rewardTeacherSuccess($data, $student_data, $payType)
	{
		$true_name = D('reward_student')->getTrueName($data['course_id'],
			$student_data['mobile_phone']);
		if (!empty($true_name)) {
			$student_data['true_name'] = $true_name;
		}

		D()->startTrans();

		//创建一条打赏信息
		$ret1 = D('SchoolCourseReward')->createOne($data, $student_data, $payType);
		//累加用户的打赏总金额
		$ret2 = D('StudentDataStatistics')->incSCount('reward_money_count', $student_data['id'], $data['money']);
		//累加用户的打赏总次数
		$ret3 = D('StudentDataStatistics')->incSCount('reward_count', $student_data['id'], 1);
		//累加被打赏对象的金额
		$ret4 = D('SystemRewardTeacher')->incSCount('money', $data['reward_teacher_id'], $data['money']);
		//累加被打赏对象的次数
		$ret5 = D('SystemRewardTeacher')->incSCount('count', $data['reward_teacher_id'], 1);

		//echo  "ret1=$ret1,ret2=$ret2,ret3=$ret3,ret4=$ret4,ret5=$ret5";
		if ($ret1 && $ret2 && $ret3 && $ret4 && $ret5) {
			D()->commit();
			return $ret1;
		} else {
			D()->rollback();
			return false;
		}
	}

	//创建一条打赏信息
	public function createOne($array, $student_data, $payType)
	{
		$data['course_id'] = $array['course_id'];
		$data['system_reward_id'] = $array['reward_id'];
		$data['teacher_id'] = $array['teacher_id'];
		$data['student_id'] = $array['student_id'];
		$data['price'] = $array['money'];
		$data['static_head_img'] = $array['static_img'];//session("headImgUrl"); //$student_data['student_head_img'];

		$data['static_true_name'] = $student_data['true_name'];
		$data['static_mobile_phone'] = $student_data['mobile_phone'];
		$data['pay_type'] = $payType;
		$data['static_msg'] = $array['static_msg'];
		$data['time'] = time();

		return $this->add($data);
	}

	//查询某个用户的（根据ID）的战绩
	public function getOneStudentCount($student_id, $course_id)
	{
		//查询总排名
		$data['all_order'] = chen_is_empty($this->getOneStudentAllCountOrder($student_id), 0);
		$data['all_money'] = chen_is_empty($this->getOneStudentAllCountMoney($student_id), 0);
		$data['one_money'] = chen_is_empty($this->getOneStudentOneCountMoney($student_id, $course_id), 0);
		$data['one_order'] = chen_is_empty($this->getOneStudentOneCountOrder($student_id, $course_id), 0);
		return $data;
	}

	//查询所有学生的总打赏排名
	public function getAllStudentAllCourseRewardOrder()
	{
		$field = 'student_id,sum(price) as all_money';
		$order = 'all_money desc';
		$group = 'student_id';
		return $this->field($field)->group($group)->order($order)->select();
	}

	//查询所有学生的某个课程的最后一轮的打赏排名
	public function getAllStudentOneCourseRewardOrder($course_id)
	{
		$field = 'student_id,sum(price) as all_money';
		$order = 'all_money desc';
		$group = 'student_id';
		$where['course_id'] = $course_id;
		$where['teacher_id'] = $this->getCourseLastRewardObject($course_id);
		return $this->field($field)->where($where)->group($group)->order($order)->select();
	}

	//查询某个学生的总打赏总排名
	public function getOneStudentAllCountOrder($student_id)
	{
		$data = $this->getAllStudentAllCourseRewardOrder();
		if (!$data) {
			return false;
		}
		foreach ($data as $k => $v) {
			if ($v['student_id'] == $student_id) {
				return $k + 1;
			}
		}
		return false;
	}

	//查询某个学生的某个课程的最后一轮的打赏排名
	public function getOneStudentOneCountOrder($student_id, $course_id)
	{
		$data = $this->getAllStudentOneCourseRewardOrder($course_id);
		if (!$data) {
			return false;
		}
//		var_dump($data);
//		var_dump($student_id);

		foreach ($data as $k => $v) {
			if ($v['student_id'] == $student_id) {
				return $k + 1;
			}
		}
		return false;
	}

	//查询某个学生的总打赏金额
	public function getOneStudentAllCountMoney($student_id)
	{
		$where['student_id'] = $student_id;
		return $this->where($where)->getField('sum(price)');
	}

	//查询某个学生的本轮打赏金额（最新轮）
	public function getOneStudentOneCountMoney($student_id, $course_id)
	{
		$lastObject = $this->getCourseLastRewardObject($course_id);
		$where['teacher_id'] = $lastObject;
		$where['student_id'] = $student_id;
		$where['course_id'] = $course_id;
		return $this->where($where)->getField('sum(price)');
	}

	//查询某个课程最后一轮打赏的老师
	public function getCourseLastRewardObject($course_id)
	{
		$where['course_id'] = $course_id;
		$where['status'] = 1;
		return M('system_reward_teacher')->where($where)->getField('teacher_id');
	}

	//查询打赏排名前十的学生信息
	public function getOneObjectRewardStudentInfo($course_id)
	{
		//分别是名字，头像，描述，学生id，
		$field = 'static_true_name,static_head_img,static_msg,student_id,sum(price) as all_money';
		$order = 'all_money desc';
		$group = 'student_id';
		$where['course_id'] = $course_id;
		$where['teacher_id'] = $this->getCourseLastRewardObject($course_id);
		return $this->field($field)->where($where)->group($group)->order($order)->limit(10)->select();
	}

	public function getOneObjectRewardStudentInfoNoGroup($course_id)
	{
		//分别是名字，头像，描述，学生id，打赏人民币
		$field = 'static_true_name,static_head_img,static_msg,student_id,price';
		$order = 'price desc';
		//$group = 'student_id'; //salty 2016-06-27 22:40:44 不做groupby
		$where['course_id'] = $course_id;
		//$where['teacher_id'] = $this->getCourseLastRewardObject($course_id);  //salty 不分老师，显示所有这个课程的打赏
		return $this->field($field)->where($where)->order($order)->limit(10)->select();
	}

}