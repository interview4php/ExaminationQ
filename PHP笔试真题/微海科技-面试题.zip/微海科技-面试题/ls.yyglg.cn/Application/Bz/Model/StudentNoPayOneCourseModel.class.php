<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//单场课程购买待支付
class StudentNoPayOneCourseModel extends RelationModel {
	
	
	//增加一条信息
	public function createOne($course_id,$coursedata,$student_id){
	
		$data['course_id'] 	= $course_id;
		$data['student_id'] = $student_id;
		$data['time']		= time();
		
		return $this->add($data);
		
	}

	//查询一条信息
	public function getOne($id){
		$where['id'] = $id;
		return $this->where($where)->find();
	}
	
	//删除一条数据
	public function deleteOne($id){
		if(!$id){
			return false;
		}
		$where['id'] = $id;
		return $this->where($where)->delete();
	}
	
}