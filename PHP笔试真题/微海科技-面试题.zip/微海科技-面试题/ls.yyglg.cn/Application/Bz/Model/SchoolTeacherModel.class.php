<?php
namespace Bz\Model;
use Think\Model\RelationModel;
//老师信息
class SchoolTeacherModel extends RelationModel {
   
	//查询一条老师对象
	public function getOne($id,$field='*'){
		$where['id'] = $id;
		return $this->field($field)->where($where)->find();
	}
   

   
}