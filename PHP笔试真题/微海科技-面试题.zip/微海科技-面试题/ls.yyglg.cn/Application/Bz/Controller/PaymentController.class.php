<?php
namespace Bz\Controller;

use Think\Controller;

class PaymentController extends Controller
{
	//升级支付成功后的显示页
	public function studentUpgradeSuccess()
	{
		$this->assign('url', '/Baozhu/ActivityCenter');
		
		$this->display('Student/studentUpgradeSuccess');
	}
}