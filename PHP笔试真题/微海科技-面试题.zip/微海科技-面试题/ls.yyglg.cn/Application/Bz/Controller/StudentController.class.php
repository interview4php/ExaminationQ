<?php
namespace Bz\Controller;

use Think\Controller;

//用户中心
class StudentController extends ExtendController
{

    //用户主页
    public function index()
    {
        //$this->redirect('/Bz/UserCenter/index');
$wxBindId=session('account_binding_wxid');
        if (is_weixin()) {
            if (empty($wxBindId)) {
                $this->redirect('/Bz/WxBinding/index');
            }
        }

        $student_id = session('student_id');
        if (empty($student_id)) {
            $this->redirect('/Baozhu/Login/index');
        }

        session('renew_student_id', $student_id);

        //查询学生详细信息
        $student_info = D('student')->getStudentInfo($student_id);
        if (empty($student_info)) {
            session('student_id', null);

            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

            $this->redirect('/Bz/School/index');
        }

        if (empty($student_info['account_binding_wxid'])) {
            $this->redirect('/Bz/WxBinding/index');
        }

        $this->assign('student', $student_info);
        $limit = "0,20";

        $data = D('StudentCourseSign')->getStudentCourseSignRecord(session('student_id'), $limit);

        $this->assign('data', $data);


        $this->display('index');
    }

    /**
     * 用户详细资料
     */
    public function studentInfo()
    {

        //查询学生详细信息
        $student_data = D('student')->getStudentInfo(session('student_id'));

        //查询职位标题
        $student_data['position_name'] = D('student_position')->getTitle($student_data['company_position_id']);
        //查询行业标题
        $student_data['vocation_name'] = D('student_vocation')->getTitle($student_data['company_vocation_id']);


        if (empty($student_data['wx_province_name'])) {
            //查询省
            $student_data['province_name'] = D('system_city_list')->getTitle($student_data['student_province_id']);
        } else {
            //查询省
            $student_data['province_name'] = $student_data['wx_province_name'];
        }

        if (empty($student_data['wx_city_name'])) {
            //查询市
            $student_data['city_name'] = D('system_city_list')->getTitle($student_data['student_city_id']);
        } else {
            //查询市
            $student_data['city_name'] = $student_data['wx_city_name'];
        }


        D('student')->SetOnlineTimeStr($student_data);


        $this->assign('student', $student_data);


        if (D("student_lawyer_profile_approval")->existsApprovaling()) {

            $this->assign('student_authenticated_approving', "1");


        } else {
            $this->assign('student_authenticated_approving', "0");
        }


        $this->display('studentInfo');
    }


    /**
     * 用户续费
     * salty 2016-07-24 15:37:51 改为升级续费
     */
    public function studentRenew()
    {
        //学生详细信息
        $student_id = $this->renew_student_id;
        if (empty($student_id)) {

        }
        $student_info = M('student')->find($student_id);

        if (empty($student_info) || empty($student_info['school_student_number'])) {
            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

            $this->redirect('/Bz/School/index');
        }

        if ('1' == $student_info['is_disable']) {
            $this->redirect("/Bz/Show/defaultError/errorCode/account_forbidden");
        }

        if (empty($student_info['end_time']) || $student_info['end_time'] < time()) {
            $apply_type_id = -1;
        } else {
            $apply_type_id = $student_info['apply_type_id'];
        }

        //$apply_type_id -1是临时会员，1是线下，2是线上
        $applyType = D('StudentApplyType')->getOneData($apply_type_id);

        //查询入社模式
        $this->assign('applyType', $applyType);

        $this->display('studentRenew');
    }

    /**
     * 选择用户续费支付方式
     *
     */
    public function studentRenewSelectPayType()
    {
        $apply_type_id = I('post.id');
        $apply_type_count = intval(I('post.id_count'));

        //查询该入社方式是否存在
        $ret = D('StudentApplyType')->where(array('student_apply_type_id' => $apply_type_id))->find();
        if (!$ret) {
            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/StudentRenew/studentRenew', 'ERR');
            $this->redirect('/Bz/StudentRenew/studentRenew');
        }

        if (empty($this->renew_student_id)) {
            $this->redirect('/Bz/StudentRenew/studentRenew');
            exit();
        }

        //学生详细信息
        $student_data = M('student')->find($this->renew_student_id);

        //技术金额
        $money = $ret['student_apply_type_price'] * $apply_type_count;

        if ('18612248383' == $student_data['mobile_phone'] || '18682032428' == $student_data['mobile_phone']) {
            //if ('13560455957' == $student_data['mobile_phone']) {
            $money = 0.01;
        }

        $this->assign('money', $money);

        //保存续费交费信息
        if (!D('student_no_pay_renew')->createOne($student_data['id'], $apply_type_id, $apply_type_count, $money)) {
            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/StudentRenew/studentRenew', 'ERR');

            $this->redirect('/Bz/StudentRenew/studentRenew');
        }

        //查询支付方式
        $payType = D('StudentPayType')->getSelectData(false);
        foreach ($payType as $k => $v) {
            if ($v['student_pay_type_id'] == '1') {
                $payType[$k]['student_pay_type_href'] = '/Bz/WxPay/payStudentRenew';
            } elseif ($v['student_pay_type_id'] == '2') {
                $pay_id = session('pay_id');
                $pay_money = session('pay_money');
                $payType[$k]['student_pay_type_href'] = "/Bz/Alipay/pay/type/3/pay_id/{$pay_id}/pay_money/{$pay_money}";
            }
        }

        $this->assign('payType', $payType);

        $this->display('studentRenewSelectPayType');
    }

    /**
     * 我的课表
     */
    public function getCourseSignRecord()
    {
        $begin = I('get.begin');
        $begin += 0;
        $number = 20;
        $limit = "$begin,$number";

        $data = D('StudentCourseSign')->getStudentCourseSignRecord(session('student_id'), $limit);
        if ($data) {
            $this->ajaxReturn(array('ret' => 'true', 'list' => $data, 'begin' => $begin + $number));
        } else {
            $this->ajaxReturn(array('ret' => 'false'));
        }
    }


    //服务号的铁杆升级链接
    public function upgradeStudentClass()
    {


        //未登录则跳转到登录
        $student_id = session('student_id');
        if (empty($student_id)) {
            $this->redirect('/Baozhu/Login/index');
        }

        //查询学生详细信息, 非会员跳转到入社
        $student_info = D('student')->getStudentInfo($student_id);
        if (empty($student_info)) {
            session('student_id', null);
            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');
            $this->redirect('/Bz/School/index');
        }

//        //未绑定则跳转到绑定页面
//        if (empty($student_info['account_binding_wxid'])) {
//            cookie('baozhu_last_url', \get_cur_url());
//            $this->redirect('/Bz/WxBinding/index');
//        }

        //如果会员有效期过期则不支持升级
        if ($student_info['end_time'] < time()) {
            $errorMsg = urlencode("对不起！您的会员有效期已失效，您可在个人中心续费即可。");
            $this->redirect("/Bz/Show/show_error/error_msg/{$errorMsg}");
        }

        //如果会员有效期在一年以上则不支持升级
        if ($student_info['end_time'] > time() + 31536000) {
            $errorMsg = urlencode("对不起！您的社员有效期在一年以上，暂不支持系统升级，请联系管理员！");
            $this->redirect("/Bz/Show/show_error/error_msg/{$errorMsg}");
        }

        //如果已经是铁杆则提示无需升级
        if ($student_info['apply_type_id'] == 2) {
            $errorMsg = urlencode("对不起！您已是抱柱网铁杆社员，无需升级！");
            $this->redirect("/Bz/Show/show_error/error_msg/{$errorMsg}");
        }

        $this->display('tieganWenDa');
    }


    /**
     * 学生升级为铁杆会员
     */
    public function studentUpgradeSelectPayType()
    {
        $student_data = D('student')->getRepeat(session('student_mobile_phone'));
        if (!$student_data) {
            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

            $this->redirect('/Bz/School/index');
        }

        //查询是否可以升级和升级需要的费用
        $retMoneyData = D('student')->getUpgradeMoney($student_data['end_time']);
        if ($retMoneyData['ret'] == 'false') {
            $this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/' . $retMoneyData['msg']);
        }

        if ('18682157284' == $student_data['mobile_phone'] || '18682032428' == $student_data['mobile_phone']) {
            $retMoneyData['money'] = 0.01;
        }

        //查询支付方式
        $payType = D('StudentPayType')->getSelectData(false);
        foreach ($payType as $k => $v) {
            if ($v['student_pay_type_id'] == '1') {
                $payType[$k]['student_pay_type_href'] = '/Bz/WxPay/payStudentUpgrade';
            } elseif ($v['student_pay_type_id'] == '2') {
                $pay_id = session('pay_id');
                $pay_money = session('pay_money');
                $payType[$k]['student_pay_type_href'] = "/Bz/Alipay/pay/type/4/pay_id/{$pay_id}/pay_money/{$pay_money}";
            }
        }

        //创建一条待付款信息
        $savedata['student_id'] = $student_data['id'];
        $savedata['money'] = $retMoneyData['money'];
        $savedata['type'] = $retMoneyData['type'];

        D('StudentNoPayUpgrade')->createOne($savedata);

        $this->assign('payType', $payType);
        $this->assign('money', $retMoneyData['money']);

        $this->display('studentUpgradeSelectPayType');
    }

    //升级成功
    public function studentUpgradeSuccess()
    {
        $this->assign('url', '/Bz/CourseOne/index/courseId/' . session('course_one_course_id'));

        $this->display('studentUpgradeSuccess');
    }

    /**
     * 编辑个人资料
     */
    public function studentEditInfo()
    {
        //查询学生详细信息
        $student_data = D('student')->getStudentInfo(session('student_id'));

        D('student')->SetOnlineTimeStr($student_data);

        //查询职位标题
        $student_data['position_name'] = D('student_position')->getTitle($student_data['company_position_id']);

        //查询 company_position_id职位标题
        if (empty($student_data['company_position_id'])) {
            $student_data['company_position_id'] = 0;
        }
        $student_position_where_id['student_position_id'] = array('neq', $student_data['company_position_id']);
        $student_data['not_in_position_name'] = M('student_position')->field('student_position_name, student_position_id')->where($student_position_where_id)->select();

        //查询行业标题
        $student_data['vocation_name'] = D('student_vocation')->getTitle($student_data['company_vocation_id']);

        //查询id 不在 company_vocation_id 行业标题
        if (empty($student_data['company_vocation_id'])) {
            $student_data['company_vocation_id'] = 0;
        }
        $student_vocation_where_id['student_vocation_id'] = array('neq', $student_data['company_vocation_id']);
        $student_data['not_in_vocation_name'] = M('student_vocation')->field('student_vocation_name, student_vocation_id')->where($student_vocation_where_id)->select();

        $p_id = '';

        if (empty($student_data['wx_province_name'])) {
            //查询省
            $student_data['province_name'] = D('system_city_list')->getTitle($student_data['student_province_id']);
            $w['name'] = array('like', '%' . $student_data['wx_province_name'] . '%');
            $p_id = $student_data['province_id'] = M('system_city_list')->where($w)->getField('id');

            //查询数据库非现有的值
            if (empty($student_data['student_province_id'])) {
                $student_data['student_province_id'] = 0;
            }
            $student_province_where_id['id'] = array('neq', $student_data['student_province_id']);
            $student_province_where_id['level'] = array('eq', 1);
            $student_data['not_in_province_name'] = M('system_city_list')->field('id, name')->where($student_province_where_id)->select();
        } else {
            //查询省
            $student_data['province_name'] = $student_data['wx_province_name'];
            $w['name'] = array('like', '%' . $student_data['wx_province_name'] . '%');
            $p_id = $student_data['province_id'] = M('system_city_list')->where($w)->getField('id');

            //查询数据库非现有的值
            $student_province_where_id['name'] = array('notlike', '%' . $student_data['wx_province_name'] . '%');
            $student_province_where_id['level'] = array('eq', 1);
            $student_data['not_in_province_name'] = M('system_city_list')->field('id, name')->where($student_province_where_id)->select();
        }

        if (empty($student_data['wx_city_name'])) {
            //查询市
            $student_data['city_name'] = D('system_city_list')->getTitle($student_data['student_city_id']);

            if (empty($student_data['student_city_id'])) {
                $student_data['student_city_id'] = 0;
            }
            $student_city_where_id['id'] = array('neq', $student_data['student_city_id']);
            $student_city_where_id['level'] = array('eq', 2);
            $student_data['not_in_city_name'] = M('system_city_list')->field('id, name')->where($student_city_where_id)->select();
        } else {
            //查询市
            $student_data['city_name'] = $student_data['wx_city_name'];

            //查询数据库非现有的值
            $student_city_where_id['name'] = array('notlike', '%' . $student_data['wx_city_name'] . '%');
            $student_city_where_id['level'] = array('eq', 2);
            $student_city_where_id['upid'] = array('eq', $p_id);

            $student_data['not_in_city_name'] = M('system_city_list')->field('id, name')->where($student_city_where_id)->select();
        }

        $this->assign('student', $student_data);

        if (D("student_lawyer_profile_approval")->existsApprovaling()) {

            $this->assign('student_authenticated_approving', "1");


        } else {
            $this->assign('student_authenticated_approving', "0");
        }


        $this->display();
    }


    //更新个人资料
    public function updateInfo()
    {
        $module = M('student');

        if (IS_AJAX) {
            $student_province_id = I('post.province');
            $student_city_id = I('post.city');
            $company_vocation_id = I('post.vocation');
            $company_position_id = I('post.position');
            $company_name = trim(I('post.company_name'));
            $student_wx = trim(I('post.student_wx'));
            if ($student_province_id != '' && $student_province_id != 'all') {
                $prov_name = M('system_city_list')->where('id = ' . $student_province_id)->getField('name');

                $data['student_province_id'] = $student_province_id;
                $data['wx_province_name'] = $prov_name;
            }
            if ($student_city_id != '' && $student_city_id != 'all') {
                $city_name = M('system_city_list')->where('id = ' . $student_city_id)->getField('name');

                $data['wx_city_name'] = $city_name;
                $data['student_city_id'] = $student_city_id;
            }
            if ($company_vocation_id != '') {
                $data['company_vocation_id'] = $company_vocation_id;
            }
            if ($company_position_id != '') {
                $data['company_position_id'] = $company_position_id;
            }
            if ($company_name != '') {
                $data['company_name'] = trim($company_name);
            }


            if ($student_wx != '') {

                $data['student_wx'] = trim($student_wx);
            }


            $bool = $module->where('id = ' . session('student_id'))->data($data)->save($data);

            if ($bool) {
                $arr = array('msg' => 'true');
                $this->ajaxReturn($arr);
            } else {
                $arr = array('msg' => 'true');
                $this->ajaxReturn($arr);
            }
        }
    }

    //抱柱课堂
    public function microclass()
    {
        $wxBindId=session('account_binding_wxid');
        if (is_weixin()) {
            if (empty($wxBindId)) {
                $this->redirect('/Bz/WxBinding/index');
            }
        }

        //查询学生详细信息
        $student_info = D('student')->getStudentInfo(session('student_id'));
        if (empty($student_info)) {
            session('student_id', null);

            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

            $this->redirect('/Bz/School/index');
        }

        if (empty($student_info['account_binding_wxid'])) {
            $this->redirect('/Bz/WxBinding/index');
        }

        header("Location: http://mp.weixin.qq.com/s?__biz=MjM5MDI0MzkyNw==&mid=401756801&idx=1&sn=639db17942c22e04d37f462267b0740c&scene=0&previewkey=DywBEVcG%2BKTIU9cBGDXHFMwqSljwj2bfCUaCyDofEow%3D#wechat_redirect");
    }

    //请假页面
    public function askforleave()
    {
        $wxBindId=session('account_binding_wxid');
        if (is_weixin()) {
            if (empty($wxBindId)) {
                $this->redirect('/Bz/WxBinding/index');
            }
        }

        //查询学生详细信息
        $student_info = D('student')->getStudentInfo(session('student_id'));
        if (empty($student_info)) {
            session('student_id', null);

            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

            $this->redirect('/Bz/School/index');
        }

        if (empty($student_info['account_binding_wxid'])) {
            $this->redirect('/Bz/WxBinding/index');
        }

        header("Location: /Bz/Course/myc");
    }


    /**
     * 提交请假原因
     *
     */
    public function submit_ask_for_leave_reason()
    {
        $cond = array(
            'id' => session('student_sign_up_id'),
            'student_id' => session('student_id')
        );

        $studentCourseInfo = M('student_course')->where($cond)->find();

        $courseId = $studentCourseInfo['school_course_id'];
        $schoolCourseInfo = M('school_course')->where(array('id' => $courseId))->find();


        if ($schoolCourseInfo['is_can_false'] == 0) {
            echo '不允许请假';
            exit();
        }

        $cur_time = time();

        if ($cur_time < $schoolCourseInfo['leave_begin_time']) {
            echo '还没到可以请假的时间';
            exit();
        }


        if ($cur_time > $schoolCourseInfo['leave_end_time']) {
            echo '已经过了可以请假的时间';
            exit();
        }

        M('student_course')->where($cond)->find();

        $result = M('student_course');

        $result->msg = $_POST['msg'];
        $result->status = 2;

        $course = $result->where($cond)->save();
        if ($course) {
            echo 1;
        } else {
            echo 0;
        }
    }

    /**
     * 缓存请假的信息
     */
    public function cache_student_sign_up_id()
    {
        if ($_POST['id']) {
            session('student_sign_up_id', $_POST['id']);
        }
    }
}