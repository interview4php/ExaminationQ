<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/3/3
 * Time: 10:34
 */

namespace Bz\Controller;


class ActivityController extends ExtendController
{

    
    //保存学生活动报名数据
    public function saveStudentActivity()
    {
        if (IS_AJAX)
        {
            $data['activity_main_id'] = $_POST['activity_main_id'];  //主会场ID
            $data['activity_lord_number'] = $_POST['lord'];  //主会场数量
//            $data['activity_branch_number'] =  $post['activity_id'];  //分会场
//            $data['activity_broadcasting_number'] = $post['broadcasts'];    //活动直播

            if(!empty($_POST['activity_id']))
            {
                $data['activity_branch_number'] =  $_POST['activity_id'];  //分会场
            }


            $res = M('student_activity')->add($data);

            if($res)
            {
                echo 'true';
            }else{
                echo 'false';
            }

        }
    }
}