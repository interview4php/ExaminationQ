<?php
namespace Bz\Controller;

use Think\Controller;

/**
 * 单场课程报名
 *
 * Class CourseOneController
 *
 * @package Bz\Controller
 */
class CourseOneController extends ExtendController
{

	//单场课程报名
	public function index()
	{
		$courseId = I('courseId');
		$placeId = I('placeId');

		if (empty($courseId)) {
			$this->redirect('/Bz/Show/defaultError/errorCode/classroom_nonexists');    // 课程不存在
		}
		if (empty($placeId)) {
			$placeId = 0;
		}

		session('course_one_course_id', $courseId);
		session('course_one_place_id', $placeId);

		$field = 't.id,t.name as course_name,s.school_name,t.one_see_type,t.one_money,t.one_status';
		$data = D('SchoolCourse')->getCourseField($courseId, $field);

		//该课程没有开启单场报名
//		if(!$data['one_status']){
//			$this->redirect('/Bz/Course/course');
//		}

		$data['placeId'] = $placeId;

		$this->assign('courseData', $data);

		$this->display('index');
	}

	/**
	 * 查询单场课程报名的支付方式
	 *
	 * @param $courseId
	 */
	public function courseOnePayType($courseId) {
		$where['id'] = $courseId;
		$data = M('school_course')->where($where)->find();
		if (!$data) {
			exit('无数据');//查询不到处理
		}

		$pay_id = D('student_no_pay_one_course')->createOne($courseId, $data, session('student_id'));//待购买
		session('need_pay_course_id', $courseId);
		session('course_one_pay_id', $pay_id);

		//查询支付方式
		$payType = D('StudentPayType')->getSelectData(false);
		foreach ($payType as $k => $v) {
			if ($v['student_pay_type_id'] == '1') {
				$payType[$k]['student_pay_type_href'] = '/Bz/WxPay/indexPayOneCourse/courseId/' . $courseId;
			} elseif ($v['student_pay_type_id'] == '2') {
				$payType[$k]['student_pay_type_href'] = "/Bz/Alipay/pay/type/2/pay_id/{$pay_id}";
			}
		}

		$this->assign('money', $data['one_money']);
		$this->assign('payType', $payType);

		$this->display();
	}

	/**
	 * 非社员错误
	 */
	public function errorNoStudent()
	{

		$this->display('errorNoStudent');
	}

	//无现场权限
	public function errorNoAuth($courseId)
	{
		$this->assign('courseId', $courseId);

		$this->display('errorNoAuth');
	}

	//index提交处理
	public function indexSubmit()
	{
		$course_id = I('post.courseId');
		$place_id = I('post.placeId');
		$true_name = I('post.true_name');
		$mobile_phone = I('post.mobile_phone');
		$one_see_type = I('post.OneSeeType');

		//查询该手机号是否为用户，查数据库，不请求31
		$user_data = D('student')->getRepeat($mobile_phone);
		//用户不存在
		if (!$user_data) {
			$this->redirect('/Bz/CourseOne/errorNoStudent');
		}
		if ($user_data['is_disable']) {
			$this->redirect('/Bz/Show/defaultError/errorCode/account_forbidden');
		}

		//帮助用户登录
		//D('student')->setLoginSession($user_data);
		$field = 't.id,t.name as course_name,s.school_name,t.one_see_type,t.one_money,t.one_status,t.black_list';
		$school_course_data = D('SchoolCourse')->getCourseField($course_id, $field);

		//该课程没有开启单场报名
		if (!$school_course_data['one_status']) {
			$this->redirect('/Bz/Course/course');
		}

		//查看用户是否在黑名单中
		if (D('student_course')->isInBlackList($school_course_data['black_list'], $user_data['mobile_phone'])) {
			$msg = "由于您之前未请假缺课，无法报名该课程，如有疑问请至“抱柱网服务号”咨询";
			$this->redirect('/Bz/Show/errorTwo/type/false3/msg/' . $msg);
		}

		//查看用户是否已经报名了
		$countwhere['school_course_id'] = $course_id;
		$countwhere['student_id'] = $user_data['id'];
		var_dump($countwhere);

		$data = D('StudentCourse')->field('status')->where($countwhere)->find();
		if ($data) {
			if ($data['status'] == '2') {
				D('StudentCourse')->where($countwhere)->delete();
			} else {
				//已报名直播需要请假
				$this->redirect('/Bz/Show/defaultError/errorCode/is_have_direct_seeding');
			}
		}

		//无权限
		if ($one_see_type == '现场' && $user_data['apply_type_id'] == '1') {
			$this->redirect('/Bz/CourseOne/errorNoAuth/courseId/' . $course_id);
		}

		//报名处理
		$ret = D('student_course')->user_sign_up_one_course($user_data['id'], $course_id, $place_id, $one_see_type);
		if ($ret['ret'] == 'true') {
			$coursedata = M('school_course')->find($course_id);

			$str_begin_time = date('Y年m月d日', $coursedata['begin_time']);
			if ($one_see_type === '现场') {
				$content = "亲爱的{$user_data['true_name']}，您已成功报名{$str_begin_time}{$coursedata['name']}{$coursedata['address']}主会场，请到".$this-> nameConfig['WECHAT_SERVICE_NAME']."右侧菜单查看报名状态或请假。";
				A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
			} else {
				$content = "亲爱的{$user_data['true_name']}，您已成功报名{$str_begin_time}{$coursedata['name']}直播课，请至".$this-> nameConfig['WECHAT_SERVICE_NAME']."菜单右侧查看直播攻略。";
				A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
			}

			$this->redirect('/Bz/Show/successOne');
		} else if ($ret['ret'] == 'false2') {

			$this->redirect('/Bz/Show/errorTwo/msg/' . $ret['msg']);
		}
	}

	//购买成功
	public function indexSuccess()
	{

		$this->display('indexSuccess');
	}

}