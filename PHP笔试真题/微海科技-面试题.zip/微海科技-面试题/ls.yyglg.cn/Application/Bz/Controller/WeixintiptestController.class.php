<?php
namespace Bz\Controller; 
use Think\Controller;

class WeixintiptestController extends Controller {
 
	public function index(){
		if (is_weixin()) {
			//$this->assign('img_url', '/Public/img/live_weixin.png');
			$this->assign('img_url', '/Public/Bz2/images/prompt.png');

			$this->display('Alipay/Bztip');
		}
	}

}