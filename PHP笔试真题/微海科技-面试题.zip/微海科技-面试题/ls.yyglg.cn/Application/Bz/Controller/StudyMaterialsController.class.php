<?php
namespace Bz\Controller;

use Think\Controller;
 
//学习资料
class StudyMaterialsController extends ExtendController
{
	//请假页面
	public function index()
	{
		$wxbindId=session('account_binding_wxid');
		if (is_weixin()) {
			if (empty($wxbindId)) {
				$this->redirect('/Bz/WxBinding/index');
			}
		}

		//查询学生详细信息
		$student_info = D('student')->getStudentInfo(session('student_id'));
		if (empty($student_info)) {
			session('student_id', null);

			\Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

			$this->redirect('/Bz/School/index');
		}

		if (empty($student_info['account_binding_wxid'])) {
			$this->redirect('/Bz/WxBinding/index');
		}

		header("Location: http://mp.weixin.qq.com/s?__biz=MjM5MDI0MzkyNw==&mid=403045117&idx=1&sn=753ea53bba4a9463c622fbf0cf418d7d&scene=1&srcid=0224QV5Pby0vZDqQDuBplhU8#rd");
	}
}