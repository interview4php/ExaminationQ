<?php
namespace Bz\Controller;

use Think\Controller;

class PublicController extends Controller
{
	//标题，显示我的display
	public function myD($url, $title)
	{
		$this->assign('thisTitle', $title);
		$this->display($url);
	}

	//获取范围的机器类型
	public function getDeviceType()
	{
		$agent = strtolower($_SERVER['HTTP_USER_AGENT']);
		$type = 'other';
		if (strpos($agent, 'iphone') || strpos($agent, 'ipad')) {
			$type = 'ios';
		}
		if (strpos($agent, 'android')) {
			$type = 'android';
		}
		return $type;
	}

	public  function  LogInfo($content )
	{
		\Think\Log::write($content, 'INFO');

	}

	//发送短信
	public function sendShortMsg($mobile_phone, $content)
	{
		\Think\Log::write("send msg to $mobile_phone, content:{$content}", 'INFO');
		vendor('yzm.cShortMsg');
		return \cShortMsg::sendMsg($mobile_phone, $content);
	}
	

}