<?php
namespace Bz\Controller;
use Think\Controller;

class WxSessionController extends Controller {
 
	public function student_id($value=''){
		if (empty($value)) {
			return session('student_id');
		} else {
			session('student_id', $value);
		}
	}

	
}