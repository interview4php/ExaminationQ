<?php
namespace Bz\Controller;
use Think\Controller;

class RewardSessionController extends Controller {

	/**
	 * 当前打赏用户的电话
	 *
	 * @param string $value
	 */
	public function reward_mobile_phone($value=''){
		if (empty($value)) {
			return session('reward_mobile_phone');
		} else {
			session('reward_mobile_phone', $value);
		}
	}


	public function reward_teacher_id($value=''){
		if (empty($value)) {
			return session('reward_teacher_id');
		} else {
			session('reward_teacher_id', $value);
		}
	}

	public function reward_type($value=''){
		if (empty($value)) {
			return session('reward_type');
		} else {
			session('reward_type', $value);
		}
	}

	public function reward_course_id($value=''){
		if (empty($value)) {
			return session('reward_course_id');
		} else {
			session('reward_course_id', $value);
		}
	}

	public function reward_teacher_data($value=''){
		if (empty($value)) {
			return session('reward_teacher_data');
		} else {
			session('reward_teacher_data', $value);
		}
	}

	public function reward_pay_show_url($value='') {
		if (empty($value)) {
			return session('reward_pay_show_url');
		} else {
			session('reward_pay_show_url', $value);
		}
	}
}