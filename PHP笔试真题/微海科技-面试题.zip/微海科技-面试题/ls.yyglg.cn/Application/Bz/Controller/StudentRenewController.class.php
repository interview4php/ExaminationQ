<?php
namespace Bz\Controller;
 
use Think\Controller;

class StudentRenewController extends ExtendController
{
	/**
	 * 首页登录界面
	 */
	public function index()
	{
//		if ($_SERVER['HTTP_HOST'] == '123.56.232.35' || $_SERVER['HTTP_HOST'] == 'ibaozhu.cn') {
//			header('Location: http://ls.yyglg.cn/Bz/Index/index');
//			exit();
//		}

		$baozhu_last_url = cookie('baozhu_last_url');

		if (empty($baozhu_last_url)) {
			$this->assign('baozhu_last_url', U('Bz/Course/course'));
		} else {
			$this->assign('baozhu_last_url', $baozhu_last_url);
		}

		//查询提示语
		$this->assign('data', M('html_login_content')->field('content,url')->find());
		//查询提示务必请假
		$this->assign('data2', M('html_login_submit')->field('title,content,button_value')->find());

		$is_in_iphone = is_iphone();
		$this->assign('is_in_iphone', $is_in_iphone);

		A('Public')->myD('index', '续费');
	}

	/**
	 * 用户续费
	 */
	public function studentRenew()
	{
		//学生详细信息
		$student_id = session('renew_student_id');
		if (empty($student_id)) {
			$this->redirect('Bz/StudentRenew/index');
		}

		$student_info = M('student')->find($student_id);

		if (empty($student_info) || empty($student_info['school_student_number'])) {
			\Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

			$this->redirect('/Bz/School/index');
		}

		if ('1' == $student_info['is_disable']) {
			$this->redirect("/Bz/Show/defaultError/errorCode/account_forbidden");
		}

//		if (empty($student_info['end_time']) || $student_info['end_time'] < time()) {
//			$apply_type_id = 1;
//			$applyType = D('StudentApplyType')->getSelectData();
//		} else {
		
			$applyType = D('StudentApplyType')->getOneData2($student_info);
//		}

		//$applyType = D('StudentApplyType')->getOneData($apply_type_id);


		//查询入社模式
		$this->assign('applyType', $applyType);

		$this->display('Student/studentRenew');
	}

	/**
	 * 选择用户续费支付方式
	 *
	 */
	public function studentRenewSelectPayType()
	{
		$apply_type_id = I('post.id');
		$apply_type_count = intval(I('post.id_count'));

		//查询该入社方式是否存在
		$ret = D('StudentApplyType')->where(array('student_apply_type_id' => $apply_type_id))->find();
		if (!$ret) {
			\Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/StudentRenew/studentRenew', 'ERR');
			$this->redirect('/Bz/StudentRenew/studentRenew');
		}

		$student_id = session('renew_student_id');
		if (empty($student_id)) {
			$this->redirect('Bz/StudentRenew/index');
		}

		//学生详细信息
		$student_data = M('student')->find($student_id);

		//技术金额
		$money = $ret['student_apply_type_price'] * $apply_type_count;

		if ('18682032428' == $student_data['mobile_phone'] || '18612248383' == $student_data['mobile_phone']) {
			$money = 0.01;
		}

		$this->assign('money', $money);

		//保存续费交费信息
		if (!D('student_no_pay_renew')->createOne($student_data['id'], $apply_type_id, $apply_type_count, $money)) {
			\Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/StudentRenew/studentRenew', 'ERR');

			$this->redirect('/Bz/StudentRenew/studentRenew');
		}

		//查询支付方式
		$payType = D('StudentPayType')->getSelectData(false);
		foreach ($payType as $k => $v) {
			if ($v['student_pay_type_id'] == '1') {
				$payType[$k]['student_pay_type_href'] = '/Bz/WxPay/payStudentRenew';
			} elseif ($v['student_pay_type_id'] == '2') {
				$pay_id = session('pay_id');
				$pay_money = session('pay_money');
				$payType[$k]['student_pay_type_href'] = "/Bz/Alipay/pay/type/3/pay_id/{$pay_id}/pay_money/{$pay_money}";
			}
		}

		$this->assign('payType', $payType);

		$this->display('Student/studentRenewSelectPayType');
	}

}