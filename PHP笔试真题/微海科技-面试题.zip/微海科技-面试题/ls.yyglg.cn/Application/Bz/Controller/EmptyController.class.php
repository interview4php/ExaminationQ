<?php
namespace Bz\Controller;
use Think\Controller;
class EmptyController extends Controller {
 
	public function index(){
		\Think\Log::record('控制器不存在, URI:' . $_SERVER['REQUEST_URI'], 'ERR');
		$this->show('系统繁忙，请稍后再试~~~~');
	}

	public function _empty(){
		\Think\Log::record('函数不存在, URI:' . $_SERVER['REQUEST_URI'], 'ERR');
		$this->show('系统繁忙，请稍后再试~~~~~');
	}
	
}