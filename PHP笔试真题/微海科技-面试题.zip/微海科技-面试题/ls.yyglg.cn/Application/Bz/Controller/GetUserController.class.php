<?php
namespace Bz\Controller;
use Think\Controller;

/**
 * 31会员
 *
 * Class GetUserController
 *
 * @package Bz\Controller
 */
class GetUserController extends Controller{
	//文件读取
	public function http_get($url){

		$oCurl = curl_init();
		if(stripos($url,'https://')!==FALSE){
			curl_setopt($oCurl,CURLOPT_SSL_VERIFYPEER,FALSE);
			curl_setopt($oCurl,CURLOPT_SSL_VERIFYHOST,FALSE);
			curl_setopt($oCurl,CURLOPT_SSLVERSION,1);
		}
		curl_setopt($oCurl,CURLOPT_URL,$url);
		curl_setopt($oCurl,CURLOPT_RETURNTRANSFER,1);
		$sContent = curl_exec($oCurl);
		$aStatus  = curl_getinfo($oCurl);
		curl_close($oCurl);
		if(intval($aStatus['http_code'])==200){
			$q=json_decode($sContent,true);
			return $q;
		}else{
			return false;
		}
		
	}

	//文件读取
	public function https_request($url,$data = null){
		$curl = curl_init();

		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		if (!empty($data)){
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}

		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

		$output = curl_exec($curl);

		curl_close($curl);

		return $output;
	}

	//获取31 access_token
	protected function get31AccessToken(){
		
	}
	
	
	
	//获取是否为31会员
	public function get31user($mobile_phone){
		/*
		if(S('31_access_token')){
			$access_token = S('31_access_token');
		}else{
			//获取access_token
			$url = 'http://www.31meijia.com/api/token/get?appid=51477101&secret=68EFD116E083F5217824CF597A956588';
			$atd = $this->http_get($url);
			S('31_access_token',$atd['access_token'],($atd['expires_in']-300));
			$access_token  =$atd['access_token'];
		}
		*/
		//获取access_token
		$url = 'http://www.31meijia.com/api/token/get?appid=51477101&secret=68EFD116E083F5217824CF597A956588';
		$atd = $this->http_get($url);
		$access_token  =$atd['access_token'];

		//检查是否为会员
		$url_get_user = 'http://www.31meijia.com/api/member/check-mobile?mobile='.$mobile_phone.'&access_token='.$access_token;
		$is_31user = $this->http_get($url_get_user);
		if($is_31user['errcode']=='0'){
			return $is_31user;
		}else{
			return false;
		}
	}
   
}