<?php
namespace Bz\Controller;

use Think\Controller;

class IndexController extends Controller
{
	/**
	 * 首页登录界面
	 */
	public function index()
	{
		$this->redirect('/Baozhu/Activity/index');

//		if ($_SERVER['HTTP_HOST'] == '123.56.232.35' || $_SERVER['HTTP_HOST'] == 'ibaozhu.cn') {
//			header('Location: http://ls.yyglg.cn/Bz/Index/index');
//			exit();
//		}

		$baozhu_last_url = cookie('baozhu_last_url');
		$session_student_id=session('student_id');
		if (!empty($session_student_id)) {
			$student_info = M('student')->find(session('student_id'));
			if (!empty($student_info)) {
				if (empty($baozhu_last_url)) {
					$this->redirect('/Bz/Course/course');
				} else {
					$this->redirect($baozhu_last_url);
				}
			}
		}

		if (is_weixin()) {
			A('Wx')->wxuserautologin();
		}

		if (!empty($session_student_id)) {
			if (empty($baozhu_last_url)) {
				$this->redirect('/Bz/Course/course');
			} else {
				$this->redirect($baozhu_last_url);
			}
		}

		if (empty($baozhu_last_url)) {
			$this->assign('baozhu_last_url', U('Bz/Course/course'));
		} else {
			$this->assign('baozhu_last_url', $baozhu_last_url);
		}

		//查询提示语
		$this->assign('data', M('html_login_content')->field('content,url')->find());
		//查询提示务必请假
		$this->assign('data2', M('html_login_submit')->field('title,content,button_value')->find());

		$is_in_iphone = is_iphone();
		$this->assign('is_in_iphone', $is_in_iphone);

		A('Public')->myD('index', '课程报名');
	}


	//登录操作
	public function login()
	{
		//header('Content-type:text/html;charset=utf-8');
		$array['user_name'] = I('get.name');
		$mobile_phone = I('get.mobile_phone');
		$array['mobile_phone'] = trim($mobile_phone);

		$student_info = M('student')->where(array('mobile_phone' => $mobile_phone))->find();

		if (empty($student_info) || empty($student_info['apply_type_id']) || empty($student_info['end_time'])) {
			$data = array('ret' => 'false', 'msg' => '不是会员');
		} else {
			$otherArray['apply_type_id'] = $student_info['apply_type_id'];
			$otherArray['expireday'] = $student_info['end_time'];

			D('Student')->login($array, $otherArray);

			$data = array('ret' => 'true', 'msg' => '登录成功');
		}

		$this->ajaxReturn($data);
	}

	//退出
	public function logout()
	{
		D('Student')->logout();
		$this->ajaxReturn(array('ret' => 'true', 'msg' => '退出成功'));
	}

	//直播
	public function indexOther()
	{
//		if ($_SERVER['HTTP_HOST'] == '123.56.232.35' || $_SERVER['HTTP_HOST'] == 'baozhu.weqxin.com') {
//			header('Location: /Bz/Index/indexOther');
//			exit();
//		}

		$this->display('indexOther');
	}

	//直播检查
	public function indexOtherCheck()
	{
		$mobile_phone = I('post.mobile_phone');
		$student_info = M('student')->where(array('mobile_phone' => $mobile_phone))->find();

		if (!empty($student_info)) {    //  || A('GetUser')->get31user($mobile_phone)
			header("Location: http://e.vhall.com/493362218");
		} else {
			header("Location: /Bz/School");
		}
	}


}