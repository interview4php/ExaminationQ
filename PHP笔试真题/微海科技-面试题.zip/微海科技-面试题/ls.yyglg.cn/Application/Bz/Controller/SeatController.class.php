<?php
namespace Bz\Controller;

use Think\Controller;

//座位
class SeatController extends ExtendController
{
	//会场，所有座位显示
	public function index()
	{
		header('Content-type:text/html;charset=utf-8');
		dump('座位列表');
		$courseId = I('get.courseId');//课程ID
		$courseId = 4;//测试

		//查询该用户是否已经签到了该课程
		$signData = D('StudentCourseSign')->isSign(session('student_id'), $courseId);
		dump('是否已经签到：' . $signData);

		//查询该课程
		$data = D('SchoolCourseSeat')->getOne($courseId);
		if ($data && $data['status'] == 1) {
			dump(unserialize($data['seat_array']));
		} else {
			dump('座位还没开放呢~');
		}

	}

	//选择座位（操作）
	public function setStudentSeat()
	{
		header('Content-type:text/html;charset=utf-8');
		dump('学生选择座位');
		$seatOne = I('get.seatOne');//座位一维坐标
		$seatTwo = I('get.seatTwo');//座位二维坐标
		$courseId = I('get.courseId');//课程ID
		$seatOne = 1;//测试
		$seatTwo = 3;//测试
		$courseId = 4;//测试

		//普通选座
		$ret = D('SchoolCourseSeat')->setStudentSeat($courseId, $seatOne, $seatTwo, session('student_id'));
		dump($ret);
	}

	//展示电子票
	public function showStudentSeat()
	{
		header('Content-type:text/html;charset=utf-8');
		dump('学生展示电子票');
		$courseId = I('get.courseId');//课程ID
		$courseId = 4;//测试

		//展示某个用户的某个课程的电子票
		$ret = D('StudentCourseSeat')->getOne($courseId, session('student_id'));
		dump($ret);


	}


}