<?php
namespace Bz\Controller;

use Think\Controller;

include_once("/ThinkPHP/Library/Vendor/WxPayPubHelper/WxPay.pub.config.php");

//用户中心
class UserCenterController extends Controller
{

    //用户主页
    public function index()
    {
        $appid = 'wx5c02b547be99f3e3';
        $sercet = '669a4287a62c578c89b3fe0416c16b5f';

        //测试环境
        session('openid','oTFiKwbOaK737ujvRxsTqT3LWYu0');
        session('headImgUrl', '/Public/Bz/images/defaultHeadImg.jpg');
        cookie('ibaozhu_user_phone', 18682157284);

        $headImgUrl = session("headImgUrl");


        if (true) {

            $openId = session("openid");

            $re = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING']);

            if ($openId != null && $openId != "" && $headImgUrl != null && $headImgUrl != "") {

                //如果有openid了

            } else {

                //如果没获取到openid

                //------------------------获取openid begin --------------------------------------

                //如果没有openid，则需要获取

                $code = $_GET['code'];

                if ($code != null && $code != "") {
                    //如果有code，说明是经过微信open auth验证并重定向回来的

                    //获取openid
                    $getOpenIdUrl = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=$appid&secret=$sercet&code=$code&grant_type=authorization_code";

                    $res = file_get_contents($getOpenIdUrl);


                    //取出openid
                    $data = json_decode($res, true);

                    $openId = $data['openid'];


                    $openAuthUrl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=$appid&redirect_uri=$re&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
                    if ($openId == null || $openId == "") {
                        //微信接口有时候会返回code非法

                        redirect($openAuthUrl);

                    }
                    //存到session里面
                    session('openid',$openId);

                    $accessToken = $data['access_token'];
                    //获取用户的头像
                    if ($headImgUrl == null || $headImgUrl == "") {

                        $getUserInfoUrl = "https://api.weixin.qq.com/sns/userinfo?access_token=$accessToken&openid=$openId&lang=zh_CN";

                        $userInfoRes = file_get_contents($getUserInfoUrl);


                        $userInfo = json_decode($userInfoRes, true);

                        $headImgUrl = $userInfo["headimgurl"];
                        //var_dump($headImgUrl);

                        session('headImgUrl',$headImgUrl);
                    }

                } else {
                    //  需要跳转到微信open auth页面

                    //返回自己，并附带code


                    //snsapi_userinfo  snsapi_base
                    $openAuthUrl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=$appid&redirect_uri=$re&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";


                    redirect($openAuthUrl);
                }


                //------------------------------获取openid end-------------------------------------

            }


        }

  
        $student_id = session('student_id');

        if (empty($student_id)) {
            //通过新微站的cookie自动登录老微站
            $mobile_phone = cookie('ibaozhu_user_phone');
            if (empty($mobile_phone)) {
                cookie('baozhu_last_url', \get_cur_url());
                $this->redirect('/Baozhu/Login/index');
            } else {
                $where['mobile_phone'] = $mobile_phone;
                $data = M('student')->field('id,mobile_phone,account_binding_wxid')->where($where)->find();

                session('student_id',$data['id']);
                session('student_mobile_phone',$data['mobile_phone']);
                session('account_binding_wxid',$data['account_binding_wxid']);
         

                cookie('baozhu_last_url', Null);
                $student_id = session('student_id');
            }
        }

        session('renew_student_id', $student_id);

        //查询学生详细信息
        $student_info = D('student')->getStudentInfo($student_id);


//        if (abs($student_info['end_time'] - $student_info['time']) < 3600) {
//            $ifFirstTime = 1;
//            echo  $ifFirstTime ;
//        }
        //var_dump($student_info);

        if ($student_info['account_binding_wxid'] == null || $student_info['account_binding_wxid'] == "" || $student_info['account_binding_wxid'] != $openId || $student_info['wxid'] == null || $student_info['wxid'] == "" || $student_info['wxid'] != $openId) {
            $student_info['account_binding_wxid'] = $openId;
            $student_info['wxid'] = $openId;
            D('student')->where(array('id' => $student_info['id']))->save(array('account_binding_wxid' => $openId, 'wxid' => $openId));

        }


        //成长值
        D('student')->SetOnlineTimeStr($student_info);


        //  echo  $student_info['student_authenticated'];
        if (empty($student_info)) {
            session('student_id', null);
            cookie('baozhu_last_url', $this->get_url());

            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

            $this->redirect('/Bz/School/index');
        }

//		if (empty($student_info['account_binding_wxid'])) {
//			$this->redirect('/Bz/WxBinding/index');
//		}

//学生信息
        $this->assign('student', $student_info);
        $limit = "0,20";

//签到记录
        $data = D('StudentCourseSign')->getStudentCourseSignRecord($student_id, $limit);


        //学习记录
        $studyRecord = D('StudentCourseSign')->getStudentStudyRecord($student_id, $limit);
        $studyRecord_online=D('VedioPlayTime')->getStudentStudyRecord($student_id, $limit);
//      var_dump($studyRecord);
//        var_dump($studyRecord_online);
        $studyRecord = array_merge($studyRecord, $studyRecord_online);

        foreach ($studyRecord as $key => $value) {

            $nameSort[$key] = $value['name'];

            $timeSor[$key] = $value['begin_time'];

        }

        array_multisort($timeSor,SORT_DESC, $nameSort, $studyRecord);
//        var_dump($studyRecord);
       // usort($studyRecord, 'sortByLen');
//        var_dump($studyRecord);
//        var_dump($studyRecord);

        $this->assign('data', $data);
        //  var_dump($studyRecord);
        $this->assign('study', $studyRecord);

        if (D("student_lawyer_profile_approval")->existsApprovaling()) {

            $this->assign('student_authenticated_approving', "1");


        } else {

            $this->assign('student_authenticated_approving', "0");
        }

        $this->display('Student/index');
    }

    function sortByLen($a, $b) {

        var_dump($a);
        var_dump($b);
        die();

        if (strlen($a) == strlen($b)) {

            return 0;

        } else {

            return (strlen($a) > strlen($b)) ? 1 : -1;

        }

    }

    function Sec2Time($time)
    {

        if (is_numeric($time)) {
            $value = array(
                "years" => 0, "days" => 0, "hours" => 0,
                "minutes" => 0, "seconds" => 0,
            );
            if ($time >= 31556926) {
                $value["years"] = floor($time / 31556926);

                $time = ($time % 31556926);
            }
            if ($time >= 86400) {
                $value["days"] = floor($time / 86400);
                $time = ($time % 86400);
            }
            if ($time >= 3600) {
                $value["hours"] = floor($time / 3600);
                $time = ($time % 3600);
            }
            if ($time >= 60) {
                $value["minutes"] = floor($time / 60);
                $time = ($time % 60);
            }
            $value["seconds"] = floor($time);

            // var_dump($value);
            //return (array) $value;
            //$t=$value["minutes"] ."分";
            $t = "";
            if ($value["years"] != "0") {
                $t = $value["years"] . "年" . $value["days"] . "天" . $value["hours"] . "小时" . $value["minutes"] . "分";

            } else {
                if ($value["days"] != "0") {
                    $t = $value["days"] . "天" . $value["hours"] . "小时" . $value["minutes"] . "分";

                } else {
                    if ($value["hours"] != "0") {
                        $t = $value["hours"] . "小时" . $value["minutes"] . "分";

                    } else {
                        $t = $value["minutes"] . "分";
                    }

                }

            }


            Return $t;

        } else {
            return (bool)FALSE;
        }
    }
}