<?php
namespace Bz\Controller;

use Think\Controller;

//打赏控制器
class CourseRewardController extends Controller
{

    //打赏控制器（查找当前打赏对象）中转站
    public function index()
    {
        $courseId = I('get.courseId');


//		echo "aaaa".$courseId;
//		exit();
        //查询当前打赏对象Id

        $reward_teacher_id = D('system_reward_teacher')->getOneId($courseId);

        if (!$reward_teacher_id) {
            //打赏不存在或者打赏已关闭
            $this->redirect('/Bz/CourseReward/rewardTeacherClose');
        }

        //保存该操作的下级操作全部使用的ID
        $obj_reward_sess = A('RewardSession');
        $obj_reward_sess->reward_teacher_id($reward_teacher_id);
        $obj_reward_sess->reward_type('teacher');
        $obj_reward_sess->reward_course_id($courseId);


        $rewardData = D('system_reward')->getRewardByCourseId($courseId);

        if (!$rewardData || !$rewardData['status']) {
            //打赏不存在或者打赏已关闭
            $this->redirect('/Bz/CourseReward/rewardTeacherClose');
        }

        $reward_id = $rewardData['id'];

        //查询该打赏对象的打赏页面信息
        $data = D('system_reward_teacher')->getRewardTeacherInfo($reward_teacher_id);

        if (1 == $data['reward_teacher']['reward_type']) {
            // 打赏抢座，只能是报名的学生
            if (!A('Extend')->is_login()) {
                $this->redirect('/Bz/Show/defaultError/errorCode/classroom_not_sign_up');
                exit();
            }

            $cond = array(
                'school_course_id' => $courseId,
                'student_id' => session('student_id'),
                'status' => 1,
                'see_type' => array('in', array('主会场', '现场')),
            );
            $is_sign_up = M('student_course')->where($cond)->getField('id');
            if (!$is_sign_up) {
                $this->redirect('/Bz/Show/defaultError/errorCode/classroom_not_sign_up');
                exit();
            }
        }

        $obj_reward_sess->reward_teacher_data($data);
        $obj_reward_sess->reward_pay_show_url(S_URL . '/Bz/CourseReward/index/courseId/' . $courseId . '/rewardId/' .
            $reward_id);

        $this->assign('courseId', $courseId);
        $this->assign('data', $data);

        $this->display('rewardTeacher');
    }

    /**
     * 打赏老师显示页
     */
    public function rewardTeacher()
    {
        $courseId = I('get.courseId');
        $rewardData = D('system_reward')->getRewardByCourseId($courseId);

        //新增2016-2-23
        session('reward_course_id', $courseId);

        $array['reward_data'] = $rewardData;
        $this->assign('rewardData', $array);

        $student_id = session('student_id');
        if (empty($student_id)) {
            $student_data = array(
                'true_name' => '',
                'mobile_phone' => '',
            );
        } else {
            $student_data = M('student')->find($student_id);
        }

        $this->assign('student_data', $student_data);

        $this->display('index');
    }

    /**
     * 打赏已关闭
     */
    public function rewardTeacherClose()
    {
        //查询该打赏对象的打赏页面信息
        $data = D('system_reward_teacher')->getRewardTeacherInfoClose(A('RewardSession')->reward_teacher_id());

        $this->assign('data', $data);

        $this->display('rewardTeacherClose');
    }

    /**
     * 开始打赏（输入金额和留言）
     */
    public function rewardTeacherBegin()
    {
        $courseId = $course_id = session('reward_course_id');

        //查询当前打赏对象Id
        $reward_teacher_id = D('system_reward_teacher')->getOneId($courseId);
        if (!$reward_teacher_id) {
            //打赏不存在或者打赏已关闭
            $this->redirect('/Bz/CourseReward/rewardTeacherClose');
        }

        $rewardData = D('system_reward')->getRewardByCourseId($courseId);
        $reward_id = $rewardData['id'];

        //查询该打赏对象的打赏页面信息
        $data = D('system_reward_teacher')->getRewardTeacherInfo($reward_teacher_id);
        //保存该操作的下级操作全部使用的ID
        $obj_reward_sess = A('RewardSession');
        $obj_reward_sess->reward_teacher_id($reward_teacher_id);
        $obj_reward_sess->reward_type('teacher');
        $obj_reward_sess->reward_course_id($courseId);
        $obj_reward_sess->reward_teacher_data($data);
        $obj_reward_sess->reward_pay_show_url(S_URL . '/Bz/CourseReward/index/courseId/' . $courseId . '/rewardId/' .
            $reward_id);

        $reward_teacher_id = session('reward_teacher_id');
        $reward_type = session('reward_type');

//        $reward_true_name = I('post.true_name');
//        $reward_mobile_phone = I('post.mobile_phone');
        $reward_mobile_phone = session("mobile_phone");

        if ($reward_mobile_phone == "" || $reward_mobile_phone == null) {
            redirect("/Baozhu/Login/index");
        }

        $course_id = session('reward_course_id');


//		$student_id = session('reward_student_id');

        if ( $reward_mobile_phone) {
            //查询该打赏人信息


            $student_data = D('student')->getRepeat($reward_mobile_phone);


            if (!$student_data) {


//                //如果为非会员则帮手机号注册一个非会员记录
//                $student_data = D('student')->getNewFalseStudent($reward_true_name, $reward_mobile_phone);
//                if (1 == $data['reward_teacher']['reward_type']) {
//                    $this->redirect('/Bz/Show/defaultError/errorCode/classroom_not_sign_up');
//                }
            } else {
                if (1 == $data['reward_teacher']['reward_type']) {
                    $cond = array(
                        'school_course_id' => $course_id,
                        'student_id' => $student_data['id'],
                        'status' => 1,
                        'see_type' => array('in', array('主会场', '现场')),
                    );
                    $is_sign_up = M('student_course')->where($cond)->getField('id');
                    if (!$is_sign_up) {
                        $this->redirect('/Bz/Show/defaultError/errorCode/classroom_not_sign_up');
                        exit();
                    }
                }
            }

            D('reward_student')->initRewardStudent($course_id, $reward_mobile_phone, $student_data['true_name']);

            session('reward_student_id', $student_data['id']);
        }

        if (!session('reward_student_id')) {
            //exit('error');
            $this->redirect("/Bz/CourseReward/index/courseId/{$course_id}/rewardId/{$reward_id}");
        }

        //新增2016-2-23
        $student_id = session('reward_student_id');
        $orderData = D('school_course_reward')->getOneStudentCount($student_id, $course_id);

        $this->assign('rewardCount', $orderData);
        $this->assign('rewardData', D('system_reward')->getRewardByCourseId($course_id));
        $this->assign('student_data', D('student')->getStudentInfo($student_id));

        $this->display('rewardTeacherBegin');
    }


    //课程打赏用的
    public function rewardPayTypeNew()
    {
        $type = "teacher";


        if (I('post.money') == null || I('post.money') == "") {
            $money = session('reward_money_new');
        } else {
            session('reward_money_new', I('post.money'));
            $money = round(I('post.money'), 2);
        }

        $msg = I('post.msg');


        if (I('post.activity_id') == null || I('post.activity_id') == "") {
            $activity_id = session('reward_activity_id_new');
        } else {
            session('reward_activity_id_new', I('post.activity_id'));
            $activity_id = I('post.activity_id');
        }


        if ($money < 0.01) {
            exit('too small money');
        }

        //打赏金额
        $this->assign('money', $money);

        $student_id = session('student_id');

        if ($student_id == null || $student_id == "") {
            $this->redirect('/Baozhu/login');
        }
        session('reward_student_id', $student_id);
        //查询当前打赏对象Id 2016-3-7
        $reward_teacher_id = D('system_reward_teacher')->getOneId($activity_id);
        if (!$reward_teacher_id) {
            //打赏不存在或者打赏已关闭
            $this->redirect('/Bz/CourseReward/rewardTeacherClose');
        }
        $rewardData = D('system_reward')->getRewardByCourseId($activity_id);
        if (!$rewardData || !$rewardData['status']) {
            //打赏不存在或者打赏已关闭
            $this->redirect('/Bz/CourseReward/rewardTeacherClose');
        }
        session('reward_course_id', $activity_id);
        session('reward_teacher_id', $reward_teacher_id);

        $reward_teacher = D('system_reward_teacher')->getObjByCourse_Id($activity_id);
        //  $courseInfo = D('school_course')->where(array('id' => $activity_id))->field('name')->find();
        //dump($courseInfo);
        $nopaydata['student_id'] = $student_id;
        $nopaydata['reward_id'] = $rewardData['id'];
        $nopaydata['course_id'] = $activity_id;
        $nopaydata['teacher_id'] = $reward_teacher['teacher_id'];

        $nopaydata['reward_teacher_id'] = $reward_teacher_id;
        $nopaydata['money'] = $money;
        $nopaydata['static_msg'] = '';
        $nopaydata['static_img'] = session("headImgUrl");
        //创建待打赏金额
        if (!D('student_no_pay_reward')->createOne($nopaydata)) {
            $this->redirect('/Bz/CourseReward/rewardTeacherClose');
        }

        //查询支付方式
        $payType = D('StudentPayType')->getSelectData(false);


        foreach ($payType as $k => $v) {
            switch ($v['student_pay_type_id']) {
                case '1':

                    $payType[$k]['student_pay_type_href'] = '/Bz/WxPay/payStudentRewardVideo';
                    break;

                    break;
                case '2':
                    $reward_pay_show_url = base64_encode(session('reward_pay_show_url'));
                    $pay_id = session('pay_id');
                    $pay_money = session('pay_money');
                    $payType[$k]['student_pay_type_href'] = "/Bz/Alipay/pay/type/7/pay_id/{$pay_id}/pay_money/{$pay_money}/reward_pay_show_url/{$reward_pay_show_url}";
                    break;
            }
        }

        $this->assign('payType', $payType);

        $this->display('rewardPayType');
    }

    /**
     * 打赏支付选择支付方式（打赏课程跟打赏老师公用）
     */
    public function rewardPayType()
    {
        $type = session('reward_type');
        $money = round(I('post.money'), 2);
        $msg = I('post.msg');
        if ($type != 'teacher' && $type != 'course') {
            exit('no rights');
        }

        if ($money < 0.01) {
            $this->redirect('/Bz/CourseReward/rewardTeacherBegin');
        }

        //打赏金额
        $this->assign('money', $money);
        $reward_teacher_data = session('reward_teacher_data');

        //查询当前打赏对象Id 2016-3-7
        $reward_teacher_id = D('system_reward_teacher')->getOneId($reward_teacher_data['reward']['other_id']);
        if (!$reward_teacher_id) {
            //打赏不存在或者打赏已关闭
            $this->redirect('/Bz/CourseReward/rewardTeacherClose');
        }
        $rewardData = D('system_reward')->getRewardByCourseId($reward_teacher_data['reward']['other_id']);
        if (!$rewardData || !$rewardData['status']) {
            //打赏不存在或者打赏已关闭
            $this->redirect('/Bz/CourseReward/rewardTeacherClose');
        }


        $nopaydata['student_id'] = session('reward_student_id');

        $nopaydata['reward_id'] = $reward_teacher_data['reward_teacher']['system_reward_id'];
        $nopaydata['course_id'] = $reward_teacher_data['reward']['other_id'];
        $nopaydata['teacher_id'] = $reward_teacher_data['reward_teacher']['teacher_id'];

        $nopaydata['reward_teacher_id'] = session('reward_teacher_id');
        $nopaydata['money'] = $money;
        $nopaydata['static_msg'] = $msg;

        //创建待打赏金额
        if (!D('student_no_pay_reward')->createOne($nopaydata)) {
            $this->redirect('/Bz/CourseReward/rewardTeacherClose');
        }

        //查询支付方式
        $payType = D('StudentPayType')->getSelectData(false);
        foreach ($payType as $k => $v) {
            switch ($v['student_pay_type_id']) {
                case '1':
                    switch ($type) {
                        case 'teacher':
                            $payType[$k]['student_pay_type_href'] = '/Bz/WxPay/payStudentRewardTeacher';
                            break;
                    }
                    break;
                case '2':
                    $reward_pay_show_url = base64_encode(session('reward_pay_show_url'));
                    $pay_id = session('pay_id');
                    $pay_money = session('pay_money');
                    $payType[$k]['student_pay_type_href'] = "/Bz/Alipay/pay/type/5/pay_id/{$pay_id}/pay_money/{$pay_money}/reward_pay_show_url/{$reward_pay_show_url}";
                    break;
            }
        }

        $this->assign('payType', $payType);

        $this->display('rewardPayType');
    }

    /**
     * 打赏成功
     */
    public function rewardTeacherSuccess()
    {
        $type = I('get.type');
        switch ($type) {
            case 'teacher':
                $url = U('Bz/CourseReward/rewardTeacherBegin');
                $is_continue = 1;
                break;
            default :
                $url = U('Bz/Index/Index');
                $is_continue = 0;
                break;
        }

        $this->assign('is_continue', $is_continue);
        $this->assign('url', $url);

        $this->display('rewardTeacherSuccess');
    }

    //打赏排名
    public function rewardRand()
    {
        $data = D('school_course_reward')->getOneObjectRewardStudentInfo(session('reward_course_id'));
        //  var_dump($data);
        $this->assign('data', $data);
        $this->display('rewardRand');
    }

    //获取打赏列表 ajax salty 2016-06-27 22:33:10
    public function rewardRandByCourseId()
    {
        $id = $_GET['id'];
        $data = D('school_course_reward')->getOneObjectRewardStudentInfo($id);
        $this->ajaxReturn($data);

        //	$this->assign('data', $data);
        //	$this->display('rewardRand');
    }


    //打赏推送
    public function cnlSocketNewReward()
    {
        $this_msg['name'] = '刘德华';
        $this_msg['msg'] = msubstr('讲得好，必须赞（测试）', 0, 20, 'utf-8', false);
        $this_msg['time'] = date('H:i');

        D('system_reward')->cnlSocketNewReward($this_msg, 11);
    }


    //查询某个学生的战绩
    public function getStudentRewardCount()
    {
        $course_id = session('reward_course_id');
        $mobile_phone = I('get.mobile_phone');

        //查询该手机号的个人信息
        $student_data = D('student')->getRepeat($mobile_phone, 'id,student_head_img,mobile_phone');
        if (!$student_data) {
            $this->ajaxReturn(array('ret' => 'false'));
        }

        //查询该人的个人战报
        $studentReward = D('school_course_reward')->getOneStudentCount($student_data['id'], $course_id);

        $ret['ret'] = 'true';
        $ret['student_data'] = $student_data;
        $ret['studentReward'] = $studentReward;

        //dump($ret);die;
        $this->ajaxReturn($ret);
    }


}