<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/2/18
 * Time: 20:57
 */

namespace Bz\Controller;
use Think\Controller;

class AjaxGetJsonController extends Controller
{
    //ajax获取city
    public function getJsonVillage()
    {
        $table = M('system_city_list');
        if(IS_AJAX)
        {
            $streets_id = I('get.streets_id');
            $village_list = $table->where('upid = '.$streets_id)->select();
            $this->ajaxReturn($village_list);
        }

    }
}