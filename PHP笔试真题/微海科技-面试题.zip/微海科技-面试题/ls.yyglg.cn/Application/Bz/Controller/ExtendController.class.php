<?php
namespace Bz\Controller;

use Think\Controller;

class ExtendController extends EmptyController
{
    /**
     * check user is login
     */
    Public function _initialize()
    {


        if ($this->is_login()) {


            cookie('baozhu_last_url', null);

            $this->student_id = session('student_id');

            $this->renew_student_id = session('student_id');


        } elseif ($this->is_exclude_list()) {

        } elseif ($this->is_renew()) {

            //就算没有登陆，如果是续费界面，也不跳转
            cookie('baozhu_last_url', $this->get_url());
            if (is_weixin()) {
                A('Wx')->wxuserautologin();
            }

            $this->renew_student_id = session('student_id');
            if (empty($this->renew_student_id)) {
                $this->redirect('/Bz/Index/index');
                die;
            }
        } else {
            //没有登陆过，并且是在需要登陆的界面
            cookie('baozhu_last_url', $this->get_url());

            if (is_weixin()) {
                A('Wx')->wxuserautologin();
            } else {
                $this->redirect('/Bz/Index/index');
                die;
            }
        }


    }

    /**
     * 检测是否登录,是否存在用户，是否被禁用
     *
     * @return bool
     */
    public function is_login()
    {
        $studentid = session('student_id');

        if (empty($studentid)) {
            return false;
        } else {
            $student_info = M('student')->field('*')->find(session('student_id'));




            if (empty($student_info)) {
                session('student_id', null);

                return false;
            } else {

                $sessionId = $student_info['login_session_id'];

                //2016-08-10 23:48:37 新加只能一处登陆的逻辑
                if (session_id() != $sessionId) {
                    if(

                        (ACTION_NAME=="index"&&CONTROLLER_NAME=="ActivityDetail")||
                        (ACTION_NAME=="indexVideo"&&CONTROLLER_NAME=="ActivityDetail")
                    )
                    {
                        //要重定向的页面
                        $this->redirect("/Bz/Show/signupError?msg=".urlencode("已在别处登陆！")."&btn=".urlencode("重新登陆")."&url=".urlencode("||baozhu||Login||Logout"));
                    }


                }


                if ($student_info['is_disable'] || empty($student_info['apply_type_id'])
                ) // || empty($student_info['end_time']) || $student_info['end_time'] < time()
                {
                    session('student_id', null);

                    return false;
                }
            }

            return true;
        }
    }

    //做一个排除列表
    protected function is_exclude_list()
    {
        $actionNameArray = array('Course', 'CourseSeat', 'Service');

        if (in_array(CONTROLLER_NAME, $actionNameArray)) {
            return true;
        }


        return false;
    }


    //判断是否为续费操作
    protected function is_renew()
    {
        $actionNameArray = array('studentRenew', 'studentRenewSelectPayType');

        if (CONTROLLER_NAME != 'Student' || !in_array(ACTION_NAME, $actionNameArray)) {
            return false;
        }


        return true;
    }

    function get_url()
    {
        $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
        $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
        $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self . (isset($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : $path_info);

//        if ($_SERVER['HTTP_HOST'] == '123.56.232.35' || $_SERVER['HTTP_HOST'] == 'ibaozhu.cn') {
//            $_SERVER['HTTP_HOST'] = 'ls.yyglg.cn';
//        }

        return $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url;
    }
}