<?php
namespace Bz\Controller;

use Think\Controller;

//服务小助手
class ServiceController extends ExtendController
{

    //服务小助手主页面
    public function index()
    {

        $student_id = session('student_id');

        if (!$student_id) {

            $this->redirect('/Baozhu/login');
        }

        $courseId = $_GET['courseId'];

        if (empty($courseId)) {
            $this->redirect('/Bz/Show/defaultError/errorCode/classroom_nonexists'); // 课程不存在
            exit();
        }
        //$courseId=-1;

        session('classroom_course_id', $courseId);
        //查询空调问题现在投票情况
        $this->assign('temperature_data', D('school_course_question_temperature')->getOneCourse($courseId));
        //查询灯光问题现在投票情况
        $this->assign('lamp_data', D('school_course_question_lamp')->getOneCourse($courseId));
        //查询音响问题现在投票情况
        $this->assign('music_data', D('school_course_question_music')->getOneCourse($courseId));
        //查询饮水文字
        $this->assign('water_data', D('school_course_question_water')->getOneCourse($courseId));
        //查询用餐问题
        $this->assign('food_data', D('school_course_question_food')->getOneCourse($courseId));

        $this->display('index');
    }

    //空调问题
    public function temperature()
    {
        $courseId = session('classroom_course_id');
        $seatNumber = session('classroom_seat_number');
        $student_id = session('student_id');

        if (!$student_id) {

            $this->redirect('/Baozhu/login');
        }

        if (!$seatNumber) {
            $seatNumber = -1;
        }


        $type = I('get.type');
        $ret = D('SchoolCourseQuestionTemperature')->setOne($courseId, $type, session('student_id'), $seatNumber);
        $this->ajaxReturn($ret);
    }

    //灯光和音响问题合并处理
    public function light()
    {
        $lamp = I('get.lamp');
        $music = I('get.music');
        if ($lamp != 'false') {
            $ret['lamp'] = $this->lamp($lamp);
        } else {
            $ret['lamp'] = 'false';
        }
        if ($music != 'false') {
            $ret['music'] = $this->music($music);
        } else {
            $ret['music'] = 'false';
        }
        $this->ajaxReturn($ret);
    }

    //音响问题
    private function music($type)
    {
        $courseId = session('classroom_course_id');
        $seatNumber = session('classroom_seat_number');
        $student_id = session('student_id');

        if (!$student_id) {

            $this->redirect('/Baozhu/login');
        }

        if (!$seatNumber) {
            $seatNumber = -1;
        }

        return D('SchoolCourseQuestionMusic')->setOne($courseId, $type, session('student_id'), $seatNumber);
    }

    //灯光问题
    private function lamp($type)
    {
        $courseId = session('classroom_course_id');
        $seatNumber = session('classroom_seat_number');
        $student_id = session('student_id');

        if (!$student_id) {

            $this->redirect('/Baozhu/login');
        }

        if (!$seatNumber) {
            $seatNumber = -1;
        }

        return D('SchoolCourseQuestionLamp')->setOne($courseId, $type, session('student_id'), $seatNumber);
    }

    //其他问题
    public function other()
    {
        $courseId = session('classroom_course_id');
        $seatNumber = session('classroom_seat_number');
        $student_id = session('student_id');
        $msg = I('get.msg');
        if (!$student_id) {

            $this->redirect('/Baozhu/login');
        }

        if (!$seatNumber) {
            $seatNumber = -1;
        }
        //	echo "courseId=$courseId,seatNumber=$seatNumber,student_id=$student_id,msg=$msg";
        $this->ajaxReturn(D('SchoolCourseQuestionOther')->createOne($courseId, $msg, $student_id, $seatNumber));

    }


}