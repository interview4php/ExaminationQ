<?php
namespace Bz\Controller;

use Think\Controller;

//上传认证资料
class LawyerProfileController extends Controller
{

    public function index()
    {
        $mobile_phone = session('student_mobile_phone');

        if ($mobile_phone == null || $mobile_phone == "") {
            redirect("/Baozhu/login");

        }

        if (D("student_lawyer_profile_approval")->existsApprovaling()) {

            $this->assign('student_authenticated_approving', "1");
            redirect("/Bz/UserCenter/index");

        }else
        {
            $this->assign('student_authenticated_approving', "0");
        }

        $this->display();

    }

    protected function chenUpload($fsave)
    {
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize = 1024 * 1024 * 40;// 设置附件上传大小
        $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->savePath = $fsave; // 设置附件上传目录
        $upload->thumbRemoveOrigin = false; //上传图片后删除原图片
        // 上传文件
        $info = $upload->upload();
        if (!$info) {// 上传错误提示错误信息
            return $upload->getError();
        } else {// 上传成功
            return $info;
        }
    }

    public function submit()
    {



        $mobile_phone = session('student_mobile_phone');
        if ($mobile_phone == null || $mobile_phone == "") {
            redirect("/Baozhu/login");

        }
        $obj = $this->chenUpload('./Upload/LawyerProfile/');


        $datadir = date('Ym');
        $save['pic_certificate'] = S_URL . '/Public/Upload/LawyerProfile/' . $datadir . '/' . $obj['pic_certificate']['savename'];
        $save['pic_idcard_front'] = S_URL . '/Public/Upload/LawyerProfile/' . $datadir . '/' . $obj['pic_idcard_front']['savename'];
        $save['pic_idcard_back'] = S_URL . '/Public/Upload/LawyerProfile/' . $datadir . '/' . $obj['pic_idcard_back']['savename'];
        $save['pic_other'] = S_URL . '/Public/Upload/LawyerProfile/' . $datadir . '/' . $obj['pic_other']['savename'];

//        $save['pic_certificate'] = ($_POST["pic_certificate"]);
//        $save['pic_idcard_front'] = ($_POST["pic_idcard_front"]);
//        $save['pic_idcard_back'] = ($_POST["pic_idcard_back"]);
//        $save['pic_other'] = ($_POST["pic_other"]);
        $save['certificate_no'] = $_POST["certificate_no"];

        $save['student_id'] = session('student_id');
        $save['mobile_phone'] = session('student_mobile_phone');
        $studentInfo = D("Student")->getRepeat(session('student_mobile_phone'));
        $save['school_student_number'] = $studentInfo['school_student_number'];
        $save['approval_status'] = "待审批";
        $save['true_name'] = $studentInfo["true_name"];
        $save['create_time'] = time();

        if (D("student_lawyer_profile_approval")->existsApprovaling()) {
            echo iconv("UTF-8", "GB2312", '您提交的资料正在审批，请返回。');
            exit();
        }

        D("student_lawyer_profile_approval")->add($save);


//        = $data['id'];
//        = $data['mobile_phone'];
//        session('account_binding_wxid') = $data['account_binding_wxid'];

        redirect("/Bz/UserCenter/index");

    }

}