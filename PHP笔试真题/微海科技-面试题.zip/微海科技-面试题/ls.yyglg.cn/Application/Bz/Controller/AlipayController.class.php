<?php
namespace Bz\Controller;

use Think\Controller;

class AlipayController extends Controller
{
    private $alipay_config;

    private $arr_show_url;

    //在类初始化方法中，引入相关类库
    public function _initialize()
    {
        $this->init_config();
    }

    public function init_config()
    {
        //↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
        //合作身份者id，以2088开头的16位纯数字
        //pid
        $this->alipay_config['partner'] = '2088421352074741';
        //收款支付宝账号，一般情况下收款账号就是签约账号
        $this->alipay_config['seller_id'] = '2088421352074741';
        //收款支付宝账号，一般情况下收款账号就是签约账号
        $this->alipay_config['seller_email'] = 'lingtianwang@qq.com';

        //安全检验码，以数字和字母组成的32位字符
        $this->alipay_config['key'] = 'i00dhdwa4um1srmpey7sojzwhb1u0ewk';

        //商户的私钥（后缀是.pen）文件相对路径
        $this->alipay_config['private_key_path'] = S_ROOT . 'Application/Common/Conf/Alipay/key/rsa_private_key.pem';

        //支付宝公钥（后缀是.pen）文件相对路径
        $this->alipay_config['ali_public_key_path'] = S_ROOT . 'Application/Common/Conf/Alipay/key/rsa_public_key.pem';

        //↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

        //签名方式 不需修改
        $this->alipay_config['sign_type'] = strtoupper('MD5');   // strtoupper('RSA');

        //字符编码格式 目前支持 gbk 或 utf-8
        $this->alipay_config['input_charset'] = strtolower('utf-8');

        //ca证书路径地址，用于curl中ssl校验
        //请保证cacert.pem文件在当前文件夹目录中
        $this->alipay_config['cacert'] = S_ROOT . 'Application/Common/Conf/Alipay/cacert.pem';

        //访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
        $this->alipay_config['transport'] = 'http';

        // 1.入社申请，2.单场课程，3.续费，4.升级，5.打赏
        $this->arr_show_url = array(
            1 => S_URL . U('Bz/School/applyType'),
            2 => S_URL . '',
            3 => S_URL . '',
            4 => S_URL . '',
            5 => S_URL . '',
            7 => S_URL . '',
        );
    }

    /**
     * pay all types
     *
     * 1.入社申请，2.单场课程，3.续费，4.升级，5.打赏, 6.活动报名, 7.打赏视频
     */
    public function pay($type, $pay_id = 0, $pay_money = 0.0)
    {
        //vendor("alipay_wap.lib.alipay_submit#class");
        vendor("alipay_direct.lib.alipay_submit#class");

        header("Content-type:text/html;charset=utf-8");
        if (is_weixin()) {
            $this->assign('img_url', '/Public/Bz2/images/prompt.png');
            $this->display('weixintip');
            exit();
        }

        switch ($type) {
            case 1:
                $pay_description = '抱柱网入社费用';
                if (empty($pay_id) || empty($pay_money)) {
                    \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');
                    $this->redirect('/Bz/School/index');
                }
                break;
            case 2:
                //查询该课程信息
                $where['id'] = $pay_id;
                $data = M('school_course')->where($where)->find();
                if (!$data) {
                    exit('无数据');//查询不到处理
                }

                $pay_description = '购买单场课程：' . ($data['name']);
                $pay_money = $data['one_money'];
                break;
            case 3:
                if (empty($pay_id) || empty($pay_money)) {
                    $this->redirect('/Bz/StudentRenew/studentRenew');
                }

                $data = D('student_no_pay_renew')->getOne($pay_id);
                //查询不到该条信息
                if (!$data) {
                    $this->redirect('/Bz/StudentRenew/studentRenew');
                }
                $pay_description = '会员续费（' . $data['apply_type_year'] . '年）';
                break;
            case 4:
                if (empty($pay_id) || empty($pay_money)) {
                    $this->redirect('/Bz/Student/studentUpgradeSelectPayType');
                }

                $data = D('student_no_pay_upgrade')->getOne($pay_id);
                //查询不到该条信息
                if (!$data) {
                    $this->redirect('/Bz/Student/studentUpgradeSelectPayType');
                }

                $pay_description = '会员升级';
                break;
            case 5:
                $pay_description = '打赏支付';
                if (empty($pay_id) || empty($pay_money)) {
                    $this->redirect('/Bz/CourseReward/rewardTeacherClose');
                }
                $this->arr_show_url[$type] = base64_decode($_GET['reward_pay_show_url']);
                break;
            case 6:
                $pay_description = '活动报名费用';
                if (empty($pay_id) || empty($pay_money)) {
                    $errorMsg = urlencode('URL参数错误');
                    $this->redirect("/Bz/Show/show_error/error_msg/{$errorMsg}");
                }
                $order_info = M('order')->find($pay_id);
                if (empty($order_info) || empty($order_info['order_number'])) {
                    $errorMsg = urlencode('URL参数错误');
                    $this->redirect("/Bz/Show/show_error/error_msg/{$errorMsg}");
                }

                $out_trade_no = $order_info['order_number'];

                $this->arr_show_url[$type] = base64_decode($_GET['pay_show_url']);
                break;

            case 7:
                $pay_description = '打赏视频';
                if (empty($pay_id) || empty($pay_money)) {
                    $this->redirect('/Bz/CourseReward/rewardTeacherClose');
                }
                $this->arr_show_url[$type] = base64_decode($_GET['reward_pay_show_url']);
                break;
            default:
                break;
        }

        if (($type >= 1 && $type <= 5) || $type == 7) {
            $out_trade_no = date('YmdHis') . mt_rand(100000, 999999);//商户订单号 通过支付页面的表单进行传递，注意要唯一！
            // add record to table y_order
            
            
            $order_data = array(
                'time' => time(),
                'order_type' => $type,
                'relate_id' => $pay_id,
                'money' => $pay_money,
                'pay_way' => 2,
                'order_number' => $out_trade_no,
            );
            $order_id = M('order')->add($order_data);
            if (empty($order_id)) {
                \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/Index/index', 'ERR');

                $this->redirect('/Bz/Index/index');
            }
        }


        /**************************请求参数**************************/
        $payment_type = "1"; //支付类型 //必填，不能修改
        $notify_url = S_URL . '/Bz/Alipay/notifyurl'; //服务器异步通知页面路径

        $jump_url = I('get.jump_url');
        $return_url = S_URL . "/Bz/Alipay/returnurl/jump_url/{$jump_url}"; //页面跳转同步通知页面路径

        $seller_email = C('alipay.seller_email');//卖家支付宝帐户必填


        $subject = $pay_description;  //订单名称 //必填 通过支付页面的表单进行传递
        $total_fee = $pay_money;   //付款金额  //必填 通过支付页面的表单进行传递
        $body = $pay_description;  //订单描述 通过支付页面的表单进行传递
        $show_url = $this->arr_show_url[$type];  //商品展示地址 通过支付页面的表单进行传递
        $anti_phishing_key = "";//防钓鱼时间戳 //若要使用请调用类文件submit中的query_timestamp函数
        $exter_invoke_ip = get_client_ip(); //客户端的IP地址
        //超时时间
        //$it_b_pay = $_POST['it_b_pay'];
        //选填
        //钱包token
        //$extern_token = $_POST['extern_token'];
        //选填
        /************************************************************/

        //构造要请求的参数数组，无需改动
        $parameter = array(
            "service" => "create_direct_pay_by_user",
            "partner" => trim($this->alipay_config['partner']),
            "seller_id" => trim($this->alipay_config['seller_id']),
            "payment_type" => $payment_type,
            "notify_url" => $notify_url,
            "return_url" => $return_url,
            "seller_email" => $seller_email,
            "out_trade_no" => $out_trade_no,
            "subject" => $subject,
            "total_fee" => $total_fee,
            "body" => $body,
            "show_url" => $show_url,
            "anti_phishing_key" => $anti_phishing_key,
            "exter_invoke_ip" => $exter_invoke_ip,
            //"it_b_pay"	=> $it_b_pay,
            //"extern_token"	=> $extern_token,
            "_input_charset" => trim(strtolower($this->alipay_config['input_charset']))
        );

        //建立请求
        $alipaySubmit = new \AlipaySubmit($this->alipay_config);

        $this->assign('html_text', $alipaySubmit->buildRequestForm($parameter, "get", "确认"));


        $this->display('payStudentRewardTeacher');
    }

    /**
     * 服务器异步通知页面方法
     * 其实这里就是将notify_url.php文件中的代码复制过来进行处理
     *
     **/
    function notifyurl()
    {
        //vendor("alipay_wap.lib.alipay_notify#class");
        vendor("alipay_direct.lib.alipay_notify#class");

        //计算得出通知验证结果
        $alipayNotify = new \AlipayNotify($this->alipay_config);
        $verify_result = $alipayNotify->verifyNotify();
        if ($verify_result) {
            //验证成功
            //获取支付宝的通知返回参数，可参考技术文档中服务器异步通知参数列表
            $out_trade_no = $_POST['out_trade_no'];      //商户订单号
            $trade_no = $_POST['trade_no'];          //支付宝交易号
            $trade_status = $_POST['trade_status'];      //交易状态
            $total_fee = $_POST['total_fee'];         //交易金额
            $notify_id = $_POST['notify_id'];         //通知校验ID。
            $notify_time = $_POST['notify_time'];    //通知的发送时间。格式为yyyy-MM-dd HH:mm:ss。
            $buyer_email = $_POST['buyer_email'];       //买家支付宝帐号；

            $parameter = array(
                "out_trade_no" => $out_trade_no, //商户订单编号；
                "trade_no" => $trade_no,     //支付宝交易号；
                "total_fee" => $total_fee,    //交易金额；
                "trade_status" => $trade_status, //交易状态
                "notify_id" => $notify_id,    //通知校验ID。
                "notify_time" => $notify_time,  //通知的发送时间。
                "buyer_email" => $buyer_email,  //买家支付宝帐号；
            );
            A('Public')->LogInfo("alipay支付notify  trade_status" . $_POST['trade_status']);
            if ($_POST['trade_status'] == 'TRADE_FINISHED') {
                //
            } else if ($_POST['trade_status'] == 'TRADE_SUCCESS') {
                //进行订单处理，并传送从支付宝返回的参数；
                //orderhandle($parameter);


                $str_ret = D('Order')->update_pay_status($out_trade_no, intval($total_fee * 100), $trade_no);
                if ($str_ret != 'success') {
                    A('Public')->LogInfo("alipay支付notify返回失败" . $str_ret);
                    exit("fail");
                }
            }

            echo "success";        //请不要修改或删除
            A('Public')->LogInfo("alipay支付notify返回成功" . $str_ret);
        } else {
            //验证失败
            A('Public')->LogInfo("alipay支付notify返回失败2");
            echo "fail";
        }
    }

    /**
     * 页面跳转处理方法；这里其实就是将return_url.php这个文件中的代码复制过来，进行处理；
     *
     */
    function returnurl($jump_url = '')
    {


        if (empty($jump_url)) {
            $jump_url = S_URL;
        } else {
            $jump_url = base64_decode($jump_url);
        }


        vendor("alipay_direct.lib.alipay_notify#class");

        header("Content-type: text/html; charset=utf-8");
        //头部的处理跟上面两个方法一样，这里不罗嗦了！
        $alipayNotify = new \AlipayNotify($this->alipay_config);//计算得出通知验证结果
        $verify_result = $alipayNotify->verifyReturn();




        if ($verify_result) {


            //验证成功
            //获取支付宝的通知返回参数，可参考技术文档中页面跳转同步通知参数列表
            $out_trade_no = $_GET['out_trade_no'];      //商户订单号
            $trade_no = $_GET['trade_no'];          //支付宝交易号
            $trade_status = $_GET['trade_status'];      //交易状态
            $total_fee = $_GET['total_fee'];         //交易金额
            $notify_id = $_GET['notify_id'];         //通知校验ID。
            $notify_time = $_GET['notify_time'];       //通知的发送时间。
            $buyer_email = $_GET['buyer_email'];       //买家支付宝帐号；

            $parameter = array(
                "out_trade_no" => $out_trade_no,      //商户订单编号；
                "trade_no" => $trade_no,          //支付宝交易号；
                "total_fee" => $total_fee,         //交易金额；
                "trade_status" => $trade_status,      //交易状态
                "notify_id" => $notify_id,         //通知校验ID。
                "notify_time" => $notify_time,       //通知的发送时间。
                "buyer_email" => $buyer_email,       //买家支付宝帐号
            );

            if ($_GET['trade_status'] == 'TRADE_FINISHED' || $_GET['trade_status'] == 'TRADE_SUCCESS') {
                //进行订单处理，并传送从支付宝返回的参数；
                //orderhandle($parameter);
                echo '支付成功，请稍后查询';
                exit();
                $str_ret = D('Order')->update_pay_status($out_trade_no, intval($total_fee * 100), $trade_no);
                echo '$str_ret=' . $str_ret;

                if ($str_ret != 'success') {
                    echo "success";
                    exit();
                    $this->redirect($jump_url);//跳转到配置项中配置的支付失败页面；C('alipay.errorpage')
                } else {
                    echo "fail";
                    exit();
                    $this->redirect($jump_url);//跳转到配置项中配置的支付成功页面；C('alipay.successpage')
                }
            } else {
                //echo "trade_status=" . $_GET['trade_status'];
                $this->redirect($jump_url);//跳转到配置项中配置的支付失败页面；C('alipay.errorpage')
            }
        } else {
            //验证失败
            //如要调试，请看alipay_notify.php页面的verifyReturn函数
            //echo "<h1>支付失败！</h1>";
            echo "fail2";
            $this->redirect($jump_url);
        }
    }
}

?>