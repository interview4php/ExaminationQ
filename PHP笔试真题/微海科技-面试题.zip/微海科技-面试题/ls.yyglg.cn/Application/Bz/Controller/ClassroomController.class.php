<?php
namespace Bz\Controller;

use Think\Controller;

//课程模式里面的操作
class ClassroomController extends ExtendController
{

	//课堂模式主页面
	public function index()
	{
		$courseId = I('courseId');
		$placeId = I('placeId');

		if (empty($courseId)) {
			$this->redirect('/Bz/Show/defaultError/errorCode/classroom_nonexists');    // 课程不存在
		}


		if (empty($placeId)) {
			$placeId = 0;
		}

		//查询该课程的信息
		$course_field = 'id,href_question_to_teacher,href_course_score,href_do_homework,is_socket';
		$course_data = D('school_course')->getOne($courseId, $course_field);

		if (!$course_data) {
			//该课程不存在处理
			$this->redirect('/Bz/Show/defaultError/errorCode/classroom_nonexists');
		}

//	var_dump($course_data);
//		exit();

		//去掉控制是否开启课程的逻辑，默认总是开启 2016-07-08 23:56:58 salty
		if(!$course_data['is_socket']){
			//该课程模式未开启
			$this->redirect('/Bz/Show/defaultError/errorCode/classroom_socket_is_false');
		}


		//查看该学生该课程状态
		$student_course_status = D('student_course')->getStatus($courseId, session('student_id'));
		if (!$student_course_status || $student_course_status['status'] == '2') {
			//未报名该课程或者已请假处理
			$this->redirect('/Bz/Show/defaultError/errorCode/classroom_not_sign_up');
		}
		//header('Content-type:text/html;charset=utf-8');dump($student_course_status);die;
		session('classroom_course_id', $courseId);



		if ($student_course_status['see_type'] == '现场' || $student_course_status['see_type'] == '主会场') {
			//检查该学生是否有座位
			$ret = D('StudentCourseSeat')->getOne($courseId, session('student_id'));
			if (!$ret) {
				//无座位处理
				//$this->redirect('/Bz/Show/defaultError/errorCode/classroom_no_seat');
				$ret = array('seat_address' => '未选座');
				$see_type['dianzipiao'] = 'javascript:void(0);';
				$see_type['has_dianzipiao'] = 0;
			} else {
				//电子票跳到座位号
				$see_type['dianzipiao'] = U('Bz/CourseSeat/showStudentSeat/courseId/' . $courseId);
				$see_type['has_dianzipiao'] = 1;
			}

			session('classroom_seat_number', $ret['seat_address']);

		} else {
			//检查该学生是否有直播码
			$student_fcode = D('student_course_fcode')->getOne(session('student_id'), $courseId);
			if (!$student_fcode) {
				//无F码处理	
				//$this->redirect('/Bz/Show/defaultError/errorCode/classroom_no_fcode');
				$see_type['dianzipiao'] = 'javascript:void(0);';
				$see_type['has_dianzipiao'] = 0;
			} else {
				//电子票跳到F码
				$see_type['dianzipiao'] = U('Bz/CourseSeat/showStudentFcode2/courseId/' . $courseId);
				$see_type['has_dianzipiao'] = 1;
			}
		}

		$see_type['see_type'] = $student_course_status['see_type'];
		//查询该课程所有PPT
		$this->assign('coursePPT', D('school_course_ppt')->getOneCourseAll($courseId));

		//查询当前显示中的PPT
		$this->assign('is_show_now_ppt_id',D('school_course_ppt')->field('id')->where(array('course_id'=>$courseId,'is_show_now'=>1))->find());
		$this->assign('see_type', $see_type);
		$this->assign('mobile_phone', md5(session('student_mobile_phone')));

		$student_data = M('student')->find(session('student_id'));

		$this->assign('student_data', $student_data);
		$this->assign('course_id', $courseId);
		$this->assign('course_data', $course_data);

		$this->display('index');
	}

	//提交聊天内容
	public function setClassroomMsg()
	{
		$head_img = I('post.head_img');
		$msg = I('post.msg');
		$user_id = I('post.user_id');
		$course_id = session('classroom_course_id');
		if (!$msg || !$course_id || !$user_id) {
			$error = array('ret' => 'false', 'msg' => '参数不对');
		} else {
			if(D('school_course_send_msg')->addMsg($course_id,$user_id,$head_img,$msg)){
				$error = array('ret' => 'true', 'msg' => '发表成功');
			}else{
				$error = array('ret' => 'false', 'msg' => '发送失败');
			}
		}
		$this->ajaxReturn($error);
	}



}