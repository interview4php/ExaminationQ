<?php
namespace Bz\Controller;

use Think\Controller;

//座位
class CourseSeatController extends ExtendController
{
    //会场，所有座位显示
    public function index()
    {

        $courseId = I('courseId');
        $placeId = I('placeId');

        if (empty($courseId)) {
            $this->redirect('/Bz/Show/defaultError/errorCode/classroom_nonexists');    // 课程不存在
        }
        if (empty($placeId)) {
            $placeId = 0;
        }

        session('courseseat_course_id', $courseId);
        session('courseseat_place_id', $placeId);
        //查询该课程
        $data = D('SchoolCourseSeat')->getByCourseAndPlace($courseId, $placeId);


        if ($data && $data['status'] == '1') {

            //查询学生座位
            $seat_list = M('SchoolCourseSeatList')->field('id,one,two,status,student_id,address')->where(array('school_course_seat_id' => $data['school_course_seat_id']))->select();
            $seat_array = array();
            foreach ($seat_list as $k => $v) {
                $seat_array[$v['one']][$v['two']] = $v;
            }

            $data['seat_array'] = $seat_array;

        } else {

            if (empty($data)) {
                //没有座位
                $this->redirect('/Bz/Show/defaultError/errorCode/classroom_no_seat');
            } else {
                //座位未开放
                $this->redirect('/Bz/Show/defaultError/errorCode/classroom_seat_lock');
            }
        }
        //exit("ccc".session('user_is_false_sign')."ddd");
        //查询该用户是否已经签到了该课程

        //这里需要登陆？？？ salty改student_id为sign_student_id
        if (session('user_is_false_sign') != ('yes' . $courseId . (session('sign_student_id')))) {
            $this->redirect('/Bz/Kcqd/index/courseId/' . $courseId);
        }

        if (D('student_course')->isRewardVip($courseId, session('student_id'))) {
            $this->assign('is_reward_vip', 'true');
        } else {
            $this->assign('is_reward_vip', 'false');
        }

        $data['address_time'] = date('Y年m月d日', $data['address_time']);
        $this->assign('data', $data);
        //dump($data);die;

        $this->assign('bg_url', '/Public/Bz2/images/congratulation-b.gif');

        $this->display('index');
    }

    //选择座位（操作）
    public function setStudentSeat()
    {
        $session_mobile_phone = session('sign_mobile_phone');
        $student_id = session('sign_student_id');

        $seatOne = I('get.seatOne');//座位一维坐标
        $seatTwo = I('get.seatTwo');//座位二维坐标

        $courseId = session('courseseat_course_id');//课程ID
        $placeId = session('courseseat_place_id');

      
        if ($student_id == -1) {
            //非会员报名签到选座位

            $ret = D('SchoolCourseSeat')->setStudentSeatByCourseAndPlaceByMobile($courseId, $placeId, $seatOne, $seatTwo, session('sign_student_id'),$session_mobile_phone);
            $this->ajaxReturn($ret);

        } else {
            //会员报名签到选座位

            //普通选座
            $ret = D('SchoolCourseSeat')->setStudentSeatByCourseAndPlace($courseId, $placeId, $seatOne, $seatTwo, session('sign_student_id'));
            $this->ajaxReturn($ret);
        }


    }

    /**
     * 展示现场座位电子票
     *
     * @param $courseId
     */
    public function showStudentSeat($courseId)
    {


        $student_id = session('sign_student_id');
        if ($student_id == null || $student_id == "") {
            $student_id = session('student_id');
        }



        if ($student_id==-1)
        {
            //非注册会员签到展示

            $session_mobile_phone = session('sign_mobile_phone');
            //展示某个用户的某个课程的电子票
            $ret = D('StudentCourseSeat')->getOneWithMobile($courseId, $student_id,$session_mobile_phone);


            $placeId = $ret['activity_place_id'];


            if (!$ret) {
                // 是否已报名
                $sign_up_ret = M('StudentCourse')->where(array('school_course_id' => $courseId,'msg'=>'非注册会员报名，手机号'.$session_mobile_phone.'%'))->find();



                if (!$sign_up_ret) {
                    $this->redirect('/Bz/Show/error_not_sign_up');
                }

                // 是否已签到
                $sign_ret = M('StudentCourseSign')->where(array('course_id' => $courseId, 'student_id' => $student_id,'mobile'=>$session_mobile_phone))->find();
                if (!$sign_ret) {
                    $this->redirect('/Bz/Show/error_not_sign');
                }


                $this->redirect('/Bz/Show/defaultError/errorCode/classroom_no_seat');
                //不自动跳到签到页
                //$this->redirect('/Bz/CourseSeat/index/courseId/' . $courseId);
            }

            //查询课程名字
            $field = 'name,address';
            $where['id'] = $placeId;
            $ret['course_data'] = M('activity_place')->field($field)->where($where)->find();


            $this->assign('data', $ret);
            $this->assign('bg_url', '/Public/Bz2/images/congratulation-b.gif');
            //微信配置
            $this->assign('wx', A('Wx')->getSignature(A('Wx')->get_url()));

            $this->display('showStudentSeatForNoMember');



        }else
        {

            //普通展示

            if (empty($student_id)) {
                $this->redirect('/Baozhu/Login/index');
            }

            //查询学生详细信息
            $student_info = D('student')->getStudentInfo($student_id);
            if (empty($student_info)) {
                session('student_id', null);

                \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

                $this->redirect('/Bz/School/index');
            }

            //展示某个用户的某个课程的电子票
            $ret = D('StudentCourseSeat')->getOne($courseId, $student_id);

            $placeId = $ret['activity_place_id'];

            if (!$ret) {
                // 是否已报名
                $sign_up_ret = M('StudentCourse')->where(array('school_course_id' => $courseId, 'student_id' => $student_id))->find();
                if (!$sign_up_ret) {
                    $this->redirect('/Bz/Show/error_not_sign_up');
                }

                // 是否已签到
                $sign_ret = M('StudentCourseSign')->where(array('course_id' => $courseId, 'student_id' => $student_id))->find();
                if (!$sign_ret) {
                    $this->redirect('/Bz/Show/error_not_sign');
                }


                $this->redirect('/Bz/Show/defaultError/errorCode/classroom_no_seat');
                //不自动跳到签到页
                //$this->redirect('/Bz/CourseSeat/index/courseId/' . $courseId);
            }

            //查询课程名字
            $field = 'name,address';
            $where['id'] = $placeId;
            $ret['course_data'] = M('activity_place')->field($field)->where($where)->find();


            $this->assign('data', $ret);
            $this->assign('bg_url', '/Public/Bz2/images/congratulation-b.gif');
            //微信配置
            $this->assign('wx', A('Wx')->getSignature(A('Wx')->get_url()));

            $this->display('showStudentSeat');

        }


    }

    /**
     * 展示直播观看F码
     */
    public function showStudentFcode()
    {
        $courseId = I('get.courseId');//课程ID
        $student_fcode = D('student_course_fcode')->getOne(session('student_id'), $courseId);
        if (!$student_fcode) {
            //无F码处理
            $this->redirect('/Bz/Show/defaultError/errorCode/classroom_no_fcode');
        }

        //查询课程名字
        $field = 'name,address';
        $where['id'] = $courseId;
        $student_fcode['course_data'] = M('school_course')->field($field)->where($where)->find();
        //dump($ret);die;
        $this->assign('data', $student_fcode);

        $this->display('showStudentFcode');
    }

    /**
     * 展示直播观看F码
     */
    public function showStudentFcode2()
    {
        $courseId = I('get.courseId');//课程ID
        $student_fcode = D('student_course_fcode')->getOne(session('student_id'), $courseId);
        if (!$student_fcode) {
            //无F码处理
            $this->redirect('/Bz/Show/defaultError/errorCode/classroom_no_fcode');
        }

        //查询课程名字
        $field = 'name,address';
        $where['id'] = $courseId;
        $student_fcode['course_data'] = M('school_course')->field($field)->where($where)->find();
        //dump($ret);die;
        $this->assign('data', $student_fcode);

        $this->display('showStudentFcode2');
    }
}