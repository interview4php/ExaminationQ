<?php
namespace Bz\Controller;

use Think\Controller;

//显示界面
class ShowController extends Controller
{

    public function signupError()
    {
       // echo "test";
        $errorMsg =  str_replace("||" ,'/' ,$_GET['msg'])  ; ;
        $data['button_value']=$_GET['btn'];
        $data['button_url']=str_replace("||" ,'/' ,$_GET['url'])  ;
        $this->assign('errorMsg', $errorMsg);
        $this->assign('data', $data);
        $this->display();
    }

    public function errorOne()
    {
        //查询提示语
        $this->assign('data', M('html_login_content')->field('content,url')->find());

        $is_in_iphone = is_iphone();
        $this->assign('is_in_iphone', $is_in_iphone);

        A('Public')->myD('errorOne', '课程报名');
    }

    public function errorTwo()
    {
        $is_in_iphone = is_iphone();

        $this->assign('is_in_iphone', $is_in_iphone);
        $this->assign('msg', I('get.msg'));

        A('Public')->myD('errorTwo', '课程报名');
    }

    public function successOne()
    {
        $is_in_iphone = is_iphone();
        $this->assign('is_in_iphone', $is_in_iphone);

        //查询提示语
        $where['type'] = 'ShowSuccessOne';

        $this->assign('data', M('html_system_text_setup')->where($where)->field('title,content,img,button_value')->find());

        A('Public')->myD('successOne', '报名成功');
    }

    //会员有效期已过期
    public function errorFalseexpireday()
    {
        $is_in_iphone = is_iphone();
        $this->assign('is_in_iphone', $is_in_iphone);

        A('Public')->myD('errorFalseexpireday', '抱柱网');
    }

    //统一报错页面
    public function defaultError()
    {
        $errorCode = I('get.errorCode');
        switch ($errorCode) {
            case 'classroom_nonexists':
                $errorMsg = '课程不存在';
                break;
            case 'classroom_not_sign_up':
                $errorMsg = '未报名该课程';
                break;
            case 'classroom_no_seat':
                $errorMsg = '还没有座位';
                break;
            case 'classroom_seat_lock':
                $errorMsg = '座位还没有开放';
                break;
            case 'classroom_no_fcode':
                $errorMsg = '还没有F码';
                break;
            case 'classroom_online_sign_in_err':
                $errorMsg = '对不起，您报名的课程是直播课程<br />您还无法现场签到';
                break;
            case 'reward_obj_not_open':
                $errorMsg = '打赏对象未开启';
                break;
            case 'err_open_in_weixin':
                $errorMsg = '请在微信打开';
                break;
            case 'account_forbidden':
                $errorMsg = '账号已被锁定，请联系管理员';
                break;
            case 'end_time_gt_2_year':
                $errorMsg = '您的社员有效期在两年以上，暂不支持系统升级。';
                break;
            case 'func_closed':
                $errorMsg = '该功能已关闭，请联系管理员';
                break;
            case 'waitting_student_pay_closed':
                $errorMsg = '铁杆报名已结束';
                break;
            case 'is_have_direct_seeding':
                $errorMsg = '您已报名直播，需在课表先请假';
                break;
            case 'classroom_socket_is_false':
                $errorMsg = '课程模式仅在上课期间开启';
                break;
            case 'other':
                $errorMsg = I('get.errorMsg');
                break;

            default :
                $errorMsg = '对不起，出错了';
                break;
        }

        $this->assign('errorMsg', $errorMsg);
        //查询提示语
        $where['type'] = 'ShowSuccessOne';
        $this->assign('data', M('html_system_text_setup')->where($where)->field('title,content,img,button_value')->find());

        A('Public')->myD('defaultError', '出错了');
    }

    public function activity_not_open_for_sign_up()
    {
        $errorMsg = '该活动未开启报名';

        $this->assign('errorMsg', $errorMsg);
        //查询提示语
        $where['type'] = 'ShowSuccessOne';
        $this->assign('data', M('html_system_text_setup')->where($where)->field('title,content,img,button_value')->find());

        A('Public')->myD('defaultError', '出错了');
    }

    public function input_error()
    {
        $errorMsg = '输入出错';

        $this->assign('errorMsg', $errorMsg);
        //查询提示语
        $where['type'] = 'ShowSuccessOne';
        $this->assign('data', M('html_system_text_setup')->where($where)->field('title,content,img,button_value')->find());

        A('Public')->myD('defaultError', '出错了');
    }

    public function sign_up_error()
    {
        $errorMsg = '报名错误，请稍后再试';

        $this->assign('errorMsg', $errorMsg);
        //查询提示语
        $where['type'] = 'ShowSuccessOne';
        $this->assign('data', M('html_system_text_setup')->where($where)->field('title,content,img,button_value')->find());

        A('Public')->myD('defaultError', '出错了');
    }

    public function sign_up_success()
    {
        $is_in_iphone = is_iphone();
        $this->assign('is_in_iphone', $is_in_iphone);

        //查询提示语
        $where['type'] = 'ShowSuccessOne';

        $this->assign('data', M('html_system_text_setup')->where($where)->field('title,content,img,button_value')->find());

        A('Public')->myD('successOne', '报名成功');
    }

    //统一成功页面
    public function defaultSuccess()
    {
        $errorCode = I('get.errorCode');
        switch ($errorCode) {
            case 'other':
                $errorMsg = I('get.errorMsg');
                break;

            default :
                $errorMsg = '操作成功';
                break;
        }

        $this->assign('errorMsg', $errorMsg);
        //查询提示语
        $where['type'] = 'ShowSuccessOne';
        $this->assign('data', M('html_system_text_setup')->where($where)->field('title,content,img,button_value')->find());
        A('Public')->myD('defaultSuccess', '操作成功');
    }

    public function show_error($error_msg = '')
    {
        $error_msg = urldecode($error_msg);

        $this->assign('errorMsg', $error_msg);
        //查询提示语
        $where['type'] = 'ShowSuccessOne';
        $this->assign('data', M('html_system_text_setup')->where($where)->field('title,content,img,button_value')->find());

        A('Public')->myD('defaultError', '出错了');
    }

    public function error_not_sign_up()
    {
        $this->assign('errorMsg', '您还未报名该课程');

        //查询提示语
        $where['type'] = 'ShowSuccessOne';
        $this->assign('data', M('html_system_text_setup')->where($where)->field('title,content,img,button_value')->find());

        A('Public')->myD('defaultError', '出错了');
    }

    public function error_not_sign()
    {
        $this->assign('errorMsg', '您还未签到');

        //查询提示语
        $where['type'] = 'ShowSuccessOne';
        $this->assign('data', M('html_system_text_setup')->where($where)->field('title,content,img,button_value')->find());

        A('Public')->myD('defaultError', '出错了');
    }
}