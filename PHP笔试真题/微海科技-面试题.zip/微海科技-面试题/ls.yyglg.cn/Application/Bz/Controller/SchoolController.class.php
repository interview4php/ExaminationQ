<?php
namespace Bz\Controller;

use Think\Controller;

//入社
class SchoolController extends Controller
{
    //判断是否会员
    public function submit()
    {
        $student = M('student')->field('*')
            ->where(array(
                    'user_name' => $_POST['name'],
                    'mobile_phone' => $_POST['phone'])
            )->find();

        if ($student) {
            if ($student['end_time'] >= time()) {
                echo 1;
            } else {
                session('renew_student_id', $student['id']);
                echo 2;
            }
        } else {
            echo 0;
        }

    }

    //抱柱大学申请
    public function index()
    {
//var_dump(D('StudentVocation')->getSelectData());
        $this->assign('vocationData', D('StudentVocation')->getSelectData());

        $this->assign('positionData', D('StudentPosition')->getSelectData());

        //入社渠道
        if ($_GET['apply_channel_id']) {
            cookie('apply_channel_id', trim($_GET['apply_channel_id']));
        } else {
            cookie('apply_channel_id', 'default');
        }


        $this->assign('password', cookie('apply_password'));
        $this->assign('confirmPassword', cookie('apply_confirmPassword'));

        $this->assign('true_name', cookie('apply_true_name'));
        $this->assign('mobile_phone', cookie('apply_mobile_phone'));
        $this->assign('mobile_phone_code', cookie('apply_mobile_phone_code'));
        $this->assign('wx', cookie('apply_wx'));
        $this->assign('company', cookie('apply_company'));
        $this->assign('vocation', cookie('apply_vocation'));
        $this->assign('vocation_id', cookie('apply_vocation_id'));
        $this->assign('position', cookie('apply_position'));
        $this->assign('position_id', cookie('apply_position_id'));


        if ($_POST['pid'] && $_POST['pname']) {

            cookie('apply_position_id', trim($_POST['pid']));
            cookie('apply_position', trim($_POST['pname']));


            $this->assign('position', trim($_POST['pname']));
            $this->assign('position_id', trim($_POST['pid']));
        }

        if ($_POST['vid'] && $_POST['vname']) {
            cookie('apply_vocation_id', trim($_POST['vid']));
            cookie('apply_vocation', trim($_POST['vname']));


            $this->assign('vocation', trim($_POST['vname']));
            $this->assign('vocation_id', trim($_POST['vid']));
        }

        //查询大学申请需要的表单
        $this->assign('needField', D('HtmlApplyInput')->getApplySchoolNeedField());
        //dump($this->needField);

        $this->display('index');


    }

    //抱柱大学申请
    public function inner()
    {
        header("Content-type: text/html; charset=utf-8");
        if ($_POST['idtype']) {
            session('postidtype_id', $_POST['idtype']);//类型
            session('post_id_count', $_POST['id_count']);//年数
        }


        $this->assign('password', cookie('apply_password'));
        $this->assign('confirmPassword', cookie('apply_confirmPassword'));


        $this->assign('true_name', cookie('apply_true_name'));
        $this->assign('mobile_phone', cookie('apply_mobile_phone'));
        $this->assign('mobile_phone_code', cookie('apply_mobile_phone_code'));
        $this->assign('wx', cookie('apply_wx'));
        $this->assign('company', cookie('apply_company'));
        $this->assign('vocation', cookie('apply_vocation'));
        $this->assign('vocation_id', cookie('apply_vocation_id'));
        $this->assign('position', cookie('apply_position'));
        $this->assign('position_id', cookie('apply_position_id'));
        $this->assign('position_id', cookie('apply_position_id'));
        $this->assign('position_id', cookie('apply_position_id'));
        if ($_POST['pid'] && $_POST['pname']) {
            $this->assign('position', trim($_POST['pname']));
            $this->assign('position_id', trim($_POST['pid']));
        }

        if ($_POST['vid'] && $_POST['vname']) {
            $this->assign('vocation', trim($_POST['vname']));
            $this->assign('vocation_id', trim($_POST['vid']));
        }

        //查询大学申请需要的表单
        $this->assign('needField', D('HtmlApplyInput')->getApplySchoolNeedField());
        //dump($this->needField);

        $this->display('inner');
    }

    //查询行业
    public function vocation2()
    {
        //保存资料 cookie
        D('School')->saveApplyInfo();
        $this->assign('vocationData', D('StudentVocation')->getSelectData());
        $this->display('vocation2');
    }

    //进入选择选择行业，这时候需要保存一下 salty
    public function vocation()
    {


        $this->assign('vocationData', D('StudentVocation')->getSelectData());
        $this->assign('apply_channel_id', cookie('apply_channel_id'));
        $this->display('vocation');
    }

    //查询职业
    public function position2()
    {
        //保存资料 cookie
        D('School')->saveApplyInfo();
        $this->assign('positionData', D('StudentPosition')->getSelectData());
        $this->display('position2');
    }

    //进入选择职位 salty
    public function position()
    {
        //保存资料 cookie
        D('School')->saveApplyInfo();
        $this->assign('positionData', D('StudentPosition')->getSelectData());
        $this->assign('apply_channel_id', cookie('apply_channel_id'));
        $this->display('position');
    }

    //选择入社模式(salty修改逻辑为先插入，在选择模式)
    public function applyType()
    {
        //查询入社模式


        $ifOk = session('apply_mobile_phone_check');
        $mobile = session('apply_mobile_phone');

        if ($mobile == null || $mobile == "" || $ifOk != 1) {
            // todo 做提示
            echo "error";
            die();
        } else {



            $this->assign('applyType', D('StudentApplyType')->getSelectData());
            $this->assign('is_tip_after_tiegan', '0');
            $user_data = D('student')->getRepeat($mobile);
            if ($user_data)
            {
//                $this->display('applyType');
//如果已经存在
                $this->display('applyType');
                die();
            }

            //有数据

            // 保存到数据库然后在做提示升级为哪种会员 salty 2016-06-20 21:10:56

            $password = session('apply_password');

            $password = sha1($password, true);
            $password = base64_encode($password);
            $cur_time = time();
            $ins_data = array();

            $ins_data['pwd'] = $password;

            $ins_data['true_name'] = session('apply_true_name');
            $ins_data['student_type'] = '临时会员';
            $ins_data['student_wx'] = session('apply_wx');
            $ins_data['company_name'] = session('apply_company');
            $ins_data['company_vocation_id'] = session('apply_vocation_id');
            $ins_data['company_position_id'] = session('apply_position_id');
            $ins_data['apply_type_id'] = -1;
            $ins_data['end_time'] = $cur_time - 1;
            $ins_data['update_time'] = $cur_time;
            $ins_data['school_student_number'] = D('HtmlSystemSetup')->createStudentNumber();
            $ins_data['mobile_phone'] = $mobile;
            $ins_data['time'] = $cur_time;
            $ins_data['student_authenticated'] = '0';
            $ret1 = D('Student')->createApplyOne($ins_data);


            if (!$ret1) {
                $this->display('applyType');

            } else {
                // add by char
                $where['mobile_phone'] = $mobile;
                $data = M('student')->field('id,mobile_phone,account_binding_wxid')->where($where)->find();
                session('student_id', $data['id']);
                session('mobile_phone', $data['mobile_phone']);
                $session_id= session_id();
                $data['login_session_id']=$session_id;

                M('student')->save($data);
                //add by char end

                $ins_data['id']=$ret1;
                D('student')->setLoginSession($ins_data);
//                session('apply_mobile_phone', "");

                D('School')->clearApplyInfo();

                $this->display('applyType');
            }
        }


    }

    public function applyType2()
    {
        //查询入社模式
        $this->assign('applyType', D('StudentApplyType')->getSelectData());
        $this->assign('is_tip_after_tiegan', '1');
        $this->display('applyType');
    }

    //显示铁杆入社问答页面
    public function tieganWenDa()
    {
        $this->display('tieganWenDa');
    }

    //选择入社学费支付方式
    public function indexSelectPayType()
    {
        //如果推荐人信息不为空, 则将推荐人信息保存到cookie中, 支付后插入到数据库中
        cookie('recommand_info', trim(I('post.recommand_info')));

        $apply_type_id = I('post.id');

        //这个是搞多少年
        $apply_type_count = I('post.id_count');

        //  echo $apply_type_count;
        //  echo "<br/>";
        //  echo  $apply_type_id;

        //查询该入社方式是否存在
        $ret = D('StudentApplyType')->where(array('student_apply_type_id' => $apply_type_id))->find();
        if (!$ret) {
            $this->redirect('/Bz/School/applyType');
        }

        $money = $ret['student_apply_type_price'] * $apply_type_count;

        // 测试用，不要删
        if ('18682157284' == session('apply_mobile_phone') || '18822865622' == session('apply_mobile_phone')) {
            $money = 0.01;
        }
        session("pay_apply_type", $ret['student_apply_type_name']);
        session('apply_count_money', $money);
        session('pay_money', $money);

        $this->assign('money', $money);

        //保存交费信息 student_no_pay为未支付表
        if (!D('student_no_pay')->createOne($apply_type_id, $apply_type_count, $money)) {


            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/Index/index', 'ERR');

            $this->redirect('/Bz/Index/index');
        }

        $reg_jump_url = session('reg_jump_url');
        if (!empty($reg_jump_url)) {
            $reg_jump_url = base64_encode($reg_jump_url);
        }
        //支付方式
        $payType = D('StudentPayType')->getSelectData();
        foreach ($payType as $key => $value) {
            if ($value['student_pay_type_name'] == '支付宝支付') {
                $pay_id = session('pay_id');
                $pay_money = session('pay_money');
                $payType[$key]['student_pay_type_href'] = "/Bz/Alipay/pay/type/1/pay_id/{$pay_id}/pay_money/{$pay_money}/jump_url/{$reg_jump_url}";
            } elseif ($value['student_pay_type_name'] == '微信支付') {
                $payType[$key]['student_pay_type_href'] = "/Bz/WxPay/pay/jump_url/{$reg_jump_url}";
            }
        }

        $this->assign('payType', $payType);

        $this->display('indexSelectPayType');

    }

    //入社申请，针对线下汇款用户
    public function trueApply()
    {
        //该控制器只为测试，真正环境应为直接调用模型不是调用控制器
        header('Content-type:text/html;charset=utf-8');
        dump('我是申请（我是操作，无界面显示，执行于支付接口的通知成功接口）');

        //增加一个入社申请，该接口增加的数据需要后台审核才能生出会员
        $ret = D('StudentApply')->createOneApply(session('student_id'));
        dump($ret);
    }

    //入社成功，针对直接付款用户
    public function schoolStudent()
    {

        //该控制器只为测试，真正环境应为直接调用模型不是调用控制器
        header('Content-type:text/html;charset=utf-8');
        dump('入社成功（我是操作，无界面显示，执行于支付接口的通知成功接口）');

        //新增一个学员
        $ret = D('SchoolStudent')->createOneSchoolStudent(session('student_id'), session('apply_type_id_input'), session('end_time_input'));
        dump($ret);
    }


    //发送验证码
    public function sendShortMsg()
    {
        $mobile_phone = trim($_GET['mobile_phone']);
        vendor('yzm.cShortMsg');
        $yzm = new \cShortMsg();
        //验证手机号正确性
        if (!\cShortMsg::checkMobilePhone($mobile_phone)) {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '请输入正确的手机号'));
        }

        //验证手机号是否已经被注册
        $student_info = D('Student')->getRepeat($mobile_phone);
        if ($student_info['end_time'] && $student_info['apply_type_id']) {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '手机号已经被注册了'));
        }

        //获取随机验证码
        $mobile_phone_code = $yzm->getRand();
        //保存SESSION
        D('School')->createApplyCodeSession($mobile_phone, $mobile_phone_code);

        $content = "您本次手机验证的验证码是{$mobile_phone_code}。";

        $ret = \cShortMsg::sendMsg($mobile_phone, $content);
        if ($ret == "发送成功") {
            $this->ajaxReturn(array('ret' => 'true', 'msg' => '发送成功'));
        } else {
            \Think\Log::Write('入社申请验证码发送失败：错误码' . $ret);
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '发送失败，请联系客服'));
        }
    }


    /**
     * 验证手机
     *
     * @param $mobile_phone
     */
    public function checkShortMsgCode($mobile_phone)
    {


        $mobile_phone = trim($mobile_phone);

        foreach ($_POST as $value) {
            if (!$value) {
                $this->ajaxReturn(array('ret' => 'false', 'msg' => '请输入要填写的内容'));
            }
        }

        //验证手机号是否已经被注册
        $student_info = D('Student')->getRepeat($mobile_phone);
        if ($student_info['end_time'] && $student_info['apply_type_id']) {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '手机号已经被注册了'));
        }

        //验证手机验证码并且session保存验证成功标志
        $this->ajaxReturn(D('School')->checkShortMsgCode($mobile_phone));
    }

    //2016-07-24 16:04:10 续费或者升级计算费用
    public function countMoneyUpgradeOrRenew()
    {
        $price = $_POST['price'];
        $count = $_POST['count'];

        $student_id = session('renew_student_id');
        $student_info = M('student')->find($student_id);

        if (empty($student_info['end_time']) || $student_info['end_time'] < time()) {
            $apply_type_id = -1;
        } else {
            $apply_type_id = $student_info['apply_type_id'];
        }
        $ret =  array();

        if ($apply_type_id == -1) {
            //属于升级：从临时会员升级到线上或者线下
//            直接为target一年的钱

            $ret['result']=1;
            $ret['money']=$price * $count;;

        }else
        {
            $id = $_POST['target'];

            if ($id == $apply_type_id) {
                //属于续费：直接为target一年的钱
                $ret['result']=1;
                $ret['money']=$price * $count;;

            }
            if ($id != $apply_type_id) {
                $retMoneyData = D('student')->getUpgradeMoney($student_info['end_time']);

                if ($retMoneyData['ret']==true)
                {
                    $ret['money']=$retMoneyData['money'];
                    $ret['result']=1;
                }else
                {
                    $ret['result']=0;
                    $ret['msg']=$retMoneyData['msg'];

                }



            }

        }



        $this->ajaxReturn($ret);

    }


    //选择入社计算金钱
    public function countMoney()
    {
        $price = $_POST['price'];
        $count = $_POST['count'];
        echo $price * $count;
        die;
    }

    /**
     * 支付成功后，跳转页面
     */
    public function indexSuccess($jump_url = '')
    {
        $mobile_phone = session('apply_mobile_phone');
        if (!$mobile_phone) {
            $this->redirect('Baozhu/Activity/index');
        }

        //帮助用户登录
        D('student')->setLoginSession(D('student')->getRepeat($mobile_phone));


        //学生编号
        $this->assign('student_number', D('student')->getStudentNumber($mobile_phone));

        $this->assign('student_apply_type_name', session("pay_apply_type"));

        $this->assign('jump_hint', '确定');

        $this->assign('jump_url', '/Bz/UserCenter/index');

//        if (empty($jump_url)) {
//            $this->assign('jump_url', '/Baozhu/Activity/index');
//        } else {
//            $this->assign('jump_url', '/Bz/UserCenter/index');
////			$jump_url = base64_decode($jump_url);
////
////			if (false === stripos($jump_url, '/Bz/ActivityOne')) {
////				$this->assign('jump_url', '/Baozhu/Activity/index');
////			} else {
////				$this->assign('jump_url', $jump_url);
////			} 
//        }

        $this->display('indexSuccess');
    }

    /**
     *
     *
     * @param string $mobile_phone
     */
    public function act_reg_pay_success($mobile_phone = '')
    {
        if (!$mobile_phone) {
            $this->redirect('/Bz/Index/Index');
        }

        //帮助用户登录
        D('student')->setLoginSession(D('student')->getRepeat($mobile_phone));

        //学生编号
        $this->assign('student_number', D('student')->getStudentNumber($mobile_phone));

        $this->display('act_reg_pay_success');
    }
}