<?php
namespace Bz\Controller;

use Think\Controller;

//微信绑定
class WxBindingController extends Controller 
{
	//获取openId
	public function index()
	{
		$wxinfo = A('Wx')->wxcode(0);
		if (!$wxinfo) {
			$this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/' . '获取微信信息失败');
		}

		$openid = $wxinfo['openid'];
		session('need_binding_openid', $openid);

		// 获取用户微信新
		//$wxinfo = A('Wx')->wxcode(1);
		//$user_info = A('Wx')->getweixinxinxi($wxinfo);
		$user_info = A('Wx')->weixinxinxi($openid);

		session('wx_nick_name', $user_info['nickname']);
		session('wx_province_name', $user_info['province']);
		session('wx_city_name', $user_info['city']);
		session('wx_headimgurl', $user_info['headimgurl']);

		$baozhu_last_url = cookie('baozhu_last_url');
		if (!empty($baozhu_last_url)) {
			$this->assign('baozhu_last_url', $baozhu_last_url);
		} else {
			$this->assign('baozhu_last_url', '/Bz/Student/index');
		}

		$this->display('index');
	}

	//发送验证码
	public function sendMobilePhoneCode()
	{
		$mobile_phone = trim($_GET['mobile_phone']);
		vendor('yzm.cShortMsg');
		$yzm = new \cShortMsg();
		//验证手机号正确性
		if (!$yzm::checkMobilePhone($mobile_phone)) {
			$this->ajaxReturn(array('ret' => 'false', 'msg' => '请输入正确的手机号'));
		}

		//检查手机号是否为会员
		$student_data = D('student')->getRepeat($mobile_phone);
		if (!$student_data || empty($student_data['apply_type_id'])) {
			$this->ajaxReturn(array('ret' => 'phone_not_member', 'msg' => '该手机号不是会员'));
		} else if ($student_data['account_binding_wxid']) {
			$this->ajaxReturn(array('ret' => 'phone_wx_binded', 'msg' => '该手机已和微信绑定'));
		} else if (D('student')->getUserInfoByOpenid(session('need_binding_openid'))) {
			$this->ajaxReturn(array('ret' => 'phone_wx_binded', 'msg' => '微信号已绑定其他手机号'));
		}

		//获取随机验证码
		$mobile_phone_code = $yzm->getRand();

		// 两台机器不能共享session，会导致验证码不对问题，需要用数据库或缓存
		session('need_binding_mobile_phone', $mobile_phone);
		session('need_binding_mobile_phone_code', $mobile_phone_code);

		$content = "您本次手机验证的验证码是{$mobile_phone_code}。";

		$ret = \cShortMsg::sendMsg($mobile_phone, $content);
		if (substr($ret, 0, 1) != '-') {
			$this->ajaxReturn(array('ret' => 'true', 'msg' => '发送成功'));
		} else {
			\Think\Log::Write('绑定账号验证码发送失败：错误码' . $ret);
			$this->ajaxReturn(array('ret' => 'false', 'msg' => '发送失败，请联系客服'));
		}
	}

	//验证手机号
	public function bindMobilePhone()
	{
		$mobile_phone = I('get.mobile_phone');
		$mobile_phone_code = I('get.mobile_phone_code');

		$openid = session('need_binding_openid');
		$nick_name = session('wx_nick_name');
		$province = session('wx_province_name');
		$city = session('wx_city_name');
		$headimgurl = session('wx_headimgurl');

		$checkstr = session('need_binding_mobile_phone') . session('need_binding_mobile_phone_code');


		//验证手机号和验证码
		if ($mobile_phone . $mobile_phone_code != $checkstr) {
			$errorData = array('ret' => 'false', 'msg' => '验证码错误');//验证码与手机不对应
		} else if (!$openid) {
			$errorData = array('ret' => 'false', 'msg' => '获取openid失败');
		} else {
			//执行绑定
			if (D('Student')->bindingWx($mobile_phone, $openid, $nick_name, $headimgurl, $province, $city)) {
				//帮助用户登录
				D('Student')->setLoginSession(D('Student')->getRepeat($mobile_phone));
				$errorData = array('ret' => 'true', 'msg' => '绑定成功');
			} else {
				$errorData = array('ret' => 'false', 'msg' => '绑定失败');
			}
		}

		$this->ajaxReturn($errorData);
	}


}