<?php
namespace Bz\Controller;
use Think\Controller;
//个人中心
class UserInfoController extends ExtendController{ 
	//个人中心主页面
	public function index(){
		header('Content-type:text/html;charset=utf-8');
		dump('个人中心主页');
		
		
		
		
	}
	
	
   
}