<?php
namespace Bz\Controller;

use Think\Controller;

//用户中心
class WaittingStudentController extends Controller
{
 
	//用户主页
	public function index()
	{
//		$this->redirect('/Bz/Show/defaultError/errorCode/waitting_student_pay_closed');
//		exit();

		$true_name = cookie('apply_true_name');
		$mobile_phone = cookie('apply_mobile_phone');

		$this->assign('true_name', $true_name);
		$this->assign('mobile_phone', $mobile_phone);

		$this->backup_apply();
	}

	public function backup_apply() {
		$this->display('Student/backup_apply');
	}

	public function backup_error() {
		$this->display('Student/backup_error');
	}

	/**
	 * 非社员，支付3000
	 * 社员，过期，支付3000,
	 * 社员，超过两年有效期，不续费
	 * 社员，有效期两年内容，续费2400
	 */
	public function check_user() {
		$true_name = I('true_name');
		$mobile_phone = I('mobile_phone');

		cookie('apply_true_name', $true_name);
		cookie('apply_mobile_phone', $mobile_phone);

		session('apply_true_name', $true_name);
		session('apply_mobile_phone', $mobile_phone);

		if (empty($mobile_phone)) {
			$this->ajaxReturn(array('ret' => 'false', 'msg' => '请输入正确的手机号'));
		}

		$is_new_user = 0;
		$cur_time = time();

		$student_info = M('student')->field('end_time')->where(array('mobile_phone' => $mobile_phone))->find();

		if (empty($student_info)) {
			// 创建一条学员信息
			$ins_data = array();
			$ins_data['true_name'] = $true_name;
			$ins_data['student_type'] = '会员';
			$ins_data['student_wx'] = '';
			$ins_data['company_name'] = '';
			$ins_data['company_vocation_id'] = 0;
			$ins_data['company_position_id'] = 0;
			$ins_data['apply_type_id'] = 2;
			$ins_data['end_time'] = $cur_time - 1;
			$ins_data['update_time'] = $cur_time;
			$ins_data['school_student_number'] = D('HtmlSystemSetup')->createStudentNumber();
			$ins_data['mobile_phone'] = $mobile_phone;
			$ins_data['time'] = $cur_time;

			$ret1 = D('Student')->createApplyOne($ins_data);

			if (!$ret1) {
				$this->ajaxReturn(array('ret' => 'false', 'msg' => '服务器繁忙，请稍后再试'));
			}

			$is_new_user = 1;
		}

		if (!empty($student_info) && $student_info['end_time'] > time() + 2*366*86400) {
			$this->ajaxReturn(array('ret' => 'end_time_gt_2_year', 'msg' => '有效期超过两年'));
		}

		$money = M('student_waitting')->where(array('mobile_phone' => $mobile_phone))->getField('money');
		if ($money) {
			if (empty($student_info) || $student_info['end_time'] < $cur_time) {
				$this->ajaxReturn(array('ret' => '3000', 'is_new' => $is_new_user, 'msg' => 'OK'));
			} else {
				$this->ajaxReturn(array('ret' => '2400', 'is_new' => $is_new_user, 'msg' => 'OK'));
			}

//			if ($money == 2400) {
//				$this->ajaxReturn(array('ret' => '2400', 'is_new' => $is_new_user, 'msg' => 'OK'));
//			} elseif ($money == 3000) {
//				$this->ajaxReturn(array('ret' => '3000', 'is_new' => $is_new_user, 'msg' => 'OK'));
//			}
		} else {
			$this->ajaxReturn(array('ret' => 'false', 'msg' => 'error'));
		}
	}

	/**
	 * 学生一次性升级，在线的付款2400, 升级成铁杆会员
	 *
	 */
	public function up2400SelectPay($is_new=0)
	{
		$student_data = D('student')->getRepeat(session('apply_mobile_phone'));
		if (!$student_data) {
			\Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

			$this->redirect('/Bz/School/index');
		}

		//创建一条待付款信息
		$savedata['student_id'] = $student_data['id'];
		$savedata['money'] = 2400;  //2400.00;  // $retMoneyData['money'];
		$savedata['type'] = 'one'; // $retMoneyData['type'];
		$savedata['is_temp'] = 1;
		$savedata['is_new'] = $is_new;
		D('StudentNoPayUpgrade')->createOne($savedata);

		//查询支付方式
		$payType = D('StudentPayType')->getSelectData(false);
		foreach ($payType as $k => $v) {
			if ($v['student_pay_type_id'] == '1') {
				$payType[$k]['student_pay_type_href'] = '/Bz/WxPay/payStudentUpgrade/is_temp/1';
			} elseif ($v['student_pay_type_id'] == '2') {
				$pay_id = session('pay_id');
				$pay_money = $savedata['money'];
				$payType[$k]['student_pay_type_href'] = "/Bz/Alipay/pay/type/4/is_temp/1/pay_id/{$pay_id}/pay_money/{$pay_money}";
			}
		}

		$this->assign('payType', $payType);
		$this->assign('money', $savedata['money']);

		$this->display('Student/studentUpgradeSelectPayType');
	}

	/**
	 * 学生一次性升级，在线的付款3000, 升级成铁杆会员
	 *
	 */
	public function up3000SelectPay($is_new=0)
	{
		$student_data = D('student')->getRepeat(session('apply_mobile_phone'));
		if (!$student_data) {
			\Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

			$this->redirect('/Bz/School/index');
		}

		//创建一条待付款信息
		$savedata['student_id'] = $student_data['id'];
		$savedata['money'] = 3000;  //3000.00;  // $retMoneyData['money'];
		$savedata['type'] = 'one'; // $retMoneyData['type'];
		$savedata['is_temp'] = 1;
		$savedata['is_new'] = $is_new;
		D('StudentNoPayUpgrade')->createOne($savedata);

		//查询支付方式
		$payType = D('StudentPayType')->getSelectData(false);
		foreach ($payType as $k => $v) {
			if ($v['student_pay_type_id'] == '1') {
				$payType[$k]['student_pay_type_href'] = '/Bz/WxPay/payStudentUpgrade/is_temp/1';
			} elseif ($v['student_pay_type_id'] == '2') {
				$pay_id = session('pay_id');
				$pay_money = $savedata['money'];
				$payType[$k]['student_pay_type_href'] = "/Bz/Alipay/pay/type/4/is_temp/1/pay_id/{$pay_id}/pay_money/{$pay_money}";
			}
		}

		$this->assign('payType', $payType);
		$this->assign('money', $savedata['money']);

		$this->display('Student/studentUpgradeSelectPayType');
	}

}