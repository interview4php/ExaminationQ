<?php
namespace Bz\Controller;

use Think\Controller;

//课程
class CourseController extends ExtendController
{
    public function index()
    {
        //$this->redirect('/Baozhu/Activity/index');

        //$this->course();
    } 

 

    /**
     * 大课程列举，用户报名
     */
    public function course()
    {



        //$this->redirect('/Baozhu/Activity/index');

        $student_data = M('student')->field('*')->find(session('student_id'));

        if (empty($student_data['end_time']) || $student_data['end_time'] < time()) {
            session('renew_student_id', $student_data['id']);

            $this->redirect('/Bz/Show/errorFalseexpireday');
        }

        $this->assign('apply_see_type', D('Student')->getStudentType(  session('student_id') ));

        A('Public')->myD('course', '课程报名');
    }

    //我的课程
    public function myc()
    {
        //$this->redirect('/Baozhu/Activity/index');

        if (is_weixin()) {

            if (empty( session('account_binding_wxid'))) {
                $this->redirect('/Bz/WxBinding/index');
            }
        }

        A('Public')->myD('myc', '我的课表');
    }


    /**
     * Ajax加载课程报名列表
     */
    public function courseList()
    {
        $student_id =session('student_id');
        $type = I('get.type');
        $begin = I('get.begin');
        if ($type != 'school' && $type != 'months') {
            $this->ajaxReturn(array('ret' => 'false'));
        }

        if (empty($begin)) {
            $begin = 0;
        }

        switch ($type) {
            case 'school':
                $this->ajaxReturn(D('SchoolCourse')->getAllBySchool($student_id, $begin));//按学校查
            case 'months':
                $this->ajaxReturn(D('SchoolCourse')->getAllByTime($student_id, $begin));//按月份查
        }

        header('Content-type:text/html;charset=utf-8');
        $data = D('SchoolCourse')->getAllByTime($student_id, 0);//按月份查
        $data = D('SchoolCourse')->getAllBySchool($student_id, 0);//按学校查

        dump($data);
    }


    /**
     * 我报名的课程 ajax
     */
    public function myCourseList()
    {
        $student_id =session('student_id');
        $type = I('get.type');
        $begin = I('get.begin');
        if ($type != 'school' && $type != 'months') {
            $this->ajaxReturn(array('ret' => 'false'));
        }
        if (empty($begin)) {
            $begin = 0;
        }

        switch ($type) {
            case 'school':
                $this->ajaxReturn(D('StudentCourse')->getAllBySchool($student_id, $begin));//按学校查
            case 'months':
                $this->ajaxReturn(D('StudentCourse')->getAllByTime($student_id, $begin));//按月份查
        }

        header('Content-type:text/html;charset=utf-8');
        //$data = D('StudentCourse')->getAllByTime($student_id,0);//按月份查
        $data = D('StudentCourse')->getAllBySchool($student_id, 0);//按学校查
        dump($data);

    }


    //学生课程报名
    /*
    public function addStudentCourse(){
        $student_id =session('student_id')student_id');
        $course_id = I('get.course_id');
        if(empty($course_id)){
            $this->ajaxReturn(array('ret'=>'false'));
        }
        $ret = D('StudentCourse')->addOne($student_id,$course_id);
        if($ret){
            if($ret=='is_have'){
                $this->ajaxReturn(array('ret'=>'is_have'));
            }
            $this->ajaxReturn(array('ret'=>'true'));
        }else{
            $this->ajaxReturn(array('ret'=>'false'));
        }
    }
    */

    /**
     * 学生课程报名多个
     */
    public function addStudentCourseMore()
    {
        $course_id_str = I('get.course_id_str');

        if (empty($course_id_str)) {
            $this->ajaxReturn(array('ret' => 'false'));
        }

        $student_id =session('student_id');
        $mobile_phone = session('student_mobile_phone');

        $this->ajaxReturn(D('StudentCourse')->addMore($student_id, $course_id_str, $mobile_phone));
    }


    //学生课程请假
    public function delStudentCourse()
    {

        $student_id =session('student_id');
        $course_id = I('get.course_id');
        $msg = I('get.msg');
        if (empty($course_id)) {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '非法操作'));
        }
        //查看该课程是否开启课程请假
        $where['id'] = $course_id;
        if (!M('school_course')->where($where)->getField('is_can_false')) {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '该课程已停止请假'));
        }
        $ret = D('StudentCourse')->delOne($student_id, $course_id, $msg);
        if ($ret) {
            $this->ajaxReturn(array('ret' => 'true'));
        } else {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '服务器繁忙'));
        }

    }


}