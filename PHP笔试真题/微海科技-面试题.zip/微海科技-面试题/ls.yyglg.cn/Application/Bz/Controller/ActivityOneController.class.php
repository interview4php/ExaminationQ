<?php
namespace Bz\Controller;

use Think\Controller;

/**
 * 单场课程报名
 *
 * Class CourseOneController
 *
 * @package Bz\Controller
 */
class ActivityOneController extends Controller
{

    //单场课程报名
    public function index()
    {
        $courseId = I('courseId');
        $placeId = I('placeId');

        if (empty($courseId)) {
            $this->redirect('/Bz/Show/defaultError/errorCode/classroom_nonexists');    // 课程不存在
        }
        if (empty($placeId)) {
            $placeId = 0;
        }
        $field = 't.id,t.name as course_name,s.school_name,t.one_see_type,t.one_money,t.one_status';
        $data = D('SchoolCourse')->getCourseField($courseId, $field);

        if (empty($data)) {
            $this->redirect('/Bz/Show/defaultError/errorCode/classroom_nonexists');    // 课程不存在
        }

        if (empty($data['one_status'])) {
            $this->redirect('/Bz/Show/activity_not_open_for_sign_up');
        }

        $data['placeId'] = $placeId;

        $module = M('SchoolCourse');
        $data2 = $module->field('name, school_id, one_see_type')->where('id = ' . $courseId)->find();

        $data2['school_name'] = "";
        //var_dump($data2);exit;
        $this->assign('name', $data2);
        $this->assign('courseId', $courseId);
        $this->assign('placeId', $placeId);
        $this->assign('courseData', $data);

        $wx = M('school_course_wx_share')->where('school_course_id=' . $courseId)->find();
        $wx['img'] = S_URL . $wx['img'];

        $this->assign('datawx', $wx);
        $this->assign('wx', A('Wx')->getSignature(A('Wx')->get_url()));

        $this->display('index');
    }

    function generate_password( $length = 8 ) {
        // 密码字符集，可任意添加你需要的字符
        $chars = 'abcdefghijkmnpqrstuvwxyz23456789';

        $password = '';
        for ( $i = 0; $i < $length; $i++ )
        {
            // 这里提供两种字符获取方式
            // 第一种是使用 substr 截取$chars中的任意一位字符；
            // 第二种是取字符数组 $chars 的任意元素
            // $password .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
            $password .= $chars[ mt_rand(0, strlen($chars) - 1) ];
        }

        return $password;
    }
    //index提交处理
    public function indexSubmit()
    {
        $course_id = I('post.courseId');
        $place_id = I('post.placeId');
        $true_name = I('post.true_name');
        $mobile_phone = I('post.mobile_phone');
        $one_see_type = I('post.OneSeeType');

        $school_course_data = D('SchoolCourse')->field('*')->find($course_id);
        //$placeInfo = M('activity_place')->where(array('id' => $place_id))->find();

        if (empty($mobile_phone)) {
            $mobile_phone = session('act_sign_up_mobile_phone');
        }

        session('reg_jump_url',
            S_URL . "/Bz/ActivityOne/changeActivity/course_id/{$course_id}/mobile_phone/{$mobile_phone}");

        //查询该手机号是否为用户，查数据库11111
        $user_data = D('student')->getRepeat($mobile_phone);

        //用户不存在,会默认给个注册会员
        if (!$user_data || empty($user_data['apply_type_id'])) {

            $pwd=$this->generate_password(6);
            $encryedPwd=     sha1($pwd, true);
            $encryedPwd = base64_encode($encryedPwd);
            $user_data=array(
                'mobile_phone'=>$mobile_phone,
                'true_name'=>$true_name,
                'pwd'=>$encryedPwd,
                'apply_type_id'=>'-1',
                'time'=>time(),
                'school_student_number'=>D('HtmlSystemSetup')->createStudentNumber(),
                'end_time'=>time()+31536000
            );

           D('student')->add($user_data);
            $user_data = D('student')->getRepeat($mobile_phone);

            $content = "尊敬的{$true_name}，欢迎加入抱柱大学！您的专属社员编号为：{$user_data['school_student_number']}。您的密码为{$pwd}";
            A('Public')->sendShortMsg($mobile_phone, $content);


        }
//        else

//        {
            //已经入社

            if ($user_data['is_disable']) {
                $this->redirect('/Bz/Show/defaultError/errorCode/account_forbidden');
            }


            //if ($user_data['end_time'] < time()) {
            if ($user_data['end_time'] < $school_course_data['begin_time']) {
                session('renew_student_id', $user_data['id']);

                $this->redirect('/Bz/Show/errorFalseexpireday');
            }

            //$school_course_data = D('SchoolCourse')->field('*')->find($course_id);

            //查看用户是否在黑名单中
            if (D('student_course')->isInBlackList($school_course_data['black_list'], $user_data['mobile_phone'])) {
                $msg = "由于您之前未请假缺课，无法报名该课程，如有疑问请至“抱柱网服务号”咨询";
                $this->redirect('/Bz/Show/errorTwo/type/false3/msg/' . $msg);
            }
//        }


        //帮助用户登录
        //D('student')->setLoginSession($user_data);$true_name
        session('act_sign_up_true_name', $true_name);
        session('act_sign_up_mobile_phone', $mobile_phone);
        session('act_sign_up_student_id', $user_data['id']);

        $this->redirect('/Bz/ActivityOne/changeActivity/course_id/' . $course_id . "/mobile_phone/" . $mobile_phone);
    }


    /**
     * 选择活动场地模式
     *
     * @param $course_id
     */
    public function changeActivity($course_id, $mobile_phone = '')
    {
        //$userType   -1是临时，1是线下，2是线上,-2作为未注册
        $userType = -2;
        if ($mobile_phone == null || $mobile_phone == "") {
            $mobile_phone = session("mobile_phone");
        }


        if ($mobile_phone != null && $mobile_phone != "") {

            //查询该手机号是否为用户，查数据库，不请求31
            $user_data = D('student')->getRepeat($mobile_phone);


            if (!$user_data || empty($user_data['apply_type_id'])) {
                //用户不存在
                $userType = -2;
                // $this->redirect('/Bz/Show/errorOne');

                //$this->redirect('/Bz/ActivityOne/inner/courseId/' . $course_id);
            } else {

                //用户存在

                $userType = $user_data['apply_type_id'];

                if ($user_data['is_disable']) {
                    $this->redirect('/Bz/Show/defaultError/errorCode/account_forbidden');
                }

                session('act_sign_up_student_id', $user_data['id']);

                if (!session('act_sign_up_student_id')) {
                    $this->redirect('/Bz/ActivityOne/index/courseId/' . $course_id);
                }

            }

            session('act_sign_up_mobile_phone', $mobile_phone);

        } else {

            //手机号为空的时候

            if (!session('act_sign_up_student_id')) {

                $this->redirect("/Bz/ActivityOne/index/courseId/".$course_id);
               // $this->redirect("/Baozhu/Login/index");
            } else {

                $user_data = M('student')->find(session('act_sign_up_student_id'));
                if (!$user_data || empty($user_data['apply_type_id'])) {
                    $this->redirect('/Bz/Show/errorOne');
                }
                if ($user_data['is_disable']) {
                    $this->redirect('/Bz/Show/defaultError/errorCode/account_forbidden');
                }
            }
        }

        //默认选座的值
        $onlyone_default_value = '';
        $multi_number = 0;

        $cond = array(
            'activity_id' => $course_id,
            'is_use' => 1,
            'limit_number' => array('gt', 0),
        );

        $obj_stu_c = M('student_course');

        //会场列表
        $data = M('activity_place')
            ->field('*')->where($cond)->select();

        //要返回过去的结果
        $placeResult = array();

        foreach ($data as $k => $v) {


            //剩余数量
            $signed_number = $obj_stu_c->where(array('activity_place_id' => $v['id'], 'pay_status' => 1, 'status' => 1))->count();
            $data[$k]['over_number'] = $v['total_number'] - $signed_number;
            if ($v['can_buy_more']) {
                $data[$k]['setImgClass'] = 'canmore';//多选
            } else {
                $data[$k]['setImgClass'] = 'onlyone';//单选
            }

            //查询改会场用户的状态
            $is_sign_up_data = M('student_course')->field('number')->where(array(
                'school_course_id' => $course_id,
                'student_id' => session('act_sign_up_student_id'),
                'activity_place_id' => $v['id'],
                'status' => 1,
                'pay_status' => 1,
            ))->find();

            //是否已经报名过
            if ($is_sign_up_data) {
                //查看该报名的是否为限购为1的
                if (empty($v['can_buy_more'])) {
                    $onlyone_default_value = $v['id'];
                } else {
                    $multi_number += $is_sign_up_data['number'];
                }

                $data[$k]['is_sign_up'] = 'yixuan';
                $data[$k]['buy_number'] = $is_sign_up_data['number'];
            } else {
                $data[$k]['is_sign_up'] = 'weixuan';
                $data[$k]['buy_number'] = '0';
            }

//            //未入社是否能够购买
//            if ($userType == -2 && $data[$k]['can_guest_user_buy'] == 1) {
//
//                $placeResult[$k] = $data[$k];
//            }
//            //临时会员能否购买
//            if ($userType == -1 && $data[$k]['can_temp_user_buy'] == 1) {
//                $placeResult[$k] = $data[$k];
//            }
//            //线下会员能否购买
//
//            if ($userType == 1 && $data[$k]['can_offline_user_buy'] == 1) {
//                $placeResult[$k] = $data[$k];
//            }
//            //线上会员能否购买
//            if ($userType == 2 && $data[$k]['can_online_user_buy'] == 1) {
//                $placeResult[$k] = $data[$k];
//            }

        }
//echo "userType=$userType";

        //   dump($data);
        $this->assign('multi_number', $multi_number);
        $this->assign('onlyone_default_value', $onlyone_default_value);
        $this->assign('course_id', $course_id);
        $this->assign('data', $data);


        if ($userType == -2) {
            $this->assign('url', "/Bz/ActivityOne/changeActivitySubmitGuest");


        } else {
            $this->assign('url', "/Bz/ActivityOne/changeActivitySubmit");


        }

        $this->display();
    }


    //未注册的人购买单门课程
    public function changeActivitySubmitGuest($course_id, $onlyone_id)
    {
        $mobile_phone = session('act_sign_up_mobile_phone');
        $true_name=session('act_sign_up_true_name');
        if ($mobile_phone == null || $mobile_phone == "") {
            http://ls.yyglg.cn/Baozhu/Activity/index
            $this->redirect("/Bz/Show/signupError?msg=" . urlencode("请重新选择") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Baozhu||Activity||index"));

        }

        if (empty($course_id)) {
            $this->redirect('/Bz/Show/input_error');
        }

        if ($onlyone_id == "0" && $_POST['multi_number'] == "0") {
            $this->redirect("/Bz/Show/signupError?msg=" . urlencode("必须选择一项报名") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));

        }
        //活动信息
        $school_course_data = D('SchoolCourse')->field('*')->find($course_id);

        $single_activity_place_pay_status = 0;

        //有单个报名的

        if ($onlyone_id > 0) {

            $placeInfo = M('activity_place')->where(array('id' => $onlyone_id))->find();

            $single_activity_place_pay_status = $placeInfo['price'] > 0 ? 0 : 1;

            //不允许非会员购买
            if ($placeInfo['can_guest_user_buy'] == 0) {
                $this->redirect("/Bz/Show/signupError?msg=" . urlencode("入社后才能报名") . "&btn=" . urlencode("入社") . "&url=" . urlencode("||Bz||School||index"));

            }
        }


        //查询是否有资格报名
        //该课程没有开启单场报名
        if (!$school_course_data['one_status']) {
            $this->redirect('/Bz/Show/activity_not_open_for_sign_up');
            //$this->redirect('/Bz/Course/course');
        }


        $cur_time = time();
        //处理可以购买多个的产品
        $post = $_POST;

        unset($post['course_id']);
        unset($post['onlyone_id']);
        unset($post['multi_number']);
        unset($post['cancel_old_sign']);


        $pay_money = $placeInfo['price'];


        $f_is_check = 0;    // 报名的分会场是否已审核，不需要审核的自动变为已审核
        $arr_sign_up_data = array();

        $str_place_type = '';
        $order_remark = "{$school_course_data['name']} 报名费用\n ";


        $student_id = -2;


        // create order
        $order_number = date('YmdHis') . mt_rand(100000, 999999);//商户订单号 通过支付页面的表单进行传递，注意要唯一！

        D()->startTrans();


        if ($pay_money > 0.0) {
            // insert order
            $data = array(
                'student_id' => $student_id,
                'order_number' => $order_number,
                'time' => $cur_time,
                'update_time' => $cur_time,
                'order_type' => 6,
                'relate_id' => $course_id,
                'is_check' => $f_is_check,
                'money' => $pay_money,
                'remark' => $order_remark,
                'mobile_phone' => $mobile_phone
            );
            $order_id = M('order')->add($data);


            if (!$order_id) {
                D()->rollback();
                $this->redirect('/Bz/Show/sign_up_error');
            }
        }


        if ($onlyone_id > 0) {
            $see_type = "";
            switch ($placeInfo['type']) {
                case 1:
                    $see_type = '主会场';
                    break;
                case 2:
                    $see_type = '直播';
                    break;
                case 3:
                    $see_type = '分会场';
                    break;
                default :
                    $see_type = '其他';
                    break;
            }

            $cond = array(
                'student_id' => $student_id,
                'school_course_id' => $course_id,
                'order_number' => $order_number,
                'activity_place_id' => $onlyone_id,//场地id
                'status' => 1,
                'pay_status' => $single_activity_place_pay_status,
                'time' => time(),
                'see_type' => $see_type,
                'msg' => "非注册会员报名，手机号" . $mobile_phone.'姓名'.$true_name
            );

            M('student_course')->add($cond);

            if ($single_activity_place_pay_status == "1") {

                $str_place_type=$school_course_data['detail_address'];
              
                $content = "尊敬的" . ($mobile_phone) . "：";
                $content = $content . "您已成功报名课程：" . $school_course_data['name'] . "。";
                $content = $content . "会场为：" . $str_place_type . "。";
                $str_time = date('n月j日', $school_course_data['begin_time']);
                $content = $content . "课程日期为：" . $str_time . "。";
//                var_dump($mobile_phone);
//                var_dump($content);
//                die();

                A('Public')->sendShortMsg($mobile_phone, $content);
            }

        }

        D()->commit();

        // 如果要支付，跳转到支付页面
        if ($pay_money > 0.0) {
            $pay_show_url = base64_encode(S_URL . "/Bz/ActivityOne/index/courseId/$course_id");
            $this->redirect("/Bz/ActivityOne/selectPayType/order_id/$order_id/money/$pay_money/pay_show_url/$pay_show_url");
        }

        //成功失败跳转页面
        if (1) {
            if ($f_is_check) {  // 已审核通过
                if ($school_course_data['is_sign_up_sms_msg']) {
                    // send sms msg
                    $content = str_replace('{姓名}', $mobile_phone, $school_course_data['sign_up_sms_msg']);
                    $content = str_replace('{课程名称}', $school_course_data['name'], $content);
                    $content = str_replace('{活动名称}', $school_course_data['name'], $content);
                    $content = str_replace('{会场类型}', trim($str_place_type), $content);
                    $str_time = date('n月j日', $school_course_data['begin_time']);
                    $content = str_replace('{活动时间}', $str_time, $content);

                    A('Public')->sendShortMsg($mobile_phone, $content);
                }
            } else {   // 未审核，发送审核通知短信
                if ($school_course_data['is_audit_sms_msg']) {
                    // send sms msg
                    $content = str_replace('{姓名}', $mobile_phone, $school_course_data['audit_sms_msg']);
                    $content = str_replace('{课程名称}', $school_course_data['name'], $content);
                    $content = str_replace('{活动名称}', $school_course_data['name'], $content);
                    $content = str_replace('{会场类型}', trim($str_place_type), $content);
                    $str_time = date('n月j日', $school_course_data['begin_time']);
                    $content = str_replace('{活动时间}', $str_time, $content);

                    A('Public')->sendShortMsg($mobile_phone, $content);
                }
            }

            $this->redirect('/Bz/Show/sign_up_success');
        } else {

            $this->redirect("/Bz/Show/show_error/error_msg/");
        }

    }


    /**
     * 选座会场提交处理
     *
     * @param $course_id 活动id
     * @param $onlyone_id 会场id
     */
    public function changeActivitySubmit($course_id, $onlyone_id)
    {

        //  $this->redirect("/Bz/Show/signupError?msg=".urlencode("对不起！您是在线会员报名该课程请选择升级高级会员")."&btn=".urlencode("升级高级会员")."&url=".urlencode("||Bz||ActivityOne||changeActivity||course_id||"));
        header('Content-type:text/html;charset=utf-8');


        $student_id = session('act_sign_up_student_id');


        if (empty($student_id)) {
            $this->redirect("/Bz/ActivityOne/index/courseId/{$course_id}/placeId/0");
        }

        if (empty($course_id)) {
            $this->redirect('/Bz/Show/input_error');
        }

        if ($onlyone_id == "0" && $_POST['multi_number'] == "0") {
            $this->redirect("/Bz/Show/signupError?msg=" . urlencode("必须选择一项报名") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));

        }


        //用户信息
        $user_data = D('student')->getStudentInfo($student_id);

        $userType = $user_data['apply_type_id'];

        //活动信息
        $school_course_data = D('SchoolCourse')->field('*')->find($course_id);

        $cur_time = time();

        $single_activity_place_pay_status = 0;

        $pay_money = 0.0;


        //重复报名的校验 bengin----------------------
        //已经报名的(不包括餐票和其他的) , 'activity_place_id' => array('gt', $course_id)
        $db_prefix = GetDbPrefix();
        $aleardyJoin = 'as this left join ' . $db_prefix . 'activity_place as place on this.activity_place_id = place.id';
        $aleardyWhere = array('this.student_id' => $student_id, 'this.school_course_id' => $course_id, 'this.pay_status' => '1', 'place.type' => array('neq', '4'));
        //已经报名的第一个找到的记录
        $aleardy = M('student_course')->join($aleardyJoin)->where($aleardyWhere)->find();


        $post = $_POST;
        if (isset($aleardy)) {

            if ($aleardy['activity_place_id'] == $onlyone_id&&$aleardy['status']==1) {

                //已经报名的，就是这次选择的,则不要再新增记录了
                $onlyone_id = 0;

                $isAllMutiSelectIsZero = 1;
                foreach ($post as $k => $v) {
                    if ($v > 0) {
                        $isAllMutiSelectIsZero = 0;
                    }
                }
                if ($isAllMutiSelectIsZero == 1) {

                    //不允许重复选
                    $this->redirect("/Bz/Show/signupError?msg=" . urlencode("对不起！您已经有过报名记录。") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));


                }

            } else {
                if ($aleardy['status']==1)
                {
                    //不允许更换场地
                    $this->redirect("/Bz/Show/signupError?msg=" . urlencode("对不起！您已经有过报名记录。") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));
                }
                if ($aleardy['status']==2)
                {
                    //不允许更换场地
                    $this->redirect("/Bz/Show/signupError?msg=" . urlencode("您已请假，不能重复报名，请联系专属管理员。") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));
                }

            }
        }

        //重复报名的校验 end----------------------


        //单个报名的 -----------------------begin-----------------
        if ($onlyone_id > 0) {

            $placeInfo = M('activity_place')->where(array('id' => $onlyone_id))->find();

            $single_activity_place_pay_status = $placeInfo['price'] > 0 ? 0 : 1;
            $pay_money = $placeInfo['price'];


            if ($cur_time < $placeInfo['sign_start_time']) {
                $this->redirect("/Bz/Show/signupError?msg=" . urlencode($placeInfo['name'] . "还没到报名时间。") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));
            }
            if ($cur_time > $placeInfo['sign_end_time']) {
                $this->redirect("/Bz/Show/signupError?msg=" . urlencode($placeInfo['name'] . "报名时间已过。") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));
            }


            //不允许临时会员购买
            if ($userType == -1 && $placeInfo['can_temp_user_buy'] == 0) {
                $this->redirect("/Bz/Show/signupError?msg=" . urlencode("升级后才能报名") . "&btn=" . urlencode("升级") . "&url=" . urlencode("||Bz||StudentRenew||studentRenew"));

            }


            //不允许线下会员购买
            if ($userType == 1 && $placeInfo['can_offline_user_buy'] == 0) {
                $this->redirect("/Bz/Show/signupError?msg=" . urlencode("不允许线下会员报名该场地") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));

            }

            //不允许线上会员
            if ($userType == 2 && $placeInfo['can_online_user_buy'] == 0) {
                $this->redirect("/Bz/Show/signupError?msg=" . urlencode("对不起！您是线上会员.报名该课程请选择升级线下会员") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));

            }

        }

        //单个报名的 -----------------------end-----------------


        //查询是否有资格报名


        //该课程没有开启单场报名
        if (!$school_course_data['one_status']) {
            $this->redirect('/Bz/Show/activity_not_open_for_sign_up');
            //$this->redirect('/Bz/Course/course');
        }

        //查看用户是否在黑名单中
        if (D('student_course')->isInBlackList($school_course_data['black_list'], $user_data['mobile_phone'])) {
            $msg = "由于您之前未请假缺课，无法报名该课程，如有疑问请至“抱柱网服务号”咨询";
            $this->redirect('/Bz/Show/errorTwo/type/false3/msg/' . $msg);
        }

        $cur_time = time();


//处理可以购买多个的产品---------------begin
        $post = $_POST;

        unset($post['course_id']);
        unset($post['onlyone_id']);
        unset($post['multi_number']);
        unset($post['cancel_old_sign']);


        $f_is_check = 0;    // 报名的分会场是否已审核，不需要审核的自动变为已审核
        $arr_sign_up_data = array();

        $str_place_type = '';
        $order_remark = "{$school_course_data['name']} 报名费用\n ";


        foreach ($post as $place_id => $sign_up_number) {

            if (empty($place_id) || $sign_up_number < 1) {
                continue;
            }
            if ($place_id > 0) {
                $placeInfo = M('activity_place')->where(array('id' => $place_id))->find();

                if ($cur_time < $placeInfo['sign_start_time']) {
                    $this->redirect("/Bz/Show/signupError?msg=" . urlencode($placeInfo['name'] . "还没到报名时间。") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));
                }
                if ($cur_time > $placeInfo['sign_end_time']) {
                    $this->redirect("/Bz/Show/signupError?msg=" . urlencode($placeInfo['name'] . "报名时间已过。") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));
                }

                //不允许临时会员购买
                if ($userType == -1 && $placeInfo['can_guest_user_buy'] == 0) {
                    $this->redirect("/Bz/Show/signupError?msg=" . urlencode("升级后才能报名") . "&btn=" . urlencode("升级") . "&url=" . urlencode("||Bz||School||applyType"));

                }

                //不允许线下会员购买
                if ($userType == 1 && $placeInfo['can_offline_user_buy'] == 0) {
                    $this->redirect("/Bz/Show/signupError?msg=" . urlencode("不允许线下会员报名该场地") . "&btn=" . urlencode("返回") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));

                }

                //不允许线上会员
                if ($userType == 2 && $placeInfo['can_online_user_buy'] == 0) {
                    $this->redirect("/Bz/Show/signupError?msg=" . urlencode("对不起！您是在线会员.报名该课程请选择升级高级会员") . "&btn=" . urlencode("升级高级会员") . "&url=" . urlencode("||Bz||ActivityOne||changeActivity||course_id||" . $course_id));

                }

            }

        }

        foreach ($post as $place_id => $sign_up_number) {

            if (empty($place_id) || $sign_up_number < 1) {
                continue;
            }

            //当前会场信息
            $place_data = M('activity_place')->find($place_id);


            $place_data['signed_number'] = M('student_course')->where(array('activity_place_id' => $place_data['id'], 'status' => 1, 'pay_status' => 1))->count();

            $can_sign_up = $this->can_sign_up_place($course_id, $place_id, $student_id, $user_data['apply_type_id'],
                $place_data, $sign_up_number);

            if ($can_sign_up['code'] === -1 && $sign_up_number > 0) {

                $errorMsg = urlencode($place_data['name'] . " 已报名，不允许重复报名！");
                $this->redirect("/Bz/Show/show_error/error_msg/{$errorMsg}");
                continue;
            }

            if ($can_sign_up['code'] !== 1) {
                $errorMsg = urlencode($can_sign_up['msg']);
                $this->redirect("/Bz/Show/show_error/error_msg/{$errorMsg}");
                continue;
            };

            //是否需要审核
            if ($place_data['is_need_audit']) {
                $is_check = 0;//设置未审核
            } else {
                $is_check = 1;
                if ($place_data['type'] >= 1 && $place_data['type'] <= 3) {
                    $f_is_check = 1;
                }
            }

            switch ($place_data['type']) {
                case 1:
                    $see_type = '主会场';
                    break;
                case 2:
                    $see_type = '直播';
                    break;
                case 3:
                    $see_type = '分会场';
                    break;
                default :
                    $see_type = '其他';
                    break;
            }

            //需要支付时  所有人都需要支付的
            if ($place_data['price'] > 0) {// 对所有人都收费项目


                // 餐票要收费，或者直播用户，选择了非直播的项目
                if (($place_data['price'] > 0 && 4 == $place_data['type'])
                    || $user_data['apply_type_id'] == 1 && $place_data['type'] != 2
                ) {
                    $tmp_money = $place_data['price'];
                    $pay_status = 0;

                    $tmp_total_money = $tmp_money * $sign_up_number;
                    $order_remark .= " {$place_data['name']}: {$tmp_total_money}元\n ";
                } else {    // 铁杆社员免费，或者直播用户选择直播的
                    $tmp_money = 0.0;
                    $pay_status = 1;
                }
            } else {    // 免费
                $tmp_money = 0.0;
                $pay_status = 1;
            }


            $str_place_type .= "{$place_data['name']} ";

            $arr_sign_up_data[] = array(
                'school_course_id' => $course_id,
                'activity_place_id' => $place_id,
                'student_id' => $student_id,
                'time' => $cur_time,
                'money' => $tmp_money,
                'pay_status' => $pay_status,
                'is_check' => $is_check,
                'see_type' => $see_type,
                'number' => $sign_up_number
            );
        }


        // create order
        $order_number = date('YmdHis') . mt_rand(100000, 999999);//商户订单号 通过支付页面的表单进行传递，注意要唯一！


        D()->startTrans();

        foreach ($arr_sign_up_data as $key => $value) {
            // 判断是否插入成功，新报名成功，计算待支付价钱
            $sign_ret = $this->check_and_sign_up($course_id, $value['activity_place_id'], $student_id, $value['see_type'],
                $value['is_check'], $value['number'], $order_number, $value['money'] * $value['number'], $value['pay_status']);

            if ($sign_ret == 1) {    // 成功
                $pay_money += $value['money'] * $value['number'];
            } else {        // 已报名
                continue;
            }
        }
//处理可以购买多个的产品---------------end


        if ($pay_money > 0.0) {
            // insert order
            $data = array(
                'student_id' => $student_id,
                'order_number' => $order_number,
                'time' => $cur_time,
                'update_time' => $cur_time,
                'order_type' => 6,
                'relate_id' => $course_id,
                'is_check' => $f_is_check,
                'money' => $pay_money,
                'remark' => $order_remark
            );
            $order_id = M('order')->add($data);
            if (!$order_id) {
                D()->rollback();
                $this->redirect('/Bz/Show/sign_up_error');
            }
        }


        if ($onlyone_id > 0) {


            switch ($place_data['type']) {
                case 1:
                    $see_type = '主会场';
                    break;
                case 2:
                    $see_type = '直播';
                    break;
                case 3:
                    $see_type = '分会场';
                    break;
                default :
                    $see_type = '其他';
                    break;
            }

            $cond = array(
                'student_id' => $student_id,
                'school_course_id' => $course_id,
                'order_number' => $order_number,
                'activity_place_id' => $onlyone_id,
                'status' => 1,
                'pay_status' => $single_activity_place_pay_status,
                'time' => time(),
                'see_type' => $see_type
            );
            if ($onlyone_id > 0) {
                M('student_course')->add($cond);

            }

        }

        D()->commit();


        // 如果要支付，跳转到支付页面
        if ($pay_money > 0.0) {
            $pay_show_url = base64_encode(S_URL . "/Bz/ActivityOne/index/courseId/$course_id");
            $this->redirect("/Bz/ActivityOne/selectPayType/order_id/$order_id/money/$pay_money/pay_show_url/$pay_show_url");
        }

        //成功失败跳转页面
        if (1) {
            if (1) {  // 已审核通过
                if (1) {
                    $str_place_type=$school_course_data['detail_address'];

                    // send sms msg
//                    $content = str_replace('{姓名}', $user_data['true_name'], '您已成功报名参加【{课程名称}】');
//                    $content = str_replace('{课程名称}', $school_course_data['name'], $content);
//                    $content = str_replace('{活动名称}', $school_course_data['name'], $content);
//                    $content = str_replace('{会场类型}', trim($str_place_type), $content);
//                    $str_time = date('n月j日', $school_course_data['begin_time']);
//                    $content = str_replace('{活动时间}', $str_time, $content);
                    $content = "尊敬的" . ($user_data['true_name']) . "：";
                    $content = $content . "您已成功报名课程：" . $school_course_data['name'] . "。";
                    $content = $content . "会场为：" . $str_place_type . "。";
                    $str_time = date('n月j日', $school_course_data['begin_time']);
                    $content = $content . "课程日期为：" . $str_time . "。";

                    A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
                   
                }
            } else {   // 未审核，发送审核通知短信
                if ($school_course_data['is_audit_sms_msg']) {
                    // send sms msg
                    $content = str_replace('{姓名}', $user_data['true_name'], $school_course_data['audit_sms_msg']);
                    $content = str_replace('{课程名称}', $school_course_data['name'], $content);
                    $content = str_replace('{活动名称}', $school_course_data['name'], $content);
                    $content = str_replace('{会场类型}', trim($str_place_type), $content);
                    $str_time = date('n月j日', $school_course_data['begin_time']);
                    $content = str_replace('{活动时间}', $str_time, $content);

                    A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
                }
            }

            $this->redirect('/Bz/Show/sign_up_success');
        } else {
            $errorMsg = urlencode($errorMsg);
            $this->redirect("/Bz/Show/show_error/error_msg/{$errorMsg}");
        }
    }

    /**
     * 查看是否能够报名分会场
     *
     * @param $course_id
     * @param $place_id
     * @param $student_id
     */
    public function can_sign_up_place($course_id, $place_id, $student_id, $user_apply_type_id, $place_data, $number)
    {
        $errorMsg = '';

        //不在有效期内
        if ($place_data['sign_end_time'] < time() || $place_data['sign_start_time'] > time()) {
            $errorMsg .= $place_data['name'] . " 会场已关闭或者未开始报名!";
            return array('code' => INPUT_DATA_ERR, 'msg' => $errorMsg);
        }

        //名额已用光
        if (($place_data['total_number'] - $place_data['signed_number']) < 1) {
            $errorMsg .= $place_data['name'] . " 报名已满!";
            return array('code' => INPUT_DATA_ERR, 'msg' => $errorMsg);
        }

        //不在使用中
        if (!$place_data['is_use']) {
            $errorMsg .= $place_data['name'] . " 报名已关闭!";
            return array('code' => INPUT_DATA_ERR, 'msg' => $errorMsg);
        }

        //线上铁杆社员皆不可购买
        if (!$place_data['can_offline_user_buy'] && !$place_data['can_online_user_buy']) {
            $errorMsg .= $place_data['name'] . " 报名已关闭!";
            return array('code' => INPUT_DATA_ERR, 'msg' => $errorMsg);
        }

        if ($number > $place_data['limit_number']) {
            $errorMsg .= $place_data['name'] . " 超出购买限额!";
            return array('code' => INPUT_DATA_ERR, 'msg' => $errorMsg);
        }

        //仅支持在线社员购买
        if ($user_apply_type_id == '2' && !$place_data['can_offline_user_buy']) {
            $errorMsg .= $place_data['name'] . " 仅支持在线社员!";
            return array('code' => INPUT_DATA_ERR, 'msg' => $errorMsg);
        }

        //仅支持铁杆社员购买
        if ($user_apply_type_id == '1' && !$place_data['can_online_user_buy']) {
            $errorMsg .= $place_data['name'] . " 仅支持铁杆社员!";
            return array('code' => INPUT_DATA_ERR, 'msg' => $errorMsg);
        }

        //是否已经报名该会场
        $cond = array(
            'activity_place_id' => $place_id,
            'student_id' => $student_id,
        );

        //该学生是否报名
        $sign_up_info = M('student_course')->where($cond)->find();
        if ($sign_up_info) {
            if (1 == $sign_up_info['pay_status']) {
                return $sign_up_info['status'] == 1 ? array('code' => -1, 'msg' => 'signed up') : array('code' => 1,
                    'msg' => 'OK', 'data' => $sign_up_info);    // 已报名,或可再报名
            } else {
                return array('code' => 1, 'msg' => 'OK', 'data' => $sign_up_info);    // 未支付，可再报名
            }
        }

        return array('code' => 1, 'msg' => 'OK', 'data' => $sign_up_info);
    }

    /**
     * 检查的并且报名
     *
     * @param $course_id
     * @param $place_id
     * @param $student_id
     *
     * @param $number 1 成功，2，请假重新报名，3，其他已报名或失败
     */
    public function check_and_sign_up($course_id, $place_id, $student_id, $see_type,
                                      $is_check, $number, $order_number, $money, $pay_status)
    {
        $cur_time = time();

        // check if sign up
        //是否已经报名该会场
        $cond = array(
            'activity_place_id' => $place_id,
            'student_id' => $student_id,
        );


        if ($student_id > 0) {
            //该学生是否报名
            $sign_up_info = M('student_course')->where($cond)->find();


            if ($sign_up_info) {
                if ($sign_up_info['status'] == 1) {
                    if ($sign_up_info['pay_status'] == 1) {
                        return 3;
                    } else {
                        $up_data = array(
                            'is_check' => $is_check,
                            'see_type' => $see_type,
                            'number' => $number,
                            'money' => $money,
                            'pay_status' => $pay_status,
                            'order_number' => $order_number,
                            'update_time' => $cur_time,
                        );
                        M('student_course')->where($cond)->save($up_data);
                        return 1;
                    }
                } else {    // resign up, 以前报过名，判断是否支付过
                    $up_data = array(
                        'status' => 1,
                        'is_check' => $is_check,
                        'see_type' => $see_type,
                        'number' => $number,
                        'money' => $money,
                        'pay_status' => $sign_up_info['pay_status'] == 1 ? 1 : $pay_status,
                        'order_number' => $order_number,
                        'update_time' => $cur_time
                    );

                    M('student_course')->where($cond)->save($up_data);

                    return $sign_up_info['pay_status'] == 1 ? 2 : 1;
                }
            }
        }

        $data = array(
            'school_course_id' => $course_id,
            'activity_place_id' => $place_id,
            'student_id' => $student_id,
            'time' => $cur_time,
            'is_check' => $is_check,
            'see_type' => $see_type,
            'number' => $number,
            'money' => $money,
            'pay_status' => $pay_status,
            'order_number' => $order_number,
        );

        $ret1 = D('student_course')->add($data);

        //自增该会场的已报名人数
        $ret2 = D('activity_place')->where(array('id' => $place_id))->setInc('signed_number', $number);

        return $ret1 ? 1 : 3;
    }

    /**
     * 检查用户是否已报名了单场的
     */
    public function check_is_sign_up_single_place($student_id, $course_id, $place_id = 0)
    {
        //查询改ID学生报名的所有改活动的分会场
        $db_prefix = GetDbPrefix();
        $join = 'as this left join ' . $db_prefix . 'activity_place as place on this.activity_place_id = place.id';

        $field = 'this.school_course_id,this.activity_place_id,this.status,this.auth_type,place.limit_number';
        $cond = array(
            'this.school_course_id' => $course_id,
            'this.student_id' => $student_id,
        );

        $place_data = M('student_course')->field($field)->join($join)->where($cond)->select();

        foreach ($place_data as $k => $v) {
            //已经选择了其他会场
            if ($v['can_buy_more'] == 0) {
                //查看该会场是否已经为购买，为购买则不允许改变

                return true;
            }
        }

        return false;
    }

    /**
     * 查询单场课程报名的支付方式
     *
     * @param $courseId
     */
    public function selectPayType($order_id, $money, $pay_show_url)
    {
        //查询支付方式
        $payType = D('StudentPayType')->getSelectData(false);
        foreach ($payType as $k => $v) {
            if ($v['student_pay_type_id'] == '1') {
                $payType[$k]['student_pay_type_href'] = "/Bz/WxPay/PayActivity/pay_id/{$order_id}/pay_money/{$money}/pay_show_url/{$pay_show_url}";
            } elseif ($v['student_pay_type_id'] == '2') {
                $payType[$k]['student_pay_type_href'] = "/Bz/Alipay/pay/type/6/pay_id/{$order_id}/pay_money/{$money}/pay_show_url/{$pay_show_url}";
            }
        }

        $this->assign('money', $money);
        $this->assign('payType', $payType);

        $this->display();
    }

    /**
     * 未注册用错误提示页
     *
     */
    public function errorNoStudent()
    {
        //$_GET['Id']=  substr($_GET['courseId'],0,strrpos($_GET['courseId'],'.'));
        $student_course = M('school_course')->where('id=' . $_GET['courseId'])->find();

        $this->assign('data', $student_course);
        $this->display();
    }

    /**
     * 未注册用户，跳转到该页面，选择入社模式，填写资料，进行
     */
    public function inner()
    {
        //$_GET['Id']=  substr($_GET['courseId'],0,strrpos($_GET['courseId'],'.'));
        $student_course = M('school_course')->where('id=' . $_GET['courseId'])->find();

        $this->assign('data', $student_course);
        $this->display();
    }
}
