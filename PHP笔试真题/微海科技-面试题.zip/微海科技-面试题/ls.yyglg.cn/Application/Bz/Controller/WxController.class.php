<?php
namespace Bz\Controller;

use Think\Controller;

class WxController extends Controller
{
	// 正式服务器的微信配置
	private $wx_app_id; 
	private $wx_app_secret;

	public function _initialize()
	{
		$this->wx_app_id = get_wx_app_id();
		$this->wx_app_secret = get_wx_app_secret();
	}

	/**
	 * weixin user auto login
	 *
	 */
	public function wxuserautologin()
	{
		$wxinfo = $this->wxcode(0);
		if (!$wxinfo || empty($wxinfo['openid'])) {
			//获取微信新失败
			\Think\Log::record($_SERVER['REQUEST_URI'] . " 获取微信openid出错，wxinfo:" . var_export($wxinfo), 'ERR');

			$this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/' . '获取微信信息失败');
		}

		$openid = $wxinfo['openid'];
		session('need_binding_openid', $openid);

		//查询该用户是否已经绑定了手机号
		$student_info = D('student')->getUserInfoByOpenid($openid);

		if (empty($student_info))
		{
			return false;
			//$this->redirect('/Bz/WxBinding/index');
		}

		if ($student_info['is_disable'] || empty($student_info['apply_type_id'])) {
			\Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/Show/errorOne', 'ERR');

			$this->redirect('/Bz/Show/errorOne');
		}

		//帮助用户登录
		D('Student')->setLoginSession($student_info);
	}

	/**
	 * 获取openid
	 *
	 * @param $type
	 * @return mixed
	 */
	public function wxcode($type)
	{
		if (isset($_GET['code'])) {
			$code = $_GET['code'];
		} else {
			$this->header('default', $type);
		}

		$appid = get_wx_app_id();
		$secret = get_wx_app_secret();

		$re = $this->https_request("https://api.weixin.qq.com/sns/oauth2/access_token?appid=" . $appid . "&secret=" . $secret . "&code=" . $code . "&grant_type=authorization_code");

		return json_decode($re, true);
	}

	//获取用户信息基本
	public function weixinxinxi($wxid)
	{
		$appid = get_wx_app_id();
		$secret = get_wx_app_secret();
		$wx_ass = $this->https_request('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' . $appid . '&secret=' . $secret);
		$wx_ass_obj = json_decode($wx_ass, true);
		$access_token = $wx_ass_obj['access_token'];

		$wx_url = 'https://api.weixin.qq.com/cgi-bin/user/info?access_token=' . $access_token . '&openid=' . $wxid;
		$wx_xinxi = $this->https_request($wx_url);//test

		//\Think\Log::record($wx_url . ' weixinxinxi=' . $wx_xinxi, 'INFO');

		$wx_xinxi_obj = json_decode($wx_xinxi, true);

		return $wx_xinxi_obj;
	}

	//获取用户授权信息 $wxid 为获取的授权信息
	public function getweixinxinxi($wxid)
	{
		$wx_url = 'https://api.weixin.qq.com/sns/userinfo?access_token=' . $wxid['access_token'] . '&openid=' . $wxid['openid'];
		$wx_xinxi = $this->https_request($wx_url);//test

		//\Think\Log::record($wx_url . ' getweixinxinxi=' . $wx_xinxi, 'INFO');

		$wx_xinxi_obj = json_decode($wx_xinxi, true);

		return $wx_xinxi_obj;
	}

	//获取jsapi_ticket
	public function jsapi_ticket($access_token)
	{
		$wx_ass = $this->https_request('https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=' . $access_token . '&type=jsapi');
		$wx_ass_obj = json_decode($wx_ass, true);

		return $wx_ass_obj['ticket'];
	}

	//文件读取
	public function https_request($url, $data = null)
	{
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);

		if (!empty($data)) {
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}

		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$output = curl_exec($curl);
		curl_close($curl);

		return $output;
	}

	//获得access_token
	public function http_get($url)
	{
		$oCurl = curl_init();
		if (stripos($url, 'https://') !== FALSE) {
			curl_setopt($oCurl, CURLOPT_SSL_VERIFYPEER, FALSE);
			curl_setopt($oCurl, CURLOPT_SSL_VERIFYHOST, FALSE);
			curl_setopt($oCurl, CURLOPT_SSLVERSION, 1);
		}

		curl_setopt($oCurl, CURLOPT_URL, $url);
		curl_setopt($oCurl, CURLOPT_RETURNTRANSFER, 1);
		$sContent = curl_exec($oCurl);
		$aStatus = curl_getinfo($oCurl);
		curl_close($oCurl);

		if (intval($aStatus['http_code']) == 200) {
			$q = json_decode($sContent, true);
			return $wxid = $q['access_token'];
		} else {
			return false;
		}
	}

	//url 为需要分享的链接
	public function getSignature($href)
	{
		$data['time_duan'] = $time_duan = date('Ym');
		$data['nonceStr'] = $nonceStr = $time_duan . substr(str_shuffle('ABCDEFGHIJKNPQRTUYabcdefghijkmnopqrstuvwxyz0123456789'), 0, 20);
		$data['appid'] = $appid = get_wx_app_id();
		$data['secret'] = $secret = get_wx_app_secret();
		$url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' . $appid . '&secret=' . $secret;
		if (S('jsapi_ticket')) {
			$data['jsapi_ticket'] = $jsapi_ticket = S('jsapi_ticket');
		} else {
			$token = $this->http_get($url);
			$data['jsapi_ticket'] = $jsapi_ticket = $this->jsapi_ticket($token);
			S('jsapi_ticket', $jsapi_ticket, 7000);
		}
		$data['timestamp'] = $timestamp = time();
		$data['url'] = $href;
		$url = $this->get_url();
		$str = 'jsapi_ticket=' . $jsapi_ticket . '&noncestr=' . $nonceStr . '&timestamp=' . $timestamp . '&url=' . $url;
		$data['signature'] = $signature = sha1($str);

		return $data;
	}


	public function isWeixin()
	{
		if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
			return true;
		}

		return false;
	}

	//跳转到微信
	public function header($url, $type)
	{
		if ($url == 'default') {
			$url = $this->get_url();
		}

		if ($type) {
			$type = 'snsapi_userinfo';
		} else {
			$type = 'snsapi_base';
		}

		//header('Location: https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$this->wx_app_id.'&redirect_uri='.$url.'?response_type=code&scope=snsapi_base&state=1#wechat_redirect');
		header('Location: https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $this->wx_app_id . '&redirect_uri=' . $url . '&response_type=code&scope=' . $type . '&state=1#wechat_redirect');
		exit();

		//snsapi_userinfo 获取用户详细信息需关注
		//snsapi_base 只获取用户OPENid

	}

	//获取当前url
	public function get_url()
	{
		$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
		$php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
		$path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
		$relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self . (isset($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : $path_info);
		return $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url;
	}

	//判断是否为微信浏览器
	public function isWx()
	{
		$user_agent = $_SERVER['HTTP_USER_AGENT'];
		if (strpos($user_agent, 'MicroMessenger') === false) {
			// 非微信浏览器禁止浏览
			return false;
		} else {
			// 获取版本号
			preg_match('/.*?(MicroMessenger\/([0-9.]+))\s*/', $user_agent, $matches);
			return $matches[2];
		}
	}


}