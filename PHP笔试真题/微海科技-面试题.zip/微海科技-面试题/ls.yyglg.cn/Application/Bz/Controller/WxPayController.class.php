<?php
namespace Bz\Controller;

use Think\Controller;

//支付 
class WxPayController extends Controller
{
    private $_config;

    public function _initialize()
    {
        $this->_config['apply_join_notify_url'] = S_URL . '/Bz/WxPay/notifyUrl';
        $this->_config['buy_one_course_notify_url'] = S_URL . '/Bz/WxPay/notifyUrlPayOneCourse';
        $this->_config['renew_notify_url'] = S_URL . '/Bz/WxPay/notifyUrlPayRenew';
        $this->_config['upgrade_notify_url'] = S_URL . '/Bz/WxPay/notifyUrlPayUpgrade';
        $this->_config['reward_notify_url'] = S_URL . '/Bz/WxPay/notifyUrlPayRewardTeacher';
        $this->_config['activity_notify_url'] = S_URL . '/Bz/WxPay/notifyUrlPayActivity';

        //salty : 打赏视频
        $this->_config['reward_video_notify_url'] = S_URL . '/Bz/WxPay/notifyUrlPayRewardVideo';

        //=======【JSAPI路径设置】===================================
        //获取access_token过程中的跳转uri，通过跳转将code传入jsapi支付页面
        $this->_config['js_api_call_url'] = S_URL . '/Bz/WxPay/pay?showwxpaytitle=1';
        $this->_config['js_api_call_url_one_course'] = S_URL . '/Bz/WxPay/indexPayOneCourse?showwxpaytitle=1';
        $this->_config['js_api_call_url_renew'] = S_URL . '/Bz/WxPay/payStudentRenew?showwxpaytitle=1';
        $this->_config['js_api_call_url_reward'] = S_URL . '/Bz/WxPay/payStudentRewardTeacher?showwxpaytitle=1';
        $this->_config['js_api_call_url_reward_video'] = S_URL . '/Bz/WxPay/payStudentRewardVideo?showwxpaytitle=1';
        $this->_config['js_api_call_url_upgrade'] = S_URL . '/Bz/WxPay/payStudentUpgrade?showwxpaytitle=1';
        $this->_config['js_api_call_url_activity'] = S_URL . '/Bz/WxPay/PayActivity?showwxpaytitle=1';
    }

    //-------------------------------------------------------------------------------------------入社费用
    public function unified_pay()
    {
        $pay_id = session('apply_pay_id');
        $apply_count_money = session('apply_count_money');
        $pay_description = '抱柱网入社费用';
        $data = D('student_no_pay')->getOne($pay_id);

        //查询不到该条信息
        if (!$data) {
            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

            $this->redirect('/Bz/School/index');
        }

        $this->assign('apply_count_money', $apply_count_money);
        vendor('WxPayPubHelper.WxPayPubHelper');
        $jsApi = new \JsApi_pub();
        if (!isset($_GET['code'])) {
            //触发微信返回code码
            $url = $jsApi->createOauthUrlForCode($this->_config['js_api_call_url']);
            Header("Location: $url");
        } else {
            //获取code码，以获取openid
            $code = $_GET['code'];
            $jsApi->setCode($code);
            $openid = $jsApi->getOpenId();
        }

        $unifiedOrder = new \UnifiedOrder_pub();
        $unifiedOrder->setParameter("openid", "$openid");//商品描述
        $unifiedOrder->setParameter("body", $pay_description);//商品描述
        $timeStamp = time();
        $out_trade_no = $this->createOrderNumber();
        $unifiedOrder->setParameter("out_trade_no", "$out_trade_no");//商户订单号
        $unifiedOrder->setParameter("total_fee", $apply_count_money * 100);//总金额
        $unifiedOrder->setParameter("notify_url", $this->_config['apply_join_notify_url']);//通知地址
        $unifiedOrder->setParameter("trade_type", "JSAPI");//交易类型
        $unifiedOrder->setParameter("attach", $pay_id);//附加数据

        $prepay_id = $unifiedOrder->getPrepayId();
        $jsApi->setPrepayId($prepay_id);
        $jsApiParameters = $jsApi->getParameters();

        $this->assign('jsApiParameters', $jsApiParameters);

        $this->display('pay');
    }


    //通知
    public function unified_notify()
    {
        vendor('WxPayPubHelper.log_');
        vendor('WxPayPubHelper.WxPayPubHelper');

        //使用通用通知接口
        $notify = new \Notify_pub();

        //存储微信的回调
        $xml = $GLOBALS['HTTP_RAW_POST_DATA'];
        $notify->saveData($xml);
        if ($notify->checkSign() == FALSE) {
            $notify->setReturnParameter("return_code", "FAIL");//返回状态码
            $notify->setReturnParameter("return_msg", "签名失败");//返回信息
        } else {
            $notify->setReturnParameter("return_code", "SUCCESS");//设置返回码
        }

        $returnXml = $notify->returnXml();
        $log_ = new \Log_();
        $log_name = "./notify_url.log";//log文件路径
        $log_->log_result($log_name, "【接收到的notify通知】:\n" . $xml . "\n");

        if ($notify->checkSign() == TRUE) {
            if ($notify->data["return_code"] == "FAIL") {
                $log_->log_result($log_name, "【通信出错】:\n" . $xml . "\n");
            } else if ($notify->data["result_code"] == "FAIL") {
                $log_->log_result($log_name, "【业务出错】:\n" . $xml . "\n");
            } else {
                $log_->log_result($log_name, "【支付成功   " . $notify->data["attach"] . "】:\n" . $xml . "\n");
                $nopaydata = D('student_no_pay')->getOne($notify->data["attach"]);
                if (!$nopaydata) {
                    die;
                }
                D('student_no_pay')->deleteOne($nopaydata['id']);

                D()->startTrans();

                //修改会员信息
                $nopaydata['apply_type_id'] = $nopaydata['apply_type_id'];
                $nopaydata['end_time'] = strtotime("+" . $nopaydata['apply_year_number'] . " year");
                //学号已经生成
                //$nopaydata['school_student_number'] = D('HtmlSystemSetup')->createStudentNumber();

                $ret1 = D('Student')->SetJoinSucceed($nopaydata['apply_type_id'], $nopaydata['end_time'], $nopaydata['mobile_phone']);


                //保存用户的入社交易记录
                $ret2 = D('student_pay_record')->createApplyOne($ret1, ($notify->data['total_fee']) / 100,
                    $notify->data['out_trade_no'], '入社费', '微信支付', 0, $notify->data['transaction_id'],
                    $nopaydata['true_name'], $nopaydata['mobile_phone'], $nopaydata['school_student_number']);

                if ($ret1 && $ret2) {
                    D()->commit();
                    //发送短信
                    $content = "尊敬的{$nopaydata['true_name']}，欢迎加入抱柱大学-！您的专属社员编号为：{$nopaydata['school_student_number']}；请在微信搜索关注" . $this->nameConfig['WECHAT_SERVICE_NAME'] . ",绑定手机号码可以查看个人信息以及报名课程。";

                    A('Public')->sendShortMsg($nopaydata['mobile_phone'], $content);
                } else {
                    D()->rollback();
                    //发送邮件
                    $content = '尊敬的' . $nopaydata['true_name'] . '，欢迎加入抱柱大学，系统错误导致入社失败，请联系客服，对您造成的不便深感抱歉。';
                    A('Public')->sendShortMsg($nopaydata['mobile_phone'], $content);
                    \Think\Log::Write($content . '手机号：' . $nopaydata['mobile_phone']);
                }
            }
        }

        echo $returnXml;
    }

    //-------------------------------------------------------------------------------------------入社费用
    public function pay($jump_url = '')
    {
        if (!empty($jump_url)) {
            session('jump_url', $jump_url);
        } else {
            $jump_url = session('jump_url');
        }

        $pay_id = session('apply_pay_id');
        $apply_count_money = session('apply_count_money');
        $pay_description = '抱柱大学入社费用';
        $data = D('student_no_pay')->getOne($pay_id);

        //查询不到该条信息
        if (!$data) {
            \Think\Log::record(__FILE__ . __FUNCTION__ . __LINE__ . ' redirect to /Bz/School/index', 'ERR');

            $this->redirect('/Bz/School/index');
        }


        $this->assign('apply_count_money', $apply_count_money);
        vendor('WxPayPubHelper.WxPayPubHelper');
        $jsApi = new \JsApi_pub();


        if (!isset($_GET['code'])) {
            //触发微信返回code码
            $url = $jsApi->createOauthUrlForCode($this->_config['js_api_call_url']);
            Header("Location: $url");
        } else {
            //获取code码，以获取openid
            $code = $_GET['code'];
            $jsApi->setCode($code);
            $openid = $jsApi->getOpenId();
        }

        $unifiedOrder = new \UnifiedOrder_pub();
        $unifiedOrder->setParameter("openid", "$openid");//商品描述
        $unifiedOrder->setParameter("body", $pay_description);//商品描述
        $timeStamp = time();
        $out_trade_no = $this->createOrderNumber();
        $unifiedOrder->setParameter("out_trade_no", "$out_trade_no");//商户订单号
        $unifiedOrder->setParameter("total_fee", $apply_count_money * 100);//总金额
        $unifiedOrder->setParameter("notify_url", $this->_config['apply_join_notify_url']);//通知地址
        $unifiedOrder->setParameter("trade_type", "JSAPI");//交易类型
        $unifiedOrder->setParameter("attach", $pay_id);//附加数据

        $prepay_id = $unifiedOrder->getPrepayId();
        $jsApi->setPrepayId($prepay_id);
        $jsApiParameters = $jsApi->getParameters();

        $this->assign('jsApiParameters', $jsApiParameters);
        if (empty($jump_url)) {
            $jump_url = '/Bz/School/indexSuccess';
        } else {
            $jump_url = "/Bz/School/indexSuccess/jump_url/{$jump_url}";
        }


        $this->assign('jump_url', $jump_url);

        $this->display('pay');
    }


    /**
     * 入社支付成功通知 ：微信的回调
     *
     */
    public function notifyUrl()
    {
        vendor('WxPayPubHelper.log_');
        vendor('WxPayPubHelper.WxPayPubHelper');

        //使用通用通知接口
        $notify = new \Notify_pub();


        //存储微信的回调
        $xml = $GLOBALS['HTTP_RAW_POST_DATA'];
        $notify->saveData($xml);
        if ($notify->checkSign() == FALSE) {
            $notify->setReturnParameter("return_code", "FAIL");//返回状态码
            $notify->setReturnParameter("return_msg", "签名失败");//返回信息
        } else {
            $notify->setReturnParameter("return_code", "SUCCESS");//设置返回码
        }

        $returnXml = $notify->returnXml();
        $log_ = new \Log_();
        $log_name = "./notify_url.log";//log文件路径
        $log_->log_result($log_name, "【接收到的notify通知】:\n" . $xml . "\n");

        if ($notify->checkSign() == TRUE) {
            if ($notify->data["return_code"] == "FAIL") {
                $log_->log_result($log_name, "【通信出错】:\n" . $xml . "\n");
            } else if ($notify->data["result_code"] == "FAIL") {
                $log_->log_result($log_name, "【业务出错】:\n" . $xml . "\n");
            } else {
                $log_->log_result($log_name, "【支付成功   " . $notify->data["attach"] . "】:\n" . $xml . "\n");
                $nopaydata = D('student_no_pay')->getOne($notify->data["attach"]);
                if (!$nopaydata) {
                    die;
                }

                D('student_no_pay')->deleteOne($nopaydata['id']);


                $where['mobile_phone'] = $nopaydata['mobile_phone'];
                $data = M('student')->where($where)->find();

                D()->startTrans();
                //  修改会员信息
                $nopaydata['apply_type_id'] = $nopaydata['apply_type_id'];
                $nopaydata['end_time'] = strtotime("+" . $nopaydata['apply_year_number'] . " year");
                $nopaydata['school_student_number'] = $data['school_student_number'];


                $ret1 = D('Student')->SetJoinSucceed($nopaydata['apply_type_id'], $nopaydata['end_time'], $nopaydata['mobile_phone']);


                //保存用户的入社交易记录
                $ret2 = D('student_pay_record')->createApplyOne($data['id'], ($notify->data['total_fee']) / 100,
                    $notify->data['out_trade_no'], '入社费', '微信支付', 0, $notify->data['transaction_id'],
                    $nopaydata['true_name'], $nopaydata['mobile_phone'], $nopaydata['school_student_number']);


                if ($ret1 && $ret2) {
                    D()->commit();
                    //  A('Public')->sendShortMsg('18682157284', "收到一次微信的回调".$nopaydata['apply_type_id']."|". $nopaydata['end_time']."|".$nopaydata['mobile_phone']."|".$ret1."|".$ret2."|".$nopaydata['school_student_number']);

                    //发送短信
                    $content = "尊敬的" . $nopaydata['true_name'] . "，欢迎加入抱柱大学！您的专属社员编号为：" . $nopaydata['school_student_number'] . "；请在微信搜索关注“抱柱大学服务号”，绑定手机号码可查看个人信息及报名课程。";

                    $a = A('Public')->sendShortMsg($nopaydata['mobile_phone'], $content);

                    // A('Public')->sendShortMsg('18682157284', "aaa" . $a );

                    $content = "尊敬的" . $nopaydata['true_name'] . "，加入抱柱大学第一天，送您一份“抱柱大学往期课堂学习笔记”大礼包，点击链接http://dwz.cn/2WHKF7，进入学习，关注微信“" . $this->nameConfig['WECHAT_SERVICE_NAME'] . "”获得更多课程信息。";


                    $b = A('Public')->sendShortMsg($nopaydata['mobile_phone'], $content);

                    //   A('Public')->sendShortMsg('18682157284',  "bbb" . $b);

                    //   A('Public')->sendShortMsg('18682157284', "test");

                } else {
                    D()->rollback();
                    //发送短信
                    $content = "尊敬的{$nopaydata['true_name']}，您好，由于系统问题导致入社失败，请到" . $this->nameConfig['WECHAT_SERVICE_NAME'] . "重新入社，如有疑问请联系抱柱网公众号";

                    A('Public')->sendShortMsg($nopaydata['mobile_phone'], $content);

                    \Think\Log::Write($content . '手机号：' . $nopaydata['mobile_phone']);
                }

            }

        }
        echo $returnXml;
    }


    //-----------------------------------------------------------------------------------------单场课程支付
    /**
     * 单场课程支付
     *
     */
    public function indexPayOneCourse()
    {
        vendor('WxPayPubHelper.WxPayPubHelper');
        $jsApi = new \JsApi_pub();
        if (!isset($_GET['code'])) {
            //触发微信返回code码
            $url = $jsApi->createOauthUrlForCode($this->_config['js_api_call_url_one_course']);
            Header("Location: $url");
        } else {
            //获取code码，以获取openid
            $code = $_GET['code'];
            $jsApi->setCode($code);
            $openid = $jsApi->getOpenId();
            $courseId = session('need_pay_course_id');
            $pay_id = session('course_one_pay_id');
            //查询该课程信息
            $where['id'] = $courseId;
            $data = M('school_course')->where($where)->find();
            if (!$data) {
                exit('无数据');//查询不到处理
            }

            $pay_description = '购买单场课程：' . ($data['name']);
            $this->assign('data', $data);
        }

        $unifiedOrder = new \UnifiedOrder_pub();
        $unifiedOrder->setParameter("openid", "$openid");//商品描述
        $unifiedOrder->setParameter("body", $pay_description);//商品描述
        $timeStamp = time();
        $out_trade_no = $this->createOrderNumber();
        $unifiedOrder->setParameter("out_trade_no", "$out_trade_no");//商户订单号
        $unifiedOrder->setParameter("total_fee", ($data['one_money']) * 100);//总金额
        $unifiedOrder->setParameter("notify_url", $this->_config['buy_one_course_notify_url']);//通知地址
        $unifiedOrder->setParameter("trade_type", "JSAPI");//交易类型
        $unifiedOrder->setParameter("attach", $pay_id);//附加数据

        $prepay_id = $unifiedOrder->getPrepayId();
        $jsApi->setPrepayId($prepay_id);
        $jsApiParameters = $jsApi->getParameters();
        $this->assign('jsApiParameters', $jsApiParameters);

        $this->display('indexPayOneCourse');
    }


    //购买单场课程通知
    public function notifyUrlPayOneCourse()
    {
        vendor('WxPayPubHelper.log_');
        vendor('WxPayPubHelper.WxPayPubHelper');

        //使用通用通知接口
        $notify = new \Notify_pub();

        //存储微信的回调
        $xml = $GLOBALS['HTTP_RAW_POST_DATA'];
        $notify->saveData($xml);
        if ($notify->checkSign() == FALSE) {
            $notify->setReturnParameter("return_code", "FAIL");//返回状态码
            $notify->setReturnParameter("return_msg", "签名失败");//返回信息
        } else {
            $notify->setReturnParameter("return_code", "SUCCESS");//设置返回码
        }
        $returnXml = $notify->returnXml();
        $log_ = new \Log_();
        $log_name = "./notify_url.log";//log文件路径
        $log_->log_result($log_name, "【接收到的notify通知】:\n" . $xml . "\n");

        if ($notify->checkSign() == TRUE) {
            if ($notify->data["return_code"] == "FAIL") {
                $log_->log_result($log_name, "【通信出错】:\n" . $xml . "\n");
            } else if ($notify->data["result_code"] == "FAIL") {
                $log_->log_result($log_name, "【业务出错】:\n" . $xml . "\n");
            } else {
                $log_->log_result($log_name, "【支付成功   " . $notify->data["attach"] . "】:\n" . $xml . "\n");
                $nopaydata = D('student_no_pay_one_course')->getOne($notify->data["attach"]);
                if (!$nopaydata) {
                    die;
                }

                D('student_no_pay_one_course')->deleteOne($nopaydata['id']);
                //查询用户信息
                $userdata = M('student')->where(array('id' => $nopaydata['student_id']))->find();
                //查询课程信息
                $coursedata = M('school_course')->where(array('id' => $nopaydata['course_id']))->find();
                $ret1 = D('StudentCourse')->addOnePayCourse($nopaydata['student_id'], $nopaydata['course_id'], ($notify->data['total_fee']) / 100);

                D('student_pay_record')->createApplyOne($nopaydata['student_id'], ($notify->data['total_fee']) / 100,
                    $notify->data['out_trade_no'], '单场课程费', '微信支付', 0, $notify->data['transaction_id'],
                    $userdata['true_name'], $userdata['mobile_phone'], $userdata['school_student_number']);

                if ($ret1) {

                    $content = '亲爱的' . $userdata['true_name'] . '，您已成功购买课程“' . $coursedata['name'] . '”(' . $coursedata['one_see_type'] . '),请记得参加哦。';
                    A('Public')->sendShortMsg($userdata['mobile_phone'], $content);

                } else {

                    $content = '亲爱的' . $userdata['true_name'] . '，系统错误导致购买失败，请联系专属管理员，对您造成的不便深感抱歉。';
                  //  A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
                    \Think\Log::Write($content . '手机号：' . $userdata['mobile_phone']);
                }

            }

        }
        echo $returnXml;
    }


    //-----------------------------------------------------------------------------------------用户续费管理
    /**
     * 用户续费管理
     *
     */
    public function payStudentRenew()
    {
        vendor('WxPayPubHelper.WxPayPubHelper');

        $jsApi = new \JsApi_pub();

        if (!isset($_GET['code'])) {
            //触发微信返回code码
            $url = $jsApi->createOauthUrlForCode($this->_config['js_api_call_url_renew']);
            Header("Location: $url");
        } else {
            //获取code码，以获取openid
            $code = $_GET['code'];
            $jsApi->setCode($code);
            $openid = $jsApi->getOpenId();
            $renew_pay_id = session('renew_pay_id');
            $data = D('student_no_pay_renew')->getOne($renew_pay_id);
            //查询不到该条信息
            if (!$data) {
                $this->redirect('/Bz/StudentRenew/studentRenew');
            }

            $pay_description = '会员续费（' . $data['apply_type_year'] . '年）';
            $this->assign('data', $data);
        }

        $unifiedOrder = new \UnifiedOrder_pub();
        $unifiedOrder->setParameter("openid", "$openid");//商品描述
        $unifiedOrder->setParameter("body", $pay_description);//商品描述
        $timeStamp = time();
        $out_trade_no = $this->createOrderNumber();
        $unifiedOrder->setParameter("out_trade_no", "$out_trade_no");//商户订单号
        $unifiedOrder->setParameter("total_fee", ($data['money']) * 100);//总金额
        $unifiedOrder->setParameter("notify_url", $this->_config['renew_notify_url']);//通知地址
        $unifiedOrder->setParameter("trade_type", "JSAPI");//交易类型
        $unifiedOrder->setParameter("attach", $renew_pay_id);//附加数据

        $prepay_id = $unifiedOrder->getPrepayId();
        $jsApi->setPrepayId($prepay_id);
        $jsApiParameters = $jsApi->getParameters();
        $this->assign('jsApiParameters', $jsApiParameters);
        $this->display('payStudentRenew');
    }

    //续费通知
    public function notifyUrlPayRenew()
    {
        vendor('WxPayPubHelper.log_');
        vendor('WxPayPubHelper.WxPayPubHelper');

        //使用通用通知接口
        $notify = new \Notify_pub();

        //存储微信的回调
        $xml = $GLOBALS['HTTP_RAW_POST_DATA'];
        $notify->saveData($xml);
        if ($notify->checkSign() == FALSE) {
            $notify->setReturnParameter("return_code", "FAIL");//返回状态码
            $notify->setReturnParameter("return_msg", "签名失败");//返回信息
        } else {
            $notify->setReturnParameter("return_code", "SUCCESS");//设置返回码
        }
        $returnXml = $notify->returnXml();
        $log_ = new \Log_();
        $log_name = "./notify_url.log";//log文件路径
        $log_->log_result($log_name, "【接收到的notify通知】:\n" . $xml . "\n");

        $cur_time = time();

        if ($notify->checkSign() == TRUE) {
            if ($notify->data["return_code"] == "FAIL") {
                $log_->log_result($log_name, "【通信出错】:\n" . $xml . "\n");
            } else if ($notify->data["result_code"] == "FAIL") {
                $log_->log_result($log_name, "【业务出错】:\n" . $xml . "\n");
            } else {
                $log_->log_result($log_name, "【支付成功   " . $notify->data["attach"] . "】:\n" . $xml . "\n");
                $nopaydata = D('student_no_pay_renew')->getOne($notify->data["attach"]);
                if (!$nopaydata) {
                    die;
                }

                D('student_no_pay_renew')->deleteOne($nopaydata['id']);
                //查询用户信息
                $userdata = M('student')->where(array('id' => $nopaydata['student_id']))->find();


                $ifFirstTime = 0;

                //如果注册时间和到期时间差不多，说明是第一次
                if (abs($userdata['end_time'] - $userdata['time']) < 3600) {
                    $ifFirstTime = 1;

                }

                //为用户续费（延长到期时间）
                if ($userdata['end_time'] < $cur_time) {
                    $userdata['end_time'] = $cur_time;
                }
                $end_time = D('student')->getNewEndTime($userdata['end_time'], $nopaydata['apply_type_year']);

                $ret1 = D('student')->incEndTime($nopaydata['student_id'], $end_time, $nopaydata['apply_type_id']);

                $ret2 = D('student_pay_record')->createApplyOne($nopaydata['student_id'], ($notify->data['total_fee']) / 100,
                    $notify->data['out_trade_no'], '续费', '微信支付', 0, $notify->data['transaction_id'],
                    $userdata['true_name'], $userdata['mobile_phone'], $userdata['school_student_number']);


                if ($ret1) {
                    //发送短信
                    $str_end_time = date('Y年m月d日', $end_time);
                    $content = "亲爱的{$userdata['true_name']}，您已续费成功，社员有效期延长至{$str_end_time}，了解最新课程、报名课程请在" . $this->nameConfig['WECHAT_SERVICE_NAME'] . "查询。";
                    if ($ifFirstTime == 1) {
                        $content = "亲爱的{$userdata['true_name']}，您已入社成功，社员有效期至{$str_end_time}，了解最新课程、报名课程请在" . $this->nameConfig['WECHAT_SERVICE_NAME'] . "查询。";
                    } else {
                        $content = "亲爱的{$userdata['true_name']}，您已续费成功，社员有效期延长至{$str_end_time}，了解最新课程、报名课程请在" . $this->nameConfig['WECHAT_SERVICE_NAME'] . "查询。";
                    }
                    A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
                } else {
                    //发送邮件
                    $content = '亲爱的' . $userdata['true_name'] . '，系统错误导致续费失败，请联系客服，对您造成的不便深感抱歉。';
                    A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
                    \Think\Log::Write($content . '手机号：' . $userdata['mobile_phone']);
                }

            }

        }

        echo $returnXml;

    }

    //-----------------------------------------------------------------------------------------------用户打赏付款

//打赏视频的 salty 2016-07-05 21:40:40
    public function payStudentRewardVideo()
    {

        vendor('WxPayPubHelper.WxPayPubHelper');

        $jsApi = new \JsApi_pub();
        if (!isset($_GET['code'])) {
            //触发微信返回code码
            $url = $jsApi->createOauthUrlForCode($this->_config['js_api_call_url_reward_video']);
            Header("Location: $url");
        } else {
            //获取code码，以获取openid
            $code = $_GET['code'];
            $jsApi->setCode($code);
            $openid = $jsApi->getOpenId();
            $course_reward_pay_id = session('course_reward_pay_id');
            $data = D('student_no_pay_reward')->getOne($course_reward_pay_id);

            //查询不到该条信息
            if (!$data) {
                $this->redirect('/Bz/CourseReward/rewardTeacherClose');
            }

            // $courseInfo = D('school_course')->where(array('id' => $data['course_id']))->field('name')->find();
            $pay_description = '打赏支付';
            $this->assign('data', $data);
        }

        $unifiedOrder = new \UnifiedOrder_pub();
        $unifiedOrder->setParameter("openid", "$openid");//商品描述
        $unifiedOrder->setParameter("body", $pay_description);//商品描述

        $timeStamp = time();
        $out_trade_no = $this->createOrderNumber();


        $unifiedOrder->setParameter("out_trade_no", "$out_trade_no");//商户订单号
        $unifiedOrder->setParameter("total_fee", ($data['money']) * 100);//总金额
        $unifiedOrder->setParameter("notify_url", $this->_config['reward_video_notify_url']);//通知地址
        $unifiedOrder->setParameter("trade_type", "JSAPI");//交易类型
        $unifiedOrder->setParameter("attach", $course_reward_pay_id);//附加数据

        $prepay_id = $unifiedOrder->getPrepayId();
        $jsApi->setPrepayId($prepay_id);
        $jsApiParameters = $jsApi->getParameters();
        $this->assign('jsApiParameters', $jsApiParameters);

        $this->display('payStudentRewardTeacher');
    }


//支付成功回调，打赏视频的 salty 2016-07-05 21:43:16
    public function notifyUrlPayRewardVideo()
    {
        vendor('WxPayPubHelper.log_');
        vendor('WxPayPubHelper.WxPayPubHelper');

        //使用通用通知接口
        $notify = new \Notify_pub();

        //存储微信的回调
        $xml = $GLOBALS['HTTP_RAW_POST_DATA'];
        $notify->saveData($xml);
        if ($notify->checkSign() == FALSE) {
            $notify->setReturnParameter("return_code", "FAIL");//返回状态码
            $notify->setReturnParameter("return_msg", "签名失败");//返回信息
        } else {
            $notify->setReturnParameter("return_code", "SUCCESS");//设置返回码
        }

        $returnXml = $notify->returnXml();
        $log_ = new \Log_();
        $log_name = "./notify_url.log";//log文件路径
        $log_->log_result($log_name, "【接收到的notify通知】:\n" . $xml . "\n");

        if ($notify->checkSign() == TRUE) {
            if ($notify->data["return_code"] == "FAIL") {
                $log_->log_result($log_name, "【通信出错】:\n" . $xml . "\n");
            } else if ($notify->data["result_code"] == "FAIL") {
                $log_->log_result($log_name, "【业务出错】:\n" . $xml . "\n");
            } else {
                $log_->log_result($log_name, "【支付成功   " . $notify->data["attach"] . "】:\n" . $xml . "\n");
                $nopaydata = D('student_no_pay_reward')->getOne($notify->data["attach"]);
                if (!$nopaydata) {
                    die;
                }
                $courseInfo = D('school_course')->where(array('id' => $nopaydata['course_id']))->field('name')->find();
                D('student_no_pay_reward')->deleteOne($nopaydata['id']);
                //查询用户信息
                $userdata = M('student')->where(array('id' => $nopaydata['student_id']))->find();
                if (!$userdata['true_name']) {
                    $userdata['true_name'] = '匿名';
                }
                if (!$userdata['school_student_number']) {
                    $userdata['school_student_number'] = '临时会员';
                }

                $reward_id = D('school_course_reward')->rewardTeacherSuccess($nopaydata, $userdata, '微信支付');
                if ($reward_id) {
                    //保存交易记录
                    D('student_pay_record')->createApplyOne($userdata['id'], $nopaydata['money'], $notify->data['out_trade_no'],
                        '打赏视频-' . $courseInfo['name'], '微信支付', $reward_id, $notify->data['transaction_id'],
                        $userdata['true_name'], $userdata['mobile_phone'], $userdata['school_student_number']);

                    //发送邮件
                    $content = '亲爱的' . $userdata['true_name'] . '，您已成功打赏。';
                    //A('Public')->sendShortMsg($userdata['mobile_phone'], $content);

                    $this_msg['name'] = D('reward_student')->getTrueName($nopaydata['course_id'], $userdata['mobile_phone']);
                    if (empty($this_msg['name'])) {
                        $this_msg['name'] = $userdata['true_name'];
                    }

                    $this_msg['msg'] = msubstr($nopaydata['static_msg'], 0, 20, 'utf-8', false);
                    $this_msg['time'] = date('H:i');
                    $this_msg['price']=$nopaydata['money'];
                    D('system_reward')->cnlSocketNewReward($this_msg, $nopaydata['reward_id']);
                } else {
                    //发送邮件
                    $content = '亲爱的' . $userdata['true_name'] . '，系统错误导致打赏失败，请联系客服，对您造成的不便深感抱歉。';
                    //A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
                    \Think\Log::Write($content . '手机号：' . $userdata['mobile_phone']);
                }
            }
        }

        echo $returnXml;
    }

//    打赏老师的
    public function payStudentRewardTeacher()
    {
        vendor('WxPayPubHelper.WxPayPubHelper');

        $jsApi = new \JsApi_pub();
        if (!isset($_GET['code'])) {
            //触发微信返回code码
            $url = $jsApi->createOauthUrlForCode($this->_config['js_api_call_url_reward']);
            Header("Location: $url");
        } else {
            //获取code码，以获取openid
            $code = $_GET['code'];
            $jsApi->setCode($code);
            $openid = $jsApi->getOpenId();
            $course_reward_pay_id = session('course_reward_pay_id');
            $data = D('student_no_pay_reward')->getOne($course_reward_pay_id);
            //查询不到该条信息
            if (!$data) {
                $this->redirect('/Bz/CourseReward/rewardTeacherClose');
            }


            $pay_description = '打赏支付';
            $this->assign('data', $data);
        }

        $unifiedOrder = new \UnifiedOrder_pub();
        $unifiedOrder->setParameter("openid", "$openid");//商品描述
        $unifiedOrder->setParameter("body", $pay_description);//商品描述

        $timeStamp = time();
        $out_trade_no = $this->createOrderNumber();

        $unifiedOrder->setParameter("out_trade_no", "$out_trade_no");//商户订单号
        $unifiedOrder->setParameter("total_fee", ($data['money']) * 100);//总金额
        $unifiedOrder->setParameter("notify_url", $this->_config['reward_notify_url']);//通知地址
        $unifiedOrder->setParameter("trade_type", "JSAPI");//交易类型
        $unifiedOrder->setParameter("attach", $course_reward_pay_id);//附加数据

        $prepay_id = $unifiedOrder->getPrepayId();
        $jsApi->setPrepayId($prepay_id);
        $jsApiParameters = $jsApi->getParameters();
        $this->assign('jsApiParameters', $jsApiParameters);

        $this->display('payStudentRewardTeacher');
    }


    /**
     * 打赏支付成功通知
     *
     */
    public function notifyUrlPayRewardTeacher()
    {
        vendor('WxPayPubHelper.log_');
        vendor('WxPayPubHelper.WxPayPubHelper');

        //使用通用通知接口
        $notify = new \Notify_pub();

        //存储微信的回调
        $xml = $GLOBALS['HTTP_RAW_POST_DATA'];
        $notify->saveData($xml);
        if ($notify->checkSign() == FALSE) {
            $notify->setReturnParameter("return_code", "FAIL");//返回状态码
            $notify->setReturnParameter("return_msg", "签名失败");//返回信息
        } else {
            $notify->setReturnParameter("return_code", "SUCCESS");//设置返回码
        }

        $returnXml = $notify->returnXml();
        $log_ = new \Log_();
        $log_name = "./notify_url.log";//log文件路径
        $log_->log_result($log_name, "【接收到的notify通知】:\n" . $xml . "\n");

        if ($notify->checkSign() == TRUE) {
            if ($notify->data["return_code"] == "FAIL") {
                $log_->log_result($log_name, "【通信出错】:\n" . $xml . "\n");
            } else if ($notify->data["result_code"] == "FAIL") {
                $log_->log_result($log_name, "【业务出错】:\n" . $xml . "\n");
            } else {
                $log_->log_result($log_name, "【支付成功   " . $notify->data["attach"] . "】:\n" . $xml . "\n");
                $nopaydata = D('student_no_pay_reward')->getOne($notify->data["attach"]);
                if (!$nopaydata) {
                    die;
                }

                D('student_no_pay_reward')->deleteOne($nopaydata['id']);
                //查询用户信息
                $userdata = M('student')->where(array('id' => $nopaydata['student_id']))->find();
                if (!$userdata['true_name']) {
                    $userdata['true_name'] = '匿名';
                }
                if (!$userdata['school_student_number']) {
                    $userdata['school_student_number'] = '临时会员';
                }

                $reward_id = D('school_course_reward')->rewardTeacherSuccess($nopaydata, $userdata, '微信支付');
                if ($reward_id) {
                    //保存交易记录
                    D('student_pay_record')->createApplyOne($userdata['id'], $nopaydata['money'], $notify->data['out_trade_no'],
                        '打赏老师', '微信支付', $reward_id, $notify->data['transaction_id'],
                        $userdata['true_name'], $userdata['mobile_phone'], $userdata['school_student_number']);

                    //发送邮件
                    $content = '亲爱的' . $userdata['true_name'] . '，您已成功打赏。';
                    //A('Public')->sendShortMsg($userdata['mobile_phone'], $content);

                    $this_msg['name'] = D('reward_student')->getTrueName($nopaydata['course_id'], $userdata['mobile_phone']);
                    if (empty($this_msg['name'])) {
                        $this_msg['name'] = $userdata['true_name'];
                    }

                    $this_msg['msg'] = msubstr($nopaydata['static_msg'], 0, 20, 'utf-8', false);
                    $this_msg['time'] = date('H:i');
                    $this_msg['price']=$nopaydata['money'];

//                    A('Public')->LogInfo("大屏幕打赏，id=" .$nopaydata['reward_id']);
                    D('system_reward')->cnlSocketNewReward($this_msg,$nopaydata['reward_id']);
                } else {
                    //发送邮件
                    $content = '亲爱的' . $userdata['true_name'] . '，系统错误导致打赏失败，请联系客服，对您造成的不便深感抱歉。';
                    //A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
                    \Think\Log::Write($content . '手机号：' . $userdata['mobile_phone']);
                }
            }
        }

        echo $returnXml;
    }

    //-----------------------------------------------------------------------------------------用户升级
    /**
     * 用户升级支付
     *
     */
    public function payStudentUpgrade()
    {
        vendor('WxPayPubHelper.WxPayPubHelper');
        $jsApi = new \JsApi_pub();
        if (!isset($_GET['code'])) {
            //触发微信返回code码
            $url = $jsApi->createOauthUrlForCode($this->_config['js_api_call_url_upgrade']);
            Header("Location: $url");
        } else {
            //获取code码，以获取openid
            $code = $_GET['code'];
            $jsApi->setCode($code);
            $openid = $jsApi->getOpenId();

            $upgrade_pay_id = session('upgrade_pay_id');
            $data = D('student_no_pay_upgrade')->getOne($upgrade_pay_id);
            //查询不到该条信息
            if (!$data) {
                $this->redirect('/Bz/Show/defaultError');
            }

            $pay_description = '会员升级';

            $this->assign('data', $data);
        }

        $unifiedOrder = new \UnifiedOrder_pub();
        $unifiedOrder->setParameter("openid", "$openid");//商品描述
        $unifiedOrder->setParameter("body", $pay_description);//商品描述
        $timeStamp = time();
        $out_trade_no = $this->createOrderNumber();
        $unifiedOrder->setParameter("out_trade_no", "$out_trade_no");//商户订单号
        $unifiedOrder->setParameter("total_fee", ($data['money']) * 100);//总金额
        $unifiedOrder->setParameter("notify_url", $this->_config['upgrade_notify_url']);//通知地址
        $unifiedOrder->setParameter("trade_type", "JSAPI");//交易类型
        $unifiedOrder->setParameter("attach", $upgrade_pay_id);//附加数据

        $prepay_id = $unifiedOrder->getPrepayId();
        $jsApi->setPrepayId($prepay_id);
        $jsApiParameters = $jsApi->getParameters();
        $this->assign('jsApiParameters', $jsApiParameters);
        $this->display('payStudentUpgrade');
    }

    /**
     * 会员升级支付成功回调
     *
     */
    public function notifyUrlPayUpgrade()
    {
        vendor('WxPayPubHelper.log_');
        vendor('WxPayPubHelper.WxPayPubHelper');

        //使用通用通知接口
        $notify = new \Notify_pub();

        //存储微信的回调
        $xml = $GLOBALS['HTTP_RAW_POST_DATA'];
        $notify->saveData($xml);
        if ($notify->checkSign() == FALSE) {
            $notify->setReturnParameter("return_code", "FAIL");//返回状态码
            $notify->setReturnParameter("return_msg", "签名失败");//返回信息
        } else {
            $notify->setReturnParameter("return_code", "SUCCESS");//设置返回码
        }
        $returnXml = $notify->returnXml();
        $log_ = new \Log_();
        $log_name = "./notify_url.log";//log文件路径
        $log_->log_result($log_name, "【接收到的notify通知】:\n" . $xml . "\n");

        if ($notify->checkSign() == TRUE) {
            if ($notify->data["return_code"] == "FAIL") {
                $log_->log_result($log_name, "【通信出错】:\n" . $xml . "\n");
            } else if ($notify->data["result_code"] == "FAIL") {
                $log_->log_result($log_name, "【业务出错】:\n" . $xml . "\n");
            } else {
                $log_->log_result($log_name, "【支付成功   " . $notify->data["attach"] . "】:\n" . $xml . "\n");
                $nopaydata = D('student_no_pay_upgrade')->getOne($notify->data["attach"]);
                if (!$nopaydata) {
                    die;
                }

                D('student_no_pay_upgrade')->deleteOne($nopaydata['id']);
                //查询用户信息
                $userdata = M('student')->where(array('id' => $nopaydata['student_id']))->find();

                D()->startTrans();
                //保存用户的入社交易记录
                $pay_money = ($notify->data['total_fee']) / 100;
                $ret1 = D('student_pay_record')->createApplyOne($userdata['id'], $pay_money, $notify->data['out_trade_no'],
                    '升级费', '微信支付', 0, $notify->data['transaction_id'],
                    $userdata['true_name'], $userdata['mobile_phone'], $userdata['school_student_number']);

                //用户升级
                $ret2 = D('student')->upgrade($nopaydata['student_id'], $nopaydata['type']);

                if ($ret1 && $ret2) {
                    D()->commit();
                    //发送短信
                    $userdata = M('student')->where(array('id' => $nopaydata['student_id']))->find();

                    if ($nopaydata['is_temp']) {
                        if ($nopaydata['is_new']) {
                            $content = "尊敬的{$userdata['true_name']}，欢迎加入抱柱大学！您的专属社员编号为：{$userdata['school_student_number']}；请在微信搜索关注“" . $this->nameConfig['WECHAT_SERVICE_NAME'] . "”,在菜单右侧绑定手机号码可查看个人信息以及报名课程，查看学习资料。谢谢！";
                        } else {
                            $str_end_time = date('Y年n月j日', $userdata['end_time']);
                            $content = "尊敬的{$userdata['true_name']}，恭喜您已成功升级为线下会员！您的专属社员编号为：{$userdata['school_student_number']}，有效期至{$str_end_time}，可在有效期内报名抱柱大学所有现场及网络直播课程，请在微信搜索关注“" . $this->nameConfig['WECHAT_SERVICE_NAME'] . "”，绑定手机号码可以查看个人信息以及报名课程。并加" . $this->nameConfig['ADMIN_NAME'] . "咨询.添加时请告知“社员编号-姓名-城市”，以便识别。谢谢！";
                        }
                    } else {
                        $str_end_time = date('Y年n月j日', $userdata['end_time']);
                        $content = "尊敬的{$userdata['true_name']}，恭喜您已成功升级为线下会员！您的专属社员编号为：{$userdata['school_student_number']}，有效期至{$str_end_time}，可在有效期内报名抱柱大学所有现场及网络直播课程，请在微信搜索关注“" . $this->nameConfig['WECHAT_SERVICE_NAME'] . "”，绑定手机号码可以查看个人信息以及报名课程。并加" . $this->nameConfig['ADMIN_NAME'] . "咨询.添加时请告知“社员编号-姓名-城市”，以便识别。谢谢！";
                    }

                    A('Public')->sendShortMsg($userdata['mobile_phone'], $content);

                    if ($nopaydata['is_temp'] && $nopaydata['is_new']) {
                        $content = "尊敬的{$userdata['true_name']}，加入抱柱大学第一天，送您一份“抱柱大学往期课堂学习笔记”大礼包，点击链接http://dwz.cn/2WHKF7，进入学习，关注微信“" . $this->nameConfig['WECHAT_SERVICE_NAME'] . "”获得更多课程信息。";
                        A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
                    }
                } else {
                    D()->rollback();
                    //发送邮件
                    $content = '亲爱的' . $userdata['true_name'] . '，系统错误导致升级失败，请联系客服，对您造成的不便深感抱歉。';
                    A('Public')->sendShortMsg($userdata['mobile_phone'], $content);
                    \Think\Log::Write($content . '手机号：' . $userdata['mobile_phone']);
                }
            }
        }

        echo $returnXml;
    }

    /**
     * @param $pay_id
     * @param $pay_money
     * @param $pay_show_url
     */
    public function PayActivity($pay_id, $pay_money = 0.0, $pay_show_url = '')
    {
        vendor('WxPayPubHelper.WxPayPubHelper');

        $jsApi = new \JsApi_pub();
        if (!isset($_GET['code'])) {
            //触发微信返回code码

            session('pay_id', $pay_id);
            session('pay_money', $pay_money);
            session('pay_show_url', $pay_show_url);

            //$this_url = S_URL . "/Bz/WxPay/PayActivity/pay_id/{$pay_id}/pay_money/{$pay_money}/pay_show_url/{$pay_show_url}/showwxpaytitle/1";
            $this_url = S_URL . "/Bz/WxPay/PayActivity?pay_id={$pay_id}&showwxpaytitle=1";
            $url = $jsApi->createOauthUrlForCode($this_url);
            Header("Location: $url");
        } else {
            //获取code码，以获取openid
            $code = $_GET['code'];
            $jsApi->setCode($code);
            $openid = $jsApi->getOpenId();

            $pay_id = session('pay_id');
            $pay_money = session('pay_money');
            $pay_show_url = session('pay_show_url');

            $pay_description = '活动报名费用';
            $this->assign('money', $pay_money);
        }

        $unifiedOrder = new \UnifiedOrder_pub();
        $unifiedOrder->setParameter("openid", "$openid");//商品描述
        $unifiedOrder->setParameter("body", $pay_description);//商品描述

        $out_trade_no = M('order')->where(array('id' => $pay_id))->getField('order_number');
// var_dump($this->_config['activity_notify_url']);
        $unifiedOrder->setParameter("out_trade_no", "$out_trade_no");//商户订单号
        $unifiedOrder->setParameter("total_fee", ($pay_money) * 100);//总金额
        $unifiedOrder->setParameter("notify_url", $this->_config['activity_notify_url']);//通知地址
        $unifiedOrder->setParameter("trade_type", "JSAPI");//交易类型
        $unifiedOrder->setParameter("attach", $pay_id);//附加数据

        $prepay_id = $unifiedOrder->getPrepayId();
        $jsApi->setPrepayId($prepay_id);
        $jsApiParameters = $jsApi->getParameters();
        $this->assign('jsApiParameters', $jsApiParameters);

        $this->display('PayActivity');
    }

    /**
     * handle notify activity
     */
    public function notifyUrlPayActivity()
    {
        echo "aaa";
        vendor('WxPayPubHelper.log_');
        vendor('WxPayPubHelper.WxPayPubHelper');

        //使用通用通知接口
        $notify = new \Notify_pub();


        //存储微信的回调
        $xml = $GLOBALS['HTTP_RAW_POST_DATA'];
        $notify->saveData($xml);
        if ($notify->checkSign() == FALSE) {
            $notify->setReturnParameter("return_code", "FAIL");//返回状态码
            $notify->setReturnParameter("return_msg", "签名失败");//返回信息
        } else {
            $notify->setReturnParameter("return_code", "SUCCESS");//设置返回码
        }
        $returnXml = $notify->returnXml();
        $log_ = new \Log_();
        $log_name = "./notify_url.log";//log文件路径
        $log_->log_result($log_name, "【接收到的notify通知】:\n" . $xml . "\n");

        if ($notify->checkSign() == TRUE) {
            if ($notify->data["return_code"] == "FAIL") {
                $log_->log_result($log_name, "【通信出错】:\n" . $xml . "\n");
            } else if ($notify->data["result_code"] == "FAIL") {
                $log_->log_result($log_name, "【业务出错】:\n" . $xml . "\n");
            } else {
                $log_->log_result($log_name, "【支付成功   " . $notify->data["attach"] . "】:\n" . $xml . "\n");

                $this->handle_pay_activity_success($notify);
            }
        }

        echo $returnXml;
    }

    /**
     *
     * @param $notify
     */
    public function handle_pay_activity_success($notify)
    {
        $cond = array(
            'order_number' => $notify->data["out_trade_no"],
        );

        $order_info = M('order')->where($cond)->find();


        $student_id = $order_info['student_id'];

        //课程信息
        $act_data = M('school_course')->find($order_info['relate_id']);

        if ($student_id == -2) {
            $mobile_phone = $order_info['mobile_phone'];

        } else {


            //查询用户信息
            $user_data = M('student')->where(array('id' => $student_id))->find();
            $mobile_phone = $user_data['mobile_phone'];
        }

        A('Public')->LogInfo("收到一次回调1" . $mobile_phone);
        // update can buy more
        $cond = array('activity_id' => $order_info['relate_id'], 'can_buy_more' => 0);

        $arr_single_ids = M('activity_place')->field('id')->where($cond)->select();

        $arr_single_activity_place_ids = array();
        foreach ($arr_single_ids as $value) {
            if (!empty($value['id'])) {
                $arr_single_activity_place_ids[] = $value['id'];
            }
        }

        $cond = array(
            'student_id' => $student_id,
            'school_course_id' => $order_info['relate_id'],
            'order_number' => array('neq', $notify->data["out_trade_no"]),
            'activity_place_id' => array('in', $arr_single_activity_place_ids)
        );

        D()->startTrans();

        A('Public')->LogInfo("收到一次回调31 student_id=" . $student_id);

        A('Public')->LogInfo("收到一次回调32 school_course_id=" . $order_info['relate_id']);


       // M('student_course')->where($cond)->save(array('status' => 0, 'msg' => '已切换会场',
          //  'update_time' => time()));

        // 更新活动报名的支付情况
        $cond = array(
            'order_number' => $notify->data["out_trade_no"],
        );

        $data = array(
            'status' => 1,
            'pay_status' => 1,
            'trade_no' => $notify->data["transaction_id"],
            'update_time' => time(),
        );
        $ret1 = M('student_course')->where($cond)->save($data);

        A('Public')->LogInfo("收到一次回调4 ret1=" . $ret1);

        if (!$ret1) {
            D()->rollback();
            //发送邮件
            $content = '亲爱的' . $user_data['true_name'] . '，系统错误导致购买失败，请联系客服，对您造成的不便深感抱歉。';
           // A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
            \Think\Log::Write($content . '手机号：' . $user_data['mobile_phone']);
        }

        //保存用户的入社交易记录
        if ($student_id == -2) {
            $ret2 = D('student_pay_record')->createApplyOne(-2, ($notify->data['total_fee']) / 100,
                $notify->data['out_trade_no'], $order_info['remark'] . "(未入社购买课程)", '微信支付', 0, $notify->data['transaction_id'],
                $mobile_phone, $mobile_phone, $mobile_phone);

        } else {
            $ret2 = D('student_pay_record')->createApplyOne($user_data['id'], ($notify->data['total_fee']) / 100,
                $notify->data['out_trade_no'], $order_info['remark'], '微信支付', 0, $notify->data['transaction_id'],
                $user_data['true_name'], $mobile_phone, $user_data['school_student_number']);
        }
        A('Public')->LogInfo("收到一次购买回调aaa ret2=" . $ret2);

        if (!$ret2) {
            D()->rollback();
            //发送邮件
            $content = '亲爱的' . $user_data['true_name'] . '，系统错误导致购买失败，请联系客服，对您造成的不便深感抱歉。';
        //    A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
            \Think\Log::Write($content . '手机号：' . $user_data['mobile_phone']);
        }

        D()->commit();

        $str_place_type = '';
        $arr_single_ids = M('student_course')->field('activity_place_id')->where($cond)->select();

        $arr_ids = array();
        foreach ($arr_single_ids as $value) {
            $arr_ids[] = $value['activity_place_id'];
        }
        $cond = array(
            'activity_id' => $act_data['id'],
            'id' => array('in', $arr_ids)
        );
        $arr_place_name = M('activity_place')->field('name')->where($cond)->select();

        foreach ($arr_place_name as $value) {
            $str_place_type .= "{$value['name']} ";
        }

        //发送短信
        if ($order_info['is_check']) {
//            if ($act_data['is_sign_up_sms_msg']) {
            if (1) {
               
                $content = "尊敬的" . ($user_data['true_name'] == null || $user_data['true_name'] == "" ? $mobile_phone : $user_data['true_name']) . "。";
                $content = $content . "您已成功报名课程：" . $act_data['name'] . "。";
                $content = $content . "会场为：" . $str_place_type . "。";
                $str_time = date('n月j日', $act_data['begin_time']);
                $content = $content . "课程日期为：" . $str_time . "。";// date('n月j日', );
                A('Public')->sendShortMsg($mobile_phone, $content);
            }
        } else {
//            if ($act_data['is_audit_sms_msg']) {
            if (1) {
                // send sms msg
//                $content = str_replace('{姓名}', $user_data['true_name'], $act_data['audit_sms_msg']);
//                $content = str_replace('{课程名称}', $act_data['name'], $content);
//                $content = str_replace('{活动名称}', $act_data['name'], $content);
//                $content = str_replace('{会场类型}', trim($str_place_type), $content);
//                $str_time = date('n月j日', $act_data['begin_time']);
//                $content = str_replace('{活动时间}', $str_time, $content);
//
//                A('Public')->sendShortMsg($mobile_phone, $content);
                $content = "尊敬的" . ($user_data['true_name'] == null || $user_data['true_name'] == "" ? $mobile_phone : $user_data['true_name']) . "。";
                $content = $content . "您已支付成功课程：" . $act_data['name'] . "。";
                $content = $content . "会场为：" . $str_place_type . "。";
                $str_time = date('n月j日', $act_data['begin_time']);
                $content = $content . "课程日期为：" . $str_time . "。";// date('n月j日', );
                A('Public')->sendShortMsg($mobile_phone, $content);

            }
        }


    }

    //创建唯一订单号
    protected function createOrderNumber()
    {
        return 'wx' . date('YmdHis') . mt_rand(100000, 999999);
    }


}