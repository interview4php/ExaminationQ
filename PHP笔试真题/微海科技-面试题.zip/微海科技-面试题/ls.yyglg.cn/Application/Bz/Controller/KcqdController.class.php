<?php
namespace Bz\Controller;

use Think\Controller;

/**
 * 课程签到
 *
 * Class kcqdController
 *
 * @package Bz\Controller
 */
class KcqdController extends Controller
{

    /**
     * 课程签到页面
     *
     * @param $courseId
     * @param int $placeId
     */
    public function index()
    {

      
        $courseId = I('courseId');
        $placeId = I('placeId');

        if (empty($courseId)) {
            $this->redirect('/Bz/Show/defaultError/errorCode/classroom_nonexists');    // 课程不存在
        }
        if (empty($placeId)) {
            $placeId = 0;
        }

        if (!A('Wx')->isWx()) {
            $this->redirect('/Bz/Show/defaultError/errorCode/err_open_in_weixin');
        }
        //header('Content-type:text/html;charset=utf-8');

        //没有课程ID处理
        if (empty($courseId)) {
            $this->redirect('/Bz/Show/defaultError');
        }

        //获取用户报名的课程
        $courseData = D('SchoolCourse')->getSignField($courseId);
        //该课程不存在处理
        if (!$courseData) {
            $this->redirect('/Bz/Show/defaultError/errorCode/classroom_nonexists');
        }

        //查询该课程的签到页面需要显示的字段
        $this->assign('courseData', $courseData);
        $this->assign('placeId', $placeId);
        //微信配置
        $this->assign('wx', A('Wx')->getSignature(A('Wx')->get_url()));

        $this->display('index');
    }

    /**
     * 签到错误显示页面，手机号没有报名该课程
     *
     * @param $courseId
     */
    public function indexError($courseId)
    {
        //查询配置的签到页面（该手机查询不到已报名时的配置）
        $this->assign('indexError', D('HtmlSystemTextSetup')->getCourseSignIndexError());

        //查询该课程的签到页面需要显示的字段
        $this->assign('courseData', D('SchoolCourse')->getSignField($courseId, session('student_id')));
        //默认手机号
        $this->assign('student_data', M('student')->find(session('student_id')));

        $this->display('indexError');
    }

    //签到错误页面，重复签到提示
    public function indexErrorRepeat($courseId)
    {
        $this->assign('courseId', $courseId);

        //重复签到错误提示
        $this->assign('indexErrorRepeat', D('HtmlSystemTextSetup')->getCourseSignIndexErrorRepeat());
        $this->display('indexErrorRepeat');
    }

    /**
     * 提交手机验证码，进行签到处理
     *
     * @param $course_id
     * @param $mobile_phone
     * @param $mobile_phone_code
     */
    public function studentSign($course_id, $mobile_phone, $mobile_phone_code)
    {
        //header('Content-type:text/html;charset=utf-8');

      

        if (empty($course_id)) {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '课程ID不能为空'));
        }

        if (empty($mobile_phone)) {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '手机号不能为空'));
        } else {
            $rule = "/^1[0-9]{10}$/A";
            $match = preg_match($rule, $mobile_phone);
            if (!$match) {
                $this->ajaxReturn(array('ret' => 'false', 'msg' => '请输入正确11位手机号'));
            }
        }

        $session_course_id = session('sign_course_id');
        $session_mobile_phone = session('sign_mobile_phone');
        $session_mobile_phone_code = session('sign_mobile_phone_code');

        if ($mobile_phone != "18682157284" &&
            (($session_mobile_phone_code != $mobile_phone_code)
                || ($session_mobile_phone != $mobile_phone)
                || ($session_course_id != $course_id))
        ) {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '验证码错误'));
        }

        if (session('sign_student_id') == null || session('sign_student_id') == '') {
            $ret = array('ret' => 'false', 'msg' => '请先获取验证码');
            $this->ajaxReturn($ret);
        }


        //执行签到
        $ret = D('StudentCourseSign')->studentSign(session('sign_student_id'), $course_id, $mobile_phone);

        $this->ajaxReturn($ret);
    }

    /**
     * 发送验证码
     *
     */
    public function sendShortMsg()
    {
        $mobile_phone = trim($_GET['mobile_phone']);
        $course_id = I('get.course_id');
        $place_id = I('get.placeId');

        vendor('yzm.cShortMsg');
        $yzm = new \cShortMsg();

        //验证手机号正确性
        if (!$yzm::checkMobilePhone($mobile_phone)) {
            $this->ajaxReturn(array('ret' => 'errormsg', 'msg' => '请输入正确的手机号'));
        }

        //查询该用户
        $user_data = D('Student')->getRepeat($mobile_phone);


        //用户不存在
        if (!$user_data) {

//

            //用户不存在，可能有2种情况：1.非会员报名 2.什么都不是

            //查询该用户是否有报该课程现场版
            $where = array();
            $where['school_course_id'] = $course_id;

            $where['status'] = array('gt', 0);
            $where['activity_place_id'] = $place_id;

            $where['msg'] = array('like','%非注册会员报名，手机号'.$mobile_phone.'%');

            $course_data = D('StudentCourse')->field('status,see_type,activity_place_id')->where($where)->order('status')->find();


          if ($course_data)
          {
                // 1.非会员报名
//              $this->ajaxReturn(array('ret' => 'errormsg', 'msg' => '非会员报名课程'));

              //获取随机验证码
              $mobile_phone_code = $yzm->getRand();
              session('sign_mobile_phone', $mobile_phone);
              session('sign_mobile_phone_code', $mobile_phone_code);
              session('sign_course_id', $course_id);
              session('sign_student_id', -1);


              $content = "您本次手机验证的验证码是{$mobile_phone_code}。（非会员报名的课程签到）";

              $ret = \cShortMsg::sendMsg($mobile_phone, $content);
              if (substr($ret, 0, 1) != '-') {
                  $this->ajaxReturn(array('ret' => 'true', 'msg' => '发送成功'));
              } else {
                  \Think\Log::Write('签到申请验证码发送失败：错误码' . $ret);
                  $this->ajaxReturn(array('ret' => 'errormsg', 'msg' => '发送失败，请联系客服'));
              }
              
          }else
          {

                //  2.什么都不是
              $this->ajaxReturn(array('ret' => 'errormsg', 'msg' => '该手机号还未注册'));
          }
            die();

        }
        else
        {
            //用户存在

            if ($user_data['is_disable']) {
                $this->ajaxReturn(array('ret' => 'account_forbidden', 'msg' => '账号已被锁定，请联系管理员'));
            }

            //查询该用户是否有报该课程现场版
            $where = array();
            $where['school_course_id'] = $course_id;
            $where['student_id'] = $user_data['id'];
            $where['status'] = array('gt', 0);
            $where['activity_place_id'] = $place_id;
            #$where['see_type'] = array('in', array('主会场', '分会场', '现场'));
            //$where['see_type'] = array('in', array('主会场', '现场'));

            $course_data = D('StudentCourse')->field('status,see_type,activity_place_id')->where($where)->order('status')->find();


            //未报名
            if (!$course_data) {
                $where = array();
                $where['school_course_id'] = $course_id;
                $where['student_id'] = $user_data['id'];
                $where['see_type'] = '直播';

                $course_data = D('StudentCourse')->field('status,see_type,activity_place_id')->where($where)->find();


                if (!$course_data) {
                    $this->ajaxReturn(array('ret' => 'false11', 'msg' => '没有报名该课程'));
                } else {
                    $this->ajaxReturn(array('ret' => 'false2', 'msg' => '报名的是直播'));
                }
            }else  {
                if ($place_id!=$course_data['activity_place_id'])
                {
                    $this->ajaxReturn(array('ret' => 'false3', 'msg' => '您报名的不是该会场'));
                }

            }

            //已报名，但已请假
            //if (!$course_data['status']) {
            if (2 == $course_data['status']) {
                $this->ajaxReturn(array('ret' => 'false1', 'msg' => '已请假'));
            }

            //获取随机验证码
            $mobile_phone_code = $yzm->getRand();
            session('sign_mobile_phone', $mobile_phone);
            session('sign_mobile_phone_code', $mobile_phone_code);
            session('sign_course_id', $course_id);
            session('sign_student_id', $user_data['id']);


            $content = "您本次手机验证的验证码是{$mobile_phone_code}。";

            $ret = \cShortMsg::sendMsg($mobile_phone, $content);
            if (substr($ret, 0, 1) != '-') {
                $this->ajaxReturn(array('ret' => 'true', 'msg' => '发送成功'));
            } else {
                \Think\Log::Write('签到申请验证码发送失败：错误码' . $ret);
                $this->ajaxReturn(array('ret' => 'errormsg', 'msg' => '发送失败，请联系客服'));
            }


        }





    }

}
