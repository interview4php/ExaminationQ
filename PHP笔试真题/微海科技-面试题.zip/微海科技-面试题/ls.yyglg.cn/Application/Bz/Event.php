<?php
/**
 * This file is part of workerman.
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the MIT-LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @author walkor<walkor@workerman.net>
 * @copyright walkor<walkor@workerman.net>
 * @link http://www.workerman.net/
 * @license http://www.opensource.org/licenses/mit-license.php MIT License
 */

/**
 * 主逻辑
 * 主要是处理 onMessage onClose 方法
 */

use \GatewayWorker\Lib\Gateway;

class Event
{	
	/**
     * 当客户端连接时触发
     * 如果业务不需此回调可以删除onConnect
     * @param int $client_id 连接id
     */
    public static function onConnect($client_id)
    {
        Gateway::sendToCurrentClient('{ "type": "who"}');
    }
   /**
    * 有消息时
    * @param int $client_id
    * @param string $message
    */
   public static function onMessage($client_id, $message)
   {
        
        // 客户端传递的是json数据
        $message_data = json_decode($message, true);
        if(!$message_data)
        {
            return ;
        }
        
        // 根据类型做相应的业务逻辑
        switch($message_data['type'])
        {
			/**
			*	服务器询问当前用户所属店铺
			*	{ "type": "who"}
			*/
			case 'who':
                return Gateway::sendToCurrentClient(json_encode(array('type'=>'who')));
			/**
			*	当前用户绑定店铺ID
			*	链接socket的时候把把自己所属店铺提交上来
			*	{ "type": "myshop", "shopId":22}
			*/
			case 'myshop':
				return Gateway::bindUid($client_id,$message_data['shop_id']);
			/**
			*	有新订单，发送消息给店员content
			*	{ "type": "sendToShopNewOrder", "shopId":22,"content":"json格式字符串"}
			*/
			case 'sendToShopNewOrder':
				return Gateway::sendToUid($message_data['shopId'], $message_data['content']);
			/**
			*	有专车师傅接单了
			*	{ "type": "sendToShopNewCar", "shopId":22,"content":"json格式字符串"}
			*/
			case 'sendToShopNewCar':
				return Gateway::sendToUid($message_data['shopId'], $message_data['content']);
			
        }
   }
   
   /**
    * 当用户断开连接时
    * @param integer $client_id 用户id
    */
   public static function onClose($client_id)
   {
      
   }
}
