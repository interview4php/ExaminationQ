<?php 
	
	
	/** 
* @desc 根据两点间的经纬度计算距离 
* @param float $lat 纬度值 
* @param float $lng 经度值 
*/
function getDistance($lat1, $lng1, $lat2, $lng2) { 
	$earthRadius = 6367000; 
	$lat1 = ($lat1 * pi() ) / 180; 
	$lng1 = ($lng1 * pi() ) / 180; 
	 
	$lat2 = ($lat2 * pi() ) / 180; 
	$lng2 = ($lng2 * pi() ) / 180; 
	$calcLongitude = $lng2 - $lng1; 
	$calcLatitude = $lat2 - $lat1; 
	$stepOne = pow(sin($calcLatitude / 2), 2) + cos($lat1) * cos($lat2) * pow(sin($calcLongitude / 2), 2); 
	$stepTwo = 2 * asin(min(1, sqrt($stepOne))); 
	$calculatedDistance = $earthRadius * $stepTwo; 
	 
	return round($calculatedDistance); 
} 
//round(6378.138*2*asin(sqrt(pow(sin( ({$lat}*pi()/180-latitude*pi()/180)/2),2)+cos({$lat}*pi()/180)*cos(latitude*pi()/180)* pow(sin( ({$lon}*pi()/180-longitude*pi()/180)/2),2)))*1000)as juli

//SQL距离，稍微有一点误差

function isinarr($str,$id){
	$arr = explode(',',$str);
	if(in_array($id,$arr)){
		echo 'checked="checked"';
	}
}
//中文字符串截取
function msubstr($str, $start=0, $length, $charset="utf-8", $suffix=true)
{
	switch($charset)
	{
		case 'utf-8':$char_len=3;break;
		case 'UTF8':$char_len=3;break;
		default:$char_len=2;
	}
	//小于指定长度，直接返回
    if(strlen($str)<=($length*$char_len))
	{	
		return $str;
	}
	if(function_exists("mb_substr"))
    {   
	 	$slice= mb_substr($str, $start, $length, $charset);
	}
    else if(function_exists('iconv_substr'))
    {
        $slice=iconv_substr($str,$start,$length,$charset);
    }
	else
    { 
	   $re['utf-8']   = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
		$re['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
		$re['gbk']    = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
		$re['big5']   = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";
		preg_match_all($re[$charset], $str, $match);
		$slice = join("",array_slice($match[0], $start, $length));
	}
    if($suffix) 
		return $slice."…";
    return $slice;
}

function strToArr($str,$fuhao){
	if($str){
		return explode($fuhao,$str);
	}
	
}
//输出时间，为空则不输出
	function chen_show_time($time){
		if($time){
			return date('Y-m-d H:i:s',$time);
		}
	}
//减排数据计算
function chen_weight($number){
	if($number<1000){
		return $number.'KG';
	}else if($number>1000){
		return ($number/1000).'T';
	}

}
//显示该值，如果没有则显示第二个参数
function chen_is_empty($value,$default){
	
	if($value){
		return $value;
	}else{
		return $default;
	}
	
}
//课程座位样式
function course_seat_class($status,$student_id,$is_reward_vip){
	//打赏会员只可以选座打赏专座
	if($is_reward_vip=='true'){
		if($status=='3'){
			if(!$student_id){
				return 'click1';
			}else{
				return 'seated';
			}
		}else{
			return 'suoding';
		}
	}else{
		//在线社员
		switch($status){
			case '0':return 'suoding';
			case '1':
				if(!$student_id){
					return 'click1';
				}else{
					return 'seated';
				}	
			case '2':return 'robseat';
			case '3':return 'vip';
		}
	}
}
/**
* 获取服务器端IP地址
 * @return string
 */
function get_server_ip() {
	return '120.24.36.108';
	return '123.56.232.35';

    if (isset($_SERVER)) { 
        if($_SERVER['SERVER_ADDR']) {
            $server_ip = $_SERVER['SERVER_ADDR']; 
        } else { 
            $server_ip = $_SERVER['LOCAL_ADDR']; 
        } 
    } else { 
        $server_ip = getenv('SERVER_ADDR');
    } 
    return $server_ip; 
}

