<?php
return array(
	//'配置项'=>'配置值'
//	'wx_app_id' => 'wx45325d915de45e32',
//	'wx_app_secret' => '9f279ebc7e1645eba8c35f59a49adeb1',
//	'template_id_begin_course' => 'CtdV1uGycB-mQ5fIjW4X1Zo6UJl_ovdEuko5C8bTBk0',//课程开课通知模板ID
//	'template_id_begin_activity' => 'IYjNg58OPERb03Ui9nV3_LW63TS6vVHiVj_CZKxclR8',//活动即将开始通知ID
//	'template_id_announcement_notice' => 'G8xyMw_Kv5z5Kq2WZYxOjySkFkGh22-71g5a_NYtwmo',//公告发布通知ID


	// 测试服务器配置
	'wx_app_id' => 'wx1ff90c4dc2dd3a58',
	'wx_app_secret' => '82854979c13b3ddf64ab52a2a4799661',
	'template_id_begin_course' => 'y_PDi3KU4GtHjTAXlAZet95YhUGaRFLqZru41KFgxTc',//课程开课通知模板ID
	'template_id_begin_activity' => 'WGPIHPKsfq149THpc12EC4utigLweYUTW4AftuQARRA',//活动即将开始通知ID
	'template_id_announcement_notice' => 'g9CF_WRy74A0X1FuQukU8HuojPeWxyEGIZ7kwI8oTes',//公告发布通知ID
);