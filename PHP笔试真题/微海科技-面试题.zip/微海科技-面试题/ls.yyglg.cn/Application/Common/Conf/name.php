<?php
$NameConfig= array(
    //'配置项'=>'配置值'
    'SMS_TEXT_PRDFIX'   => '【抱柱网】', // 发短信的前缀
    'ORGANIZATION_NAME'   => '抱柱大学', // 机构的自称
    'CUSTOM_SERVICE_WECHAT'   => 'Little_strong', // 客服微信
    'ADMIN_NAME'   => '管理员（公众号：抱柱网）', // 管理员
    'WECHAT_SERVICE_NAME'    => '抱柱网', // 服务号

);
