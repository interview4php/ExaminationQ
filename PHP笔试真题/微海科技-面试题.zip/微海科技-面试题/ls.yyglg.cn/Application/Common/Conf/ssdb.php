<?php
return array(
	'SSDB_CONFIG' => array(
			// 下面的配置，可以用逗号分隔，配置多个
			'DB_HOST'			=>	'127.0.0.257',
			'DB_PORT' 			=> 	8888,
			
			//接下来配置主从数据库
			'DB_DEPLOY_TYPE'=>1,//开启分布式数据库
			'DB_RW_SEPARATE'=>false,	//在读写分离的情况下，第一个数据库配置是主服务器的配置信息，负责写入数据，其它的都是从数据库的配置信息，负责读取数据，数量不限制。
			'DB_MASTER_NUM'=> 1, // 读写分离后 主服务器数量
	),	
);