<?php
return array(
	//'配置项'=>'配置值'

	// 加载扩展配置文件
	'LOAD_EXT_CONFIG' => 'db,mongodb,weixin',
	//加载 自动加载类库文件
	"LOAD_EXT_FILE"=>"constant,class,global,",
	
	'LOG_LEVEL' => 'EMERG,ALERT,CRIT,ERR,WARN,NOTIC,INFO,DEBUG,SQL',
	
	'MODULE_ALLOW_LIST'     =>  array('Bz','Admin','Home','Baozhu','Api',), // 配置你原来的分组列表
	'DEFAULT_MODULE'        =>  'Bz', // 配置你原来的默认分组
	
	'URL_MODEL'            => 2, //URL模式
	
	'URL_CASE_INSENSITIVE' =>true,
	
	'HASH_KEY' => 'abefg123+45^&*(',
	
	//客户端类型
	'CLIENT_TYPE'=>array(
			'0' => '未知',
			1=>'网站',
			2=>'短信',
			3=>'Android',
			4=>'Iphone',
			5=>'Windows Phone',
			6=>'AndroidPad',
			7=>'Ipad',
	),

	//支付宝配置参数
    'alipay_config'=>array(
		'partner' =>'2088421352074741',   //这里是你在成功申请支付宝接口后获取到的PID；
		'key'=>'i00dhdwa4um1srmpey7sojzwhb1u0ewk',//这里是你在成功申请支付宝接口后获取到的Key
		'sign_type'=>strtoupper('MD5'),
		'input_charset'=> strtolower('utf-8'),
		'cacert'=> getcwd().'\\cacert.pem',
		'transport'=> 'http',
	),
    //以上配置项，是从接口包中alipay.config.php 文件中复制过来，进行配置；
        
    'alipay'=>array(
		//这里是卖家的支付宝账号，也就是你申请接口时注册的支付宝账号
		'seller_email'=>'lingtianwang@qq.com',

		//支付成功跳转到的页面，我这里跳转到项目的User控制器，myorder方法，并传参payed（已支付列表）
		'successpage'=>'User/myorder?ordtype=payed',
		//支付失败跳转到的页面，我这里跳转到项目的User控制器，myorder方法，并传参unpay（未支付列表）
		'errorpage'=>'User/myorder?ordtype=unpay', 
	),
);