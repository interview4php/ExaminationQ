<?php
return array(
		'MONGODBCONF' => array(
		//'配置项'=>'配置值'
		'DB_TYPE'   => 'mongo', // 数据库类型
		'DB_HOST'   => 'localhost-257', // 服务器地址
		'DB_NAME'   => 'vegestreet', // 数据库名
		'DB_USER'   => '', // 用户名
		'DB_PWD'    => '',  // 密码
		'DB_PORT'   => '27017', // 端口
		'DB_PREFIX' => '', // 数据库表前缀
		'DB_CHARSET'=>'UTF8',// 数据库编码默认采用utf8
		
		//接下来配置主从数据库
		'DB_DEPLOY_TYPE'=>1,//开启分布式数据库】
		'DB_RW_SEPARATE'=>false,	//在读写分离的情况下，第一个数据库配置是主服务器的配置信息，负责写入数据，其它的都是从数据库的配置信息，负责读取数据，数量不限制。
		'DB_MASTER_NUM' => 1, // 读写分离后 主服务器数量
		),
);