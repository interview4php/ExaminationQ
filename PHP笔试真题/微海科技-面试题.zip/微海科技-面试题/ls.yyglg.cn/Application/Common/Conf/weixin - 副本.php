<?php
return array(
	//'配置项'=>'配置值'
//	'wx_app_id' => 'wx45325d915de45e32',
//	'wx_app_secret' => '9f279ebc7e1645eba8c35f59a49adeb1',
//	'template_id_begin_course' => 'CtdV1uGycB-mQ5fIjW4X1Zo6UJl_ovdEuko5C8bTBk0',//课程开课通知模板ID
//	'template_id_begin_activity' => 'IYjNg58OPERb03Ui9nV3_LW63TS6vVHiVj_CZKxclR8',//活动即将开始通知ID
//	'template_id_announcement_notice' => 'G8xyMw_Kv5z5Kq2WZYxOjySkFkGh22-71g5a_NYtwmo',//公告发布通知ID


	// 测试服务器配置
	'wx_app_id' => 'wx5c02b547be99f3e3',
	'wx_app_secret' => '669a4287a62c578c89b3fe0416c16b5f',
	'template_id_begin_course' => 'FnrjYlPs1j5zd_LO_3LaUjQeNx8oM8d3bdx0cDX5-bM',//课程开课通知模板ID
	'template_id_begin_activity' => 'a6yqhrl9HFa0rP1DHT0-NYWeM6osiRARkjOY2AqNU_0',//活动即将开始通知ID
	'template_id_announcement_notice' => 'K3pMrW5A343bIAtcIZZbt1UIPp3p8uO3ey2RsFoHLR4',//公告发布通知ID
);