<?php
Vendor('SSDB.SSDB');

/**
 * 用户头像位置
 * @param int $UserId
 * @param int 用户注册时间（时间戳）
 * @param int 头像跟新时间（时间戳）
 * @param string 尺寸（big middle small）
 */
function GET_AVATAR_URL($UserId, $RegTime, $LastUpdateHeadImgTime, $size='_thumb') {
	return S_URL . GetAvatarUri($UserId, $RegTime, $LastUpdateHeadImgTime, $size);
}

/**
 * 获取头像的uri，去除域名后面的一部分
 * @param int $UserId
 * @param int $RegTime
 * @param int $LastUpdateHeadImgTime
 * @param string $size
 */
function GetAvatarUri($UserId, $RegTime, $LastUpdateHeadImgTime, $size='_thumb') {
	if (empty($RegTime)) {
		$RegTime = 0;
	}

	$uri = '/avatar/' . date("Y", $RegTime).'/'.date("md", $RegTime).'/'.$UserId.'_'.$LastUpdateHeadImgTime.'_';//URL

//	if ($size == '') {
//		$size = '_thumb';
//	} 
	
	if (!file_exists(S_ROOT . $uri. $size . '.jpg')) {
		return GetDefaultAvatarUri($size);
	}
	
	return $uri. $size . '.jpg';
}

function GetDefaultAvatarUrl($strSizeType = '_thumb') {
	// default avatar url
	return S_URL . GetDefaultAvatarUri($strSizeType);
}

function GetDefaultAvatarUri($strSizeType = '_thumb') {
	// default avatar url

	$default_avatar_url_pre = '/avatar/default/';
	if ('_thumb' == $strSizeType) {
		return $default_avatar_url_pre . 'noavatar_small.gif';
	} elseif ('big' == $strSizeType) {
		return $default_avatar_url_pre . 'noavatar_big.gif';
	} else {
		return $default_avatar_url_pre . 'noavatar_middle.gif';
	}
}

/**
 * Logfmt: time clientip userId url errcode
 * @param int $userId
 * @param int $errCode
 */
function log_user_access($user_id, $err_code) {
	$date = date('d');

	$year = date('Y');
	$month = date('m');
	$log_dir = S_ROOT . "log/user-access/$year/$month";
	if (!is_dir($log_dir)) {
		mkdir($log_dir, 0755, true);
	}

	$data = date('H:i:s') . ' ' . get_client_ip() . " $user_id " . I('SERVER.REQUEST_URI') . " $err_code\n";
	file_put_contents("$log_dir/$date.log", $data, FILE_APPEND);
}

function log_slow($user_id, $err_code) {
	$time = G('begin', 'end');
	//if ($time < 0.1) {
	//	return ;
	//}
	
	$date = date('d');
	
	$year = date('Y');
	$month = date('m');
	$log_dir = S_ROOT . "log/slow/$year/$month";
	if (!is_dir($log_dir)) {
		mkdir($log_dir, 0755, true);
	}
	
	$data = date('H:i:s') . ' ' . get_client_ip() . " $user_id " . I('SERVER.REQUEST_URI') . " $err_code {$time}s\n";
	file_put_contents("$log_dir/$date.log", $data, FILE_APPEND);
}

function exit_admin_user_not_exists($userId, $msg = '管理员不存在') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access(0, ADMIN_USERNAME_NOT_EXISTS);
	}

	exit(json_encode(array('code' => ADMIN_USERNAME_NOT_EXISTS, 'msg' => $msg)));
}


function exit_admin_username_or_password_err($userId, $msg = '账号或密码错误') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, ADMIN_USERNAME_OR_PASSWORD_ERR);
	}

	exit(json_encode(array('code' => ADMIN_USERNAME_OR_PASSWORD_ERR, 'msg' => $msg)));
}

function exit_admin_account_forbidden($userId, $msg = '账号已被禁用') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, ADMIN_ACCOUNT_FORBIDDEN);
	}

	exit(json_encode(array('code' => ADMIN_ACCOUNT_FORBIDDEN, 'msg' => $msg)));
}

function exit_ok_output($user_id, $data) {
	log_slow($user_id, WD_SUCCESS);
	if (C('LOG_USER_ACCESS')) {
		log_user_access($user_id, WD_SUCCESS);
	}
	
	if (is_array($data)) {
		foreach ($data as $key => $value) {
			if (!isset($value)) {
				$data[$key] = '';
			} else {
				if (is_array($value)) {
					foreach ($value as $k2 => $v2) {
						if (!isset($v2)) {
							$data[$key][$k2] = '';
						}
					}
				}
			}
		}
		
		$data = json_encode($data);
	}
	
	exit($data);
}

function exit_success($user_id, $arr_more_return = array()) {
	log_slow($user_id, WD_SUCCESS);
	if (C('LOG_USER_ACCESS')) {
		log_user_access($user_id, WD_SUCCESS);
	}

	$arr_rtn = array('code'=>WD_SUCCESS, 'msg'=>DFL_MSG_OK, 'en_msg'=>DFL_EN_MSG_OK);
	foreach ($arr_more_return as $key => $value) {
		$arr_rtn[$key] = $value;
	}
	exit(json_encode($arr_rtn));
}

function exit_input_data_error($userId, $msg = DFL_MSG_INPUT_DATA_ERROR, $dbgMsg = '') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, INPUT_DATA_ERR);
	}

	if (empty($msg)) {
		$msg = DFL_MSG_INPUT_DATA_ERROR;
	}

	\Think\Log::record($_SERVER['REQUEST_URI'] . ' input:' . json_encode($_POST), 'ERR');

	exit(json_encode(array('code'=>INPUT_DATA_ERR, 'msg'=>$msg, 'dbg_msg' => $dbgMsg)));
}

function exit_force_update($userId, $updateInfo) {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, CLIENT_VERSION_FORCE_UPDATE);
	}
	exit(json_encode(array('code'=>CLIENT_VERSION_FORCE_UPDATE, 'msg'=>'客户端需要升级', 'update_info'=>$updateInfo)));
}

function exit_user_not_exists($userId, $msg = '用户不存在') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access(0, USERNAME_NOT_EXISTS);
	}
	 
	exit(json_encode(array('code'=>USERNAME_NOT_EXISTS, 'msg'=>$msg)));
}

function exit_permission_denied($userId, $msg = '没有权限', $dbgMsg = '') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, PERMISSION_DENIED_ERR);
	}
	exit(json_encode(array('code'=>PERMISSION_DENIED_ERR, 'msg'=>$msg, 'en_msg'=>'Permission denied!', 'dbg_msg' => $dbgMsg)));
}

function exit_sql_error($userId, $msg = '服务器出错', $dbgMsg = 'SQL ERROR') {
	log_slow($userId, SQL_ERR);
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, SQL_ERR);
	}
	//$bAppDebug = APP_DEBUG;
	//if (!$bAppDebug) {
	//	Log::record('SQL ERR:' . $msg, 'ERR');
	//} else {
	//	Log::record('SQL ERR:' . $msg, 'ERR');
	//}
	// do not return sql to client
	exit(json_encode(array('code'=>SQL_ERR, 'msg'=>$msg, 'dbg_msg'=>$dbgMsg)));	// $msg
}

function exit_server_error($userId, $msg = '服务器出错', $dbgMsg = 'Server error!') {
	log_slow($userId, SERVER_ERROR);
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, SERVER_ERROR);
	}

	exit(json_encode(array('code'=>SERVER_ERROR, 'msg'=>$msg, 'en_msg'=>$dbgMsg)));
}

function exit_account_forbidden($userId, $msg = '账号已被禁用') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, ACCOUNT_FORBIDDEN);
	}

	exit(json_encode(array('code'=>ACCOUNT_FORBIDDEN, 'msg'=>$msg)));
}

function exit_account_deleted($userId, $msg = '账号已被删除') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, ACCOUNT_DELETED);
	}

	exit(json_encode(array('code'=>ACCOUNT_DELETED, 'msg'=>$msg)));
}

function exit_username_or_password_err($userId, $msg = '账号或密码错误') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, USERNAME_OR_PASSWORD_ERR);
	}

	exit(json_encode(array('code'=>USERNAME_OR_PASSWORD_ERR, 'msg'=>$msg)));
}

function exit_site_closed($userId, $msg = '站点已关闭') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, SITE_CLOSED);
	}

	exit(json_encode(array('code'=>SITE_CLOSED, 'msg'=>$msg)));
}

function ExitWithSiteCertOverDue($userId, $msg = '社区证书已过期') {
	log_slow($userId, SITE_CERT_OVER_DUE);
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, SITE_CERT_OVER_DUE);
	}

	exit(json_encode(array('code'=>SITE_CERT_OVER_DUE, 'msg'=>$msg)));
}

function exit_nodata($userId, $msg = '已加载完所有数据') {
	log_slow($userId, NO_DATA_ERROR);
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, NO_DATA_ERROR);
	}

	exit(json_encode(array('code'=>NO_DATA_ERROR, 'msg'=>$msg)));
}

function exit_repeat_submit($userId, $msg = '重复提交') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, SUBMIT_REPEATED);
	}

	exit(json_encode(array('code'=>SUBMIT_REPEATED, 'msg'=>$msg)));
}

function exit_permission_notenough($userId, $msg = '没有权限进行操作') {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, PERMISSION_NOT_ENOUGH);
	}

	exit(json_encode(array('code'=>PERMISSION_NOT_ENOUGH, 'msg'=>$msg)));
}

function exit_not_login($userId, $msg = '用户没有登录', $dbgMsg) {
	if (C('LOG_USER_ACCESS')) {
		log_user_access($userId, USER_NOT_LOGIN);
	}
	
	exit(json_encode(array('code'=>USER_NOT_LOGIN, 'msg'=>$msg, 'dbg_msg' => $dbgMsg)));
}

/**
 * get client type id by string
 */
function get_client_typeid($strClientType) {
	if (stripos($strClientType, 'iphone') !== false) {
		return CLIENT_LOGIN_TYPE_IPHONE;
	} elseif (stripos($strClientType, 'ipad') !== false) {
		return CLIENT_LOGIN_TYPE_IPAD;
	} elseif (stripos($strClientType, 'andriod') !== false) {
		return CLIENT_LOGIN_TYPE_ANDRIODPHONE;
	} elseif (stripos($strClientType, 'andriodpad') !== false) {
		return CLIENT_LOGIN_TYPE_ANDRIODPAD;
	} elseif (stripos($strClientType, 'win') !== false) {
		return CLIENT_LOGIN_TYPE_WINPHONE;
	} else {
		return CLIENT_LOGIN_TYPE_WEBSITE;
	}
}

function GetDbPrefix() {
	$dbPrefix = C('DB_PREFIX');
	if (!isset($dbPrefix)) {
		$dbPrefix = '';
	}
		
	return $dbPrefix;
}

/**
 * 生成密码方法
 * Enter description here ...
 * @param $passWord
 * @return array()
 */
function createPassWord($passWord) {
	if(empty($passWord)) return array();
	$salt = createPasswordSalt();

	$passwordmd5 = preg_match('/^\w{32}$/', $passWord) ? $passWord : md5($passWord);

	$newPassWordMd5 = md5($passwordmd5.$salt);

	$return = array(
			'salt'			=> $salt,
			'password'	=> $newPassWordMd5
	);
	return $return;
}

function createPasswordSalt($pw_length = 6) {
	$salt = substr(uniqid(rand()), -6);

	return $salt;
}

function getPassword($passWord, $salt) {
	if(empty($passWord)) return '';

	$passwordmd5 = preg_match('/^\w{32}$/', $passWord) ? $passWord : md5($passWord);

	$newPassWordMd5 = md5($passwordmd5.$salt);

	return $newPassWordMd5;
}

function GenHash($strJson) {
	$key = C('HASH_KEY');
	 
	$objMcrypt = new \CommonClass\Mcrypt();
	return $objMcrypt->base64_ecb_encrypt($strJson, $key);
}

function DecodeHash($hash) {
	$key = C('HASH_KEY');

	$objMcrypt = new \CommonClass\Mcrypt();
	$plainText = $objMcrypt->base64_ecb_decrypt($hash, $key);

	return $plainText;
}

function GetUserIdByHashKey($hash, $key) {
	$objMcrypt = new \CommonClass\Mcrypt();
	$plainText = $objMcrypt->base64_ecb_decrypt($hash, $key);
	$arrInfo = json_decode($plainText, true);
	return intval($arrInfo['uid']);
}

function GetUserIdByHash($hash) {
	$key = C('HASH_KEY');
	return GetUserIdByHashKey($hash, $key);
}

/**
 * author: scz
 * get the client's type record id directly
 */
function GetClientTypeIdByHash($hash)
{
	$arrInfo = GetArrInfoByHash($hash);
	return intval($arrInfo["ctid"]);
}

/**
 *
 * @param string $hash
 * @return mixed  array(uid,ctid)  uid=>uid ctid=>客户端类型
 */
function GetArrInfoByHash($hash) {
	$plainText = DecodeHash($hash);
	$arrInfo = json_decode($plainText, true);
	 
	if (!is_numeric($arrInfo['ctid'])) {
		$arrInfo['ctid'] = get_client_typeid($arrInfo['ctid']);
	}

	return $arrInfo;
}

function GetIpLocation($ip) {
	import('ORG.Net.IpLocation');// 导入IpLocation类
	$objIp = new Org\Net\IpLocation(); // 实例化类
	$location = $objIp->getlocation($ip); // 获取某个IP地址所在的位置
	 
	return $location['country'] . $location['area'];
}

function GetArrIpLocation($ip) {
	import('ORG.Net.IpLocation');// 导入IpLocation类
	$objIp = new Org\Net\IpLocation(); // 实例化类
	$location = $objIp->getlocation($ip); // 获取某个IP地址所在的位置
	 
	return $location;
}

/**
 * get client type id by string
 */
function GetClientTypeId($strClientType) {
	if (stripos($strClientType, 'iphone') !== false) {
		return CLIENT_LOGIN_TYPE_IPHONE;
	} elseif (stripos($strClientType, 'ipad') !== false) {
		return CLIENT_LOGIN_TYPE_IPAD;
	} elseif (stripos($strClientType, 'andriod') !== false) {
		return CLIENT_LOGIN_TYPE_ANDRIODPHONE;
	} elseif (stripos($strClientType, 'andriodpad') !== false) {
		return CLIENT_LOGIN_TYPE_ANDRIODPAD;
	} elseif (stripos($strClientType, 'win') !== false) {
		return CLIENT_LOGIN_TYPE_WINPHONE;
	} else {
		return CLIENT_LOGIN_TYPE_WEBSITE;
	}
}

/**
 * 	//处理@ 用户数组 格式(签名有空格): @[张三] @[李四]
 * @param string $content
 * @return string
 */
function GetRidOfMentionsData($content) {
	return preg_replace("/\@\[(.*?)\]/i", '', $content);
}

function GetShortContent($content, $len = 50) {
	//GetRidOfMentionsData(down_tags_replace($content))
	$shortContent = mb_substr(down_tags_replace($content), 0, $len, 'UTF-8');
	if (isset($content[$len])) {
		$shortContent .= '...';
	}
		
	return str_replace(array("\r\n", "\n"), ' ', $shortContent);
}

//下行内容字符串格式化
function down_tags_replace($con) {
	$con = htmlspecialchars_decode($con);

	$con = strip_tags ( str_replace ( array ("&nbsp;", "<p>", "</p>", "<br>", "</br>", "<br/>", "<br />", "\t" ),
			array (" ", "", "\r\n", "\r\n", "\r\n", "\r\n", "\r\n", "    " ), $con )
	);

	return $con;
}

function SSDBLink() {
	// parse config, get slave master
	$host = C('SSDB_CONFIG.DB_HOST');
	$port = C('SSDB_CONFIG.DB_PORT');
	if (empty($host)) {
		//echo __FUNCTION__ . ", host is empty<br />";
		$host = '127.0.0.257';
	}
	if (empty($port)) {
		//echo __FUNCTION__ . ", port is empty<br />";
		$port = 8888;
	}
	// 如果需要分布式部署，需要重新封装接口，区分读写分离接口
	if (!class_exists('SimpleSSDB')) {
		return false;
	}
	
	try {
		//\Think\Log::record("Start new SimpleSSDB($host, $port)", 'INFO');
		$ssdb = new SimpleSSDB($host, $port);
	} catch(SSDBException $e) {
		//die(__LINE__ . ' ' . $e->getMessage());
		\Think\Log::record(__FUNCTION__ . ", error:" . $e->getMessage(), 'ERR');
		return false;
	}
	
	return $ssdb;
}

function SSDBRdLink() {
	
}

function SSDBWrLink() {

}

function GetMongoDb() {
	$mongoConf = C('MONGODBCONF');
    	
    $dbHost = empty($mongoConf['DBHOST']) ? 'localhost' : $mongoConf['DBHOST'];
    $dbPort = empty($mongoConf['DBPORT']) ? '27017' : $mongoConf['DBPORT'];
    	
    $dbName = empty($mongoConf['DBNAME']) ? 'dbvegestreet' : $mongoConf['DBNAME'];
    	
    $connection = new \MongoClient( "mongodb://$dbHost:$dbPort" ); // 连接远程数据库，端口号为指定的端口号。
    return $connection->selectDB($dbName);
}

function GetSmsErrMsg($code) {
	if ($code > 0) {
		return "成功发送{$code}条短信";
	}
	
	$arrErrMsg = array(
			-1	=> '没有该用户账户',
			-2	=> '接口密钥不正确 ,不是账户登陆密码',
			-21	=> 'MD5接口密钥加密不正确',
			-3	=> '短信数量不足',
			-11	=> '该用户被禁用',
			-14	=> '短信内容出现非法字符',
			-4	=> '手机号格式不正确',
			-41	=> '手机号码为空',
			-42	=> '短信内容为空',
			-51	=> '短信签名格式不正确',
			-6	=> 'IP限制',
	);
	
	$errMsg = $arrErrMsg[$code];
	if (empty($errMsg)) {
		$errMsg = "未知错误{$code}";
	}
	
	return $errMsg;
}

function SendSmsText($mobilePhone, $text) {
	$key = C('SENDSMSTEXTKEY');
	if (empty($key)) {
		return 0;//$key = "92f45cd4f5711b38aab0";
	}
	
	$text = urlencode($text);
	$url = "http://utf8.sms.webchinese.cn/?Uid=wendao&Key={$key}&smsMob={$mobilePhone}&smsText={$text}";
	
	if(function_exists('file_get_contents'))
	{
		$file_contents = file_get_contents($url);
	}
	else
	{
		$ch = curl_init();
		$timeout = 5;
		curl_setopt ($ch, CURLOPT_URL, $url);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		$file_contents = curl_exec($ch);
		curl_close($ch);
	}
	
	if (!isset($file_contents)) {
		\Think\Log::record(__FUNCTION__ . " url:$url", 'ERROR');
	}
	
	return $file_contents;
}

function GetSmsNum() {
	$key = C('SENDSMSTEXTKEY');
	if (empty($key)) {
		return 0;//$key = "92f45cd4f5711b38aab0";
	}
	
	$url = "http://sms.webchinese.cn/web_api/SMS/?Action=SMS_Num&Uid=wendao&Key={$key}";
	if(function_exists('file_get_contents'))
	{
		$file_contents = file_get_contents($url);
	}
	else
	{
		$ch = curl_init();
		$timeout = 5;
		curl_setopt ($ch, CURLOPT_URL, $url);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		$file_contents = curl_exec($ch);
		curl_close($ch);
	}
	
	return $file_contents;
}


/**
 *
 * @param string $url
 * @param string $json_string
 * @return mixed
 */
function curl_post_json($url, $json_string) {
	$ch = curl_init($url);

	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($ch, CURLOPT_POSTFIELDS, $json_string);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	'Content-Type: application/json',
	'Content-Length: ' . strlen($json_string))
	);

	$result = curl_exec($ch);
	curl_close($ch);

	return $result;
}

function  curl_post_one_file($url, $arrPostFiles) {
	$ch = curl_init($url);

	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $arrPostFiles);

	$ret = curl_exec($ch);
	curl_close($ch);

	return $ret;
}

function curl_get($url) {
	$ch = curl_init($url);

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_NOSIGNAL, 1);

	$result = curl_exec($ch);
	curl_close($ch);

	return $result;
}

function http_request($url, $timeout=30, $header=array()) {
	if (!function_exists('curl_init')) {
		return false;
	}

	if (strncasecmp('http', $url, 4) != 0) {
		//echo "<h1>http_request URL ERROR $url</h1>";
		return false;
	}

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
	curl_setopt($ch, CURLOPT_HEADER, true);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
	if (!empty($header)) {
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	}

	$data = curl_exec($ch);

	//list($header, $data) = explode("\r\n\r\n", $data);
	if (strncasecmp('http', $data, 4) == 0) {
		$strPos = strpos($data, "\r\n\r\n");
		if ($strPos) {
			$header = substr($data, 0,  $strPos + 1);
		}
	}

	$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	if ($http_code == 301 || $http_code == 302) {
		$matches = array();
		preg_match('/Location:(.*?)\n/', $header, $matches);
		$url = trim(array_pop($matches));
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HEADER, false);
		$data = curl_exec($ch);
	} else {
		if ($strPos) {
			$data = substr($data, $strPos + 4);
		}
	}

	@curl_close($ch);

	return $data;
}


function is_weixin() {
    if (stristr($_SERVER['HTTP_USER_AGENT'], 'micromessenger')) {
        return true;
    } else {
        return false;
    }
}

function is_qq() {
    if (stristr($_SERVER['HTTP_USER_AGENT'], 'qq')) {
        return true;
    } else {
        return false;
    }
}

function is_windows() {
    if (stristr($_SERVER['HTTP_USER_AGENT'], 'windows')) {
        return true;
    } else {
        return false;
    }
}

function is_android() {
    if (stristr($_SERVER['HTTP_USER_AGENT'], 'android')) {
        return true;
    } else {
        return false;
    }
}

function is_iphone() {
    if (stristr($_SERVER['HTTP_USER_AGENT'], 'iphone')) {
        return true;
    } else {
        return false;
    }
}
function is_ipad() {
    if (stristr($_SERVER['HTTP_USER_AGENT'], 'ipad')) {
        return true;
    } else {
        return false;
    }
}

function is_ipod() {
    if (stristr($_SERVER['HTTP_USER_AGENT'], 'ipod')) {
        return true;
    } else {
        return false;
    }
}

function is_unix() {
    if (stristr($_SERVER['HTTP_USER_AGENT'], 'unix')) {
        return true;
    } else {
        return false;
    }
}

function is_linux() {
    if (stristr($_SERVER['HTTP_USER_AGENT'], 'linux') && !stristr($_SERVER['HTTP_USER_AGENT'], 'android')) {
        return true;
    } else {
        return false;
    }
}

function is_macos() {
    if (stristr($_SERVER['HTTP_USER_AGENT'], 'mac os')&& !is_iphone() && !is_ipad() && !is_ipod()) {
        return true;
    } else {
        return false;
    }
}

function get_wx_app_id() {
	return C('wx_app_id');
}

function get_wx_app_secret() {
	return C('wx_app_secret');
}

function get_cur_url(){
	$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
	$php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
	$path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
	$relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self . (isset($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : $path_info);

//	if ($_SERVER['HTTP_HOST'] == '123.56.232.35' || $_SERVER['HTTP_HOST'] == 'ibaozhu.cn') {
//		$_SERVER['HTTP_HOST'] = 'ls.yyglg.cn';
//	}

	return $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url;
}