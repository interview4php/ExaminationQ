<?php
// 客户端的登录类型
define('CLIENT_LOGIN_TYPE_WEBSITE', 1);
define('CLIENT_LOGIN_TYPE_SMS', 2);
define('CLIENT_LOGIN_TYPE_ANDRIODPHONE', 3);
define('CLIENT_LOGIN_TYPE_IPHONE', 4);
define('CLIENT_LOGIN_TYPE_WINPHONE', 5);
define('CLIENT_LOGIN_TYPE_ANDRIODPAD', 6);
define('CLIENT_LOGIN_TYPE_IPAD', 7);

define('USER_STATUS_ONLINE', 1);
define('USER_STATUS_OFFLINE', 0);

// 错误码定义
define('WD_SUCCESS', 0);
// 10000开始的为系统错误
define('USERNAME_OR_PASSWORD_ERR', 10001);
define('PERMISSION_DENIED_ERR', 10002);
define('USERNAME_NOT_EXISTS', 10003);
define('PASSWORD_ERR', 10004);
define('SERVER_ERROR', 10005);
define('USERNAME_OR_PASSWORD_ERR_6', 10006);
define('LOGIN_FROM_OTHER', 10007);
define('ACCOUNT_FORBIDDEN', 10008);
define('CLIENT_VERSION_FORCE_UPDATE', 10010);
define('ACCOUNT_DELETED', 10011);
define('NO_DATA_ERROR', 10012);
define('SITE_CLOSED', 10013);
define('USER_NOT_LOGIN', 10014);
define('PERMISSION_NOT_ENOUGH', 10021);
define('ADD_FRIEND_HAS_REJECT', 10026);
define('CONFIG_VERSION_IS_UP_TO_DATE', 10027);
define('ACTIVITY_WAS_CLOSED', 10028);
define('POSTBAR_CREDITS_NOT_ENOUGH', 10029);
define('USER_NAME_EXISTS', 10030);
define('SITE_CERT_OVER_DUE', 10031);

// 服务器内部错误，数据库操作出错
define('SQL_ERR', 10050);

// 20000开始的为客户端错误
define('INPUT_IS_EMPTY_ERR', 20001);
define('INPUT_DATA_ERR', 20002);
define('DATING_NOT_REGISTERED', 20012);
define('DATING_ALREADY_MATCH', 20014);
define('FAVORITE_EXISTS', 20004);
// 重复提交，比如评论支持等
define('SUBMIT_REPEATED', 20005);

define('USER_NOT_IN_COMMUNITY', 20013);
define('USER_REG_REQUIRED', 20015);
define('USER_APPLY_REQUIRED', 20016);

// 30000开始的为


// ERR Msg define
define('DFL_MSG_OK', '成功');
define('DFL_EN_MSG_OK', 'OK');
define('DFL_MSG_ERR', '服务器出错');
define('DFL_EN_MSG_ERR', 'Server Error');
define('DFL_MSG_SQL_ERR', '服务器出错');
define('DFL_EN_MSG_SQL_ERR', 'Server Error');
define('DFL_MSG_ACCOUNT_FORBIDDEN', '账号已被禁用');
define('DFL_EN_MSG_EN_ACCOUNT_FORBIDDEN', 'Account Forbidden');
define('DFL_MSG_ACCOUNT_DELETED', '账号已被删除');
define('DFL_EN_MSG_ACCOUNT_DELETED', 'Account Deleted');
define('DFL_MSG_INPUT_EMPTY', '提交数据不完全');
define('DFL_EN_MSG_INPUT_EMPTY', 'Input Empty');
define('DFL_MSG_PERMISSION_DENIED', '没有权限');
define('DFL_EN_MSG_PERMISSION_DENIED', 'Permission Denied');
define('DFL_MSG_ALL_DATA_LOADED', '已加载完所有数据');
define('DFL_EN_MSG_ALL_DATA_LOADED', 'All Data Loaded');
define('DFL_MSG_DATA_NOT_FOUND', '没有数据');
define('DFL_EN_MSG_DATA_NOT_FOUND', 'Data Not Found');

define('DFL_MSG_INPUT_DATA_ERROR', '提交数据错误');
define('DFL_EN_MSG_INPUT_DATA_ERROR', 'Input data error');


// attachment type
define('ATTACHMENT_TYPE_PICTURE', 1); // .jpg
define('ATTACHMENT_TYPE_VOICE', 2); // .aac
define('ATTACHMENT_TYPE_VIDEO', 3);	// .mp4
define('ATTACHMENT_TYPE_FILE', 4);	// 普通文件
define('ATTACHMENT_TYPE_DOC_FILE', 5);	// 普通文件

// attach content type
define('ATTACHMENT_CONTENT_TYPE_PARENT', 1);
define('ATTACHMENT_CONTENT_TYPE_CHILD', 2);
define('ATTACHMENT_CONTENT_TYPE_PARENT_COMMENT', 3);
define('ATTACHMENT_CONTENT_TYPE_PARENT_REPLY', 4);
define('ATTACHMENT_CONTENT_TYPE_CHILD_COMMENT', 5);
define('ATTACHMENT_CONTENT_TYPE_CHILD_REPLY', 6);
define('ATTACHMENT_CONTENT_TYPE_P_COVER', 7);

define('MSG_TYPE_TEXT', 1);
define('MSG_TYPE_VOICE', 2);
define('MSG_TYPE_PICTURE', 3);
define('MSG_TYPE_VIDEO', 4);
