<?php
// DES加密解密函数，用于用户信息的加密解密
namespace CommonClass;

class Mcrypt
{
	/**
	 * 解密
	 *
	 * @param string $encryptedText 已加密字符串
	 * @param string $key  密钥
	 * @return string
	 */
	public static function base64_ecb_decrypt($encryptedText, $key)
	{
		$cryptText = base64_decode(urldecode($encryptedText));
		$ivSize = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($ivSize, MCRYPT_RAND);
		$decryptText = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, $cryptText, MCRYPT_MODE_ECB, $iv);
		return trim($decryptText);
	}

	/**
	 * 加密
	 *
	 * @param string $plainText	未加密字符串
	 * @param string $key		 密钥
	 */
	public static function base64_ecb_encrypt($plainText, $key)
	{
		$ivSize = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($ivSize, MCRYPT_RAND);
		$encryptText = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $plainText, MCRYPT_MODE_ECB, $iv);
		return trim(urlencode(base64_encode($encryptText)));
	}
}// class Mcrypt


/**
 * 检查用户ID是否为靓号
 * @author songcz
 */
class UserIDChecker {
	/**
	 * 6位数字组成userId，例AAAAAA,ABCDEF,ABABAB等
	 * @param string $strUserId
	 */
	public function IsGoodUserId($strUserId) {
		//echo '<br />' . 'IsGoodUserId(' . $strUserId . ')' . '<br />';

		// 匹配6位顺增
		$strPattern = '/(123456|234567|345678|456789|567890)\d*/';
		if (preg_match($strPattern, $strUserId)) {
			return true;
		}

		// 匹配6位顺降
		$strPattern = '/(987654|876543|765432|654321|543210)\d*/';
		if (preg_match($strPattern, $strUserId)) {
			return true;
		}

		// 匹配3位以上的重复数字，111425,156222
		$strPattern = '/([\d])\1{2,}/';
		if (preg_match($strPattern, $strUserId)) {
			return true;
		}

		// 匹配2位相同的重复组合,121212
		$strPattern = '/(\d{2})\1{2,}/';
		if (preg_match($strPattern, $strUserId)) {
			return true;
		}

		// 匹配3位相同的重复组合,123123，12341234
		$strPattern = '/(\d{3,})\1{1,}/';
		if (preg_match($strPattern, $strUserId)) {
			return true;
		}

		$len = strlen($strUserId)/2;
		$halfLen = (int)floor($len);
		$secondHalf = substr($strUserId, (int)ceil($len));
		// 匹配回文
		if (substr($strUserId, 0, $halfLen) == strrev($secondHalf)) {
			return true;
		}

		// 匹配前后相同，1234123
		//$strPattern = '/';
		if (substr($strUserId, 0, $halfLen) == $secondHalf) {
			return true;
		}

		return false;
	}// end of func IsGoodUserId

	public function IsAllTheSame() {

	}
}// class UserIDChecker


class ClientUpdater {
	/**
	 * get latest client version from db
	 */
	public function GetLatestVersion($clientTypeId, $nVer)
	{
		$arrNewVersion = array();
		if (CLIENT_LOGIN_TYPE_ANDRIODPHONE == $clientTypeId 
		 || CLIENT_LOGIN_TYPE_ANDRIODPAD == $clientTypeId) 
		{
			$arrNewVersion['VersionNum'] = C('ANDROID_NEW_VERSION');
			$arrNewVersion['VersionInfo'] = C('ANDROID_NEW_EXPLAIN');
			$arrNewVersion['DownloadUrl'] = C('SITE_URL') . '/' . C('ANDROID_NEW_APK');
		} elseif (CLIENT_LOGIN_TYPE_IPHONE == $clientTypeId 
		 || CLIENT_LOGIN_TYPE_IPAD == $clientTypeId) 
		{
			$arrNewVersion['VersionNum'] = C('IOS_NEW_VERSION');
			$arrNewVersion['VersionInfo'] = C('IOS_NEW_EXPLAIN');
			$arrNewVersion['DownloadUrl'] = C('IOS_NEW_HREF');
		} 
		
		return $arrNewVersion;
	}
	
	/**
	 * get force update version
	 */
	public function GetForceUpdateVersion($clientTypeId, $nVer)
	{
		$arrNewVersion = array();
		if (CLIENT_LOGIN_TYPE_ANDRIODPHONE == $clientTypeId 
		 || CLIENT_LOGIN_TYPE_ANDRIODPAD == $clientTypeId) 
		{
			$availVer = C('ANDROID_VERSIONS');
			$arrAvailVer = explode(',', $availVer);
			if (in_array($nVer, $arrAvailVer) || $nVer > max($arrAvailVer)) {
				return array();
			}
			
			\Think\Log::record(__FUNCTION__ . " clientTypeId=$clientTypeId, Ver=$nVer, vers=" . json_encode($arrAvailVer), 'INFO');
			
			$arrNewVersion['ForceUpdate'] = 1;
			$arrNewVersion['VersionNum'] = C('ANDROID_NEW_VERSION');
			$arrNewVersion['VersionInfo'] = C('ANDROID_NEW_EXPLAIN');
			$arrNewVersion['DownloadUrl'] = C('SITE_URL') . '/' . C('ANDROID_NEW_APK');
		} elseif (CLIENT_LOGIN_TYPE_IPHONE == $clientTypeId 
		 || CLIENT_LOGIN_TYPE_IPAD == $clientTypeId) 
		{
			$availVer = C('IOS_VERSIONS');
			$arrAvailVer = explode(',', $availVer);
			if (in_array($nVer, $arrAvailVer) || $nVer > max($arrAvailVer)) {
				return array();
			}
			
			\Think\Log::record(__FUNCTION__ . " clientTypeId=$clientTypeId, Ver=$nVer, vers=" . json_encode($arrAvailVer), 'INFO');
			
			$arrNewVersion['ForceUpdate'] = 1;
			$arrNewVersion['VersionNum'] = C('IOS_NEW_VERSION');
			$arrNewVersion['VersionInfo'] = C('IOS_NEW_EXPLAIN');
			$arrNewVersion['DownloadUrl'] = C('IOS_NEW_HREF');
		}
		
		return $arrNewVersion;
	}
}// class ClientUpdater

/**
 * Certification decrypt
 */
class Certification {
	private $_arrContent = array();

	private $_arrKeys = array(
			'GroupId',
			'GroupName',
			'GroupDescription',
			'GroupEnName',
			'GroupIcon',
			'GroupImage',
			'GroupMaxMember',
			'Time',
			'PastDue',
			'CentralUrl',
			'ManagerUserId',
			'SecretKey',
			'CentralHashKey',
			'GroupType',
	);

	/**
	 * read Certification file, decode decrypt, and store it into array
	*/
	public function __construct($fileName = '') {
		if (empty($fileName)) {
			$fileName = S_ROOT . '/Application/Common/Conf/ck.wd';
		}
		// 读取内容
		$encryptedText = file_get_contents($fileName);

		// 解密
		$plainText = Mcrypt::base64_ecb_decrypt($encryptedText, 'afd564s6a8dd54dfadg4d4s648fhj4k78');

		$arrKw = explode('&', $plainText);
		foreach ($arrKw as $keyValue) {
			// find first '='
			$eqPos = strpos($keyValue, '=');
			$key = substr($keyValue, 0, $eqPos);
			$value = substr($keyValue, $eqPos + 1);
			if (!empty($key)) {
				$this->_arrContent[$key] = urldecode($value);
			}
		}
	} // __construct

	/**
	 * 检查是否所有的值都有了
	 */
	public function Check() {
		foreach ($this->_arrKeys as $key) {
			$value = $this->_arrContent[$key];
			if (!isset($value)) {
				return false;
			}
		}

		return true;
	}

	public function GetArrayValues() {
		return $this->_arrContent;
	}

	public function GroupId() {
		return $this->_arrContent['GroupId'];
	}

	public function GroupName() {
		return $this->_arrContent['GroupName'];
	}

	public function GroupDescription() {
		return $this->_arrContent['GroupDescription'];
	}

	public function GroupEnName() {
		return $this->_arrContent['GroupEnName'];
	}

	public function GroupIcon() {
		return $this->_arrContent['GroupIcon'];
	}

	public function GroupImage() {
		return $this->_arrContent['GroupImage'];
	}

	public function GroupMaxMember() {
		return $this->_arrContent['GroupMaxMember'];
	}

	public function CentralHashKey() {
		return $this->_arrContent['CentralHashKey'];
	}

	/**
	 * 社区创建时间
	 */
	public function GroupCreateTime() {
		return $this->_arrContent['Time'];
	}

	public function CentralUrl() {
		return $this->_arrContent['CentralUrl'];
	}

	/**
	 * 社区管理员UID，创始人
	 */
	public function ManagerUserId() {
		return $this->_arrContent['ManagerUserId'];
	}
	
	public function PastDue() {
		return $this->_arrContent['PastDue'];
	}

	public function SecretKey() {
		return md5($this->_arrContent['SecretKey']);
	}

	/**
	 * 社区类型，1公共社区，2问道群，3组织社区，3企业社区
	 */
	public function GroupType() {
		return $this->_arrContent['GroupType'];
	}
}// class Certification