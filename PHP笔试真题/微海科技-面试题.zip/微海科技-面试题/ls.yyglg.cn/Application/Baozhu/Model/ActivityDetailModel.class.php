<?php
namespace Baozhu\Model;
//
class ActivityDetailModel
{

    //获取老师信息列表
    public function getActivityTeacher($activity_id)
    {

        $where['this.course_id'] = $activity_id;
        $field = 't.teacher_name,t.teacher_description,t.teacher_head_img,t.teacher_info';
        $join = 'as this left join ' . C('DB_PREFIX') . 'school_teacher as t on this.teacher_id = t.id';
        return M('school_course_teacher')->join($join)->field($field)->where($where)->select();
    }

    //活动信息里面的信息
    public function getActivityDetail($activity_id, $teacher_id)
    {

        /*
        $where['this.course_id'] = $activity_id;
        $where['this.teacher_id'] = $teacher_id;
        $field = 'this.video_cover,this.video_url,this.video_title,this.learning_objectives,this.suitable_object,t.teacher_name,t.teacher_description,t.teacher_head_img,t.teacher_info';
        $join 	= 'as this left join ' . C('DB_PREFIX') . 'school_teacher as t on this.teacher_id = t.id';
        return M('school_course_teacher')->join($join)->field($field)->where($where)->find();
        */
        $field = 'video_cover,video_url,video_title,learning_objectives,suitable_object,address,begin_time,end_time,cover_img';
        return M('school_course')->field($field)->find($activity_id);
    }

    //

    //获取目录列表
    public function getActivityVideoDir($activity_id, $teacher_id, $begin = 0, $limit = 100)
    {
        $where['activity_id'] = $activity_id;
        $where['teacher_id'] = $teacher_id;
        $field = 'id,cover,title_level,title,film_length,url';
        $order = 'sort desc,id desc';
        return M('activity_video_dir')->field($field)->where($where)->order($order)->limit($begin, $limit)->select();
    }

    //查询某个课程的第一个老师id
    public function getFirstTeacher($activity_id)
    {
        $where['course_id'] = $activity_id;
        return M('school_course_teacher')->where($where)->getField('teacher_id');
    }


    //判断是否需要限制3分钟
    public function isNeedToLimit($video_src)
    {
        if (!session('student_id')) {
            return true;
        } else {
            return false;
        }

    }

    //是否已经问过改问题了
    public function getRepeatAsk($ask_id, $student_id)
    {
        $where['ask_id'] = $ask_id;
        $where['student_id'] = $student_id;
        return M('ActivityAskRepeat')->where($where)->find();
    }

    //设置一个同样问的问题
    public function setRepeatAsk($ask_id, $student_id)
    {

        D()->startTrans();

        //保存问同问题记录
        $data['ask_id'] = $ask_id;
        $data['student_id'] = $student_id;
        $data['time'] = time();
        $ret1 = D('ActivityAskRepeat')->add($data);

        //自增该问题的同问题次数
        $where['id'] = $ask_id;
        $ret2 = D('ActivityAskTeacher')->where($where)->setInc('number');

        if ($ret1 && $ret2) {
            D()->commit();
            return true;
        } else {
            D()->rollback();
            return false;
        }
    }


    //提交问题
    public function sendAskContent($activity_id, $student_id, $content)
    {
        //查询该学生的头像和名字



        $headImgUrl = session('headImgUrl');

        $where['id'] = $student_id;
        $student_data = M('Student')->field('student_head_img,true_name')->where($where)->find();
        $data['activity_id'] = $activity_id;
        $data['student_id'] = $student_id;
        $data['statics_head_img'] = $headImgUrl == null || $headImgUrl == "" ? $student_data['student_head_img'] : $headImgUrl;
        $data['statics_name'] = $student_data['true_name'];
        $data['content'] = $content;
        $data['time'] = time();
        return M('ActivityAskTeacher')->add($data);
    }

    //提交笔记
    public function sendNoteContent($activity_id, $student_id, $content)
    {
        //查询该学生的头像和名字
        $where['id'] = $student_id;
        $student_data = M('Student')->field('student_head_img,true_name')->where($where)->find();
        $data['activity_id'] = $activity_id;
        $data['student_id'] = $student_id;
        $data['statics_head_img'] = session("headImgUrl");// $student_data['student_head_img'];
        $data['statics_name'] = $student_data['true_name'];
        $data['content'] = $content;
        $data['time'] = time();
        $data['user_type'] = 1;
        return M('ActivityNote')->add($data);
    }


    //是否已经赞过笔记了
    public function getRepeatNoteTop($note_id, $student_id)
    {
        $where['note_id'] = $note_id;
        $where['student_id'] = $student_id;
        return M('ActivityNoteRepeat')->where($where)->find();
    }

    //设置笔记点赞
    public function setNoteNumber($note_id, $student_id)
    {

        D()->startTrans();

        //保存问同问题记录
        $data['note_id'] = $note_id;
        $data['student_id'] = $student_id;
        $data['time'] = time();
        $ret1 = D('ActivityNoteRepeat')->add($data);

        //自增该问题的同问题次数
        $where['id'] = $note_id;
        $ret2 = D('ActivityNote')->where($where)->setInc('top_number');

        if ($ret1 && $ret2) {
            D()->commit();
            return true;
        } else {
            D()->rollback();
            return false;
        }
    }


    //获取老师回答的问题列表
    public function getTeacherAnswer($activity_id, $begin, $limit)
    {
        $field = 'this.id,this.statics_head_img as ask_head_img,this.content as ask_content,answer.statics_head_img as answer_head_img,answer.ask_type as answer_type,answer.content as answer_content,answer.audio_url,answer.audio_time';
        $join = 'as this right join ' . C('DB_PREFIX') . 'activity_ask_answer as answer on this.id = answer.ask_id';
        $where['this.activity_id'] = $activity_id;
        return M('activity_ask_teacher')->join($join)->field($field)->where($where)->limit($begin, $limit)->select();
    }

    //获取老师回答的问题列表总数
    public function getTeacherAnswerCount($activity_id)
    {
        $join = 'as this right join ' . C('DB_PREFIX') . 'activity_ask_answer as answer on this.id = answer.ask_id';
        $where['this.activity_id'] = $activity_id;
        return M('activity_ask_teacher')->join($join)->where($where)->count();
    }


    /**保存用户的直播视频访问记录
     * @param: string $activity_id 当前直播所属的活动
     * @param: string $student_id  当前观看直播的用户
     *
     **/
    public function accessWatchLiveTime($activity_id, $student_id)
    {

        $where['activity_id'] = $activity_id;
        $where['student_id'] = $student_id;
        $oldRecord = M('ActivityWatchLive')->where($where)->find();
        if ($oldRecord) {
            //echo "a".$oldRecord['student_id'];
            //有过学习记录了
        } else {
            //echo "b";
            //没有学习记录，需要添加时长
//            $this->updateGrowthValue($student_id,$activity_id);

        }

        $data['activity_id'] = $activity_id;
        $data['student_id'] = $student_id;


        $data['access_time'] = time();
        return M('ActivityWatchLive')->add($data);
    }


    //退出
    public function exitWatchLiveTime($id, $student_id)
    {

        $where['id'] = $id;
        $where['student_id'] = $student_id;
        $save['exit_time'] = time();
        return M('ActivityWatchLive')->where($where)->save($save);
    }

}