<?php
namespace Baozhu\Model;

use Think\Model\RelationModel;

//学院课程
class SchoolCourseModel extends RelationModel{
	/**
	 * 获取活动列表的信息
	 *
	 * @param $type
	 * @param int $begin
	 * @param int $limit
	 * @return mixed
	 */
	public function getActivityList($type, $begin=0, $limit=3) {
		
//		$order = 'video_status desc,begin_time,is_hold desc,sort desc,id desc';
				$order = ' begin_time  desc';
		$field = 'id,cover_img,name,begin_time,end_time,address,video_status,school_course_status,description,is_hold';

		$where['type'] = 1;
		$where['video_status'] = array('neq', 4);//排除回放的视频
		$where['school_course_status'] = array('in', array(1,2,4));

		switch($type){
			case 'is_scene'	: $where['activity_type'] = 1;break;
			case 'is_online': $where['activity_type'] = 3;break;
		}

		//var_dump($where);
		$info= $this->field($field)->where($where)->order($order)->limit($begin,$limit)->select();
	
		return $info;
	}

	/**
	 * 获取某个活动的老师列表
	 *
	 * @param $activity_id
	 * @return mixed
	 */
	public function getTeacherList($activity_id){
		$where['this.course_id'] = $activity_id;
		$join 	= 'as this left join ' . C('DB_PREFIX') . 'school_teacher as t on this.teacher_id = t.id';
		$order = 'this.sort desc,this.id desc';
		$field = 't.id,t.teacher_name,t.teacher_description';
		return M('school_course_teacher')->field($field)->join($join)->where($where)->order($order)->select();
	}

	/**
	 * 返回活动列表里面的课程状态和样式
	 *
	 * @param $status
	 * @return mixed
	 */
	public function getActivityStatusView($status){
		switch($status){
			case '1':	
				$data['video_status_class'] = 'preview';
				$data['video_status_name'] = '预告';
			break;
			case '2':
				$data['video_status_class'] = 'apply';
				$data['video_status_name'] = '报名中';
			break;
			case '3':
				$data['video_status_class'] = 'live';
				$data['video_status_name'] = '直播中';
			break;
			case '4':
				$data['video_status_class'] = 'preview';
				$data['video_status_name'] = '回放';
				break;
		}
		return $data;
	}
	
	//重新组合课程开始时间和结束时间
	public function setBeginAndEndTimeToDay($begin, $end){
		$begin_m = date('m', $begin);
		$end_m = date('m', $end);
		$begin_d = date('d', $begin);
		$end_d = date('d', $end);
		if($begin_m==$end_m && $begin_d==$end_d){
			return date('m', $begin) . '月' . date('d', $begin) . '日';
		}else if($begin_m==$end_m){
			return date('m', $begin) . '月' . date('d', $begin) . '-' . date('d', $end) . '日';
		}else{
			return date('m', $begin) . '月' . date('d', $begin) . '-' . date('m', $end) . '月' . date('d', $end) . '日';
		}
	}
	

}