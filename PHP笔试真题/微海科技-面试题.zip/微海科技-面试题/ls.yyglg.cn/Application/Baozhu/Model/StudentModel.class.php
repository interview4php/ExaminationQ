<?php
namespace Baozhu\Model;
use Think\Model\RelationModel;
//
class StudentModel extends RelationModel
{


//更新成长值--在线的
    public function updateOnlineGrowthValue($id, $second)
    {

        $where['id'] = $id;

        $student = $this->where($where)->field('growth_value_online')->find();


        $student['growth_value_online']=$student['growth_value_online']+$second;

        return $this->where($where)->save($student);
    }


}