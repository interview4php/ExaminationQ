<?php
namespace Baozhu\Model;
use Think\Model\RelationModel;
//
class VedioPlayTimeModel extends RelationModel
{



}