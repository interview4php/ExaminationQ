<?php
namespace Baozhu\Model;

class ActivityModel{
	
	//获取广告列表
	public function getBannerList(){
		
		$where['address'] 	= 1;//微站首页广告
		$where['status']	= 1;
		$order = 'sort desc,id desc';
		$field = 'title,img,url';
		return M('WxsiteBanner')->field($field)->where($where)->order($order)->select();
	}

}