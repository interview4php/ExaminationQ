<?php
namespace Baozhu\Model;
//
class LoginModel
{

    public function SetPassword($mobile_phone, $password)
    {

        $password = sha1($password, true);
        $password = base64_encode($password);

        $ret = M('student')->where(array('mobile_phone' => $mobile_phone))->save(array('pwd' => $password));


    }

    public function CheckPassword($mobile_phone, $password)
    {
        $password = sha1($password, true);
        $password = base64_encode($password);
        $where['mobile_phone'] = $mobile_phone;
        $where['pwd'] = $password;
//		C5QEjGDtiwBjLpkYIEQ35XaX6og=
        $data = M('student')->where($where)->find();


        if (!empty($data)) {
            return true;
        } else {
            return false;
        }
    }

    //设置登陆
    public function setLogin($mobile_phone)
    {
        $where['mobile_phone'] = $mobile_phone;
        $data = M('student')->field('id,mobile_phone,account_binding_wxid')->where($where)->find();
        session('student_id', $data['id']);

        session('mobile_phone', $data['mobile_phone']);
        $session_id= session_id();
        $data['login_session_id']=$session_id;

        M('student')->save($data);

        session('student_mobile_phone', $data['mobile_phone']);
        session('account_binding_wxid', $data['account_binding_wxid']);


    }

    //查询用户是否存在并且是否为正常用户(是会员、未过期、未被禁用)
    public function getNormalStudent($mobile_phone)
    {
        $where['mobile_phone'] = $mobile_phone;
        $data = M('student')->where($where)->find();

        if (!$data) {
            return array('ret' => 'false', 'msg' => '用户不存在');
        } else if ($data['student_type'] != '会员' && $data['student_type'] != '临时会员') {

            return array('ret' => 'false', 'msg' => '非会员');
        } else if ($data['student_frozen_time'] > time()) {
            return array('ret' => 'false', 'msg' => '账号已冻结');
        }
//		else if($data['end_time'] < time()){
//			session('renew_student_id', $data['id']);
//
//			return array('ret'=>'false','msg'=>'您的社员有效期已失效，请续费');
//		}

        else if ($data['is_disable']) {
            return array('ret' => 'false', 'msg' => '账号已禁用');
        } else {
            return array('ret' => 'true');
        }

    }

}