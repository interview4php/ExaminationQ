<?php
namespace Baozhu\Controller;
use Think\Controller;
//课程中心
class ActivityCenterController extends Controller {
	
	//课程中心主页
	public function index(){

		
		$this->display('index');
	}
	
	//获取活动列表
	public function getActivityList($begin,$limit,$type='all'){
		
		switch($type){
			case '1':$where['activity_type'] = 1;break;//线下大课
			case '2':$where['activity_type'] = 2;break;//沙龙
			case '3':$where['activity_type'] = 3;break;//在线课堂
			case '4':$where['activity_type'] = 4;break;//其他
		}
		
		$order = 'is_hold desc,sort desc,id desc';
		$field = 'id as course_id,cover_img,name,is_hold,school_id,view_number study_number,description';
		$where['type'] = 1;
		$where['video_status'] = 4;//回放状态
		$data = M('SchoolCourse')->field($field)->where($where)->order($order)->limit($begin,$limit)->select();
		if($data){
			foreach($data as $k=>$v){
				$data[$k]['teacher_data'] = D('SchoolCourse')->getTeacherList($v['course_id']);
				$data[$k]['school_name'] = M('School')->where(array('id'=>$v['school_id']))->getField('school_name');

				if (strlen($data[$k]['description'])>99)
				{
					$data[$k]['description']=	substr($data[$k]['description'],0,48)."...";

				}
				//$data[$k]['study_number'] = M('StudentCourse')->where(array('school_course_id'=>$v['course_id']))->count();
			}

			$this->ajaxReturn(array('ret'=>'true','data'=>$data));
		}else{
			$this->ajaxReturn(array('ret'=>'false'));
		}

	}
	
	
	
   
}