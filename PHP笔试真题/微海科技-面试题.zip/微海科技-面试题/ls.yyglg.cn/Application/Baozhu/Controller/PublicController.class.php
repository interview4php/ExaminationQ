<?php
namespace Baozhu\Controller;

use Think\Controller;

class PublicController extends Controller
{
	
	//需要登陆，跳转到登陆页面并且记录当前页面路径
	public function haveToLogin(){
		if(!session('student_id')){
			cookie('baozhu_last_url', $this->get_url());
			$this->redirect('/Baozhu/Login/index');
		}
	}
	
	//AJAX形式时需要登陆则返回true
	public function haveToLoginAjax(){
		if(!session('student_id')){
			cookie('baozhu_last_url',cookie('baozhu_last_url_ajax'));
			return array('ret'=>'need_login','url'=>'/Baozhu/Login/index','msg'=>'请先登陆');
		}
		return false;
	}
	
	//保存用户访问的最后一个有AJAX操作的URL
	public function saveLastHaveAjaxUrl(){
		cookie('baozhu_last_url_ajax', $this->get_url());
	}

	public function get_url(){
		$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
		$php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
		$path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
		$relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self . (isset($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : $path_info);

//		if ($_SERVER['HTTP_HOST'] == '123.56.232.35' || $_SERVER['HTTP_HOST'] == 'ibaozhu.cn') {
//			$_SERVER['HTTP_HOST'] = 'ls.yyglg.cn';
//		}

		return $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url;
	}
}