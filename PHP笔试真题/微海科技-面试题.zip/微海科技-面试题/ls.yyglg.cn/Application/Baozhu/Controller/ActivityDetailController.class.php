<?php
namespace Baozhu\Controller;

use Think\Controller;

//活动详细
class ActivityDetailController extends Controller
{

    //记录视频播放时间
    public function recordVideoPlayTime()
    {
        //courseId，videoId，time 三个参数
        $courseId = $_POST['courseId'];
        $videoId = $_POST['videoId'];
        $time = $_POST['time'];
        $student_id = session('student_id');
        if ($student_id == null || $student_id == "") {

            return;
        }
        $record = M('VedioPlayTime')->field("*")->where(array('course_id' => $courseId, 'vedio_id' => $videoId, 'student_id' => $student_id, 'is_live' => 0))->find();
        if ($record == null) {
            //如果不存在，则插入数据
            D('student')->updateOnlineGrowthValue($student_id,$time);
            M('VedioPlayTime')->add(array('course_id' => $courseId, 'vedio_id' => $videoId, 'student_id' => $student_id, 'is_live' => 0, 'play_seconds' => $time, 'play_datetime' => time()));
        } else {

            //如果存在，则更新时间
            if ($time > $record['play_seconds']) {

                $span = $time - $record['play_seconds'];

                $record['play_seconds'] = $time;
                D('student')->updateOnlineGrowthValue($student_id,$span);

                M('VedioPlayTime')->where(array('id' => $record['id']))->save($record);


            }

        }


    }


    //记录直播播放时间
    public function liveVideoPlayTime()
    {
        //courseId，time  2个参数
        //courseId，videoId，time 三个参数
        $courseId = $_POST['courseId'];
        $videoId = 0;
        $time = $_POST['time'];
        $student_id = session('student_id');
        if ($student_id == null || $student_id == "") {

            return;
        }
        $record = M('VedioPlayTime')->where(array('course_id' => $courseId, 'vedio_id' => $videoId, 'student_id' => $student_id, 'is_live' => 1))->find();

        D('student')->updateOnlineGrowthValue($student_id,60);

        if ($record == null) {
            //如果不存在，则插入数据

            M('VedioPlayTime')->add(array('course_id' => $courseId, 'vedio_id' => $videoId, 'student_id' => $student_id, 'is_live' => 1, 'play_seconds' => $time, 'play_datetime' => time()));
        } else {
            //如果存在，则更新时间



            //每次加60秒，前台是60秒调一次
            $record['play_seconds'] = $record['play_seconds'] + 60;
            M('VedioPlayTime')->where(array('id' => $record['id']))->save($record);

        }


        echo  "salty test";
    }


    //活动简介
    public function index($activity_id)
    {

        $teacher_id = $_POST["teacher_id"];
        //查询改课程的报名时间和直播状态
        $course_data = M('SchoolCourse')->field('video_status')->find($activity_id);


        if (!$course_data) {
            $this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/活动不存在');
        } else if (in_array($course_data['video_status'], array(1, 2))) {
            //如果为预告或者报名中状态则跳转到另一个详细页
            $this->redirect('/Baozhu/ActivityDetail/indexPreview/activity_id/' . $activity_id . '/teacher_id/' . $teacher_id);
        } else if (!in_array($course_data['video_status'], array(3, 4))) {
            $this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/活动状态出错了');
        }

        //直播调到新页面
        if ($course_data['video_status'] == 3) {


            $this->redirect('/Baozhu/ActivityDetail/indexVideo/activity_id/' . $activity_id);
        }
        //	session('reward_type','teacher');
        //保存最后一个有AJAX操作的路径
        A('Public')->saveLastHaveAjaxUrl();


        //如果是不是点击老师而是标题或者图片点击进来的则查询第一个老师
        if (!$teacher_id) {
            $teacher_id = D('ActivityDetail')->getFirstTeacher($activity_id);
        }

        //没有老师
        if (!$teacher_id) {
            $this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/活动未有老师');
        }
        //详细信息
        $data = D('ActivityDetail')->getActivityDetail($activity_id, $teacher_id);
        //dump($data);
        if (!$data) {
            $this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/活动未开放');
        }

        M('SchoolCourse')->where(array('id' => $activity_id))->save(array('view_number' => array('exp', 'view_number+1')));

        //判断是否需要限制3分钟
        if (D('ActivityDetail')->isNeedToLimit($data['video_url'])) {
            cookie('baozhu_last_url', A('Public')->get_url());
            $data['isNeedToLimit'] = 'true';
        } else {
            $data['isNeedToLimit'] = 'false';
        }
//		dump($data);
        $this->assign('data', $data);
        $this->assign('activity_id', $activity_id);
        $this->assign('teacher_id', $teacher_id);
        $this->assign('teacher_data', M('SchoolTeacher')->field('teacher_name,teacher_head_img,teacher_description,teacher_info')->find($teacher_id));
        $this->assign('teacher_answer_count', D('ActivityDetail')->getTeacherAnswerCount($activity_id));

        $wx = M('school_course_wx_share')->where('school_course_id=' . $activity_id)->find();
        $wx['img'] = S_URL . $wx['img'];
        $this->assign('datawx', $wx);

        $wx_sign = A('Bz/Wx')->getSignature(A('Bz/Wx')->get_url());
        $this->assign('wx', $wx_sign);

        $this->display('index');
    }


    //预告、报名中的详细页
    public function indexPreview($activity_id)
    {

        $teacher_id = $_POST['teacher_id'];

        //查询改课程的报名时间和直播状态
        $course_data = M('SchoolCourse')->field('video_status,start_sign_up_time,school_course_status')->find($activity_id);
        if (!$course_data) {

            $this->redirect('/Baozhu/Show/defaultError/errorCode/other/errorMsg/活动不存在');
        } else if (in_array($course_data['video_status'], array(3, 4))) {
            echo "bbbb";
            exit();
            //如果为直播中或者已完成状态则跳转到另一个详细页
            $this->redirect('/Baozhu/ActivityDetail/index/activity_id/' . $activity_id . '/teacher_id/' . $teacher_id);
        } else if (!in_array($course_data['video_status'], array(1, 2))) {
            echo "cccc";
            exit();

            $this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/活动状态出错了');
        }


        if ($course_data['start_sign_up_time'] > time()) {
            $course_data['is_begin'] = 'false';
        } else {
            $course_data['is_begin'] = 'true';
        }

        //保存最后一个有AJAX操作的路径
        A('Public')->saveLastHaveAjaxUrl();


        //如果是不是点击老师而是标题或者图片点击进来的则查询第一个老师
        if (!$teacher_id) {
            $teacher_id = D('ActivityDetail')->getFirstTeacher($activity_id);
        }
        //没有老师
        if (!$teacher_id) {
            $this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/活动未有老师');
        }
        //详细信息
        $data = D('ActivityDetail')->getActivityDetail($activity_id, $teacher_id);
        if (!$data) {
            $this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/活动未开放');
        }

        M('SchoolCourse')->where(array('id' => $activity_id))->save(array('view_number' => array('exp', 'view_number+1')));

        //判断是否需要限制3分钟
        if (D('ActivityDetail')->isNeedToLimit($data['video_url'])) {
            cookie('baozhu_last_url', A('Public')->get_url());
            $data['isNeedToLimit'] = 'true';
        } else {
            $data['isNeedToLimit'] = 'false';
        }
//		<!--cover_img     video_cover-->
//var_dump($data['cover_img']);
        //var_dump($data['video_cover']);
        $this->assign('data', $data);
        $this->assign('activity_id', $activity_id);
        $this->assign('mobile_phone', session('mobile_phone'));
        $this->assign('teacher_id', $teacher_id);
        $this->assign('course_data', $course_data);
        $this->assign('teacher_data', D('ActivityDetail')->getActivityTeacher($activity_id));

        $wx = M('school_course_wx_share')->where('school_course_id=' . $activity_id)->find();
        $wx['img'] = S_URL . $wx['img'];

        //分享的数据
        $this->assign('datawx', $wx);

        $wx_sign = A('Bz/Wx')->getSignature(A('Bz/Wx')->get_url());
        $this->assign('wx', $wx_sign);

//		$share_data = D('SchoolCourseWxShare')->where(array('school_course_id'=>$activity_id))->find();
//
//
//		$this->assign('share', $share_data);
        $this->display('indexPreview');


    }


    //获取某个课程的向老师提问问题列表  ajax
    public function getAskList($activity_id, $begin, $limit)
    {
        $student_id = session('student_id');
        $where['activity_id'] = $activity_id;
        $order = 'number desc,id desc';
        $field = 'id,statics_head_img,statics_name,content,number';
        $data = M('ActivityAskTeacher')->field($field)->where($where)->order($order)->limit($begin, $limit)->select();
        if ($data) {
            foreach ($data as $k => $v) {
                //该问题是否已经问过了
                if (D('ActivityDetail')->getRepeatAsk($v['id'], $student_id)) {
                    $data[$k]['numberclass'] = 'good';
                } else {
                    $data[$k]['numberclass'] = 'no';
                }
            }
            $this->ajaxReturn(array('ret' => 'true', 'data' => $data));
        } else {
            $this->ajaxReturn(array('ret' => 'false'));
        }
    }

    //获取某个课程的课堂预习
    public function getClassPreview($activity_id)
    {
        $where['id'] = $activity_id;
        $data = M('SchoolCourse')->where($where)->getField('class_preview');
        if ($data) {
            $this->ajaxReturn(array('ret' => 'true', 'data' => htmlspecialchars_decode($data)));
        } else {
            $this->ajaxReturn(array('ret' => 'false'));
        }
    }

    //问题同问
    public function setRepeatAsk($ask_id)
    {
        //AJAX形式时需要登陆
        $is_need_login = A('Public')->haveToLoginAjax();
        if ($is_need_login) {
            $this->ajaxReturn($is_need_login);
        }
        $student_id = session('student_id');

        //该问题是否已经问过了
        if (D('ActivityDetail')->getRepeatAsk($ask_id, $student_id)) {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '该问题已经问过了'));
        }
        //执行同问操作
        if (D('ActivityDetail')->setRepeatAsk($ask_id, $student_id)) {
            $this->ajaxReturn(array('ret' => 'true', 'msg' => '操作成功'));
        } else {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '系统繁忙'));
        }

    }


    //提交问题 ajax
    public function sendAskContent($activity_id, $content)
    {
        //AJAX形式时需要登陆
        $is_need_login = A('Public')->haveToLoginAjax();
        if ($is_need_login) {
            $this->ajaxReturn($is_need_login);
        }
        $student_id = session('student_id');

        if (D('ActivityDetail')->sendAskContent($activity_id, $student_id, $content)) {
            $this->ajaxReturn(array('ret' => 'true', 'msg' => '提交成功'));
        } else {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '系统繁忙'));
        }
    }


    //获取目录
    public function getVideoDir($activity_id, $teacher_id, $begin = 0, $limit = 99)
    {
        $data = D('ActivityDetail')->getActivityVideoDir($activity_id, $teacher_id, $begin, $limit);
        if ($data) {
            $this->ajaxReturn(array('ret' => 'true', 'data' => $data));
        } else {
            $this->ajaxReturn(array('ret' => 'false'));
        }
    }

    //获取笔记
    public function getNote($activity_id, $begin, $limit)
    {
        $where['activity_id'] = $activity_id;
        $where['user_type'] = 1;
        $student_id = session('student_id');
        $order = 'is_top desc,top_number desc';
        $field = 'id,statics_head_img,statics_name,content,top_number,is_top,jump_href';
        $data = M('ActivityNote')->field($field)->where($where)->order($order)->limit($begin, $limit)->select();
        if ($data) {
            foreach ($data as $k => $v) {
                //该笔记已点赞过了
                if (D('ActivityDetail')->getRepeatNoteTop($v['id'], $student_id)) {
                    $data[$k]['is_top_img'] = 'Like_enter';
                } else {
                    $data[$k]['is_top_img'] = 'Like';
                }
            }
            $this->ajaxReturn(array('ret' => 'true', 'data' => $data));
        } else {
            $this->ajaxReturn(array('ret' => 'false'));
        }
    }

    //获取官方笔记
    public function getSystemNote($activity_id)
    {
        $where['activity_id'] = $activity_id;
        $where['user_type'] = 2;
        $student_id = session('student_id');

        $order = 'is_top desc,top_number desc';
        $field = 'id,statics_head_img,statics_name,content,top_number,is_top,jump_href';

        $data = M('ActivityNote')->field($field)->where($where)->order($order)->select();
        if ($data) {
            foreach ($data as $k => $v) {
                //该笔记已点赞过了
                if (D('ActivityDetail')->getRepeatNoteTop($v['id'], $student_id)) {
                    $data[$k]['is_top_img'] = 'Like_enter';
                } else {
                    $data[$k]['is_top_img'] = 'Like';
                }
            }

            $this->ajaxReturn(array('ret' => 'true', 'data' => $data));
        } else {
            $this->ajaxReturn(array('ret' => 'false'));
        }
    }

    //笔记点赞
    public function setNoteNumber($note_id)
    {

        //AJAX形式时需要登陆
        $is_need_login = A('Public')->haveToLoginAjax();
        if ($is_need_login) {
            $this->ajaxReturn($is_need_login);
        }
        $student_id = session('student_id');

        //该问题是否已经问过了
        if (D('ActivityDetail')->getRepeatNoteTop($note_id, $student_id)) {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '该笔记已点赞过了'));
        }
        //执行点赞操作
        if (D('ActivityDetail')->setNoteNumber($note_id, $student_id)) {
            $this->ajaxReturn(array('ret' => 'true', 'msg' => '操作成功'));
        } else {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '系统繁忙'));
        }

    }

    //获取老师解答
    public function getTeacherAnswer($activity_id, $begin, $limit)
    {
        //header('Content-type:text/html;charset=utf-8');
        $data = D('ActivityDetail')->getTeacherAnswer($activity_id, $begin, $limit);
        //dump($data);die;
        if ($data) {
            $this->ajaxReturn(array('ret' => 'true', 'data' => $data));
        } else {
            $this->ajaxReturn(array('ret' => 'false'));
        }
    }


    //观看直播
    public function indexVideo($activity_id)
    {

        if (!A('Bz/Wx')->isWx()) {
            $this->redirect('/Bz/Show/defaultError/errorCode/err_open_in_weixin');
        }


        $course_data = M('SchoolCourse')->field('video_status,video_url')->find($activity_id);
        $firstTeacher = M('SchoolCourseTeacher')->where(array('course_id' => $activity_id))->order(' sort desc')->find();

        //$course_data['video_url'] = $firstTeacher['video_url'];
        //需要登陆，跳转到登陆页面并且记录当前页面路径
        A('Public')->haveToLogin();

        if ($course_data['video_status'] != 3 || !$course_data['video_url']) {
            $this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/直播路径错误');
        }

        $student_id = session('student_id');


        $studentInfo = M("student")->field('apply_type_id,end_time')->find($student_id);

        if (($studentInfo['apply_type_id'] != 1 && $studentInfo['apply_type_id'] != 2) || $studentInfo['end_time'] < time()) {

            $this->redirect("/Bz/Show/signupError?msg=" . urlencode("需要升级才能观看直播") . "&btn=" . urlencode("升级") . "&url=" . urlencode("||Bz||StudentRenew||studentRenew"));

        }

        $this->assign('student', M("student")->find());
        $this->assign('student_id', $student_id);
        $this->assign('activity_id', $activity_id);

        //微信配置
        $this->assign('wx', A('Bz/Wx')->getSignature(A('Bz/Wx')->get_url()));
        $this->assign('course_data', $course_data);
        //记录访问id
        $this->assign('watch_live_id', D('ActivityDetail')->accessWatchLiveTime($activity_id, $student_id));


        $this->display('indexVideo');
    }

    //退出直播保存退出记录
    public function exitLive($id)
    {
        $student_id = session('student_id');
        if (D('ActivityDetail')->exitWatchLiveTime($id, $student_id)) {
            $this->ajaxReturn(array('ret' => 'true'));
        } else {
            $this->ajaxReturn(array('ret' => 'false'));
        }

    }


    //提交笔记内容
    public function sendNoteContent($activity_id, $content)
    {

        //AJAX形式时需要登陆
        $is_need_login = A('Public')->haveToLoginAjax();
        if ($is_need_login) {
            $this->ajaxReturn($is_need_login);
        }
        $student_id = session('student_id');

        if (D('ActivityDetail')->sendNoteContent($activity_id, $student_id, $content)) {
            $this->ajaxReturn(array('ret' => 'true', 'msg' => '提交成功'));
        } else {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '系统繁忙'));
        }

    }

    /**
     * note detail list,置顶、官方笔记列表
     *
     * @param int $activity_id
     */
    public function note_detail_list($activity_id = 0, $teacher_id = 0)
    {
        //查询改课程的报名时间和直播状态
        $course_data = M('SchoolCourse')->field('video_status')->find($activity_id);
        if (!$course_data) {
            $this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/活动不存在');
        }

        //保存最后一个有AJAX操作的路径
        A('Public')->saveLastHaveAjaxUrl();

        //详细信息
        $data = D('ActivityDetail')->getActivityDetail($activity_id, $teacher_id);
        //dump($data);
        if (!$data) {
            $this->redirect('/Bz/Show/defaultError/errorCode/other/errorMsg/活动未开放');
        }

        //判断是否需要限制3分钟
        if (D('ActivityDetail')->isNeedToLimit($data['video_url'])) {
            cookie('baozhu_last_url', A('Public')->get_url());
            $data['isNeedToLimit'] = 'true';
        } else {
            $data['isNeedToLimit'] = 'false';
        }
        $this->assign('data', $data);
        $this->assign('activity_id', $activity_id);
        $this->assign('teacher_id', $teacher_id);

        // 获取官方笔记
        $where = array();
        $where['activity_id'] = $activity_id;
        $where['user_type'] = 2;
        $student_id = session('student_id');

        $order = 'is_top desc,top_number desc';
        $field = 'id,statics_head_img,statics_name,content,top_number,is_top,jump_href';

        $official_list = M('ActivityNote')->field($field)->where($where)->order($order)->limit(100)->select();
        if ($official_list) {
            foreach ($official_list as $k => $v) {
                //该笔记已点赞过了
                if (D('ActivityDetail')->getRepeatNoteTop($v['id'], $student_id)) {
                    $official_list[$k]['is_top_img'] = 'Like_enter';
                } else {
                    $official_list[$k]['is_top_img'] = 'Like';
                }
            }
        } else {
            $official_list = array();
        }

        $this->assign('official_list', $official_list);

        // 获取置顶笔记
        $where = array();
        $where['activity_id'] = $activity_id;
        $where['is_top'] = 1;
        $top_list = M('ActivityNote')->field($field)->where($where)->order($order)->limit(100)->select();
        if ($top_list) {
            foreach ($top_list as $k => $v) {
                //该笔记已点赞过了
                if (D('ActivityDetail')->getRepeatNoteTop($v['id'], $student_id)) {
                    $top_list[$k]['is_top_img'] = 'Like_enter';
                } else {
                    $top_list[$k]['is_top_img'] = 'Like';
                }
            }
        } else {
            $top_list = array();
        }

        $this->assign('top_list', $top_list);

        $this->display('note_detail_list');
    }

}
