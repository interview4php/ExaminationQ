<?php
namespace Baozhu\Controller;

use Think\Controller;

/**
 * 单场课程报名
 *
 * Class CourseOneController
 *
 * @package Baozhu\Controller
 */
class ActivityOneController extends Controller
{

	//单场课程报名
	public function index()
	{
		$courseId = I('courseId');
		$placeId = I('placeId');

		if (empty($courseId)) {
			$this->redirect('/Baozhu/Show/defaultError/errorCode/classroom_nonexists');    // 课程不存在
		}
		if (empty($placeId)) {
			$placeId = 0;
		}

		session('course_one_course_id', $courseId);
		session('course_one_place_id', $placeId);

		$field = 't.id,t.name as course_name,s.school_name,t.one_see_type,t.one_money,t.one_status';
		$data = D('SchoolCourse')->getCourseField($courseId, $field);

        if (empty($data))
        {
            die('服务器繁忙………………');
        }

		//该课程没有开启单场报名
//		if(!$data['one_status']){
//			$this->redirect('/Baozhu/Course/course');
//		}
 
		$data['placeId'] = $placeId;

        $module = M('SchoolCourse');
        $data2 = $module->field('name, school_id, one_see_type')->where('id = '.$courseId.' and type = 1')->find();
		$data2['school_name'] = M('school')->where('id = '.$data2['school_id'])->getField('school_name');

        $this->assign('name', $data2);
        $this->assign('courseId', $courseId);
        $this->assign('placeId', $placeId);
		$this->assign('courseData', $data);

		$this->display('index');
	}

	/**
	 * 查询单场课程报名的支付方式
	 *
	 * @param $courseId
	 */
	public function courseOnePayType($courseId) {
		$where['id'] = $courseId;
		$data = M('school_course')->where($where)->find();
		if (!$data) {
			exit('无数据');//查询不到处理
		}

		$pay_id = D('student_no_pay_one_course')->createOne($courseId, $data, session('student_id'));//待购买
		session('need_pay_course_id', $courseId);
		session('course_one_pay_id', $pay_id);

		//查询支付方式
		$payType = D('StudentPayType')->getSelectData(false);
		foreach ($payType as $k => $v) {
			if ($v['student_pay_type_id'] == '1') {
				$payType[$k]['student_pay_type_href'] = '/Baozhu/WxPay/indexPayOneCourse/courseId/' . $courseId;
			} elseif ($v['student_pay_type_id'] == '2') {
				$payType[$k]['student_pay_type_href'] = "/Baozhu/Alipay/pay/type/2/pay_id/{$pay_id}";
			}
		}

		$this->assign('money', $data['one_money']);
		$this->assign('payType', $payType);

		$this->display();
	}

	/**
	 * 非社员错误
	 */
	public function errorNoStudent()
	{
		$mobile_phone = I('get.phone');
		$user_name = I('get.username');


		$this->assign('phone', $mobile_phone);
		$this->assign('user_name', $user_name);
		$this->display('errorNoStudent');
	}

	//无现场权限
	public function errorNoAuth($courseId)
	{
		$this->assign('courseId', $courseId);

		$this->display('errorNoAuth');
	}

	//index提交处理
	public function indexSubmit()
	{
		$course_id = I('post.courseId');
		$place_id = I('post.placeId');
		$true_name = I('post.true_name');
		$mobile_phone = I('post.mobile_phone');
		$one_see_type = I('post.OneSeeType');
        

		//查询该手机号是否为用户，查数据库，不请求31
		$user_data = D('student')->getRepeat($mobile_phone);
		//用户不存在
		if (!$user_data) {
			$this->redirect('/Baozhu/ActivityOne/errorNoStudent/username/'.$true_name.'/phone/'.$mobile_phone.'');
		}
		if ($user_data['is_disable']) {
			$this->redirect('/Baozhu/Show/defaultError/errorCode/account_forbidden');
		}

		//帮助用户登录
		D('student')->setLoginSession($user_data);



        /*$y_activity_place_module = M('activity_place');
        $field2 = 'id, name, type';
        $data2 = $y_activity_place_module->field($field2)->where('activity_id = '.$course_id)->select();
        $this->assign('data', $data2);
        $this->display('Select_mode2');
        die;*/




		$field = 't.id,t.name as course_name,s.school_name,t.one_see_type,t.one_money,t.one_status,t.black_list';
		$school_course_data = D('SchoolCourse')->getCourseField($course_id, $field);

		//该课程没有开启单场报名
		if (!$school_course_data['one_status']) {
			$this->redirect('/Baozhu/Course/course');
		}

		//查看用户是否在黑名单中
		if (D('student_course')->isInBlackList($school_course_data['black_list'], $user_data['mobile_phone'])) {
			$msg = "由于您之前未请假缺课，无法报名该课程，如有疑问请至“".$this-> nameConfig['WECHAT_SERVICE_NAME']."”咨询";
			$this->redirect('/Baozhu/Show/errorTwo/type/false3/msg/' . $msg);
		}

		//查看用户是否已经报名了
		$countwhere['school_course_id'] = $course_id;
		$countwhere['student_id'] = $user_data['id'];

		$data = D('StudentCourse')->field('status')->where($countwhere)->find();
		if ($data) {
			if ($data['status'] == '2') {
				D('StudentCourse')->where($countwhere)->delete();
			} else {
				//已报名直播需要请假
				$this->redirect('/Baozhu/Show/defaultError/errorCode/is_have_direct_seeding');
			}
		}

		//无权限
		if ($one_see_type == '现场' && $user_data['apply_type_id'] == '1') {
			$this->redirect('/Baozhu/ActivityOne/errorNoAuth/courseId/' . $course_id);
		}

        //报名处理
        $this->redirect('/Baozhu/ActivityOne/changeActivity/course_id/' . $course_id);

        die;


		//报名处理
		$ret = D('student_course')->user_sign_up_one_course($user_data['id'], $course_id, $place_id, $one_see_type);
		if ($ret['ret'] == 'true') {
			$coursedata = M('school_course')->find($course_id);

			$str_begin_time = date('Y年m月d日', $coursedata['begin_time']);
			if ($one_see_type === '现场') {
				$content = "亲爱的{$user_data['true_name']}，您已成功报名{$str_begin_time}{$coursedata['name']}{$coursedata['address']}主会场，请到".$this-> nameConfig['WECHAT_SERVICE_NAME']."右侧菜单查看报名状态或请假。";
				A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
			} else {
				$content = "亲爱的{$user_data['true_name']}，您已成功报名{$str_begin_time}{$coursedata['name']}直播课，请至".$this-> nameConfig['WECHAT_SERVICE_NAME']."菜单右侧查看直播攻略。";
				A('Public')->sendShortMsg($user_data['mobile_phone'], $content);
			}

			$this->redirect('/Baozhu/Show/successOne');
		} else if ($ret['ret'] == 'false2') {

			$this->redirect('/Baozhu/Show/errorTwo/msg/' . $ret['msg']);
		}
	}

	//购买成功
	public function indexSuccess()
	{

		$this->display('indexSuccess');
	}

    //选择活动模式
    public function changeActivity($course_id)
    {

        $y_activity_place_module = M('activity_place');
        $field2 = 'id, name, type, total_number, signed_number, limit_number';
        $data2 = $y_activity_place_module->field($field2)->where('activity_id = '.$course_id)->select();

        foreach($data2 as $data_key => $data_value)
        {
            if($data_value['signed_number'] >= $data_value['total_number'])
            {
                $data2[$data_key]['total_number'] = 1;
                $data2[$data_key]['onclickAdd'] = '';   //单击加
                $data2[$data_key]['onclickReduce'] = '';   //单击减
                $data2[$data_key]['onclickChange_pic'] = '';   //单击勾选

            }else{
                $data2[$data_key]['total_number'] = 0;
                $data2[$data_key]['onclickAdd'] = 'onClick="add(this)"';   //单击加
                $data2[$data_key]['onclickReduce'] = 'onClick="reduce(this)"';   //单击减
                $data2[$data_key]['onclickChange_pic'] = 'onclick="change_pic(this)"';   //单击勾选
            }
        }

        $this->assign('data', $data2);
        $this->display('Select_mode2');
    }

}