<?php
namespace Baozhu\Controller;
use Think\Controller;
//获取微吼Api
class GetVhallApiController extends Controller {
	//账号
	private $username = '15010226600';
	//密码
	private $password = 'a31415926';
	
	public function index(){
		header('Content-type:text/html;charset=utf-8');
		$post_data = array(
            'auth_type'=>'1',
            'account'=>$this->username,
            'password'=>$this->password,
		);
		$post_data = json_encode($post_data);
		$url = 'http://e.vhall.com/api/vhallapi/v2/record/list';
		$ret = $this->http_post($url,$post_data);
		
		$ret = json_decode($ret);
		dump($ret);
	}
	
	
   
   
   
   	//http post数据
	protected function http_post($url, $post_data = '', $timeout = 5){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		if ($post_data != '') {
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
		}
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_HEADER, false);
		$file_contents = curl_exec($ch);
		curl_close($ch);
		return $file_contents;
	}
   
}