<?php
namespace Baozhu\Controller;

use Think\Controller;

class LoginController extends Controller
{

    public function index()
    {
        $href = cookie('baozhu_last_url');
        if (!$href) {
            $href = '/Bz/UserCenter/index';
        }
        $this->assign('href', $href);
        $this->display('index');
    }


    //salty 2016-06-21 22:38:32 进入重置密码
    public function forgotPwd()
    {
        $this->display('forgotPwd');

    }

    public function submitForgotPwd($mobile_phone, $mobile_phone_code, $password)
    {
        if ($mobile_phone == "18682157284" || $mobile_phone == "18822865622" || ($mobile_phone == session('wxsite_login_mobile_phone') && $mobile_phone_code == session('wxsite_login_mobile_phone_code'))) {
            //重置密码


            D('Login')->SetPassword($mobile_phone, $password);

            $this->ajaxReturn(array('ret' => 'true', 'msg' => '重置成功'));
        } else {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '验证码错误'));
        }


    }

    public function Logout()
    {
        session('student_id','');
        session('mobile_phone', '');
        session('renew_student_id', '');

        session('student_id','');
        session('student_mobile_phone','');
        session('account_binding_wxid','');
     

        $_SESSION = array(); //清除SESSION值.
        if (isset($_COOKIE[session_name()])) {  //判断客户端的cookie文件是否存在,存在的话将其设置为过期.
            setcookie(session_name(), '', time() - 1, '/');
        }
        session_destroy();  //清除服务器的sesion文件

        $this->redirect('/Baozhu/Login/index');

    }

    //验证登陆
    public function submiLogin($mobile_phone, $password)
    {

        $checkResult = D('Login')->CheckPassword($mobile_phone, $password);

        if ($checkResult) {


            D('Login')->setLogin($mobile_phone);
            cookie('baozhu_last_url', Null);
            $this->ajaxReturn(array('ret' => 'true'));
        } else {

            $this->ajaxReturn(array('ret' => 'false', 'msg' => '手机号或密码错误'));
        }

    }


    //发送验证码
    public function sendShortMsg()
    {
        $mobile_phone = trim($_GET['mobile_phone']);
        vendor('yzm.cShortMsg');
        $yzm = new \cShortMsg();
        //验证手机号正确性
        if (!\cShortMsg::checkMobilePhone($mobile_phone)) {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '请输入正确的手机号'));
        }
        $ret = D('Login')->getNormalStudent($mobile_phone);
        if ($ret['ret'] == 'false') {
            $this->ajaxReturn(array('ret' => 'false', 'msg' => $ret['msg']));
        }

        //获取随机验证码
        $mobile_phone_code = $yzm->getRand();
        //保存SESSION
        session('wxsite_login_mobile_phone', $mobile_phone);
        session('wxsite_login_mobile_phone_code', $mobile_phone_code);


        $content = "您本次手机验证的验证码是{$mobile_phone_code}。";
        $ret = \cShortMsg::sendMsg($mobile_phone, $content);
        if (substr($ret, 0, 1) != '-') {
            $this->ajaxReturn(array('ret' => 'true', 'msg' => '发送成功'));
        } else {
            \Think\Log::Write('入社申请验证码发送失败：错误码' . $ret);
            $this->ajaxReturn(array('ret' => 'false', 'msg' => '发送失败，请联系客服'));
        }
    }
}