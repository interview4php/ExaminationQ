<?php
namespace Baozhu\Controller;
use Think\Controller;

class ActivityController extends Controller {


	public  function clist()
	{
		//线下
		$data_scene = D('SchoolCourse')->getActivityList('is_scene', 0, 20);
	
		if($data_scene){
			foreach($data_scene as $k=>$v){
				$data_scene[$k]['teacher_data'] = D('SchoolCourse')->getTeacherList($v['id']);
				$data_scene[$k]['video_status'] = D('SchoolCourse')->getActivityStatusView($v['video_status']);
				$data_scene[$k]['time'] = D('SchoolCourse')->setBeginAndEndTimeToDay($v['begin_time'],$v['end_time']);
				if (strlen($data_scene[$k]['description'])>99)
				{
					$data_scene[$k]['description']=	substr($data_scene[$k]['description'],0,96)."...";

				}
			}
		}


		$this->assign('data_scene',$data_scene);
		$this->assign('banner',D('Activity')->getBannerList());

		$this->display();
	}


	public function index(){
		
		//线下
		$data_scene = D('SchoolCourse')->getActivityList('is_scene', 0, 20);
		if($data_scene){
			foreach($data_scene as $k=>$v){
				$data_scene[$k]['teacher_data'] = D('SchoolCourse')->getTeacherList($v['id']);
				$data_scene[$k]['video_status'] = D('SchoolCourse')->getActivityStatusView($v['video_status']);
				$data_scene[$k]['time'] = D('SchoolCourse')->setBeginAndEndTimeToDay($v['begin_time'],$v['end_time']);
//			echo 	$data_scene[$k]['description']."|||".;
				if (strlen($data_scene[$k]['description'])>99)
				{
					$data_scene[$k]['description']=	substr($data_scene[$k]['description'],0,96)."...";

				}
			}
		}



		$addressData = M('IndexAddresses')->where(array('id' => 1))->find();

		$this->assign('addressData',$addressData);
		$this->assign('data_scene',$data_scene);
		$this->assign('banner',D('Activity')->getBannerList());
		$this->display('index');
	}

	
}