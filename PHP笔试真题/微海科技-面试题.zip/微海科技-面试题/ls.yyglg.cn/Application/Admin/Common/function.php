<?php
	//显示该值，如果没有则显示第二个参数
	function chen_is_empty($value,$default){
		
		if($value){
			return $value;
		}else{
			return $default;
		}
		
	}
	//是否显示1为显示0为不显示
	function chen_is_show($is_show){
		if($is_show==1){
			return '使用';
		}else{
			return '禁用';
		}
	}
	//输出时间，为空则不输出
	function chen_show_time($time,$type='Y-m-d H:i:s'){
		if($time){
			switch($type){
				case 'Y':return date('Y-m-d',$time);
				default :return date($type,$time);
			}
		}
	}

	//Yes OR no 1为显示0为不显示
	function chen_yes_or_no($is_show){
		if($is_show==1){
			return '是';
		}else{
			return '否';
		}
	}

	//男或女
	function chen_show_sex($is_show){
		if($is_show==1){
			return '男';
		}else if($is_show==0){
			return '女';
		}
	}

	//男或女一男二女
	function chen_show_sex_wx($is_show){
		if($is_show==1){
			return '男';
		}else if($is_show==2){
			return '女';
		}else{
			return '未知';
		}
	}

	//达人
	function chen_show_master($is_show){
		if($is_show==0){
			return '申请';
		}else if($is_show==1){
			return '通过';
		}else if($is_show==2){
			return '未通过';
		}
	}

	//认证
	function chen_show_cert($is_show){
		if($is_show==0){
			return '未验证';
		}else if($is_show==1){
			return '已认证';
		}else if($is_show==2){
			return '未通过';
		}
	}

	//是否处理
	function chen_is_check($is_show){
		if($is_show==0){
			return '未处理';
		}else if($is_show==1){
			return '已处理';
		}
	}

	function isinarr($str,$id){
		$arr = explode(',',$str);
		if(in_array($id,$arr)){
			echo 'checked="checked"';
		}
	}

	function isinarr2($str,$id){
		$arr = explode('||',$str);
		if(in_array($id,$arr)){
			echo 'checked="checked"';
		}
	}

	//中文字符串截取
function msubstr($str, $start=0, $length, $charset="utf-8", $suffix=true)
{
	switch($charset)
	{
		case 'utf-8':$char_len=3;break;
		case 'UTF8':$char_len=3;break;
		default:$char_len=2;
	}

	//小于指定长度，直接返回
    if(strlen($str)<=($length*$char_len))
	{	
		return $str;
	}
	if(function_exists("mb_substr"))
    {   
	 	$slice= mb_substr($str, $start, $length, $charset);
	}
    else if(function_exists('iconv_substr'))
    {
        $slice=iconv_substr($str,$start,$length,$charset);
    }
	else
    { 
		$re['utf-8']  = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
		$re['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
		$re['gbk']    = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
		$re['big5']   = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";

	    preg_match_all($re[$charset], $str, $match);
		$slice = join("",array_slice($match[0], $start, $length));
	}

    if($suffix) {
	    return $slice."…";
    }

    return $slice;
}

//学生预约状态
function chen_show_student_course_status($status){
	switch($status){
		case '1':return '正常';
		case '2':return '已请假';
	}
}

/**	功能，传入两个时间，返回一个小的时间在前面，大的时间在后面的数组
*	$wuliu_begin_time   string 开始时间
*	$wuliu_end_time 	string 结束时间
*	return array
*/
function getBeginTimeAndEndTime($wuliu_begin_time,$wuliu_end_time){
	//开始时间
	if(!$wuliu_begin_time && !$wuliu_end_time){
		$wuliu_begin_time = 0;
		$wuliu_end_time = time();
	}else{
		if(!$wuliu_begin_time){
			$wuliu_begin_time = 0;
		}else{
			$wuliu_begin_time = strtotime($wuliu_begin_time);
		}
		if(!$wuliu_end_time){
			$wuliu_end_time = time();
		}else{
			$wuliu_end_time = strtotime($wuliu_end_time);
		}
	}
	if($wuliu_begin_time>=$wuliu_end_time){
		return array($wuliu_end_time,$wuliu_begin_time);
	}else{
		return array($wuliu_begin_time,$wuliu_end_time);
	}
	
	
}

//课程状态
function chen_show_school_course_status($status){
	switch($status){
		case '1':return '正常';
		case '2':return '待预约';
		case '3':return '已关闭';
	}
}

//服务小助手投票
function chen_show_course_question($show){
	switch($show){
		case 'light':return '灯光太亮';
		case 'dark':return '灯光太暗';
		case 'big':return '声音太大';
		case 'small':return '声音太小';
		case 'hot':return '空调太热';
		case 'cold':return '空调太冷';
	}
}

//课程的F码状态
function chen_show_course_fcode($show){
	switch($show){
		case '1':return '已分配';
		case '0':return '空闲中';
	}
}

//打赏管理的状态
function chen_show_reward_status($show){
	switch($show){
		case '1':return '开启打赏';
		case '0':return '关闭打赏';
	}
}

//学生申请入学审核状态
function chen_show_apply_check_status($show){
	switch($show){
		case '1':return '申请中';
		case '2':return '申请通过';
		case '3':return '申请不通过';
	}
}

//入学类型
function chen_show_apply_type($type){
	switch($type){
		case '-1':return '临时会员';
		case '1':return '线下会员';
		case '2':return '线上会员';
	}
}


//短信发送状态（主动）
function chen_show_short_message_status($status){
	switch($status){
		case '0':return '等待发送';
		case '1':return '发送成功';
		case '2':return '发送失败';
	}
}

//是否禁用
function chen_is_disable($status){
	switch($status){
		case '0':return '正常';
		case '1':return '禁用';
	}
}

//是否禁用
function chen_is_past_due($end_time){
	if ($end_time > time()) {
		return '正常';
	} else {
		return '已过期';
	}
}

//模板消息推送状态
function chen_show_wx_template_status($status){
	switch($status){
		case '1':return '推送中';
		case '2':return '推送成功';
	}
}


//模板消息推送状态
function chen_show_activity_price($price){
	if ($price < 0.01) {
		return '免费';
	} else {
		return round($price, 2);
	}
}

	//区分直播还是点播1为显示0为不显示
	function is_live($is_live){
		if($is_live==1){
			return '直播';
		}else{
			return '点播';
		}
	}


