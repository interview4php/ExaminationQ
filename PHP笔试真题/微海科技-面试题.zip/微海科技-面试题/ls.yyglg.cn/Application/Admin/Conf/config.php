<?php
return array(
	//'配置项'=>'配置值'
	'TMPL_PARSE_STRING' => array('__ADMIN__' => __ROOT__ . '/admin'),
	'SHOW_PAGE_TRACE' => 0,//显示调试信息
	'LOG_LEVEL' => 'EMERG,ALERT,CRIT,ERR,WARN,NOTIC,INFO,DEBUG,SQL',
);