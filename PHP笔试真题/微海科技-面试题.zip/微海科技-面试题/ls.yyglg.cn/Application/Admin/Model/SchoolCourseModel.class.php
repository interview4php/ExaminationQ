<?php
namespace Admin\Model;

use Think\Model\RelationModel;

//学院课程
class SchoolCourseModel extends RelationModel
{
	protected $_link = array(//连表
		//管理员
		'admin' => array(
			'mapping_type' => self::BELONGS_TO,
			'class_name' => 'Admin',
			'foreign_key' => 'admin_id',
			'mapping_fields' => 'user_name,true_name,mobile_phone,email,job_number',
			'as_fields' => 'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		),
		//学校
		'school' => array(
			'mapping_type' => self::BELONGS_TO,
			'class_name' => 'School',
			'foreign_key' => 'school_id',
			'mapping_fields' => 'school_name',
			'as_fields' => 'school_name:school_name',
		),

	);

	protected $_validate = array(
		array('school_id', 'require', '课程所属学院不能为空', 3),
		array('one_status', 'require', '请选择是否开启单场课程报名', 3),
		array('one_see_type', 'require', '请选择开启单场课程的类型', 3),
		array('name', 'require', '课程名字不能为空', 3),
		array('address', 'require', '上课地点不能为空', 3),
		array('sort', 'number', '排序应该为数字，越大越靠前', 3),
		array('all_number', 'number', '现场名额应为数字', 3),
		array('one_money', 'currency', '请输入正确的单场价格', 3),
	);

	protected $_auto = array(
		array('time', 'time', 1, 'function'),
		array('update_time', 'time', 2, 'function'),
		array('admin_id', 'getAdminId', 3, 'callback'),
		array('begin_time', 'getDateToTime', 3, 'callback'),
		array('end_time', 'getDateToTime', 3, 'callback'),
	);

	protected function getAdminId()
	{

		if (session('adminid')) {
			return session('adminid');
		} else {
			return 1;
		}

	}

	protected function getDateToTime($field)
	{

		return strtotime($field);

	}


	//现场名额自减
	public function setDecUseNumber($id)
	{
		return D('SchoolCourse')->where(array('id' => $id))->setDec('use_number');
	}

}