<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//课程座位
class SchoolCourseSeatModel extends RelationModel{
	protected $_link = array(//连表
		//管理员
		  'admin'=>array(
			'mapping_type' =>self::BELONGS_TO,
			'class_name'   =>'Admin',
			'foreign_key'  =>'admin_id',
			'mapping_fields'=>'user_name,true_name,mobile_phone,email,job_number',
			'as_fields'    =>'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		 ),
		 
	);
	protected $_validate = array(
		//array('course_id','','该课程已经有座位了！',1,'unique',3), // 字段是否唯一
		array('course_id','require','请选择课程'),
		array('one_number','require','座位排数不能为空'),
		array('two_number','require','每排位数不能为空'),
		array('status','require','状态不能为空'),

	);
	
	
	protected $_auto = array ( 
		array('time','time',1,'function'), 
		array('update_time','time',2,'function'), 
		array('admin_id','getAdminId',3,'callback'),
	);
	protected function getAdminId(){
		
		if(session('adminid')){
			return session('adminid');
		}else{
			return 1;
		}
		
	}
	protected function getDateToTime($field){
		
		return strtotime($field);
		
	}
	
	//回复某个座位的状态
	public function delOneSeatStatus($course_id,$student_id){
		$where['course_id'] = $course_id;
		$school_course_seat_id = $this->where($where)->getField('school_course_seat_id');
		
		return D('SchoolCourseSeatList')->where(array(
					'school_course_seat_id'=>$school_course_seat_id,
					'student_id'=>$student_id
				))->save(array(
					'student_id'=>0
				));
	}
	
	
	//回复某个课程的某个学生的座位号状态
	public function delOneStudentSeat($course_id,$student_id){
		$field = 'seat_array,status_0,status_1,status_2,status_3';
		$where['course_id'] = $course_id;
		$data = $this->field($field)->where($where)->find();
		if(!$data){
			return true;
		}
		$seat_array = unserialize($data['seat_array']);
		foreach($seat_array as $k=>$v){
			foreach($v as $kk=>$vv){
				if($vv['student_id']==$student_id){
					$seat_array[$k][$kk]['student_id'] = 0;				
				}
			}
		}
		
		$save['seat_array'] = serialize($seat_array);
		$save['update_time'] = time();
		$save['admin_id'] = session('adminid');
		return $this->where($where)->save($save);
	}
	
	
	//更新座位
	public function updateSeatArray($courseId,$seatArray){
		$save['seat_array']  = $seatArray;
		$save['update_time'] = time();
		$where['course_id'] = $courseId;
		return $this->where($where)->save($save);
	}

	
}