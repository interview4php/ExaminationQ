<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//打赏抽奖
class SystemRewardLuckDrawModel extends RelationModel{
	protected $_link = array(//连表
		//管理员
		  'admin'=>array(
			'mapping_type' =>self::BELONGS_TO,
			'class_name'   =>'Admin',
			'foreign_key'  =>'admin_id',
			'mapping_fields'=>'user_name,true_name,mobile_phone,email,job_number',
			'as_fields'    =>'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		 ),
		 
	);
	
	protected $_validate = array(
		array('draw_name','require','奖项标题不能为空',3),	
		array('draw_description','require','奖项内容不能为空',3),	
		array('draw_begin_time','require','开始时间不能为空',3),	
		array('draw_end_time','require','结束时间不能为空',3),	
		array('draw_type','require','抽奖类型不能为空',3),	
		array('draw_begin_number','require','开始名次不能为空',3),	


		
		array('draw_all_number','number','中奖名额应为数字',3),		
		array('draw_begin_money','currency','请输出正确的金额',3),		
	);
	 
	protected $_auto = array ( 
		array('time','time',1,'function'), 
		array('update_time','time',2,'function'), 
		array('admin_id','getAdminId',3,'callback'),
		array('draw_begin_time','getDateToTime',3,'callback'),
		array('draw_end_time','getDateToTime',3,'callback'),
	);
	protected function getAdminId(){
		
		if(session('adminid')){
			return session('adminid');
		}else{
			return 1;
		}
		
	}
	protected function getDateToTime($field){
		
		return strtotime($field);
		
	}
	
	
	//查询某个奖品的信息
	public function getOneRewardLuckDraw($luckDrawId,$field='*'){
		$where['id']  = $luckDrawId;
		$where['draw_status'] 		= 1; 
		$where['is_executeLuckdram']= 0; 
		return $this->field($field)->where($where)->find();
	}
	
	//更新某个奖品的抽出数
	public function updateDrawUseNumber($id,$count){
		$where['id']= $id;
		$save['is_executeLuckdram'] = 1;
		$save['draw_use_number'] = $count;
		return $this->where($where)->save($save);
	}
	
	//查询某个奖品是否已经抽奖过了
	public function isExecuteLuckDram($luckDrawId){
		$where['id'] = $luckDrawId;
		$where['is_executeLuckdram'] = 1;
		if($this->where($where)->find()){
			return true;
		}else{
			return false;
		}
	}
	
	
	
	
}