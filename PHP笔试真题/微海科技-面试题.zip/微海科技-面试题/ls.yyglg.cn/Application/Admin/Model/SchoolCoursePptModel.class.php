<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//学院课程里面的PPT
class SchoolCoursePptModel extends RelationModel{
	protected $_link = array(//连表
		//管理员
		  'admin'=>array(
			'mapping_type' =>self::BELONGS_TO,
			'class_name'   =>'Admin',
			'foreign_key'  =>'admin_id',
			'mapping_fields'=>'user_name,true_name,mobile_phone,email,job_number',
			'as_fields'    =>'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		 ),
		 
	);
	protected $_validate = array(
		array('course_id','require','课程不能为空',3),		
	);
	protected $_auto = array ( 
		array('time','time',1,'function'), 
		array('update_time','time',2,'function'), 
		array('admin_id','getAdminId',3,'callback'),
	);
	protected function getAdminId(){
		
		if(session('adminid')){
			return session('adminid');
		}else{
			return 1;
		}
		
	}
	protected function getDateToTime($field){
		
		return strtotime($field);
		
	}
	
	/**修改当前显示的PPT
	* @param string $course_id 课程ID school_course
	* @param string $pptid  ppt表ID school_course_ppt
	* return boolean
	*/
	public function isShowNowPpt($course_id,$pptid){
		

		$ret1 = $this->where(array('course_id'=>$course_id))->save(array('is_show_now'=>0));
		$ret2 = $this->where(array('id'=>$pptid))->save(array('is_show_now'=>1));

		if($ret2){
			return true;
		}else{
			return false;
		}
		
	}

	
	
	
}