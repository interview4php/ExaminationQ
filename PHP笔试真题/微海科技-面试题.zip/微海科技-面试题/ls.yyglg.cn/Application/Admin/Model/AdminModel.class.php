<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//管理员
class AdminModel extends RelationModel{
	 protected $_link = array(//连表
		// 所属分组
			'Group'=>array(
			'mapping_type' =>self::BELONGS_TO,
			'class_name'   =>'Admin_group',
			'foreign_key'  =>'group_id',
			'mapping_fields'=>'name',
			'as_fields'    =>'name:group_name',
		 )
		 
	 );

	protected $_validate = array(
		array('user_name','','帐号已经存在！',1,'unique',3), // 字段是否唯一
		array('job_number','','工号已经存在！',1,'unique',3), // 字段是否唯一
		array('user_name','require','账号不能为空'),
		array('group_id','require','请选择所属分组'),
		array('password','require','密码不能为空'),
		array('mobile_phone','require','手机号不能为空'),
		array('email','email','请输入有效邮箱'),
		array('sort','number','排序为数字，越大越靠前'),
		array('job_number','require','工号不能为空'),
		array('password','/^[0-9a-zA-z]\w{5,15}$/','密码由6-15个字母或数字组成'),
	);
	
	protected $_auto = array ( 
		array('time','time',1,'function'), 
		array('update_time','time',2,'function'),  
		array('password', 'md5', self::MODEL_BOTH, 'function'),//必须注意顺序
		array('password', '', self::MODEL_UPDATE, 'ignore'),
		array('password', NULL, self::MODEL_UPDATE, 'ignore'),
		array('admin_id','getAdminId',3,'callback'),
	);

	protected function getAdminId(){
		
		if(session('adminid')){
			return session('adminid');
		}else{
			return 1;
		}
		
	}
	
}