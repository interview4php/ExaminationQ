<?php
namespace Admin\Model;

use Think\Model\RelationModel;

//微信自定义分享信息
class SchoolCourseWxShareModel extends RelationModel
{
	

	/**
	*查询一条信息
	* @param string $id  分享表的ID
	* @param string $field  需要查询的字段
	* @return array
	*/
	public function getOne($id,$field='*'){
		$where['school_course_id'] = $id;
		return $this->field($field)->where($where)->find();
	}
	
	/**
	* 创建一条信息
	 *
	* @param string $course_id  课程ID
	* @param string $title  分享的标题
	* @param string $description  分享的内容
	* @param string $img  分享的图片
	*/
	public function createOne($course_id,$title,$description,$img){
		$data['school_course_id']	= $course_id;
		$data['title']				= $title;
		$data['description']		= $description;
		$data['img']				= $img;
		$data['time']				= time();
		$data['admin_id']			= session('adminid');

		return $this->add($data);
	}
	
	
	/**
	*更新一条信息
	* @param string $id  分享表的Id
	* @param string $course_id  课程ID
	* @param string $title  分享的标题
	* @param string $description  分享的内容
	* @param string $img  分享的图片
	*/
	public function updateOne($id,$course_id,$title,$description,$img){
		$save['school_course_id']	= $course_id;
		$save['title']				= $title;
		$save['description']		= $description;
		$save['img']				= $img;
		$save['time']				= time();
		$save['admin_id']			= session('adminid');
		
		$where['id']				= $id;
		return $this->where($where)->save($save);
		
		
	}

}