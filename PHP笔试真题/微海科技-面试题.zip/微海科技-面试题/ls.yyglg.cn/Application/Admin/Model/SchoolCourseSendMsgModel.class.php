<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//课程模式聊天待发送列表
class SchoolCourseSendMsgModel extends RelationModel{
	
	
	//删除一条待发送数据
	public function delMsg($course_id){
		
		$where['course_id'] = $course_id;
		return $this->where($where)->order('id asc')->limit(1)->delete();
		
	}
	
	//查询一条待发送信息
	public function getMsg($course_id){
	
		$where['course_id'] = $course_id;
		return $this->where($where)->order('id asc')->find();
		
	}
	
	
}