<?php
namespace Admin\Model;
use Think\Model\RelationModel;
class StudentLawyerProfileModel extends RelationModel{

}