<?php
namespace Admin\Model;

use Think\Model\RelationModel;

//打赏列表
class SchoolCourseRewardModel extends RelationModel
{
    /**
     * 查询符合抽奖的人员（根据打赏金额）
     *
     * @param string $system_reward_id 打赏ID 关联system_reward
     * @param string $system_reward_teacher_id 打赏对象ID 关联system_reward_teacher
     * @param string $begin_money 起始金额
     *
     * return array
     */
    public function getListByMoney($system_reward_id, $system_reward_teacher_id, $begin_money)
    {
        $getOneWhere['system_reward_id'] = $system_reward_id;
        $reward_data = D('system_reward_teacher')->getone($getOneWhere);

        return $this->getMoneyOrder($reward_data['course_id'], $system_reward_teacher_id, $begin_money);
    }

    /**
     * 查询符合抽奖的人员（根据打赏名词）
     *
     * @param string $system_reward_id 打赏ID 关联system_reward
     * @param string $system_reward_teacher_id 打赏对象ID 关联system_reward_teacher
     * @param string $begin_number 起始名词，前后，比如为4，3个人，则为 名次为 4 、5 、6
     *
     * return array
     */
    public function getListByRanking($system_reward_id, $system_reward_teacher_id, $begin_number, $all_number)
    {
        $getOneWhere['system_reward_id'] = $system_reward_id;
        $reward_data = D('system_reward_teacher')->getone($getOneWhere);
        if ($begin_number) {
            $begin_number--;
        }

        $limit = "$begin_number,$all_number";
        return $this->getMoneyOrderLimit($reward_data['course_id'], $system_reward_teacher_id, $limit);
    }

    //查询打赏排名
    public function getMoneyOrder($course_id, $teacher_id, $begin_money)
    {
        $field = 'student_id,sum(price) as all_money';
        $order = ' rand()';
        $group = 'student_id';
        $where = " course_id = $course_id and teacher_id = $teacher_id ";

        return M()->query("select $field from " . C('DB_PREFIX') . "school_course_reward where $where group by $group  having sum(price) >= $begin_money order by $order ");
    }

    //查询打赏排名某些名次
    public function getMoneyOrderLimit($course_id, $teacher_id, $limit)
    {
        $field = 'student_id,sum(price) as all_money';
        $order = 'all_money desc';
        $group = 'student_id';

        $where['course_id'] = $course_id;
        $where['teacher_id'] = $teacher_id;

        return $this->field($field)->where($where)->group($group)->order($order)->limit($limit)->select();
    }

    //查询某个打赏的总金额
    public function getOneRewardAllMoney($system_reward_id, $pay_type = false)
    {
        $where['system_reward_id'] = $system_reward_id;
        if ($pay_type) {
            $where['pay_type'] = $pay_type;
        }
        return $this->where($where)->sum('price');
    }

    //查询某个打赏的打赏总人数
    public function getOneRewardAllStudent($system_reward_id, $pay_type = false)
    {
        $where['system_reward_id'] = $system_reward_id;
        if ($pay_type) {
            $where['pay_type'] = $pay_type;
        }
        return count($this->where($where)->group('student_id')->select());
    }

    //查询某个打赏的打赏总人次
    public function getOneRewardAllCount($system_reward_id, $pay_type = false)
    {
        $where['system_reward_id'] = $system_reward_id;
        if ($pay_type) {
            $where['pay_type'] = $pay_type;
        }
        return $this->where($where)->count();
    }

    //查询某个打赏对象的学生打赏记录
    public function getOneTeacherRewardRecord($reward_id, $teacher_id, $limit = 5)
    {
        $where['system_reward_id'] = $reward_id;
        $where['teacher_id'] = $teacher_id;
        $field = 'static_true_name,static_msg,time';
        $order = 'reward_id desc';
        $data = $this->field($field)->where($where)->order($order)->limit($limit)->select();
        if (!$data) {
            return false;
        }

        foreach ($data as $k => $v) {
            $data[$k]['time'] = date('H:i', $v['time']);
        }

        return $data;
    }

    public function getOneTeacherRewardRecordWhitShowLogic($reward_id, $teacher_id, $limit = 5, $ifShowMsg, $ifShowMoney)
    {
        $where['system_reward_id'] = $reward_id;
        $where['teacher_id'] = $teacher_id;
        $field = 'static_true_name,time';
        if ($ifShowMsg === true) {
            $field=$field.",static_msg";
        }
        if ($ifShowMoney === true) {
            $field=$field.",price";
        }
//var_dump($field);
        $order = 'reward_id desc';
        $data = $this->field($field)->where($where)->order($order)->limit($limit)->select();
        if (!$data) {
            return false;
        }

        foreach ($data as $k => $v) {
            $data[$k]['time'] = date('H:i', $v['time']);
        }

        return $data;
    }

    //查询某个打赏的打赏对象的打赏总人次
    public function getOneRewardOneObjAllCount($system_reward_id, $teacher_id, $pay_type = false)
    {
        $where['system_reward_id'] = $system_reward_id;
        $where['teacher_id'] = $teacher_id;
        if ($pay_type) {
            $where['pay_type'] = $pay_type;
        }
        return $this->where($where)->count();
    }


}