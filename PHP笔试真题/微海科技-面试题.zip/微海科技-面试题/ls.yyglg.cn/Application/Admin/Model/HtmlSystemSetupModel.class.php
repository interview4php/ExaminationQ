<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//系统配置
class HtmlSystemSetupModel extends RelationModel {
   	protected $_link = array(//连表
		//管理员
		  'admin'=>array(
			'mapping_type' =>self::BELONGS_TO,
			'class_name'   =>'Admin',
			'foreign_key'  =>'admin_id',
			'mapping_fields'=>'user_name,true_name,mobile_phone,email,job_number',
			'as_fields'    =>'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		 ),
		 
	);
	protected $_auto = array ( 
		array('time','time',1,'function'), 
		array('update_time','time',1,'function'), 
		array('admin_id','getAdminId',3,'callback'),
	);
	protected function getAdminId(){
		
		if(session('adminid')){
			return session('adminid');
		}else{
			return 1;
		}
		
	}
	//创建一个学生编号
	public function createStudentNumber(){
		$data = $this->getStudentNumberPrefix();
		//检查Id长度是否符号最小长度，如果不则在前面增加0
		$lastId = D('student')->getLastSchoolStudentId();
		$lastId = $this->checkMinLength($lastId+1,$data['student_number_min_length']);
		return $data['student_number_prefix'].$lastId;
	}
	
	
	//查询用户配置的学生编号前缀和最小长度
	public function getStudentNumberPrefix(){
		$field = 'student_number_prefix,student_number_min_length';
		$order = 'system_id desc';
		$data = $this->field($field)->order($order)->find();
		return $data;
	}
	//检查Id长度是否符号最小长度，如果不则在前面增加0
	private function checkMinLength($lastId,$minLen){	
		$strlen = strlen($lastId);
		$c = $minLen-$strlen;
		if($c>0){
			for($i=0;$i<$c;$i++){
				$lastId = '0'.$lastId;
			}
		}
		return $lastId;
		
	}
   
}