<?php
namespace Admin\Model;

use Think\Model\RelationModel;

//学生个人的标签
class StudentTagListModel extends RelationModel
{
	protected $_link = array(//连表
		//管理员
		'admin' => array(
			'mapping_type' => self::BELONGS_TO,
			'class_name' => 'Admin',
			'foreign_key' => 'admin_id',
			'mapping_fields' => 'user_name,true_name,mobile_phone,email,job_number',
			'as_fields' => 'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		),

	);

	/**
	 * 查询有该标签的用户ID
	 *
	 * @param $tag
	 * @return mixed
	 */
	public function getStudentID($tag)
	{
		$where['tag_id'] = array('in', $tag);
		$data = $this->field('student_id')->where($where)->group('student_id')->select();

		foreach ($data as $k => $v) {
			$data[$k] = $v['student_id'];
		}

		\Think\Log::record('get student id by tag, sql:' . $this->getLastSql() . ' data=' . json_encode($data), 'INFO');

		if (empty($data)) {
			$data = array(0);
		}

		return $data;
	}


}