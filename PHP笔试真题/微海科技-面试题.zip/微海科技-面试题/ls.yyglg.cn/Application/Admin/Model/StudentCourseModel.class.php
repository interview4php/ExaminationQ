<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//社员预约的课程
class StudentCourseModel extends RelationModel{
	protected $_link = array(//连表
		//管理员
		  'admin'=>array(
			'mapping_type' =>self::BELONGS_TO,
			'class_name'   =>'Admin',
			'foreign_key'  =>'admin_id',
			'mapping_fields'=>'user_name,true_name,mobile_phone,email,job_number',
			'as_fields'    =>'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		 ),
		 
	);
	//查询需要分配F码的学生
	public function getNeedFcodeStudent($course_id){
		$sc = D('student_course');
		$where['this.school_course_id'] = $course_id;
		$where['this.see_type'] = '直播';
		$where['this.status']	= 1;
		$join = 'as this left join '.C('DB_PREFIX').'student_course_fcode as st_f on (this.student_id = st_f.student_id  and this.school_course_id = st_f.course_id)';
		$field = 'this.id,this.student_id,st_f.f_code';
		return $sc->join($join)->field($field)->where($where)->select();
	}
	
	
	//学生课程请假
	public function delOne($student_course_id,$course_id,$msg='管理员手动请假'){
		
		$where['id'] 	= $student_course_id;
		//查询学生该课程是直播还是现场
		$see_type = $this->where($where)->getField('see_type');
		
		$data['status'] 			= 2;
		$data['update_time']  		= time();
		$data['msg']				= $msg;
		D()->startTrans();
		$ret1 = D('StudentCourse')->where($where)->save($data);
		//如果为现场则自减已使用的座位
		if($see_type=='现场'){
			$ret2 = D('SchoolCourse')->setDecUseNumber($course_id);
		}else{
			$ret2 = true;
		}
		if($ret1 && $ret2){
			D()->commit();
			return true;
		}else{
			D()->rollback();
			return false;
		}
		
	}
	
	
	//返回推送短信需要的用户ID
	public function getStudentID($course_id,$course_type){
		$where['school_course_id'] = $course_id;
		switch($course_type){
			case 'online':$where['see_type'] = '直播';break;
			case 'scence':$where['see_type'] = array('in', array('主会场', '现场'));break;
		}

		$where['status'] = 1;
		$data = $this->field('student_id')->where($where)->select();
		foreach($data as $k=>$v){
			$data[$k] = $v['student_id'];
		}
		return $data;
	}
	
	//查询该用户该课程是否为VIP
	public function isRewardVip($course_id,$student_id){
		$where['student_id'] 	= $student_id;
		$where['school_course_id']		= $course_id;
		return $this->where($where)->getField('is_reward_vip');
	}
	
	//批量设置打赏专座
	public function setMoreVip(){
		$course_id = I('post.course_id');
		$student_ids = I('post.student_ids');
		$student_id_arr = explode(',', $student_ids);


		foreach ($student_id_arr as $k => $v) {
			//查询当前用户是否已经报名了课程
			$where['student_id'] = $v;
			$where['school_course_id'] = $course_id;
			$ret = D('student_course')->where($where)->find();
		
			if ($ret && $ret['is_reward_vip']==0) {
				$where2['student_id'] = $v;
				$where2['school_course_id'] = $course_id;
				$data['is_reward_vip'] = 1;
				
				M('student_course')->where($where2)->save($data);
			}
		}

		return true;
	}
	
	//批量取消打赏专座
	public function delMoreVip(){
		$course_id = I('post.course_id');
		$student_ids = I('post.student_ids');
		$student_id_arr = explode(',', $student_ids);
		$id = 0;

		foreach ($student_id_arr as $k => $v) {
			//查询当前用户是否已经报名了课程
			$where['student_id'] = $v;
			$where['school_course_id'] = $course_id;
			$ret = D('student_course')->where($where)->find();
			if ($ret && $ret['is_reward_vip']==1) {
				$where2['student_id'] = $v;
				$where2['school_course_id'] = $course_id;
				$data['is_reward_vip'] = 0;
				
				M('student_course')->where($where2)->save($data);
			}
		}

		return true;
	}
	
	
}