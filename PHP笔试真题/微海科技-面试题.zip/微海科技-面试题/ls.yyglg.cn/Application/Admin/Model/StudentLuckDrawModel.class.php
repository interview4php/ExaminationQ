<?php
namespace Admin\Model;

use Think\Model\RelationModel;

//中奖列表
class StudentLuckDrawModel extends RelationModel
{
	protected $_link = array(//连表
		//管理员
		'admin' => array(
			'mapping_type' => self::BELONGS_TO,
			'class_name' => 'Admin',
			'foreign_key' => 'admin_id',
			'mapping_fields' => 'user_name,true_name,mobile_phone,email,job_number',
			'as_fields' => 'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		),

	);

	protected $_validate = array(
		array('address', 'require', '发货地址不能为空', 3),
		array('wl_number', 'require', '物流单号不能为空', 3),
		array('wl_company', 'require', '物流公司不能为空', 3),
	);

	protected $_auto = array(
		array('time', 'time', 1, 'function'),
		array('update_time', 'time', 2, 'function'),
		array('admin_id', 'getAdminId', 3, 'callback'),
	);

	protected function getAdminId()
	{
		if (session('adminid')) {
			return session('adminid');
		} else {
			return 1;
		}
	}

	protected function getDateToTime($field)
	{
		return strtotime($field);
	}

	/**
	 * 执行抽奖
	 */
	public function executeLuckDram($system_reward_id, $system_reward_teacher_id,$luckDrawId)
	{
		//查询当前打赏的奖品列表
		$luck_draw_data = D('system_reward_luck_draw')->getOneRewardLuckDraw($luckDrawId);
		if (!$luck_draw_data) {
			exit('<h1>请先设置奖品</h1>');
		}
		//dump($luck_draw_data);die;
		$all_number = $luck_draw_data['draw_all_number'];
		switch ($luck_draw_data['draw_type']) {
			case '从打赏人员中抽奖':
				//查询符合条件的打赏人员
				$userList = D('school_course_reward')->getListByMoney($system_reward_id, $system_reward_teacher_id, $luck_draw_data['draw_begin_money']);
				//dump('从打赏人员中抽奖'.$luck_draw_data['draw_begin_money']);
				break;
			case '按打赏名次抽奖':
				//查询符合条件的打赏人员
				$userList = D('school_course_reward')->getListByRanking($system_reward_id, $system_reward_teacher_id,
					$luck_draw_data['draw_begin_number'], $luck_draw_data['draw_all_number']);
				//dump('按打赏名次抽奖');
				//dump($userList);

				break;
		}
		if (!$userList) {
			exit('没有符合条件的用户.最低金额'. $luck_draw_data['draw_begin_money']);
		}

		//符合抽奖的人数
		$userListCount = count($userList);
		//数据随机
		$luck_people = array_rand($userList, $all_number>$userListCount?$userListCount:$all_number);
		if (is_array($luck_people)) {
			foreach ($luck_people as $k => $v) {
				$sql['luck_draw_id'] = $luck_draw_data['id'];
				$sql['student_id'] = $userList[$v]['student_id'];
				$sql['system_reward_id'] = $system_reward_id;
				$sql['system_reward_teacher_id'] = $system_reward_teacher_id;
				$sql['time'] = time();

				$luck_sql[] = $sql;
			}
		} else {
			$sql['luck_draw_id'] = $luck_draw_data['id'];
			$sql['student_id'] = $userList[$luck_people]['student_id'];
			$sql['system_reward_id'] = $system_reward_id;
			$sql['system_reward_teacher_id'] = $system_reward_teacher_id;
			$sql['time'] = time();

			$luck_sql[] = $sql;
		}


		if (empty($luck_sql)) {
			//$debug_info = " userlist" .var_export($userList, true) . " luckypeople" . var_export($luck_people, true) . " all_number:" . $all_number;
			exit('<h1>还没有人打赏，请先打赏</h1>');   // . $debug_info
		}

		D()->startTrans();
		$this->where(array('luck_draw_id' => $luck_draw_data['id']))->delete();
		$ret1 = $this->addAll($luck_sql);
		$ret2 = D('system_reward_luck_draw')->updateDrawUseNumber($luck_draw_data['id'], count($luck_people));
		$ret3 = D('system_reward_teacher')->updateIsLuckDraw($system_reward_teacher_id);
		if ($ret1 && $ret2 !== false && $ret3 !== false) {
			D()->commit();
			return true;
		} else {
			D()->rollback();
			return false;
		}
	}

}