<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//打赏对象
class SystemRewardTeacherModel extends RelationModel{
	protected $_link = array(//连表
		//管理员
		  'admin'=>array(
			'mapping_type' =>self::BELONGS_TO,
			'class_name'   =>'Admin',
			'foreign_key'  =>'admin_id',
			'mapping_fields'=>'user_name,true_name,mobile_phone,email,job_number',
			'as_fields'    =>'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		 ),
		 
	);
	protected $_validate = array(
		array('system_reward_id','require','请重新从打赏页面进入'),
		array('teacher_id','require','请选择老师'),
		array('teacher_id','checkTeacherUnique','该老师已存在于该打赏',0,'callback'), // 自定义函数验证老师
		array('sort','number','排序为数字，越大越靠前'),
	);
	
	
	protected $_auto = array ( 
		array('time','time',1,'function'), 
		array('update_time','time',2,'function'), 
		array('admin_id','getAdminId',3,'callback'),
	);

	protected function getAdminId(){
		
		if(session('adminid')){
			return session('adminid');
		}else{
			return 1;
		}
		
	}

	//判断该老师是否已经存在于该条打赏
	protected function checkTeacherUnique(){
		$editType = I('post.editType');
		$system_reward_id = I('post.system_reward_id');
		$id = I('post.id');
		$teacher_id = I('post.teacher_id');

		if($editType=='update'){
			//查询除了自己以外的该打赏记录是否有该老师
			$where['system_reward_id'] 	= $system_reward_id;
			$where['teacher_id']		= $teacher_id;
			$where['id']				= array('neq',$id);
			if($this->where($where)->find()){
				return false;
			}

			return true;
		}else if($editType=='create'){
			//查询该打赏记录是否有该老师
			$where['system_reward_id'] 	= $system_reward_id;
			$where['teacher_id']		= $teacher_id;
			if($this->where($where)->find()){
				return false;
			}

			return true;
		}

		return false;
	}



	
	//根据课程查询当前打赏对象ID
	public function getOneId($course_id){
		$where['status'] = 1;
		$where['course_id'] = $course_id;
		return $this->where($where)->getField('id');
	}

	//根据打赏查询当前打赏对象ID
	public function getOneIdBySystemRewardId($system_reward_id){
		$where['status'] = 1;
		$where['system_reward_id'] = $system_reward_id;
		return $this->where($where)->getField('id');
	}

	//查询某个打赏对象信息根据传进来的条件
	public function getone($where, $field='*'){
		return $this->field($field)->where($where)->find();
	}
	
	//更新某个打赏对象已经抽奖了
	public function updateIsLuckDraw($id){
		$where['id'] = $id;
		$save['is_luck_draw'] = 1;
		$save['update_time']	= time();
		return $this->where($where)->save($save);
	}
	
	//查询某个打赏的打赏对象列表
	public function getRewardObjList($reward_id){
		$where['this.system_reward_id'] = $reward_id;
		$field = 'this.id,tea.teacher_name';
		$join = 'as this left join ' . C('DB_PREFIX') . 'school_teacher as tea on this.teacher_id = tea.id ';
		return $this->field($field)->join($join)->where($where)->select();
	}
	
	
}