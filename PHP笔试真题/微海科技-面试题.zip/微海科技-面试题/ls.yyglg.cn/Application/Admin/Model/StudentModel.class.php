<?php
namespace Admin\Model;

use Think\Model\RelationModel;

//社员
class StudentModel extends RelationModel
{
	protected $_link = array(//连表
		//管理员
		'admin' => array(
			'mapping_type' => self::BELONGS_TO,
			'class_name' => 'Admin',
			'foreign_key' => 'admin_id',
			'mapping_fields' => 'user_name,true_name,mobile_phone,email,job_number',
			'as_fields' => 'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		),

	);

	protected $_validate = array(
		array('mobile_phone', '', '手机号已存在', 1, 'unique', 3), // 字段是否唯一
		array('school_student_number', '', '学号已存在', 1, 'unique', 3), // 字段是否唯一
	);

	protected $_auto = array(
		array('time', 'time', 1, 'function'),
		array('update_time', 'time', 2, 'function'),
		array('admin_id', 'getAdminId', 3, 'callback'),
		array('end_time', 'getDateToTime', 3, 'callback'),
		array('student_birthday', 'getDateToTime', 3, 'callback'),
	);

	protected function getAdminId()
	{

		if (session('adminid')) {
			return session('adminid');
		} else {
			return 1;
		}

	}

	protected function getDateToTime($field)
	{

		return strtotime($field);

	}

	//根据姓名、手机号、入学类型、入学有效期生成一个会员
	public function createOne($mobile_phone, $true_name, $apply_type_id, $end_time, $school_student_number)
	{
		$data['mobile_phone'] = $mobile_phone;
		$data['true_name'] = $true_name;
		$data['user_name'] = $true_name;
		$data['apply_type_id'] = $apply_type_id;
		$data['end_time'] = $end_time;
		$data['school_student_number'] = $school_student_number;
		$data['time'] = time();
		return $this->add($data);

	}

	//查询最后一个学员的ID
	public function getLastSchoolStudentId()
	{
		$field = 'id';
		$order = 'id desc';
		$data = $this->field($field)->order($order)->find();
		return $data['id'];
	}

	/**
	 * 返回短信推送的数据
	 *
	 * @param $send_obj
	 * @param bool $field
	 * @return bool|mixed
	 */
	public function getSendMessageData($send_obj, $field = false)
	{
        $cur_time = time(); //新增

		if ($send_obj) {
			switch ($send_obj) {
				case 'all':
					$where = 1;//所有会员
					break;
				case 'all_one'://在线社员
					$where['apply_type_id'] = 1;
					break;
				case 'all_two'://铁杆社员
					$where['apply_type_id'] = 2;
					break;
				case 'test'://测试
					$where['mobile_phone'] = array('in', array('18320493968', '18620471122', '18610128558','18603024321','18682157284'));
					break;
				case 'tag'://根据标签
					//查询标签为提交的标签的用户ID（去重）
					$where['id'] = array('in', D('student_tag_list')->getStudentID(I('post.tag')));
					break;
				case 'course'://根据课程
					//根据某个课程来查询需要推送的用户ID
					$data = D('student_course')->getStudentID(I('post.course_id'), I('post.course_type'));
					if (empty($data)) {
						$data = array(0);
					}
					$where['id'] = array('in', $data);
					break;


                //2016-2-25 新增 会员状态
                case 'normal':  //正常会员
                    $where['end_time'] = array('egt', $cur_time);
                    break;
                case 'expired': //过期会员
                    $where['end_time'] = array(array('lt', $cur_time), array('egt', 0));
                    break;
			}

			if (!$field) {
				$field = 'true_name,mobile_phone,school_student_number,end_time';
			}

			return D('student')->field($field)->where($where)->select();
		} else {
			return false;
		}

	}

	//批量给用户增加标签
	public function setMoreTag()
	{
		$tag_id = I('post.tag_id');
		$student_ids = I('post.student_ids');
		$student_id_arr = explode(',', $student_ids);
		$id = 0;

		foreach ($student_id_arr as $k => $v) {
			//查询当前用户是否已经有该标签了
			$where['student_id'] = $v;
			$where['tag_id'] = $tag_id;
			if (!D('student_tag_list')->where($where)->find()) {
				$data[$id]['student_id'] = $v;
				$data[$id]['tag_id'] = $tag_id;
				$data[$id]['time'] = time();
				$data[$id]['admin_id'] = $this->getAdminId();
				$id++;
			}
		}

		return D('student_tag_list')->addAll($data);
	}

	//批量给用户增加分组
	public function setMoreGroup()
	{
		$group_id = I('post.student_group_id');
		$student_ids = I('post.student_ids');
		$student_id_arr = explode(',', $student_ids);
		$id = 0;

		foreach ($student_id_arr as $k => $v) {
			//查询当前用户是否已经有该标签了
			$where['student_id'] = $v;
			$where['group_id'] = $group_id;
			if (!D('student_group_list')->where($where)->find()) {
				$data[$id]['student_id'] = $v;
				$data[$id]['group_id'] = $group_id;
				$data[$id]['time'] = time();
				$data[$id]['admin_id'] = $this->getAdminId();
				$id++;
			}
		}

		return D('student_group_list')->addAll($data);
	}

	//批量删除标签 2016-2-25
	public function delMoreTag()
	{
		$tag_id = I('post.tag_id');
		$student_ids = I('post.student_ids');
		$student_id_arr = explode(',', $student_ids);
		$id = 0;

        $bool = false;

		foreach ($student_id_arr as $k => $v) {
			//查询当前用户是否已经有该标签了
			$where['student_id'] = $v;
			$where['tag_id'] = $tag_id;
			if (D('student_tag_list')->where($where)->find()) {
                $bool = D('student_tag_list')->where($where)->delete();
			}
		}

		return $bool;
	}
	
	
	//批量删除分组
	public function delMoreGroup()
	{
		$group_id = I('post.group_id');
		$student_ids = I('post.student_ids');
		$student_id_arr = explode(',', $student_ids);
		$id = 0;

        $bool = false;

		foreach ($student_id_arr as $k => $v) {
			//查询当前用户是否已经有该标签了
			$where['student_id'] = $v;
			$where['group_id'] = $group_id;
			if (D('student_group_list')->where($where)->find()) {
                $bool = D('student_group_list')->where($where)->delete();
			}
		}

		return $bool;
	}

}