<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//预约成功界面设置
class IndexAddressesModel extends RelationModel{


}