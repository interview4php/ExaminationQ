<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//社员行业类型
class StudentVocationModel extends RelationModel{
	protected $_link = array(//连表
		//管理员
		  'admin'=>array(
			'mapping_type' =>self::BELONGS_TO,
			'class_name'   =>'Admin',
			'foreign_key'  =>'admin_id',
			'mapping_fields'=>'user_name,true_name,mobile_phone,email,job_number',
			'as_fields'    =>'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		 ),
		 
	);
	
	 protected $_validate = array(
		array('student_vocation_name','require','行业类型不能为空',3),		
		array('student_vocation_name','','行业类型已存在',1,'unique',3), // 字段是否唯一		
		array('sort','number','排序应该为数字，越大越靠前',3),		
	 );
	protected $_auto = array ( 
		array('time','time',1,'function'), 
		array('update_time','time',2,'function'), 
		array('admin_id','getAdminId',3,'callback'),
	);
	protected function getAdminId(){
		
		if(session('adminid')){
			return session('adminid');
		}else{
			return 1;
		}
		
	}
	
	
	
	
}