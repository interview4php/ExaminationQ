<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//音响问题
class SchoolCourseQuestionMusicModel extends RelationModel {
	//查询某个课程的音响问题投票情况
	public function getOneCourse($courseId,$field='too_big,too_small,default_title,default_description,default_img'){
		//查看该课程的该投票是否已经创建没有则创建
		$this->isHave($courseId);
	
		$where['course_id'] = $courseId;
		return $this->field($field)->where($where)->find();
	}
   
	//设置投票
	public function setOne($courseId,$type,$studentId,$seatNumber){
		if(empty($courseId) || empty($type) || empty($studentId) || empty($seatNumber)){
			return array('ret'=>'false','msg'=>'参数不全');
		}
		$where['course_id'] = $courseId;
		//查看该课程的该投票是否已经投票过了
		if(D('StudentCourseQuestionMusic')->isHave($courseId,$studentId)){
			return array('ret'=>'false','msg'=>'已经投票过了');
		}
		
		//查看该课程的该投票是否已经创建没有则创建
		$this->isHave($courseId);
		
		//开启事务
		D()->startTrans();
		switch($type){
			case 'big':$ret1 = $this->where($where)->setInc('too_big');break;
			case 'small':$ret1 =  $this->where($where)->setInc('too_small');break;
			default :$ret = false;
		}
		//设置该学生为已经投票
		$res2 = D('StudentCourseQuestionMusic')->createOne($courseId,$studentId,$type,$seatNumber);
		if($ret1 && $res2){
			D()->commit();
			return array('ret'=>'true','msg'=>'投票成功');
		}else{
			D()->rollback();
			return array('ret'=>'false','msg'=>'服务器繁忙');
		}
		
	}
	
	//检查是否有该条数据
	public function isHave($courseId){
		$where['course_id'] = $courseId;
		if(!$this->where($where)->count()){
			$this->add(array('course_id'=>$courseId,'time'=>time()));
		}
	}
	
	
	
	protected $_link = array(//连表
		//管理员
		  'admin'=>array(
			'mapping_type' =>self::BELONGS_TO,
			'class_name'   =>'Admin',
			'foreign_key'  =>'admin_id',
			'mapping_fields'=>'user_name,true_name,mobile_phone,email,job_number',
			'as_fields'    =>'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		 ),
		 
	);
	protected $_auto = array ( 
		array('time','time',1,'function'), 
		array('update_time','time',3,'function'), 
		array('admin_id','getAdminId',3,'callback'),
	);
	protected function getAdminId(){
		
		if(session('adminid')){
			return session('adminid');
		}else{
			return 1;
		}
		
	}
}