<?php
namespace Admin\Model;

use Think\Model\RelationModel;

//打赏管理
class SystemRewardModel extends RelationModel
{
	protected $_link = array(//连表
		//管理员
		'admin' => array(
			'mapping_type' => self::BELONGS_TO,
			'class_name' => 'Admin',
			'foreign_key' => 'admin_id',
			'mapping_fields' => 'user_name,true_name,mobile_phone,email,job_number',
			'as_fields' => 'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		),

	);

	protected $_validate = array(
		array('other_id', 'checkCourse', '该课程已经有打赏了', 1, 'callback'),
	);

	protected $_auto = array(
		array('time', 'time', 1, 'function'),
		array('update_time', 'time', 2, 'function'),
		array('admin_id', 'getAdminId', 3, 'callback'),
	);

	protected function getAdminId()
	{
		if (session('adminid')) {
			return session('adminid');
		} else {
			return 1;
		}
	}

	protected function getDateToTime($field)
	{

		return strtotime($field);

	}

	protected function checkCourse($field)
	{
		if (empty($field)) {
			return true;
		}

		$where['other_id'] = $field;
		$pk = $this->getPk();
		//如果有主键传入, 说明是编辑, 加入排除自己的条件.
		if (!empty($_POST['id'])) {
			$where[$pk] = array('neq', $_POST['id']);
		}

		if ($this->where($where)->find()) {
			return false;
		} else {
			return true;
		}
	}
}