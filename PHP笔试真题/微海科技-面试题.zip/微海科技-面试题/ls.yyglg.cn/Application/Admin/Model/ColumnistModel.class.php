<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/10/3 0003
 * Time: 下午 9:45
 */
namespace Admin\Model;

use Think\Model\RelationModel;

class ColumnistModel extends RelationModel {

    protected $_link = array(
        'Columns' => array(
            'mapping_type' =>self::HAS_MANY,
            'foreign_key'  =>'columnist_id',
            'mapping_name'=>'clumns',
            'mapping_order' => 'time desc',
        ),
    );

    protected $_validate = array(
        array('columnist_name','','专栏作家名字已经存在！',1,'unique',3), // 字段是否唯一
        array('columnist_name','require','专栏作家名字不能为空'),
    );

    protected $_auto = array (
        array('time','time',1,'function'),
        array('update_time','time',2,'function'),
        array('admin_id','getAdminId',3,'callback'),
    );

    protected function getAdminId(){
        if(session('adminid')){
            return session('adminid');
        }else{
            return 1;
        }
    }


}