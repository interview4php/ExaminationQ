<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/10/3 0003
 * Time: 下午 9:43
 */
namespace Admin\Model;

use Think\Model\RelationModel;

class ColumnsModel extends RelationModel {

    protected $_link = array(
        'Columnist' => array(
            'mapping_type' =>self::BELONGS_TO,
            'foreign_key'  =>'columnist_id',
            'mapping_fields'=>'columnist_name,columnist_head_img',
            'as_fields'    =>'columnist_name:columnist_name,columnist_head_img:columnist_head_img',
        ),
        'Article' => array(
            'mapping_type' =>self::HAS_MANY,
            'foreign_key'  =>'columns_id',
            'mapping_name'=>'article',
            'mapping_order' => 'time desc',
        ),
    );

    protected $_validate = array(
        array('columnist_id','require','请选择专栏作家'),
        array('columnist_id',0,'请选择专栏作家', 0, 'notequal'),
        array('columns_name','','名称已经存在！',1,'unique',3), // 字段是否唯一
        array('columns_name','require','名称不能为空'),
        array('columns_description','require','专栏简介不能为空'),
        array('suitable_object','require','适宜人群不能为空'),
        array('notes','require','订阅须知不能为空'),
    );

    protected $_auto = array (
        array('time','time',1,'function'),
        array('update_time','time',2,'function'),
        array('admin_id','getAdminId',3,'callback'),
    );

    protected function getAdminId(){
        if(session('adminid')){
            return session('adminid');
        }else{
            return 1;
        }
    }


}