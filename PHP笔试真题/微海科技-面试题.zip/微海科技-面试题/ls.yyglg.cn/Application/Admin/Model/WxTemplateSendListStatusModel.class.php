<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//微信模板发送状态
class WxTemplateSendListStatusModel extends RelationModel{
	
	/**创建一条新的信息
	* @string $template_name 模板名字
	* @array  $student_data 学生信息数组
	* @string  $send_status  发送状态
	* @string  $error_msg 错误信息
	*/
	public function createOne($template_id, $template_name,$student_data,$send_status,$error_msg){
		$data['template_id'] 	= $template_id;
		$data['template_name'] 	= $template_name;
		$data['student_id'] 	= $student_data['id'];
		$data['mobile_phone'] 	= $student_data['mobile_phone'];
		$data['send_status'] 	= $send_status;
		$data['error_msg'] 		= $error_msg;
		$data['time'] 			= time();

		return $this->add($data);
		
	}
	
}