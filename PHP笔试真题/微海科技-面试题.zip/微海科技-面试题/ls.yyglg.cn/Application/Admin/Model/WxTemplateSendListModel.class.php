<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//微信模板消息
class WxTemplateSendListModel extends RelationModel{
	protected $_link = array(//连表
		//管理员
		  'admin'=>array(
			'mapping_type' =>self::BELONGS_TO,
			'class_name'   =>'Admin',
			'foreign_key'  =>'admin_id',
			'mapping_fields'=>'user_name,true_name,mobile_phone,email,job_number',
			'as_fields'    =>'user_name:admin_user_name,true_name:admin_true_name,mobile_phone:admin_mobile_phone,email:admin_email,job_number:admin_job_number',
		 ),
		 
	);
	
	//推送开始
	public function beginOne($template_name,$count, $send_data){
		$data['template_name'] = $template_name;
		$data['number_all'] = $count;
		$data['begin_time'] = time();
		$data['admin_id'] = session('adminid');
		$data['send_data'] = $send_data;

		return M('wx_template_send_list')->add($data);
	}
	
	//推送结束
	public function endOne($id,$success,$error,$nobinding){
		$save['number_success'] = $success;
		$save['number_error'] = $error;
		$save['number_no_binding'] = $nobinding;
		$save['end_time'] = time();
		$save['status'] = 2;
		$where['id'] = $id;
		return $this->where($where)->save($save);
	}

	//推送结束
	public function update_resume_ret($id){
		$save['end_time'] = time();
		$save['status'] = 2;

		$where['id'] = $id;

		return $this->where($where)->save($save);
	}
	
	//更新推送的记录
	public function updateOne($id,$field,$template_name,$student_data){
		$where['id'] = $id;
		//$this->where($where)->setInc($field);
		$data = array('update_time' => time(), "$field" => array('exp', "$field+1"));
		$this->where($where)->save($data);

		switch($field){
			case 'number_success'	: $error_msg = '发送成功';break;
			case 'number_error'		: $error_msg = '微信端发送失败';break;
			case 'number_no_binding': $error_msg = '用户未绑定微信';break;
		}

		D('WxTemplateSendListStatus')->createOne($id, $template_name,$student_data,$field,$error_msg);

		return true;
	}
	
	
	
}