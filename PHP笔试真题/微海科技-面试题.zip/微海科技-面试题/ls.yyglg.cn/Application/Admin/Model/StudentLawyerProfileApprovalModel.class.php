<?php
namespace Admin\Model;
use Think\Model\RelationModel;
class StudentLawyerProfileApprovalModel extends RelationModel{

}