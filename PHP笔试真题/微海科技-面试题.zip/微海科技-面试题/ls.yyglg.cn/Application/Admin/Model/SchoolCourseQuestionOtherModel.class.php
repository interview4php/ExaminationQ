<?php
namespace Admin\Model;
use Think\Model\RelationModel;
//其他问题
class SchoolCourseQuestionOtherModel extends RelationModel {
   
	//提交问题
	public function createOne($courseId,$msg,$studentId,$seatNumber){
		if(empty($courseId) || empty($msg) || empty($studentId) || empty($seatNumber)){
			return array('ret'=>'false','msg'=>'参数不全');
		}
		$data['course_id'] 	= $courseId;
		$data['student_id']	= $studentId;
		$data['msg']		= $msg;
		$data['seat_number']= $seatNumber;
		$data['time']		= time();
		if($this->add($data)){
			return array('ret'=>'true','msg'=>'提交成功');
		}else{
			return array('ret'=>'false','msg'=>'添加失败');
		}
		
	}
	
	
   
}