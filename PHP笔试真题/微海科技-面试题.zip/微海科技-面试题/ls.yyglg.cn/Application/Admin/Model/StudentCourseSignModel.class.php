<?php
namespace Admin\Model;

use Think\Model\RelationModel;

//签到
class StudentCourseSignModel extends RelationModel
{

    //$student_id可以为空
    //$limit是类似与‘0，20’这样的串
    //$course_name是课程名字的模糊搜索，可以为空
    public function getStudentStudyRecord($student_id, $course_name, $limit)
    {

        $db_prefix = GetDbPrefix();

        $field = 'this.student_id,this.id,this.school_course_id,this.activity_place_id,this.status,this.see_type,course.name,
		course.begin_time,course.relate_course_id,course.is_can_false,course.video_status';
        // ,sign.time

        $join = 'as this inner join ' . $db_prefix . 'school_course as course on this.school_course_id = course.id';

        $where = array();

        if ($course_name) {
            $where['course.name'] = array('like', '%' . trim($course_name) . '%');
        }

        if ($student_id) {
            $where['this.student_id'] = $student_id;
        } else {
            $where['this.student_id'] = array('gt', 0);
        }


        $where['this.pay_status'] = '1';

        //视频回看状态的才是学习记录
        // $where['course.video_status'] = '4';


        $where['course.type'] = 1;


        $where['this.status'] = array('gt', 0);


        //  $where['this.see_type'] = array('neq', '其他');

        $order = 'course.begin_time desc';

        //学生报名的活动
        $student_course = D('student_course')->field($field)->join($join)->where($where)->order($order)->limit($limit)->select();


        if (!$student_course) {
            return $student_course;
        }

//		var_dump($student_course);

        $arr_rtn = array();


        $obj_sc_sign = M('student_course_sign');

        //报名记录
        // “X未签到”“√已签到”“ √已报名”“ √已请假”
        foreach ($student_course as $k => $v) {

            //学生签到的时间
            $v['time'] = $obj_sc_sign->where(array('student_id' => $v['student_id'], 'course_id' => $v['school_course_id']))->getField('time');

            //请假的不计入其中
            if (2 == $v['status']) {
                continue;
            }

            $ifSigned = false;
            if ($v['time']) {
                //如果学生签到了
                $ifSigned = true;
            }

            $has_repeat = false;
            foreach ($arr_rtn as $key1 => $value1) {
                if (trim($student_course[$k]['name']) == trim($value1['name'])
                    || $v['school_course_id'] == $value1['school_course_id']
                    || $v['relate_course_id'] == $value1['school_course_id']
                ) {
                    $has_repeat = true;
                    break;
                }
            }

            if ($has_repeat || (!$ifSigned)) {
                continue;
            } else {

                $arr_rtn[] = $student_course[$k];
            }
        }


        return $arr_rtn;
    }


    //查看是否已经签名了
    public function isSign($student_id, $course_id)
    {
        $where['course_id'] = $course_id;
        $where['student_id'] = $student_id;

        return $this->where($where)->count();
    }

    //新增签名（执行签名）
    public function createOne($student_id, $course_id)
    {
        $data['student_id'] = $student_id;
        $data['course_id'] = $course_id;
        $data['time'] = time();

        return $this->add($data);
    }


}