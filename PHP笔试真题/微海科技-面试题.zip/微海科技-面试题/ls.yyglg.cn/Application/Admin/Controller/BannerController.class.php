<?php
namespace Admin\Controller;
use Think\Controller;
class BannerController extends ExtendController {
   
	//微站首页广告列表
	public function activityIndex(){
		
		$sc = M('wxsite_banner');
		$where['address'] = 1;
		$count = $sc->where($where)->count();
		$order = 'sort desc,id desc';
		$Page = new \Think\Page($count, 10);
		$show = $Page->show();
		$list = $sc->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();

		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('activityIndex');
	}
	
	//微站首页广告列表新增||修改
	public function activityIndexEdit(){	
		A('Public')->getEdit('wxsite_banner');
		
		$this->display('activityIndexEdit');
	}
   
}