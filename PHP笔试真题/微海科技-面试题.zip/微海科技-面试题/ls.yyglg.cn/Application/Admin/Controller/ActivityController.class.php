<?php
namespace Admin\Controller;

use Think\Controller;

class ActivityController extends ExtendController
{
    private $courseListNum = 10;//学院课程每页显示个数
    private $teacherListNum = 10;//学院课程里面的老师
    private $courseSeatListNum = 20;//学院课程里面的座位
    private $pptListNum = 100;//学院课程里面的PPT

    /**
     * 列举所有的活动
     */
    public function activity()
    {
        $search = !empty($_GET['search']) ? $_GET['search'] : 'all';

        $where = array(
            'type' => 1,
        );

        //课题名字
        if ($search != 'all') {
            $where['name'] = array('like', '%' . trim($search) . '%');
            $this->assign('search', $search);
        }

        $sc = D('school_course');
        $count = $sc->where($where)->count();

        $Page = new \Think\Page($count, $this->courseListNum);
        $show = $Page->show();

        $field = 'id,name,address,admin_id,begin_time,end_time,is_publish,cover_img';

        //获取排序
        $order = 'id desc';

        $list = $sc->relation('admin')->field($field)->where($where)
            ->order($order)->limit($Page->firstRow, $Page->listRows)->select();

        $obj_stu_c = M('student_course');

        foreach ($list as $key => $value) {
            //查询每个分活动的名字数量信息
            $obj_act_place = M('activity_place');

            $main_place = $obj_act_place->where(array('activity_id' => $value['id'], 'type' => 1))->find();
            $online_place = $obj_act_place->where(array('activity_id' => $value['id'], 'type' => 2))->find();

            $cond = array('activity_place_id' => $main_place['id'], 'pay_status' => 1, 'status' => 1);
            $list[$key]['main_signed_number'] = $obj_stu_c->where($cond)->count();

            $list[$key]['has_online'] = $online_place['is_use'];

            $cond = array('activity_place_id' => $online_place['id'], 'pay_status' => 1, 'status' => 1);
            $list[$key]['online_signed_number'] = $obj_stu_c->where($cond)->count();

            $cond = array('activity_id' => $value['id'], 'type' => array('gt', 2));
            $place_list = $obj_act_place->where($cond)->select();

            foreach ($place_list as $key_place => $value_place) {
                $cond = array('activity_place_id' => $value_place['id'], 'pay_status' => 1, 'status' => 1);
                $place_list[$key_place]['signed_number'] = $obj_stu_c->where($cond)->count();
            }

            $list[$key]['place_list'] = $place_list;

            $list[$key]['admin_name'] = 'admin';
        }

        $this->assign('list', $list);
        $this->assign('page', $show);

        $this->display();
    }

//删除课前提问
    public  function  DelAsk($id=0)
    {
        $name=M('ActivityAskTeacher');
        $pname=$name->where('id='.$id)->delete();
        if($pname){
            $this->success('删除成功');
        }else{
            $this->success('删除失败');
        }

    }
//	课前提问管理界面
    public function AskList($course_id = 0)
    {






        $where['activity_id'] = $course_id;
        $order = 'number desc,id desc';

        $sc = M('ActivityAskTeacher');
        $count = $sc->where($where)->count();

        $Page = new \Think\Page($count, $this->courseListNum);
        $show = $Page->show();

        $field = 'id,statics_head_img,statics_name,content,number,time,student_id';
        $data = M('ActivityAskTeacher')->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();

        $this->assign('page', $show);
        $this->assign('list', $data);
//        var_dump($show);
//        var_dump($data);
        $this->display();
    }


    /**
     *
     * @param int $id
     */
    public function editactivity($id = 0)
    {
        if (!empty($id)) {
            $foodType = M('school_course');
//			$foodType = M('activity');	//修改 2016-2-29
            $data = $foodType->find($id);
            $this->assign('data', $data);

            $this->assign('course_sign_url', S_URL . U("Bz/Kcqd/index/courseId/$id"));
            $this->assign('course_mode_url', S_URL . U("Bz/Classroom/index/courseId/$id"));
            $this->assign('service_helper_url', S_URL . U("Bz/Service/index/courseId/$id"));
            // 分会场信息
            $obj_act_place = M('activity_place');

            $is_main_place_use = $obj_act_place->where(array('activity_id' => $id, 'type' => 1))->getField('is_use');
            $is_online_use = $obj_act_place->where(array('activity_id' => $id, 'type' => 2))->getField('is_use');
            $place_list = $obj_act_place->where(array('activity_id' => $id, 'type' => array('gt', 2)))->select();

            $this->assign('is_main_place_use', $is_main_place_use);
            $this->assign('is_online_use', $is_online_use);
            $this->assign('place_list', $place_list);
        }

        if (empty($data['relate_course_id'])) {
            $data['relate_course_id'] = 0;
        }

        //课程选择  // $table, $where, $order, $kk, $vv, $value, $idAndName, $default = '', $myclass = ''
        $course_select = A('GetSelect')->getDtoS('school_course', array('type' => 0), 'begin_time desc', 'id', 'name', $data['relate_course_id'], 'relate_course_id', array(0, '请选择关联课程'));
        $this->assign('course_select', $course_select);

        $this->display();
    }

    /**
     * 列举管理页的信息
     *
     * @param $id
     */
    public function manage($id = 0)
    {
        //$url=MODULE_NAME."/".CONTROLLER_NAME."/".ACTION_NAME;
        if ($id == 0) {
            $this->error('请创建活动', '/Admin/activity/editactivity');
        }

        if ($id !== 0) {
            $obj = M('school_course');
            $data = $obj->find($id);
            $this->assign('data', $data);
            session('urlid', $id);

            //
            $obj_stu_c = M('student_course');
            $obj_act_place = M('activity_place');
            $place_list = $obj_act_place->where(array('activity_id' => $id))->select();

            foreach ($place_list as $key => $value) {
                // 已报名，待审核数量
                $cond = array('activity_place_id' => $value['id'], 'pay_status' => 1, 'status' => 1);
                $place_list[$key]['signed_number'] = $obj_stu_c->where($cond)->count();

                $cond['is_check'] = 0;
                $place_list[$key]['wait_audit_number'] = $obj_stu_c->where($cond)->count();

                $place_list[$key]['course_one_url'] = S_URL . "/Bz/ActivityOne/index/courseId/{$id}/placeId/{$value['id']}";

                $place_list[$key]['sign_url'] = S_URL . "/Bz/Kcqd/index/courseId/{$id}/placeId/{$value['id']}";

            }
            $this->assign('place_list', $place_list);
        }

        $this->display();
    }

    /**
     * 发布活动
     *
     * @param $id
     */
    public function publish($id)
    {
//		$foodType = M('activity');	//修改 2016-2-29
//		$ret = M('school_course')->where(array('id' => $id))->save(array('is_publish' => 1));
        $ret = M('school_course')->where(array('id' => $id))->save(array('is_publish' => 1));    //修改 2016-2-29


        if ($ret != false) {
            $this->success('发布成功', "/Admin/Activity/activity");
        } else {
            $this->error('发布失败', "/Admin/Activity/activity");
        }
    }


    public function edit_place()
    {

    }

    /**
     *
     * @param $id
     */
    public function promote($id = 0)
    {
        if ($id == 0) {
            $this->error('请创建活动', '/Admin/activity/editactivity');
        }
        if ($id !== 0) {
            $foodType = M('school_course');
            $data = $foodType->find($id);
            $this->assign('data', $data);

            $share_data = D('SchoolCourseWxShare')->getOne($id);
            $share_url = $this->createRewardQRCode($id, 0, "promoteCode");
            $this->assign('share_url', $share_url);
            //查询该活动微信分享的配置内容
            $this->assign('share_data', $share_data);
            $this->assign('editType', !empty($_GET['t']) ? 'update' : 'create');

            //课程ID
            $this->assign('course_id', $id);

            $this->display();
        }
    }

    //生成二维码
    private function createRewardQRCode($course_id, $reward_id, $name)
    {
        $data = S_URL . "/Baozhu/ActivityDetail/indexPreview/activity_id/{$course_id}/teacher_id/0";
        $level = 'H';// 纠错级别：L、M、Q、H
        $size = 100;// 点的大小：1到10,用于手机端4就可以了
        $path = "./Public/" . $name . "/" . $reward_id . "/";
        $fileName = $path . $size . '.png';
        A('ChenImg')->mydir($path);
        $short_path = '/Public/' . $name . '/' . $reward_id . '/' . $size . '.png';
        $all_path = S_URL . $short_path;
        $logo = './Public/Bz/images/logo20160130.png';//准备好的logo图片
        //if(!is_file($fileName)){

        vendor("phpqrcode.phpqrcode");

        \QRcode::png($data, $fileName, $level, $size);
        if (is_file($logo)) {
            $QR = imagecreatefromstring(file_get_contents($all_path));
            $logo = imagecreatefromstring(file_get_contents($logo));
            $QR_width = imagesx($QR);//二维码图片宽度
            $QR_height = imagesy($QR);//二维码图片高度
            $logo_width = imagesx($logo);//logo图片宽度
            $logo_height = imagesy($logo);//logo图片高度
            $logo_qr_width = $QR_width / 5;
            $scale = $logo_width / $logo_qr_width;
            $logo_qr_height = $logo_height / $scale;
            $from_width = ($QR_width - $logo_qr_width) / 2;
            //重新组合图片并调整大小
            imagecopyresampled($QR, $logo, $from_width, $from_width, 0, 0, $logo_qr_width,
                $logo_qr_height, $logo_width, $logo_height);
        }

        //输出图片
        imagepng($QR, $fileName);
        //}

        return $short_path;
    }

    /**
     *
     * @param $id
     */
    public function statistics($id = 0)
    {
        if ($id == 0) {
            $this->error('请创建活动', '/Admin/activity/editactivity');
        }

        if ($id !== 0) {
            $foodType = M('school_course');

            $data = $foodType->find($id);
            $this->assign('data', $data);
            $this->assign('id', $id);

            // $table, $where, $order, $kk, $vv, $value, $idAndName, $default = '', $myclass = ''
            $place_select = A('GetSelect')->getDtoS('activity_place', array('activity_id' => $id, 'is_use' => 1), 'type ASC', 'id', 'name', $data['id'], 'activity_place_id', array(0, '请选择类型'));
            $this->assign('place_select', $place_select);

            $place_id = I('get.place_id');

            $cond = array(
                'c.school_course_id' => $id,
                'c.pay_status' => 1,
                'c.status' => array('gt', 0),
            );
            if (!empty($place_id) && is_numeric($place_id)) {
                $cond['c.activity_place_id'] = $place_id;
            }

            $db_prefix = GetDbPrefix();
            $field = 'c.id,t.true_name,t.mobile_phone,t.school_student_number,t.student_email,t.company_name,
			t.company_vocation_id,t.company_position_id,c.time,c.status,c.student_id,c.activity_place_id,c.pay_status';

            $User = M('student_course');
            $count = $User->table("{$db_prefix}student_course c")
                ->join("left join {$db_prefix}student t on(c.student_id=t.id)")->field($field)->where($cond)->count();

            $Page = new \Think\Page($count, 50);
            $Page->setConfig('theme', '%HEADER% %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%');
            $show = $Page->show();

            $user_list = $User->table("{$db_prefix}student_course c")
                ->join("left join {$db_prefix}student t on(c.student_id=t.id)")->field($field)
                ->where($cond)->order('id desc')->limit($Page->firstRow . ',' . $Page->listRows)->select();

            $obj_sign = M('student_course_sign');
            $obj_seat = M('student_course_seat');
            $obj_fcode = M('student_course_fcode');
            $obj_place = M('activity_place');
            $obj_stu_del = M('student_deleted');

            foreach ($user_list as $key => $value) {
                $cond = array(
                    'course_id' => $id,
                    //'activity_place_id' => $value['activity_place_id'],
                    'student_id' => $value['student_id'],
                );
                $user_list[$key]['is_sign'] = $obj_sign->where($cond)->find();
                if ($user_list[$key]['is_sign']) {
                    $user_list[$key]['is_sign'] = 1;
                } else {
                    $user_list[$key]['is_sign'] = 0;
                }

                //$user_list[$key]['is_sign'] = empty($user_list[$key]['is_sign']) ? 0 : 1;
                $cond = array(
                    'course_id' => $id,
                    'activity_place_id' => array('in', array(0, $value['activity_place_id'])),
                    'student_id' => $value['student_id'],
                );
                $user_list[$key]['seat_address'] = $obj_seat->where($cond)->order('activity_place_id DESC')
                    ->getField('seat_address');

                $user_list[$key]['f_code'] = $obj_fcode->where($cond)->getField('f_code');

                if (empty($value['mobile_phone'])) {
                    $tmp_field = 'true_name,mobile_phone,school_student_number,student_email,company_name,
					company_vocation_id,company_position_id';
                    $deleted_user_info = $obj_stu_del->field($tmp_field)
                        ->where(array('student_id' => $value['student_id']))
                        ->find();

                    $user_list[$key]['true_name'] = $deleted_user_info['true_name'] ? $deleted_user_info['true_name']
                        : $value['true_name'];
                    $user_list[$key]['mobile_phone'] = $deleted_user_info['mobile_phone'] ? $deleted_user_info['mobile_phone']
                        : $value['mobile_phone'];
                    $user_list[$key]['school_student_number'] = $deleted_user_info['school_student_number'] ? $deleted_user_info['school_student_number']
                        : $value['school_student_number'];
                    $user_list[$key]['student_email'] = $deleted_user_info['student_email'] ? $deleted_user_info['student_email']
                        : $value['student_email'];

                    $user_list[$key]['company_name'] = $deleted_user_info['company_name'] ? $deleted_user_info['company_name']
                        : $value['company_name'];
                    $user_list[$key]['company_vocation_id'] = $deleted_user_info['company_vocation_id'] ? $deleted_user_info['company_vocation_id']
                        : $value['company_vocation_id'];
                    $user_list[$key]['company_position_id'] = $deleted_user_info['company_position_id'] ? $deleted_user_info['company_position_id']
                        : $value['company_position_id'];
                }
            }

            session('listcard', $user_list);
            $this->assign('user_list', $user_list);
            $this->assign('page', $show);

            $vocation_list = M('student_vocation')->limit(300)->select();
            $position_list = M('student_position')->limit(300)->select();
            foreach ($vocation_list as $value) {
                $vocation_kv[$value['student_vocation_id']] = $value['student_vocation_name'];
            }

            foreach ($position_list as $value) {
                $position_kv[$value['student_position_id']] = $value['student_position_name'];
            }

            $this->assign('vocation_kv', $vocation_kv);
            $this->assign('position_kv', $position_kv);

            $place_list = $obj_place->field('id,name')->where(array('activity_id' => $id))->select();
            foreach ($place_list as $value) {
                $place_kv[$value['id']] = $value['name'];
            }

            $this->assign('place_kv', $place_kv);
        }

        $this->display();
    }

    /**
     *
     * @param $actid
     * @param $id
     */
    public function ticketedit($actid, $id)
    {
        $foodType = M('school_course');
        $data = $foodType->find($actid);

        $this->assign('data', $data);

        $foodType = M('activity_place');
        $ticket_data = $foodType->find($id);

        $this->assign('ticket_data', $ticket_data);

        $this->display();
    }


    /**
     * 保存分会场配置的内容
     *
     * @param $actid
     * @param $id
     */
    public function save_ticketedit($actid, $id)
    {
        $is_free = I('post.is_free');
        $type = I('post.type');
        $price = I('post.price');
        $total_number = I('post.total_number');
        $limit_number = I('post.limit_number');
        $sign_start_time = I('post.sign_start_time');
        $sign_end_time = I('post.sign_end_time');
        $is_need_audit = I('post.is_need_audit');
        $can_buy_more = 0;
        if ($type == 4) {
            $can_buy_more = 1;
        }
        $can_offline_user_buy = I('post.can_offline_user_buy');
        $can_temp_user_buy = I('post.can_temp_user_buy');
        $can_guest_user_buy = I('post.can_guest_user_buy');
        $can_online_user_buy = I('post.can_online_user_buy');
        $address = I('post.address');
        $sign_start_time = strtotime($sign_start_time);
        $sign_end_time = strtotime($sign_end_time);
        if ($sign_start_time > $sign_end_time) {
            $this->error('结束时间不能小于开始时间');
        }

        if (empty($price)) {
            $price = 0;
        }
        if (empty($total_number)) {
            $total_number = 0;
        }
        if (empty($limit_number)) {
            $limit_number = 0;
        }

        $data = array(
            'is_free' => $is_free,
            'type' => $type,
            'price' => $price,
            'total_number' => $total_number,
            'limit_number' => $limit_number,
            'sign_start_time' => $sign_start_time,
            'sign_end_time' => $sign_end_time,
            'is_need_audit' => $is_need_audit,
            'can_buy_more' => $can_buy_more,
            'can_offline_user_buy' => $can_offline_user_buy,
            'can_online_user_buy' => $can_online_user_buy,
            'can_guest_user_buy' => $can_guest_user_buy,
            'can_temp_user_buy' => $can_temp_user_buy,
            'address'=>$address
        );

        $obj_act_p = M('activity_place');
        $ret = $obj_act_p->where(array('id' => $id))->save($data);

        if (!$ret) {
            \Think\Log::record("update activity_place error, sql:" . $obj_act_p->getLastSql() . " ERR:" . $obj_act_p->getDbError(), 'ERR');
        }

        if ($ret !== false) {
            $this->success('修改成功', "/Admin/activity/manage/id/{$actid}");
        } else {
            $this->error('修改失败', "/Admin/activity/manage/id/{$actid}");
        }

    }

    /**
     * 添加新用户
     *
     * @param $course_id
     */
    public function useradd($course_id)
    {
        $foodType = M('school_course');
        $data = $foodType->where(array('id' => $course_id))->find();
        $this->assign('data', $data);
        $this->assign('id', $course_id);

        $cur_time = time();

        if ($_POST) {
            //查找student_course里面对应的student_id
            $mobile_phone = I('post.mobile_phone');
            if (empty($mobile_phone)) {
                $this->error('手机号为空');
            }
            $true_name = I('post.true_name');
            if (empty($true_name)) {
                $this->error('姓名为空');
            }
            $student_id = M('student')->where(array('mobile_phone' => $mobile_phone))->getField('id');
            if (empty($student_id)) {
                $new_stu_data = array();
                $new_stu_data['true_name'] = $true_name;
                $new_stu_data['user_name'] = $true_name;
                $new_stu_data['mobile_phone'] = $mobile_phone;
                $new_stu_data['student_type'] = '非会员';
                $new_stu_data['time'] = time();

                //if (empty($student_info)) {
                $student_id = M('student')->add($new_stu_data);
                if (empty($student_id)) {
                    $this->error('新增用户记录出错');
                }
            }

            $activity_place_id = I('post.activity_place_id');
            if (empty($activity_place_id)) {
                $this->error('请选择分会场');
            }

            $obj_place = M('activity_place');
            $see_type = $obj_place->where(array('id' => $activity_place_id))->getField('name');

            $obj_sc = M('student_course');
            $cond = array(
                'school_course_id' => $course_id,
                'student_id' => $student_id,
                'activity_place_id' => $activity_place_id
            );
            $result = $obj_sc->where($cond)->find();

            D()->startTrans();

            if (empty($result)) {
                // insert student course sign record
                $data = array(
                    'school_course_id' => $course_id,
                    'student_id' => $student_id,
                    'activity_place_id' => $activity_place_id,
                    'time' => $cur_time,
                    'update_time' => $cur_time,
                    'status' => 1,
                    'see_type' => $see_type,
                    'auth_type' => '有权限',
                    'number' => 1,
                    'is_check' => 1,
                    'pay_status' => $_POST['pay'] ? 1 : 0,
                );

                $ret = $obj_sc->add($data);
            } else {
                $ret = $obj_sc->where($cond)->save(array(
                        'status' => 1,
                        'pay_status' => $_POST['pay'] ? 1 : 0,
                        'update_time' => $cur_time,)
                );
            }
            if (!$ret) {
                D()->rollback();
                $this->error('添加失败');
            }

            //座位号
            if ($_POST['seat']) {
                $obj_seat = M('student_course_seat');
                $cond = array(
                    'course_id' => $course_id,
                    'student_id' => $student_id,
                    'activity_place_id' => $activity_place_id
                );

                $results = $obj_seat->where($cond)->find();
                if (empty($results)) {
                    $obj_seat->student_id = $student_id;
                    $obj_seat->course_id = $course_id;
                    $obj_seat->activity_place_id = $activity_place_id;
                    $obj_seat->seat_address = $_POST['seat'];
                    $obj_seat->time = $cur_time;

                    $ret = $obj_seat->add();
                } else {
                    $ret = $obj_seat->where($cond)->save(array('seat_address' => $_POST['seat'], 'time' => $cur_time));
                }

                if (!$ret) {
                    D()->rollback();
                    $this->error('添加失败');
                }
            }

            //直播码
            if ($_POST['fcode']) {
                $obj_fcode = M('student_course_fcode');
                $cond = array(
                    'course_id' => $course_id,
                    'student_id' => $student_id,
                );

                $ookj = $obj_fcode->where($cond)->find();
                if (empty($ookj)) {
                    $obj_fcode->student_id = $student_id;
                    $obj_fcode->course_id = $course_id;
                    $obj_fcode->f_code = $_POST['fcode'];
                    $obj_fcode->admin_id = 3;
                    $obj_fcode->time = $cur_time;
                    $ret = $obj_fcode->add();
                } else {
                    $ret = $obj_seat->where($cond)->save(array('f_code' => $_POST['fcode'], 'time' => $cur_time));
                }

                if (!$ret) {
                    D()->rollback();
                    $this->error('添加失败');
                }
            }

            //是否签到
            if ($_POST['openstyle']) {
                $obj_sign = M('student_course_sign');

                $cond = array(
                    'course_id' => $course_id,
                    'student_id' => $student_id,
                    'activity_place_id' => $activity_place_id
                );
                $ookjs = $obj_sign->where($cond)->find();

                if (!empty($ookjs)) {
                    if ($_POST['openstyle'] == 0) {
                        $ret = $obj_sign->where(array('sign_id' => $ookjs['sign_id']))->delete();
                    } else {
                        $ret = true;
                    }
                } else {
                    $obj_sign->course_id = $course_id;
                    $obj_sign->activity_place_id = 0;
                    $obj_sign->student_id = $student_id;
                    $obj_sign->time = $cur_time;

                    $ret = $obj_sign->add();
                }

                if (!$ret) {
                    D()->rollback();
                    $this->error('添加失败');
                }
            }

            D()->commit();
            $this->success('添加成功', U("Admin/Activity/studentList/id/{$course_id}"));
        } else {
            $obj_place = M('activity_place');
            //获取所有的类型
            $ret_placeAll = $obj_place->where(array('activity_id' => $course_id))->select();
            $this->assign('placeAll', $ret_placeAll);
        }

        $this->display();
    }// end func user add

    /**
     * 编辑用户报名，签到，座位信息
     *
     * @param $id
     * @param $course_id
     */
    public function useredit($id, $course_id)
    {
        header("Content-type: text/html; charset=utf-8");

        $foodType = M('school_course');
        $data = $foodType->where(array('id' => $course_id))->find();
        $this->assign('data', $data);

        $this->assign('sc_id', $id);
        $this->assign('id', $course_id);

        $cur_time = time();

        if ($_POST) {
            $student_id = I('post.student_id');
            if (empty($student_id)) {
                $this->error('提交数据错误');
            }

            $activity_place_id = I('post.activity_place_id');
            if (empty($activity_place_id)) {
                $activity_place_id = 0;
            }

            D()->startTrans();

            //是否支付
            $student = M('student');
            $student->create();
            $student_info = $student->find($student_id);

            $studentc = M('student_course');

            $studentcd = array();
            $studentcd['pay_status'] = $_POST['pay'];
            $studentcd['update_time'] = $cur_time;
            $ret = $studentc->where(array('id' => $id))->save($studentcd);
            if (!$ret) {
                D()->rollback();
                $this->error('编辑失败' . __LINE__);
            }

            //签到编辑
            $obj_sign = M('student_course_sign');
            $obj_sign->create();

            $cond = array(
                'course_id' => $course_id,
                'activity_place_id' => $activity_place_id,
                'student_id' => $student_info['id'],
            );
            $jjk = $obj_sign->where($cond)->find();
            if ($_POST['openstyle'] == 1) {
                if (empty($jjk)) {
                    $obj_sign->course_id = $course_id;
                    $obj_sign->activity_place_id = $activity_place_id;
                    $obj_sign->student_id = $student_info['id'];
                    $obj_sign->time = time();

                    $ret = $obj_sign->add();
                }
            } else {
                $ret = $obj_sign->where(array('sign_id' => $jjk['sign_id'], 'student_id' => $student_info['id']))
                    ->delete();
            }

            if (!$ret) {
                D()->rollback();
                $this->error('编辑失败' . __LINE__);
            }

            //编辑座位
            $obj_seat = M('student_course_seat');
            $obj_seat->create();

            $cond = array(
                'course_id' => $course_id,
                'activity_place_id' => $activity_place_id,
                'student_id' => $student_info['id'],
            );

            $ook = $obj_seat->where($cond)->find();
            if (empty($ook)) {
                $obj_seat->student_id = $student_info['id'];
                $obj_seat->course_id = $course_id;
                $obj_seat->activity_place_id = $activity_place_id;
                $obj_seat->seat_address = $_POST['seat'];
                $obj_seat->time = $cur_time;

                $ret = $obj_seat->add();
            } else {
                $obj_seath = M('student_course_seat');

//					$obj_seath->student_course_seat_id = $ook['student_course_seat_id'];
//					$obj_seath->student_id = $student_info['id'];
//					$obj_seath->course_id = $ook['course_id'];
//					$obj_seath->activity_place_id = $ook['activity_place_id'];
                $obj_seath->seat_address = $_POST['seat'];
//					$obj_seath->time = $ook['time'];
//					$obj_seath->admin_id = $ook['admin_id'];
                $obj_seath->update_time = $cur_time;

                $ret = $obj_seath->where(array('student_course_seat_id' => $ook['student_course_seat_id']))
                    ->save();
            }

            if (!$ret) {
                D()->rollback();
                $this->error('编辑失败' . __LINE__);
            }


            //编辑直播码
            $obj_fcode = M('student_course_fcode');
            $cond = array(
                'course_id' => $course_id,
                'student_id' => $student_info['id'],
            );

            $ookj = $obj_fcode->where($cond)->find();
            if (empty($ookj)) {
                $obj_fcode->student_id = $student_info['id'];
                $obj_fcode->course_id = $course_id;
                $obj_fcode->f_code = $_POST['fcode'];
                $obj_fcode->admin_id = 3;
                $obj_fcode->time = time();
                $ret = $obj_fcode->add();
            } else {
                $obj_fcode->id = $ookj['id'];
                $obj_fcode->student_id = $student_info['id'];
                $obj_fcode->course_id = $course_id;
                $obj_fcode->f_code = $_POST['fcode'];
                $obj_fcode->time = $ookj['time'];
                $obj_fcode->admin_id = $ookj['admin_id'];
                $obj_fcode->update_time = $cur_time;

                $ret = $obj_fcode->where('id=' . $ookj['id'])->save();
            }

            if (!$ret) {
                D()->rollback();
                $this->error('编辑失败' . __LINE__);
            }

            D()->commit();

            $this->success('编辑成功', "/Admin/activity/useredit/id/{$id}/course_id/{$course_id}");
        } else {    // display info to edit
            $foodType = M('student_course');
            $sign_up_data = $foodType->find($id);

            $student = M('student');
            $student_info = $student->find($sign_up_data['student_id']);

            //查看是否签到
            $obj_sign = M('student_course_sign');
            $cond = array(
                'student_id' => $sign_up_data['student_id'],
                'course_id' => $course_id,
                'activity_place_id' => $sign_up_data['activity_place_id']
            );
            $ret_sign = $obj_sign->where($cond)->find();


            //获取座位
            $obj_seat = M('student_course_seat');
            $cond = array(
                'course_id' => $course_id,
                'activity_place_id' => $sign_up_data['activity_place_id'],
                'student_id' => $student_info['id'],
            );
            $ret_seat = $obj_seat->where($cond)->find();

            //获取直播码
            $obj_fcode = M('student_course_fcode');
            $cond = array(
                'course_id' => $course_id,
                'student_id' => $student_info['id'],
            );
            $ret_fcode = $obj_fcode->where($cond)->find();

            $obj_place = M('activity_place');

            //获取所有分会场的类型
            $ret_placeAll = $obj_place->where(array('activity_id' => $course_id))->select();
            $this->assign('placeAll', $ret_placeAll);

            $ret_place = $obj_place->where('id=' . $sign_up_data['activity_place_id'])->find();
            $sign_up_data['seat'] = $ret_seat['seat_address'];
            if ($ret_sign) {
                $sign_up_data['is_sign'] = 1;
            } else {
                $sign_up_data['is_sign'] = 0;
            }

            $sign_up_data['true_name'] = $student_info['true_name'];
            $sign_up_data['mobile_phone'] = $student_info['mobile_phone'];
            $sign_up_data['school_student_number'] = $student_info['school_student_number'];
            $sign_up_data['fcode'] = $ret_fcode['f_code'];

            $sign_up_data['place'] = $ret_place['id'];
            $sign_up_data['placename'] = $ret_place['name'];

            $this->assign('sign_up_data', $sign_up_data);
        }

        $this->display();
    }

    /**
     * search or list activity sign up students
     *
     * @param $id
     */
    public function studentList($id = 0)
    {
        if ($id == 0) {
            $this->error('请创建活动', '/Admin/activity/editactivity');
        }

        $this->assign("id", $id);

        $foodType = M('school_course');
        $data = $foodType->find($id);
        $this->assign('data', $data);

        $place_select = A('GetSelect')->getDtoS('activity_place', array('activity_id' => $id, 'is_use' => 1), 'type ASC', 'id', 'name', $data['id'], 'activity_place_id', array(0, '请选择类型'));
        $this->assign('place_select', $place_select);

        //判断搜索的条件
        if ($_POST['is_ask_for_leave']=='1') {
//            echo "aaaa";
            if (!empty($_POST['activity_place_id'])) {
                $cond = array(
                    'c.school_course_id' => $id,
                    'c.activity_place_id' => $_POST['activity_place_id'],
                    'status' => 2,
                );
            } else {
                $cond = array(
                    'c.school_course_id' => $id,
                    'status' =>2,
                );
            }
        } else {


            //is_ask_for_leave为空和0的时候，都到了这里
            if (!empty($_POST['activity_place_id'])) {
                $cond = array(
                    'c.activity_place_id' => $_POST['activity_place_id'],
                    'c.school_course_id' => $id,
                );
                if (!empty($_POST['name'])) {
                    $_POST['name'] = trim($_POST['name']);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'c.activity_place_id' => $_POST['activity_place_id'],
                        'true_name' => $_POST['name'],
                    );

                } else if (!empty($_POST['mobile_phone'])) {
                    $_POST['mobile_phone'] = trim($_POST['mobile_phone']);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'c.activity_place_id' => $_POST['activity_place_id'],
                        'mobile_phone' => $_POST['mobile_phone'],
                    );

                } else if (!empty($_POST['member_number'])) {
                    $_POST['member_number'] = trim($_POST['member_number']);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'c.activity_place_id' => $_POST['activity_place_id'],
                        'school_student_number' => $_POST['member_number'],
                    );

                }
            } else {
                if (!empty($_POST['name'])) {
                    $_POST['name'] = trim($_POST['name']);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'true_name' => $_POST['name'],
                    );

                } else if (!empty($_POST['mobile_phone'])) {
                    $_POST['mobile_phone'] = trim($_POST['mobile_phone']);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'mobile_phone' => $_POST['mobile_phone'],
                    );

                } else if (!empty($_POST['member_number'])) {
                    $_POST['member_number'] = trim($_POST['member_number']);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'school_student_number' => $_POST['member_number'],
                    );

                }

            }
            if ( $_POST['is_ask_for_leave']=='0')
            {
                $cond['status']=1;

            }

        }

        if (empty($cond['c.school_course_id'])) {
            $cond['c.school_course_id'] = $id;
        }

        $cond['c.status'] = array('gt', 0);

        // salty 2016-07-19 23:33:47 不要把没支付成功的展示出来
        $cond['c.pay_status'] = array('gt', 0);

        $db_prefix = GetDbPrefix();
        $field = 'c.id,c.msg,t.true_name,t.mobile_phone,t.school_student_number,t.student_email,t.company_name,t.company_vocation_id,t.company_position_id,c.time,c.status,c.student_id,c.pay_status,c.activity_place_id';
        $User = M('student_course');
        $count = $User->table("{$db_prefix}student_course c")
            ->join("left join {$db_prefix}student t on(c.student_id=t.id)")
            ->field($field)->where($cond)->count();

        $Page = new \Think\Page($count, 50);
        $Page->setConfig('theme', '%HEADER% %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%');
        $show = $Page->show();

        $user_list = $User->table("{$db_prefix}student_course c")
            ->join("left join {$db_prefix}student t on(c.student_id=t.id)")
            ->field($field)->where($cond)->order('id desc')->limit($Page->firstRow . ',' . $Page->listRows)->select();

        $obj_sign = M('student_course_sign');
        $obj_seat = M('student_course_seat');
        $obj_fcode = M('student_course_fcode');
        $obj_place = M('activity_place');
        $obj_stu_del = M('student_deleted');

        foreach ($user_list as $key => $value) {
            $cond = array(
                'course_id' => $id,
                //'activity_place_id' => $value['activity_place_id'],
                'student_id' => $value['student_id'],
            );
            $user_list[$key]['is_sign'] = $obj_sign->where($cond)->find();
            if ($user_list[$key]['is_sign']) {
                $user_list[$key]['is_sign'] = 1;
            } else {
                $user_list[$key]['is_sign'] = 0;
            }

            $cond = array(
                'course_id' => $id,
                'activity_place_id' => array('in', array(0, $value['activity_place_id'])),
                'student_id' => $value['student_id'],
            );
            $user_list[$key]['seat_address'] = $obj_seat->where($cond)->order('activity_place_id DESC')
                ->getField('seat_address');

            $user_list[$key]['f_code'] = $obj_fcode->where($cond)->getField('f_code');

            if (empty($value['mobile_phone'])) {
                $tmp_field = 'true_name,mobile_phone,school_student_number,student_email,company_name,
				company_vocation_id,company_position_id';
                $deleted_user_info = $obj_stu_del->field($tmp_field)
                    ->where(array('student_id' => $value['student_id']))
                    ->find();

                $user_list[$key]['true_name'] = $deleted_user_info['true_name'] ? $deleted_user_info['true_name']
                    : $value['true_name'];
                $user_list[$key]['mobile_phone'] = $deleted_user_info['mobile_phone'] ? $deleted_user_info['mobile_phone']
                    : $value['mobile_phone'];
                $user_list[$key]['school_student_number'] = $deleted_user_info['school_student_number'] ? $deleted_user_info['school_student_number']
                    : $value['school_student_number'];
                $user_list[$key]['student_email'] = $deleted_user_info['student_email'] ? $deleted_user_info['student_email']
                    : $value['student_email'];

                $user_list[$key]['company_name'] = $deleted_user_info['company_name'] ? $deleted_user_info['company_name']
                    : $value['company_name'];
                $user_list[$key]['company_vocation_id'] = $deleted_user_info['company_vocation_id'] ? $deleted_user_info['company_vocation_id']
                    : $value['company_vocation_id'];
                $user_list[$key]['company_position_id'] = $deleted_user_info['company_position_id'] ? $deleted_user_info['company_position_id']
                    : $value['company_position_id'];
            }
        }

        session('listcard', $user_list);
        $this->assign('user_list', $user_list);
        $this->assign('page', $show);

        $vocation_list = M('student_vocation')->limit(300)->select();
        $position_list = M('student_position')->limit(300)->select();
        foreach ($vocation_list as $value) {
            $vocation_kv[$value['student_vocation_id']] = $value['student_vocation_name'];
        }
        foreach ($position_list as $value) {
            $position_kv[$value['student_position_id']] = $value['student_position_name'];
        }

        $this->assign('vocation_kv', $vocation_kv);
        $this->assign('position_kv', $position_kv);

        $place_list = $obj_place->field('id,name')->where(array('activity_id' => $id))->select();
        foreach ($place_list as $value) {
            $place_kv[$value['id']] = $value['name'];
        }

        $this->assign('place_kv', $place_kv);

        $this->assign('post', $_POST);

        $place_id = $_POST['activity_place_id'] ? $_POST['activity_place_id'] : 0;
        $name = $_POST['name'] ? $_POST['name'] : 0;
        $mobile_phone = $_POST['mobile_phone'] ? $_POST['mobile_phone'] : 0;
        $member_number = $_POST['member_number'] ? $_POST['member_number'] : 0;
        $sign_status = $_POST['is_signed'] ? $_POST['is_signed'] : 'x';
        $ask_for_leave = $_POST['is_ask_for_leave'] ? $_POST['is_ask_for_leave'] : '0';

        $this->assign('place_id', $place_id);
        $this->assign('name', $name);
        $this->assign('mobile_phone', $mobile_phone);
        $this->assign('member_number', $member_number);
        $this->assign('sign_status', $sign_status);
        $this->assign('ask_for_leave', $ask_for_leave);

        $this->display();
    }

    //导出数据
    public function export_all($id)
    {
        $this->export_search($id);
    }

    /**
     * 导出搜索的数据
     *
     * @param $id
     * @param int $place_id
     * @param string $name
     * @param string $mobile_phone
     * @param string $mobile_phone
     * @param string $sign
     * @param string $ask_for_leave
     */
    public function export_search($id, $place_id = 0, $name = '', $mobile_phone = '', $member_number = '',
                                  $sign = '', $ask_for_leave = '')
    {
        set_time_limit(3600);

        //判断搜索的条件
        if ($ask_for_leave=='1') {
            //是否请假为是
            if (!empty($place_id)) {
                $cond = array(
                    'c.school_course_id' => $id,
                    'c.activity_place_id' => $place_id,
                    'status' => 2,
                );
            } else {
                $cond = array(
                    'c.school_course_id' => $id,
                    'status' => 2,
                );
            }
        } else {
//            是否请假为否或者空没选
            if (!empty($place_id)) {
                $cond = array(
                    'c.activity_place_id' => $place_id,
                    'c.school_course_id' => $id,
                );
                if (!empty($name)) {
                    $name = trim($name);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'c.activity_place_id' => $place_id,
                        'true_name' => $name,
                    );

                } else if (!empty($mobile_phone)) {
                    $mobile_phone = trim($mobile_phone);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'c.activity_place_id' => $place_id,
                        'mobile_phone' => $mobile_phone,
                    );

                } else if (!empty($member_number)) {
                    $member_number = trim($member_number);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'c.activity_place_id' => $place_id,
                        'school_student_number' => $member_number,
                    );

                }
            } else {
                if (!empty($name)) {
                    $name = trim($name);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'true_name' => $name,
                    );

                } else if (!empty($mobile_phone)) {
                    $mobile_phone = trim($mobile_phone);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'mobile_phone' => $mobile_phone,
                    );

                } else if (!empty($member_number)) {
                    $member_number = trim($member_number);
                    $cond = array(
                        'c.school_course_id' => $id,
                        'school_student_number' => $member_number,
                    );

                }

            }
            if ( $_POST['is_ask_for_leave']=='0')
            {
                $cond['status']=1;

            }
        }

        if (empty($cond['c.school_course_id'])) {
            $cond['c.school_course_id'] = $id;
        }

        $cond['c.status'] = array('gt', 0);
        $cond['c.pay_status'] = 1;


        $db_prefix = GetDbPrefix();
        $field = 'c.id,t.true_name,t.mobile_phone,t.school_student_number,t.student_email,t.company_name,t.company_vocation_id,t.company_position_id,c.time,c.status,c.student_id,c.pay_status,c.activity_place_id';
        $User = M('student_course');

        $user_list = $User->table("{$db_prefix}student_course c")
            ->join("left join {$db_prefix}student t on(c.student_id=t.id)")
            ->field($field)->where($cond)->order('id desc')->select();

        $obj_sign = M('student_course_sign');
        $obj_seat = M('student_course_seat');
        $obj_fcode = M('student_course_fcode');
        $obj_place = M('activity_place');
        $obj_stu_del = M('student_deleted');

        foreach ($user_list as $key => $value) {
            if (empty($value['activity_place_id'])) {
                $user_list[$key]['activity_place_name'] = '主会场';
            } else {
                $user_list[$key]['activity_place_name'] = $obj_place->where(array('id' => $value['activity_place_id']))->getField('name');
            }

            $cond = array(
                'course_id' => $id,
                //'activity_place_id' => $value['activity_place_id'],
                'student_id' => $value['student_id'],
            );
            $user_list[$key]['is_sign'] = $obj_sign->where($cond)->find();
            if ($user_list[$key]['is_sign']) {
                $user_list[$key]['is_sign'] = 1;
            } else {
                $user_list[$key]['is_sign'] = 0;
            }

            $cond = array(
                'course_id' => $id,
                'activity_place_id' => array('in', array(0, $value['activity_place_id'])),
                'student_id' => $value['student_id'],
            );
            $user_list[$key]['seat_address'] = $obj_seat->where($cond)->order('activity_place_id DESC')
                ->getField('seat_address');

            $user_list[$key]['f_code'] = $obj_fcode->where($cond)->getField('f_code');

            if (empty($value['mobile_phone'])) {
                $tmp_field = 'true_name,mobile_phone,school_student_number,student_email,company_name,
					company_vocation_id,company_position_id';
                $deleted_user_info = $obj_stu_del->field($tmp_field)
                    ->where(array('student_id' => $value['student_id']))
                    ->find();

                $user_list[$key]['true_name'] = $deleted_user_info['true_name'] ? $deleted_user_info['true_name']
                    : $value['true_name'];
                $user_list[$key]['mobile_phone'] = $deleted_user_info['mobile_phone'] ? $deleted_user_info['mobile_phone']
                    : $value['mobile_phone'];
                $user_list[$key]['school_student_number'] = $deleted_user_info['school_student_number'] ? $deleted_user_info['school_student_number']
                    : $value['school_student_number'];
                $user_list[$key]['student_email'] = $deleted_user_info['student_email'] ? $deleted_user_info['student_email']
                    : $value['student_email'];

                $user_list[$key]['company_name'] = $deleted_user_info['company_name'] ? $deleted_user_info['company_name']
                    : $value['company_name'];
                $user_list[$key]['company_vocation_id'] = $deleted_user_info['company_vocation_id'] ? $deleted_user_info['company_vocation_id']
                    : $value['company_vocation_id'];
                $user_list[$key]['company_position_id'] = $deleted_user_info['company_position_id'] ? $deleted_user_info['company_position_id']
                    : $value['company_position_id'];
            }
        }

        $data = array();
        foreach ($user_list as $k => $goods_info) {
            if ($sign === 0 || $sign === '0') {
                if ($goods_info['is_sign']) {
                    continue;
                }
            } elseif ($sign === 1 || $sign === '1') {
                if (!$goods_info['is_sign']) {
                    continue;
                }
            }

            $tmp_data = array();
            $tmp_data['true_name'] = $goods_info['true_name'];
            $tmp_data['mobile_phone'] = $goods_info['mobile_phone'];
            $tmp_data['school_student_number'] = $goods_info['school_student_number'];
            $tmp_data['student_email'] = $goods_info['student_email'];
            $tmp_data['company_name'] = $goods_info['company_name'];
            $tmp_data['company_vocation_id'] = M('student_vocation')->where(array('student_vocation_id' => $goods_info['company_vocation_id']))->getField('student_vocation_name');
            $tmp_data['company_position_id'] = M('student_position')->where(array('student_position_id' => $goods_info['company_position_id']))->getField('student_position_name');
            if ($goods_info['is_sign'] == "1") {
                $tmp_data['is_sign'] = "是";
            } else {
                $tmp_data['is_sign'] = "否";
            }
            if ($goods_info['pay_status'] == "1") {
                $tmp_data['pay_status'] = "是";
            } else {
                $tmp_data['pay_status'] = "否";
            }
            $tmp_data['seat_address'] = $goods_info['seat_address'];
            $tmp_data['f_code'] = $goods_info['f_code'];
            $tmp_data['time'] = date('Y-m-d H:i:s', $goods_info['time']);
            if ($goods_info['status'] == 1) {
                $tmp_data['status'] = "正常";
            } else {
                $tmp_data['status'] = "请假";
            }
            $tmp_data['activity_place_name'] = $goods_info['activity_place_name'];

            $data[] = $tmp_data;
        }

        $filename = "课程报名信息";

        $xlsCell = array(
            array('true_name', '姓名', 'A', '20'),
            array('mobile_phone', '手机', 'B', '15'),
            array('school_student_number', '学生编号', 'C', '10'),
            array('student_email', '邮箱', 'D', '30'),
            array('company_name', '公司', 'E', '30'),
            array('company_vocation_id', '职位', 'F', '20'),
            array('company_position_id', '行业', 'G', '20'),
            array('is_sign', '是否签到', 'H', '5'),
            array('pay_status', '是否支付', 'I', '5'),
            array('seat_address', '座位号', 'J', '10'),
            array('f_code', '直播码', 'K', '20'),
            array('time', '报名时间', 'L', '15'),
            array('status', '请假状态', 'M', '10'),
            array('activity_place_name', '会场类型', 'N', '30'),
        );

        A('MyExcel')->exportExcel($filename, $xlsCell, $data);
    }

    /**
     * 同步学生报名信息
     *
     * @param int $id
     */
    public function syncstudent($id = 0)
    {
        if (empty($id)) {
            $this->error('输入出错', U('Admin/Activity/activity'));
        }

        $ret = false;

        $relate_course_id = M('school_course')->where(array('id' => $id))->getField('relate_course_id');
        if (empty($relate_course_id)) {
            $this->success('未关联课程'); //, "/Admin/activity/manage/id/{$actid}"
        }

        $cur_time = time();

        $obj_act_p = M('activity_place');
        $main_place_id = $obj_act_p->where(array('activity_id' => $id, 'type' => 1))->getField('id');
        $online_place_id = $obj_act_p->where(array('activity_id' => $id, 'type' => 2))->getField('id');

        if (empty($main_place_id)) {
            $main_place_id = 0;
        }
        if (empty($online_place_id)) {
            $online_place_id = 0;
        }

        $obj_sc = M('student_course');
        $fields = 'school_course_id,activity_place_id,student_id,time,status,msg,see_type,is_reward_vip,
auth_type,auth_type_pay_money,number,is_check,pay_status,pay_status,pay_way,money,order_number,
trade_no,one_status';
        $sign_up_data = $obj_sc->field($fields)->where(array('school_course_id' => $relate_course_id))->select();

        foreach ($sign_up_data as $key => $value) {
            if ($value['see_type'] == '现场') {
                $value['activity_place_id'] = $main_place_id;
            } else {
                $value['activity_place_id'] = $online_place_id;
            }

            $cond = array(
                'school_course_id' => $id,
                'activity_place_id' => $value['activity_place_id'],
                'student_id' => $value['student_id'],
            );

            $sign_rcd = $obj_sc->where($cond)->find();
            if (empty($sign_rcd)) {
                $value['school_course_id'] = $id;
                $value['update_time'] = $cur_time;

                $obj_sc->add($value);
            }
        }

        if (1) {
            $this->success('同步成功'); //, "/Admin/activity/manage/id/{$actid}"
        } else {
            $this->error('同步失败');   // , "/Admin/activity/manage/id/{$actid}"
        }
    }

    public function synccourseinfo()
    {
        $ret = true;
        if ($ret !== false) {
            $this->success('同步成功'); // , "/Admin/activity/manage/id/{$actid}"
        } else {
            $this->error('同步失败');   // , "/Admin/activity/manage/id/{$actid}"
        }
    }


    public function delete_status()
    {
        $student_course = M('student_course');
        $student_course->status = 2;
        $result = $student_course->where('id=' . $_GET['id'])->save();
        if ($result) {
            $this->success('请假成功');
        } else {
            $this->success('不允许请假');
        }


    }

    /**
     * 删除报名和签到记录
     */
    public function statusdelete()
    {
        $student_course = M('student_course');
        $sc_info = $student_course->find($_GET['id']);
        if (empty($sc_info) || empty($sc_info['school_course_id']) || empty($sc_info['student_id'])) {
            $this->error('删除失败');
        }

        $cond = array(
            'course_id' => $sc_info['school_course_id'],
            'student_id' => $sc_info['student_id'],
        );

        // 删除签到
        $result = M('student_course_sign')->where($cond)->delete();

        // 删除f码

        // 删除座位

        $result = $student_course->where('id=' . $_GET['id'])->delete();

        if ($result) {
            $this->success('删除成功');
        } else {
            $this->success('不允许删除');
        }
    }

    public function pname()
    {
        $name = M('school_course');
        $pname = $name->where("name='" . $_POST['name'] . "'")->find();
        $share_url = $this->createRewardQRCodeimg($pname['id'], 0, $_POST['url']);
        echo $share_url;

    }

    private function createRewardQRCodeimg($course_id, $reward_id, $name)
    {

        $data = S_URL . '/Baozhu/ActivityDetail/indexPreview/activity_id/' . $course_id . '/teacher_id/0';
        $level = 'H';// 纠错级别：L、M、Q、H
        $size = 100;// 点的大小：1到10,用于手机端4就可以了
        $path = "./Public/" . $name . "/" . $reward_id . "/";
        $fileName = $path . $size . '.png';
        A('ChenImg')->mydir($path);
        $short_path = '/Public/' . $name . '/' . $reward_id . '/' . $size . '.png';
        $all_path = S_URL . $short_path;
        $logo = './Public/Bz/images/logo20160130.png';//准备好的logo图片
        //if(!is_file($fileName)){

        vendor("phpqrcode.phpqrcode");

        \QRcode::png($data, $fileName, $level, $size);
        if (is_file($logo)) {
            $QR = imagecreatefromstring(file_get_contents($all_path));
            $logo = imagecreatefromstring(file_get_contents($logo));
            $QR_width = imagesx($QR);//二维码图片宽度
            $QR_height = imagesy($QR);//二维码图片高度
            $logo_width = imagesx($logo);//logo图片宽度
            $logo_height = imagesy($logo);//logo图片高度
            $logo_qr_width = $QR_width / 5;
            $scale = $logo_width / $logo_qr_width;
            $logo_qr_height = $logo_height / $scale;
            $from_width = ($QR_width - $logo_qr_width) / 2;
            //重新组合图片并调整大小
            imagecopyresampled($QR, $logo, $from_width, $from_width, 0, 0, $logo_qr_width,
                $logo_qr_height, $logo_width, $logo_height);
        }

        //输出图片
        imagepng($QR, $fileName);
        //}
        return $short_path;
    }

}