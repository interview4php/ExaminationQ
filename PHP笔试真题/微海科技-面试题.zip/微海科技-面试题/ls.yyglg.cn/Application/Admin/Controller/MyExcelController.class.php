<?php
namespace Admin\Controller;
use Think\Controller;

class MyExcelController extends ExtendController {
   
    /**
     * 方法
     *
     **/
    function  index(){
		$this->display();
	}

	public function exportExcelRowByRow() {

	}

    public function exportExcel($expTitle,$expCellName,$expTableData){
		$xlsTitle = iconv('utf-8', 'gb2312', $expTitle);//文件名称
		$fileName = $xlsTitle.date('_Ymd_His');//or $xlsTitle 文件名称可根据自己情况设定
		$cellNum = count($expCellName);
		$dataNum = count($expTableData);

		vendor("PHPExcel.PHPExcel");
	   
		$objPHPExcel = new \PHPExcel();
		$cellName = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ');
		
		$objPHPExcel->getActiveSheet(0)->mergeCells('A1:'.$cellName[$cellNum-1].'1');//合并单元格

	    // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', $expTitle.'  Export time:'.date('Y-m-d H:i:s'));
		for($i=0;$i<$cellNum;$i++){
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($cellName[$i].'2', $expCellName[$i][1]); 
			$objPHPExcel->getActiveSheet()->getColumnDimension($expCellName[$i][2])->setWidth($expCellName[$i][3]);
		} 

		// Miscellaneous glyphs, UTF-8
		for($i=0;$i<$dataNum;$i++){
		  for($j=0;$j<$cellNum;$j++){
			$objPHPExcel->getActiveSheet(0)->setCellValue($cellName[$j].($i+3), $expTableData[$i][$expCellName[$j][0]]);
		  }             
		}  
		
		header('pragma:public');
		header('Content-type:application/vnd.ms-excel;charset=utf-8;name="'.$xlsTitle.'.xls"');
		header("Content-Disposition:attachment;filename=$fileName.xls");//attachment新窗口打印inline本窗口打印

	    $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
		$objWriter->save('php://output');

	    exit;
	}

	/**
	 *
	 * 导出学生预约列表（所有数据）
	 */
	function studentCourseList(){
		set_time_limit(1800);
		/**
		*		st_c  学生预约表（student_course） 
		*		st_ 学生表（student） 
		*		sc_c 学院课程表 （school_course_id）
		* 		sc_学校表（school）
		*/
		
		$school_name 	 = !empty($_GET['school_name'])?$_GET['school_name']:'all';
		$course_name 	 = !empty($_GET['course_name'])?$_GET['course_name']:'all';
		$course_address 	 = !empty($_GET['course_address'])?$_GET['course_address']:'all';
		$student_user_name 	 = !empty($_GET['student_user_name'])?$_GET['student_user_name']:'all';
		$student_mobile_phone 	 = !empty($_GET['student_mobile_phone'])?$_GET['student_mobile_phone']:'all';
		$student_status 	 = !empty($_GET['student_status'])?$_GET['student_status']:'all';
		$see_type 	 = !empty($_GET['see_type'])?$_GET['see_type']:'all';
		
		//所属学院
		if($school_name!='all'){
			$where['sc_c.school_id'] = $school_name;
		}
		//课题名字
		if($course_name!='all'){
			$where['sc_c.name'] = array('like','%'.trim($course_name).'%');
			$this->assign('course_name',$course_name);
		}
		//上课地点
		if($course_address!='all'){
			$where['sc_c.address'] = array('like','%'.trim($course_address).'%');
			$this->assign('course_address',$course_address);
		}
		//学生账号
		if($student_user_name!='all'){
			$where['st_.user_name'] = array('like','%'.trim($student_user_name).'%');
			$this->assign('student_user_name',$student_user_name);
		}
		//学生手机
		if($student_mobile_phone!='all'){
			$where['st_.mobile_phone'] = array('like','%'.trim($student_mobile_phone).'%');
			$this->assign('student_mobile_phone',$student_mobile_phone);
		}
		//状态
		if($student_status!='all'){
			$where['st_c.status'] = $student_status;
		}
		//预约类型
		if($see_type!='all'){
			$where['st_c.see_type'] = $see_type;
		}
		
		
		$xlsName  = "学生预约列表";
		$xlsCell  = array(
			array('school_name','学校名字','A', '15'),
			array('course_name','课程名字','B', '30'),
			array('course_address','上课地点','C', '10'),
			array('true_name','学生姓名','D', '15'),
			array('mobile_phone','学生手机','E', '15'),  
			array('time','报名时间','F', '25'),  
			array('status','学生状态','G', '10'),  
			array('msg','请假理由','H', '20'),  
			array('see_type','预约类型','I', '10')
		);
		
		$sc = D('student_course');
		$join = 'as st_c inner join '.C('DB_PREFIX').'student as st_ on st_c.student_id = st_.id left join '.C('DB_PREFIX').'school_course as sc_c on st_c.school_course_id = sc_c.id  left join '.C('DB_PREFIX').'school as sc_ on sc_c.school_id = sc_.id';
		
		$field = 'sc_.school_name,sc_c.name as course_name,sc_c.address as course_address,st_.user_name,st_.true_name,st_.mobile_phone,st_c.time,st_c.id,st_c.status,st_c.msg,st_c.see_type';
		$xlsData  = $sc->join($join)->field($field)->where($where)->select();
		
		foreach($xlsData as $k=>$v){
			$xlsData[$k]['time'] = chen_show_time($v['time']);
			$xlsData[$k]['status'] = chen_show_student_course_status($v['status']);
		}
		
		$this->exportExcel($xlsName,$xlsCell,$xlsData);
	}
	
	
	
	
	
	/**
	 *
	 * 导出学生F码（所有数据）
	 */
	function studentFcodeList(){
		set_time_limit(1800);
		/**
		*		this  学生预约表（student_course）
		*		st 学生表（student） 
		*		sc_c 学院课程表 （school_course_id）
		* 		st_f F码表（student_course_fcode）
		*/  
		$course_id = I('get.course');
		//查询课程信息
		$course_name = M('school_course')->where(array('id'=>$course_id))->getField('name');
		$xlsName  = "课程{$course_name}的学生F码";
		$xlsCell  = array(
			array('school_student_number','学生编号','A', '10'),
			array('true_name','学生姓名','B', '15'),
			array('mobile_phone','学生手机','C', '20'),  
			array('f_code','F码','D', '20'),  
			array('time','添加时间','E', '30'),  
		);
		
		$searchtype = I('get.searchtype');
		$search = trim(I('get.search'));
		$begin_time = !empty($_GET['begin_time']) ? $_GET['begin_time'] : 'all';
		$end_time = !empty($_GET['end_time']) ? $_GET['end_time'] : 'all';
		if ($searchtype && $search) {
			if ($searchtype != 'all') {
				if($searchtype=='fcode'){
					$where['this.f_code'] = array('like', '%' . $search . '%');
				}else{
					$where['st.'.$searchtype] = array('like', '%' . $search . '%');
				}
			} else {
				$whereor['st.true_name'] = array('like', '%' . $search . '%');
				$whereor['st.mobile_phone'] = array('like', '%' . $search . '%');
				$whereor['st.school_student_number'] = array('like', '%' . $search . '%');
				$whereor['this.f_code'] = array('like', '%' . $search . '%');
				$whereor['_logic'] = 'or';
				$where['_complex'] = $whereor;
			}
		}
		//时间区间查询
		if ($begin_time != 'all' && $begin_time != 'NaN' && $end_time != 'all' && $end_time != 'NaN') {
			$btime = getBeginTimeAndEndTime(chen_show_time($begin_time), chen_show_time($end_time));
			$where['this.time'] = array('between', $btime);
		}
		
		
		
		$sc = D('student_course_fcode');
		$join = 'as this inner join ' . C('DB_PREFIX') . 'student as st on this.student_id = st.id ';
		
		$where['this.course_id'] = $course_id;
		$field = 'st.school_student_number,st.true_name,st.mobile_phone,this.f_code,this.time';
		$xlsData = $sc->join($join)->field($field)->where($where)->select();
		foreach($xlsData as $k=>$v){
			$xlsData[$k]['time'] = chen_show_time($v['time']);
		}
		$this->exportExcel($xlsName,$xlsCell,$xlsData);
		 
	}

	/**
	 *
	 * 导出所有用户
	 */
	function studentStudentList(){
		set_time_limit(1800);
		$searchtype = I('get.searchtype');
		$search = trim(I('get.search'));
		$apply_type_id 	 = !empty($_GET['apply_type_id'])?$_GET['apply_type_id']:'all';

		if($searchtype && $search){
			if($searchtype != 'all'){
				$where[$searchtype] = array('like','%'.$search.'%');
			}else{
				$whereor['id']  = $search;
				$whereor['true_name']  = array('like','%'.$search.'%');
				$whereor['mobile_phone']  = array('like','%'.$search.'%');
				$whereor['school_student_number']  = array('like','%'.$search.'%');
				$whereor['_logic'] = 'or';
				$where['_complex'] = $whereor;
			}
		}

		//会员类型
		if($apply_type_id!='all'){
			$where['apply_type_id'] = $apply_type_id;
		}
	
		/**
		*		this  学院的学生表（student）
		*		st_a 入学类型（student_apply_type） 
		*/  
		$xlsName  = "入学学生";
		$xlsCell  = array(
			array('school_student_number','学生编号','A', '15'),
			array('student_apply_type_name','入学模式','B', '40'),
			array('true_name','姓名','C', '15'),
			array('mobile_phone','手机','D', '15'),
			array('time','入学时间','E', '25'),  
			array('end_time','有效期','F', '25'),  
			array('student_email','邮箱','G', '20'),  
			array('student_qq','QQ','H', '10'),  
			array('student_wx','微信号','I', '15'),  
			array('student_birthday','生日','J', '20'), 
			array('student_frozen_time','冻结时间','K', '20'), 
			array('student_invoice_title','冻结时间','L', '20'), 
			array('student_invoice_address','冻结时间','M', '20'), 
			array('student_address','客户详细地址','N', '20'), 
			array('company_name','公司名称','O', '20'), 
			array('company_address','公司地址','P', '20'), 
			array('company_tel','公司固话','Q', '20'), 
			array('company_fax','公司传真','R', '20'), 
			array('company_vocation_id','学生所属行业','S', '20'), 
			array('company_position_id','学生的职位','T', '20'), 
			array('recommend_from','推荐人/来源','U', '20'), 
			array('account_binding_wxid','绑定的微信ID','V', '20'), 
			array('is_disable','是否禁用','W', '20'),
			array('wx_nick_name','微信昵称','X', '20'),		//新增
			array('wx_province_name','省份','Y', '20'),		//新增
			array('wx_city_name','城市','Z', '20'),		//新增
			array('group_name','分组（多个空格分开）','AA', '30'),		//新增
			array('tag_name','标签（多个空格分开）','AB', '30'),		//新增
			array('exclusive_admin_name','专属管理员','AC', '20'),		//新增
			array('exclusive_admin_wechat','专属管理员微信号','AD', '20'),		//新增
		);
		
		$sc = D('student');
		$field = '*';
		
		$xlsData = $sc->field($field)->where($where)->limit(10000)->select();
		
		foreach($xlsData as $k=>$v){
			$xlsData[$k]['time'] = chen_show_time($v['time']);
			$xlsData[$k]['end_time'] = chen_show_time($v['end_time']);
			$xlsData[$k]['student_frozen_time'] = chen_show_time($v['student_frozen_time']);
			$xlsData[$k]['student_birthday'] = chen_show_time($v['student_birthday']);
			$xlsData[$k]['student_apply_type_name'] = chen_show_apply_type($v['apply_type_id']);
			$xlsData[$k]['is_disable'] = chen_is_disable($v['is_disable']);
			$xlsData[$k]['company_vocation_id'] = M('student_vocation')->where(array('student_vocation_id'=>$v['company_vocation_id']))->getField('student_vocation_name');
			$xlsData[$k]['company_position_id'] = M('student_position')->where(array('student_position_id'=>$v['company_position_id']))->getField('student_position_name');


			//新增2016-2-23
			$db_prefix = GetDbPrefix();
			$obj_stu_grp = M('student_group_list');
			$obj_stu_tag = M('student_tag_list');

			// 获取用户标签和分组
			$stu_grp_list = $obj_stu_grp->table("{$db_prefix}student_group_list l")
				->join("{$db_prefix}student_group g on(l.group_id=g.student_group_id)")
				->field('g.student_group_name')
				->where(array('l.student_id' => $v['id'], 'g.status' => 1))->select();

			$xlsData[$k]['group_name'] = '';
			foreach ($stu_grp_list as $gkey => $gvalue) {
				$xlsData[$k]['group_name'] .= $gvalue['student_group_name'] . ' ';
			}

			$stu_tag_list = $obj_stu_tag->table("{$db_prefix}student_tag_list l")
				->join("{$db_prefix}student_tag g on(l.tag_id=g.id)")
				->field('g.name')
				->where(array('l.student_id' => $v['id'], 'g.status' => 1))->select();

			$xlsData[$k]['tag_name'] = '';
			foreach ($stu_tag_list as $gkey => $gvalue) {
				$xlsData[$k]['tag_name'] .= $gvalue['name'] . ' ';
			}






		}

		$this->exportExcel($xlsName,$xlsCell,$xlsData);
	}
   
	/**
	 *
	 * 导出某个打赏的打赏对象
	 */
	function rewardTeacherOne(){
		set_time_limit(1800);
		//查询该打赏的信息
		$reward_id = I('get.rewardId');
		if(!$reward_id){
			die;
		}

		$system_r_field = 'name';
		$system_r_where['id'] = $reward_id;
		$system_r_data = M('system_reward')->field($system_r_field)->where($system_r_where)->find();
		$xlsName  = $system_r_data['name'].'打赏列表';
		$xlsCell  = array(
			array('teacher_name','老师名字','A', '20'),
			array('money','总金额','B', '10'),
			array('count','总次数','C', '10'),
			array('status','状态','D', '10'),
			array('time','添加时间','E', '20'),  
			array('update_time','更新时间','F', '20'),  
		);

		$sc = D('system_reward_teacher');
		$join = 'as this left join '.C('DB_PREFIX').'school_teacher as teacher on this.teacher_id = teacher.id ';
		$field = 'this.money,this.count,this.time,this.update_time,this.status,teacher.teacher_name';
		$where['system_reward_id'] = $reward_id;
		$xlsData = $sc->join($join)->field($field)->where($where)->select();
		foreach($xlsData as $k=>$v){
			$xlsData[$k]['time'] = chen_show_time($v['time']);
			$xlsData[$k]['update_time'] = chen_show_time($v['update_time']);
			$xlsData[$k]['status'] = chen_is_show($v['status']);
		}

		$this->exportExcel($xlsName,$xlsCell,$xlsData);
		 
	}
   
	
	/**
	 *
	 * 导出某个打赏的抽奖信息
	 */
	function rewardLuckDrawOne(){
		set_time_limit(1800);
		//查询该打赏的信息
		$reward_id = I('get.rewardId');
		if(!$reward_id){
			die;
		}
		$system_r_field = 'name';
		$system_r_where['id'] = $reward_id;
		$system_r_data = M('system_reward')->field($system_r_field)->where($system_r_where)->find();
		$xlsName  = $system_r_data['name'].'抽奖列表';
		$xlsCell  = array(
			array('draw_name','奖项名称','A', '20'),
			array('draw_description','奖项内容','B', '50'),
			array('draw_all_number','中奖名额','C', '10'),
			array('draw_use_number','已抽出数','D', '10'),
			array('draw_begin_time','开始时间','E', '20'),  
			array('draw_end_time','结束时间','F', '20'),  
			array('time','添加时间','G', '20'),  
		);
		$st = D('system_reward_luck_draw');
		$field = 'draw_name,draw_description,draw_all_number,draw_use_number,time,draw_begin_time,draw_end_time';
		$where['system_reward_id'] = $reward_id;
		$xlsData = $st->field($field)->where($where)->select();
		foreach($xlsData as $k=>$v){
			$xlsData[$k]['time'] = chen_show_time($v['time']);
			$xlsData[$k]['draw_begin_time'] = chen_show_time($v['draw_begin_time']);
			$xlsData[$k]['draw_end_time'] = chen_show_time($v['draw_end_time']);
		}
		$this->exportExcel($xlsName,$xlsCell,$xlsData);
		 
	}
   
	/**
	 *
	 * 导出某个打赏的中奖信息
	 */
	function rewardLuckDrawStudentOne(){
		set_time_limit(1800);
		//查询该打赏的信息
		$reward_id = I('get.rewardId');
		if(!$reward_id){
			die;
		}

		$system_r_field = 'name';
		$system_r_where['id'] = $reward_id;
		$system_r_data = M('system_reward')->field($system_r_field)->where($system_r_where)->find();
		$xlsName  = $system_r_data['name'].'中奖名单';
		$xlsCell  = array(
			array('draw_name','奖项名称','A', '20'),
			array('draw_description','奖项内容','B', '40'),
			array('student_true_name','中奖用户','C', '15'),
			array('student_mobile_phone','手机','D', '15'),
			array('time','中奖时间','E', '25'),  
			array('address','收货地址','F', '50'),  
			array('wl_number','物流单号','G', '25'),  
			array('wl_company','物流公司','H', '15'),  
			array('status','是否发货','I', '10'),  
		);

		$where['this.system_reward_id'] = $reward_id;
		$st = D('system_reward_luck_draw');
		$join = 'as this left join '.C('DB_PREFIX').'student_luck_draw as st_l on this.id = st_l.luck_draw_id ';
		$join .= 'left join '.C('DB_PREFIX').'student as st on st_l.student_id = st.id ';
		$field = 'this.draw_name,this.draw_description,st_l.wl_number,st_l.wl_company,st_l.address,st_l.status,st_l.time,st.true_name as student_true_name,st.mobile_phone as student_mobile_phone';
		$xlsData = $st->join($join)->field($field)->where($where)->select();
		foreach($xlsData as $k=>$v){
			$xlsData[$k]['time'] = chen_show_time($v['time']);
			$xlsData[$k]['status'] = chen_yes_or_no($v['status']);
		}

		$this->exportExcel($xlsName,$xlsCell,$xlsData);
		 
	}
	/**
	 *
	 * 导出打赏统计里面的打赏金额TOP排行榜数据
	 */
	function getRewardCountOrder(){
		set_time_limit(1800);
		//查询该打赏的信息
		$reward_id = I('get.reward_id');
		if(!$reward_id){
			die;
		}
		$system_r_field = 'name';
		$system_r_where['id'] = $reward_id;
		$system_r_data = M('system_reward')->field($system_r_field)->where($system_r_where)->find();
		$xlsName  = $system_r_data['name'].'打赏金额Top排行榜';
		$xlsCell  = array(
			array('mingci','名次','A', '10'),
			array('static_true_name','姓名','B', '20'),
			array('static_mobile_phone','手机','C', '20'),
			array('money','金额','D', '15'),
			array('reward_count','次数','E', '15'),  
		);
		$begin_time = I('get.begin_time');
		$end_time 	= I('get.end_time');
		$number 	= I('get.number');
		$reward_id 	= I('get.reward_id');

		$where['system_reward_id'] = $reward_id;
		$where['time'] = array('between',array($begin_time,$end_time));
		$sc = D('school_course_reward');
		$group = 'student_id';
		$order = 'money desc';
		$field = 'static_true_name,static_mobile_phone,sum(price) as money,count(reward_id) as reward_count';
		$xlsData = $sc->field($field)->where($where)->group($group)->order($order)->limit($number)->select();
		foreach($xlsData as $k=>$v){
			$xlsData[$k]['mingci'] = $k+1;
		}
		$this->exportExcel($xlsName,$xlsCell,$xlsData);
		 
	}
	
	
	
	
	/**
	 *
	 * 导出财务管理里面的记录
	 */
	function getStudentPayRecord(){
		set_time_limit(1800);

		$xlsName  = '用户交易记录';
		$xlsCell  = array(
			array('pay_number','商户订单号','A', '40'),
			array('transaction_id','支付订单号','B', '40'), 
			array('school_student_number','学生学号','C', '20'), 
			array('true_name','学生名字','D', '20'), 
			array('mobile_phone','学生手机','E', '20'), 
			array('pay_money','交易金额','F', '20'), 
			array('pay_status','交易方式','G', '20'), 
			array('pay_type','支付方式','H', '20'), 
			array('pay_time','交易时间','I', '20'), 
		);

		$begin_time 	 = !empty($_GET['begin_time'])?$_GET['begin_time']:'all';
		$end_time 	 = !empty($_GET['end_time'])?$_GET['end_time']:'all';
		$searchtype = I('get.searchtype');
		$search = trim(I('get.search'));
		
		$moneyone 	 = $_GET['moneyone'];
		$moneytwo 	 = $_GET['moneytwo'];

		//时间区间查询
		if($begin_time!='all' && $begin_time!='NaN' && $end_time!='all' && $end_time!='NaN'){
			$btime =getBeginTimeAndEndTime(chen_show_time($begin_time),chen_show_time($end_time));
			$where['this.pay_time']  = array('between',$btime);
			$this->assign('begin_time',$begin_time);
			$this->assign('end_time',$end_time);
		}

		if(($moneyone==='0' || !empty($moneyone)) && !empty($moneytwo)){
			$where['this.pay_money']  = array('between',array($moneyone,$moneytwo));
			$this->assign('moneyone',$moneyone);
			$this->assign('moneytwo',$moneytwo);
		}

		if($searchtype && $search){
			if($searchtype != 'all'){
				switch($searchtype){
					case 'pay_number':$wherefield = 'this.pay_number';
					case 'transaction_id':$wherefield = 'this.transaction_id';
					case 'pay_status':$wherefield = 'this.pay_status';
					case 'pay_type':$wherefield = 'this.pay_type';
					case 'true_name':$wherefield = 'st.true_name';
					case 'mobile_phone':$wherefield = 'st.mobile_phone';
					case 'school_student_number':$wherefield = 'st.school_student_number';
				}
				$where[$wherefield] = array('like','%'.$search.'%');
			}else{
				$whereor['this.pay_number']  = array('like','%'.$search.'%');
				$whereor['this.transaction_id']  = array('like','%'.$search.'%');
				$whereor['this.pay_status']  = array('like','%'.$search.'%');
				$whereor['this.pay_type']  = array('like','%'.$search.'%');
				
				$whereor['st.school_student_number']  = array('like','%'.$search.'%');
				$whereor['st.true_name']  = array('like','%'.$search.'%');
				$whereor['st.mobile_phone']  = array('like','%'.$search.'%');
				$whereor['_logic'] = 'or';
				$where['_complex'] = $whereor;	
			}
			$this->assign('searchtype',$searchtype);
			$this->assign('search',$search);
		}
	
		$sc = D('student_pay_record');
		$join = 'as this left join '.C('DB_PREFIX').'student as st on this.pay_student_id = st.id ';
		$field = 'this.pay_number,this.pay_money,this.pay_status,this.pay_info_id,this.pay_type,this.pay_time,st.true_name ,st.mobile_phone,st.school_student_number,this.transaction_id';
		$order = 'this.pay_id desc';
		$xlsData = $sc->join($join)->field($field)->where($where)->order($order)->select();
		foreach($xlsData as $k=>$v){
			$xlsData[$k]['pay_time'] = chen_show_time($v['pay_time']);
			$xlsData[$k]['transaction_id'] = ' '.$v['transaction_id'];
		}
		$this->exportExcel($xlsName,$xlsCell,$xlsData);
		 
	}
	
	
	
	
	
	
	/**
	* 到处打赏记录
	* 
	*/
	function getRewardRecord(){
		$xlsName  = '打赏记录';
		$xlsCell  = array(
			array('pay_number','商户订单号','A', '40'),
			array('transaction_id','支付订单号','B', '40'), 
			array('reward_static_true_name','名字','C', '20'), 
			array('reward_static_mobile_phone','手机','D', '20'), 
			array('reward_price','打赏金额','E', '15'), 
			array('teacher_id','老师编号','F', '15'), 
			array('teacher_name','老师名字','G', '20'), 
			array('time','打赏时间','H', '20'), 
			array('reward_static_msg','留言','I', '30'), 
		);
	
		$reward_id = I('get.reward_id');
		$begin_time = !empty($_GET['begin_time']) ? $_GET['begin_time'] : 'all';
		$end_time = !empty($_GET['end_time']) ? $_GET['end_time'] : 'all';
		$teacher_id = !empty($_GET['teacher_id']) ? $_GET['teacher_id'] : 'all';
		$moneyone = $_GET['moneyone'];
		$moneytwo = $_GET['moneytwo'];
		//时间区间查询
		if ($begin_time != 'all' && $begin_time != 'NaN' && $end_time != 'all' && $end_time != 'NaN') {
			$btime = getBeginTimeAndEndTime(chen_show_time($begin_time), chen_show_time($end_time));
			$where['this.time'] = array('between', $btime);
		}
		//金额区间查询
		if (($moneyone === '0' || !empty($moneyone)) && !empty($moneytwo)) {
			$where['this.price'] = array('between', array($moneyone, $moneytwo));
		}
		//打赏对象查询
		if ($teacher_id != 'all') {
			$where['this.teacher_id'] = $teacher_id;
		}

		$sc = D('school_course_reward');
		$join = 'as this left join ' . C('DB_PREFIX') . 'school_teacher as sc_t on this.teacher_id = sc_t.id ';
		$join .= ' left join ' . C('DB_PREFIX') . 'student_pay_record as pay on this.reward_id = pay.pay_info_id ';

		$where['this.system_reward_id'] = $reward_id;
		$field = 'this.price as reward_price,this.static_true_name as reward_static_true_name,this.static_mobile_phone as reward_static_mobile_phone,this.static_msg as reward_static_msg,this.teacher_id,sc_t.teacher_name,this.time,pay.pay_number,pay.transaction_id';
		$order = 'time desc';
		$xlsData = $sc->join($join)->field($field)->where($where)->order($order)->select();
		foreach($xlsData as $k=>$v){
			$xlsData[$k]['time'] = chen_show_time($v['time']);
			$xlsData[$k]['transaction_id'] = ' '.$v['transaction_id'];
			$xlsData[$k]['pay_number'] = ' '.$v['pay_number'];
		}
		$this->exportExcel($xlsName,$xlsCell,$xlsData);
	}
	
	
	//签到记录
	function getStudentSignRecord(){
		$xlsName  = '签到记录';
		$xlsCell  = array(
			array('school_student_number','学号','A', '10'),
			array('student_mobile_phone','学生手机','B', '20'), 
			array('student_true_name','学生名字','C', '20'), 
			array('time','签到时间','D', '30'), 
		);
		$course_id = I('get.course');
		$searchtype = I('get.searchtype');
		$search = trim(I('get.search'));
		$begin_time = !empty($_GET['begin_time']) ? $_GET['begin_time'] : 'all';
		$end_time = !empty($_GET['end_time']) ? $_GET['end_time'] : 'all';
		if ($searchtype && $search) {
			if ($searchtype != 'all') {
				$where['st.'.$searchtype] = array('like', '%' . $search . '%');
			} else {
				$whereor['st.true_name'] = array('like', '%' . $search . '%');
				$whereor['st.mobile_phone'] = array('like', '%' . $search . '%');
				$whereor['st.school_student_number'] = array('like', '%' . $search . '%');
				$whereor['_logic'] = 'or';
				$where['_complex'] = $whereor;
			}
		}
		//时间区间查询
		if ($begin_time != 'all' && $begin_time != 'NaN' && $end_time != 'all' && $end_time != 'NaN') {
			$btime = getBeginTimeAndEndTime(chen_show_time($begin_time), chen_show_time($end_time));
			$where['this.time'] = array('between', $btime);
		}
	
		$sc = M('student_course_sign');
		$join = 'as this inner join ' . C('DB_PREFIX') . 'student as st on this.student_id = st.id ';
		$where['this.course_id'] = $course_id;

		$field = 'st.true_name as student_true_name,st.mobile_phone as student_mobile_phone,this.time,st.school_student_number';

		$order = 'time DESC';
		$xlsData = $sc->join($join)->field($field)->where($where)->order($order)->select();
		foreach($xlsData as $k=>$v){
			$xlsData[$k]['time'] = chen_show_time($v['time']);
		}
		$this->exportExcel($xlsName,$xlsCell,$xlsData);
	}
	
	
	//座位列表
	function getStudentSeatRecord($course){
		$xlsName  = '座位列表';
		$xlsCell  = array(
			array('school_student_number','学号','A', '10'),
			array('student_mobile_phone','学生手机','B', '20'), 
			array('student_true_name','学生名字','C', '20'), 
			array('seat_address','座位号','D', '20'), 
			array('time','选座时间','E', '30'), 
		);
		$searchtype = I('get.searchtype');
		$search = trim(I('get.search'));
		$begin_time = !empty($_GET['begin_time']) ? $_GET['begin_time'] : 'all';
		$end_time = !empty($_GET['end_time']) ? $_GET['end_time'] : 'all';
		if ($searchtype && $search) {
			if ($searchtype != 'all') {
				if($searchtype=='seat_address'){
					$where['this.seat_address'] = array('like', '%' . $search . '%');
				}else{
					$where['st.'.$searchtype] = array('like', '%' . $search . '%');
				}
			} else {
				$whereor['this.seat_address'] = array('like', '%' . $search . '%');
				$whereor['st.true_name'] = array('like', '%' . $search . '%');
				$whereor['st.mobile_phone'] = array('like', '%' . $search . '%');
				$whereor['st.school_student_number'] = array('like', '%' . $search . '%');
				$whereor['_logic'] = 'or';
				$where['_complex'] = $whereor;
			}
		}
		//时间区间查询
		if ($begin_time != 'all' && $begin_time != 'NaN' && $end_time != 'all' && $end_time != 'NaN') {
			$btime = getBeginTimeAndEndTime(chen_show_time($begin_time), chen_show_time($end_time));
			$where['this.time'] = array('between', $btime);
		}
	
		$db_prefix = GetDbPrefix();

		$sc = D('student_course_seat');
		$join = 'as this inner join ' . $db_prefix . 'student as st on this.student_id = st.id ';

		$where['this.course_id'] = $course;

		$field = 'st.true_name as student_true_name,st.mobile_phone as student_mobile_phone,this.time,this.seat_address,st.school_student_number';

		$order = 'this.time DESC';
		$xlsData = $sc->field($field)->join($join)->where($where)->order($order)->select();
		foreach($xlsData as $k=>$v){
			$xlsData[$k]['time'] = chen_show_time($v['time']);
		}
		$this->exportExcel($xlsName,$xlsCell,$xlsData);

	}
   
  	   
	/**
	 *
	 * 导出线上学习记录
	 */
	function onlineList(){
		set_time_limit(1800);
		$searchtype = I('get.searchtype');
        $search = trim(I('get.search'));

        $mobilePhone=!empty($search) && $searchtype == "mobile_phone" ? $search : '';
        $courseName=!empty($search) && $searchtype == "name" ? $search : '';

		$system_r_field = 'name';
		$system_r_where['id'] = $reward_id;
		$system_r_data = M('system_reward')->field($system_r_field)->where($system_r_where)->find();
		$xlsName  = $system_r_data['name'].'线上学习记录';
		$xlsCell  = array(
			array('true_name','姓名','A', '20'),
			array('mobile_phone','手机','B', '10'),
			array('courseName','课程名称','C', '40'),
			array('is_live_','课程类型','D', '10'),
			array('play_seconds','播放时长(秒)','E', '20'),  
			array('play_datetime_','最后播放时间','F', '20'),  
		);

		$db_prefix = GetDbPrefix();
        $field = ' this.play_seconds,this.play_datetime,this.is_live ,this.vedio_id,this.course_id,this.student_id,stu.true_name,course.name as courseName,stu.mobile_phone ';
        $join = 'as this inner join ' . $db_prefix . 'school_course as course on this.course_id = course.id inner  join ' . $db_prefix . 'student stu on this.student_id=stu.id';

        if ($courseName) {
            $whereSelect['course.name'] = array('like', '%' . trim($courseName) . '%');
        }
        if ($mobilePhone) {
            $whereSelect['stu.mobile_phone'] = array('like', '%' . trim($mobilePhone) . '%');
        }

        $order = 'this.play_datetime desc';
        $record= D('vedio_play_time');

        $xlsData= $record->field($field)->join($join)->where($whereSelect)->order($order)->select();

        foreach($xlsData as $k=>$v){
			$xlsData[$k]['play_datetime_'] = chen_show_time($v['play_datetime']);
			
			$xlsData[$k]['is_live_'] = is_live($v['is_live']);
		}

		$this->exportExcel($xlsName,$xlsCell,$xlsData);
		 
	}


	/**
	 *
	 * 导出线下学习记录
	 */
	function offlineList(){
		set_time_limit(1800);
		$searchtype = I('get.searchtype');
        $search = trim(I('get.search'));

        $mobilePhone=!empty($search) && $searchtype == "mobile_phone" ? $search : '';
        $courseName=!empty($search) && $searchtype == "name" ? $search : '';

		$system_r_field = 'name';
		$system_r_where['id'] = $reward_id;
		$system_r_data = M('system_reward')->field($system_r_field)->where($system_r_where)->find();
		$xlsName  = $system_r_data['name'].'线下学习记录';
		$xlsCell  = array(
			array('true_name','姓名','A', '20'),
			array('mobile_phone','手机','B', '10'),
			array('name','活动名称','C', '40'),
			array('see_type','活动类型','D', '10'),
			array('begin_time_','开始时间','E', '20') 
		);

		$db_prefix = GetDbPrefix();
        $field = 'this.student_id,this.id,this.school_course_id,this.activity_place_id,this.status,place.name as see_type,stu.true_name,stu.mobile_phone,course.name,
        course.begin_time,course.relate_course_id,course.is_can_false,course.video_status';
        $join = 'as this inner join ' . $db_prefix . 'school_course as course on this.school_course_id = course.id  inner  join ' . $db_prefix . 'student stu on this.student_id=stu.id';
        $join=$join." inner join y_activity_place place on this.activity_place_id=place.id ";
        $whereSelect['this.pay_status'] = '1';
        $whereSelect['course.type'] = 1;
        $whereSelect['this.status'] = array('gt', 0);

       if ($mobilePhone) {
            $whereSelect['stu.mobile_phone'] = array('like', '%' . trim($mobilePhone) . '%');
        }
        if ($courseName) {
            $whereSelect['course.name'] = array('like', '%' . trim($courseName) . '%');
        }

        $order = 'course.begin_time desc';
        $record= D('student_course');

        $xlsData= $record->field($field)->join($join)->where($whereSelect)->order($order)->select();

        foreach($xlsData as $k=>$v){
			$xlsData[$k]['begin_time_'] = chen_show_time($v['begin_time']);
		}

		
		$this->exportExcel($xlsName,$xlsCell,$xlsData);
		 
	}
}