<?php
namespace Admin\Controller;

use Think\Controller;

//打赏大屏显示
class RewardBigScreenController extends ExtendController
{

    //打赏大屏显示主页面
    public function index()
    {
        $id = I('get.id');
        $where['system_reward_id'] = $id;
        $data = D('system_reward_big_screen')->where($where)->find();
        if (!$data) {
            $this->show('<script type="text/javascript">alert("请配置大屏打赏设置")</script>');
            die;
        }
//var_dump($data);

        $listType = $data['list_type'];
        $limit = 5;
        if ($listType == "最新打赏人员名单") {
            $limit = 100;
            $data['list_type']="最新打赏人员";
        }else
        {

            $data['list_type']="打赏前五名人员";
        }
        $showType=$data['list_new_show'];

        $this->assign('data', $data);

        //查询当前打赏对象Id
        $wheret['status'] = 1;
        $wheret['system_reward_id'] = $id;
        $reward_teacher_data = D('system_reward_teacher')->getone($wheret, 'id,teacher_id');

        //最新打赏人员名单



        $ifShowMsg=$this->checkstr($showType, "显示留言");
        $ifShowMoney=$this->checkstr($showType, "显示金额");

        $this->assign('ifShowMsg', $ifShowMsg);
        $this->assign('ifShowMoney', $ifShowMoney);
        $this->assign('rewardId', $id);


        //查询当前打赏对象的用户打赏记录
       $rewardRecords= D('school_course_reward')->getOneTeacherRewardRecordWhitShowLogic($id, $reward_teacher_data['teacher_id'],$limit,$ifShowMsg,$ifShowMoney);
        //var_dump($rewardRecords);
        $this->assign('reward_list', $rewardRecords);

        //查询该课程的当前对象打赏总次数
        //$reward_count = D('school_course_reward')->getOneRewardOneObjAllCount($id,
        //$reward_teacher_data['teacher_id']);

        $cond = array('system_reward_id' => $id, 'teacher_id' => $reward_teacher_data['teacher_id']);
        $reward_count = M('system_reward_teacher')->where($cond)->getField('count');

        $reward_count_len = strlen($reward_count);
        switch ($reward_count_len) {
            case '1':
                $reward_count_str = '0000' . $reward_count;
                break;
            case '2':
                $reward_count_str = '000' . $reward_count;
                break;
            case '3':
                $reward_count_str = '00' . $reward_count;
                break;
            case '4':
                $reward_count_str = '0' . $reward_count;
                break;
            case '5':
                $reward_count_str = '' . $reward_count;
                break;
            default :
                $reward_count_str = '00000';
        }


        $this->assign('reward_count_str', $reward_count_str);

        $this->display('index');
    }

    function checkstr($str,$child){

        $tmparray = explode($child,$str);
        if(count($tmparray)>1){
            return true;
        } else{
            return false;
        }
    }

    //打赏大屏抽奖
    public function luck()
    {
        $id = I('get.id');
        $this->assign('id', $id);
        $luckDrawId = I('get.luckDrawId');

        //查询当前打赏对象Id
        $reward_obj_id = D('system_reward_teacher')->getOneIdBySystemRewardId($id);



        if (empty($luckDrawId)) {
            //查询第一条奖品的信息
            $luckDrawId = M('system_reward_luck_draw')->where(array(
                'system_reward_id' => $id,
                'reward_obj_id' => $reward_obj_id,
            ))->order('time asc')->getField('id');
        }


        if (empty($luckDrawId))
        {
            header('Content-type:text/html;charset=utf-8');
            echo  "未设置奖品";

            exit();
        }
        $is_executable = D('system_reward_luck_draw')->isExecuteLuckDram($luckDrawId);
        //查询该奖品是否已经抽奖
        if ($is_executable) {
            $this->redirect('/Admin/RewardBigScreen/luckPeopleList/id/' . $id . '/luckDrawId/' . $luckDrawId);
        }


        //查询当前点击的奖品信息
        $this->assign('luckdrawdata', M('system_reward_luck_draw')->field('id,draw_description')->find($luckDrawId));


        $where['system_reward_id'] = $id;
        $where['reward_obj_id'] = $reward_obj_id;

        $field = '*';
        $order = 'time ASC';
        //奖品列表
        $luckList = M('system_reward_luck_draw')->field($field)->where($where)->order($order)->select();
        $this->assign('luckList', $luckList);

        //大屏设置
        $this->assign('data', D('system_reward_big_screen')->where($where)->find());
        $this->display('luck');
    }

    /**
     * 中奖人员
     */
    public function luckPeopleList()
    {
        header('Content-type:text/html;charset=utf-8');
        $id = I('get.id');
        $this->assign('id', $id);
        $luckDrawId = I('get.luckDrawId');
        $myexecute = I('get.myexecute');
        $is_executable = D('system_reward_luck_draw')->isExecuteLuckDram($luckDrawId);
        if ($myexecute != 'true') {
            //查询该奖品是否已经抽奖
            if (!$is_executable) {
                $this->redirect('/Admin/RewardBigScreen/luck/id/' . $id . '/luckDrawId/' . $luckDrawId);
            }

        }
        //查询当前打赏是否已经关闭
        $system_reward_data = M('system_reward')->where(array('id' => $id))->find();
        if (!$system_reward_data || $system_reward_data['status']) {
            exit('<h1>请先关闭打赏</h1>');
        }

        //查询当前打赏对象Id
        $getOneWhere = array(
            'system_reward_id' => $id,
            'status' => 1,
        );

        $db_prefix = GetDbPrefix();

        $reward_teacher_data = M('system_reward_teacher')->where($getOneWhere)->find();
        if (!$reward_teacher_data || $reward_teacher_data['status'] != 1) {
            exit('<h1>请先设置打赏对象</h1>');
        }

        //是否已经抽奖，如果未抽奖则执行抽奖程序
        if (!$is_executable) {
            $executeLuckDramRet = D('student_luck_draw')->executeLuckDram($id, $reward_teacher_data['teacher_id'], $luckDrawId);

            if (!$executeLuckDramRet) {
                exit('<h1>系统繁忙，请重试！</h1>');
            }
        }

        $field = '*';
        $order = 'time ASC';
        //查询当前打赏对象Id
        $reward_obj_id = D('system_reward_teacher')->getOneIdBySystemRewardId($id);
        $where['system_reward_id'] = $wheredraw['system_reward_id'] = $id;
        $wheredraw['reward_obj_id'] = $reward_obj_id;

        //查询当前点击的奖品信息
        $this->assign('luckdrawdata', M('system_reward_luck_draw')->field('id,draw_description')->find($luckDrawId));
        //奖品列表
        $luckList = M('system_reward_luck_draw')->field($field)->where($wheredraw)->order($order)->select();
        $this->assign('luckList', $luckList);

        //大屏设置
        $this->assign('data', D('system_reward_big_screen')->where($where)->find());

        //中奖名单
        $fieldPeopleList = 'this.system_reward_id,this.student_id,st.true_name';
        $join = 'as this left join ' . C('DB_PREFIX') . 'student as st on this.student_id = st.id';
        $where['system_reward_teacher_id'] = $reward_teacher_data['teacher_id'];
        $where['luck_draw_id'] = $luckDrawId;
        $luckPeople = M('student_luck_draw')->join($join)->field($fieldPeopleList)->where($where)->select();
        $num = 20;//分页，每页个数

        $page = ceil(count($luckPeople) / $num);
        $begin = 0;//当前页
        $kk = 0;

        // 所有的打赏人员名字，都显示用户输入的
        foreach ($luckPeople as $k => $v) {
            if ($k % $num == 0) {
                $begin++;
                $kk = 0;
            }

            $cond = array('system_reward_id' => $v['system_reward_id'], 'student_id' => $v['student_id']);
            $v['true_name'] = M('school_course_reward')->where($cond)->getField('static_true_name');

            $luckPeopleList[$begin][$kk]['true_name'] = $v['true_name'];
            $kk++;
        }

        //dump($luckPeopleList);
        $this->assign('luckPeopleList', $luckPeopleList);
        $this->display('luckPeopleList');
    }

}