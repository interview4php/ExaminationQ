<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/10/3 0003
 * Time: 下午 9:28
 */
namespace Admin\Controller;

use Think\Page;

class ColumnsController extends ExtendController {

    public function columns() {
        $columnist_id 	 = !empty($_GET['columnist_id'])?$_GET['columnist_id']:'all';
        $columns_name 	 = !empty($_GET['columns_name'])?$_GET['columns_name']:'all';
        if ($columnist_id != 'all') {
            $where['columnist_id'] = $columnist_id;
        }
        if ($columns_name != 'all') {
            $where['columns_name'] = array('like','%'.trim($columns_name).'%');
        }

        $where = array();
        $order = 'id desc';

        $Columns = D('Columns');
        $count = $Columns->where($where)->count();
        $Page = new Page($count);
        $show = $Page->show();

        $list = $Columns->relation('Columnist')->where($where)
            ->order($order)->limit($Page->firstRow, $Page->listRows)->select();
        $this->assign('columnist_id', A('GetSelect')->getDtoS('Columnist', '', 'id desc', 'id', 'columnist_name', $columnist_id, 'columnist_id', array('', '专栏作家')));

        $this->assign('list', $list);
        $this->assign('page', $show);
        $this->display();
    }

    public function columnsEdit() {
        $editType = !empty($_GET['t']) ? 'update' : 'create';
        if ($editType == 'update') {
            $foodType = M("Columns");
            $data = $foodType->find($_GET['t'] + 0);
            $this->assign('data', $data);
            $rights=explode(',',$data['rights']);

            $rightsData=array();
            foreach ($rights as $value)
            {
                $this->assign($value, 1);
                $rightsData[$value]=1;
            }
        }
        $this->assign('editType', $editType);
        $this->assign('columnist_id', A('GetSelect')->getDtoS('Columnist', '', 'id desc', 'id', 'columnist_name', $this->data['columnist_id'], 'columnist_id', array('', '请选择')));

        $this->display();
    }

    public function columnist() {
        $columnist_name 	 = !empty($_GET['columnist_name'])?$_GET['columnist_name']:'all';
        if ($columnist_name != 'all') {
            $where['columnist_name'] = array('like','%'.trim($columnist_name).'%');
        }

        $where = array();
        $order = 'id desc';

        $Columns = D('Columnist');
        $count = $Columns->where($where)->count();
        $Page = new Page($count);
        $show = $Page->show();

        $list = $Columns->where($where)
            ->order($order)->limit($Page->firstRow, $Page->listRows)->select();

        $this->assign('list', $list);
        $this->assign('page', $show);
        $this->display();
    }

    public function columnistEdit() {
        $editType = !empty($_GET['t']) ? 'update' : 'create';
        if ($editType == 'update') {
            $foodType = M("Columnist");
            $data = $foodType->find($_GET['t'] + 0);
            $this->assign('data', $data);
            $rights=explode(',',$data['rights']);

            $rightsData=array();
            foreach ($rights as $value)
            {
                $this->assign($value, 1);
                $rightsData[$value]=1;
            }
        }
        $this->assign('editType', $editType);

        $this->display();
    }

    public function article() {
        $columns_id 	 = !empty($_GET['columns_id'])?$_GET['columns_id']:'all';
        $columnist_id 	 = !empty($_GET['columnist_id'])?$_GET['columnist_id']:'all';
        $title 	 = !empty($_GET['title'])?$_GET['title']:'all';
        if ($columns_id != 'all') {
            $where['columns_id'] = $columns_id;
        }
        if ($columnist_id != 'all') {
            $where['columnist_id'] = $columnist_id;
        }
        if ($title != 'all') {
            $where['title'] = array('like','%'.trim($title).'%');
        }
        $where = array();
        $order = 'id desc';

        $ColumnsArticle = D('ColumnsArticle');
        $count = $ColumnsArticle->where($where)->count();
        $Page = new Page($count);
        $show = $Page->show();

        $list = $ColumnsArticle->relation(true)->where($where)
            ->order($order)->limit($Page->firstRow, $Page->listRows)->select();

        $this->assign('columns_id', A('GetSelect')->getDtoS('Columns', '', 'id desc', 'id', 'columns_name', $columns_id, 'columns_id', array('', '专栏')));

        $this->assign('list', $list);
        $this->assign('page', $show);
        $this->display();
    }

    public function articleEdit() {
        $editType = !empty($_GET['t']) ? 'update' : 'create';
        if ($editType == 'update') {
            $foodType = M("ColumnsArticle");
            $data = $foodType->find($_GET['t'] + 0);
            $this->assign('data', $data);
            $rights=explode(',',$data['rights']);

            $rightsData=array();
            foreach ($rights as $value)
            {
                $this->assign($value, 1);
                $rightsData[$value]=1;
            }
        }

        $this->assign('columns_id', A('GetSelect')->getDtoS('Columns', '', 'id desc', 'id', 'columns_name', $this->data['columns_id'], 'columns_id', array('', '请选择')));
        $this->assign('editType', $editType);

        $this->display();
    }

    public function ColumnsDel($id) {
        $count = M('ColumnsArticle')->where(array('columns_id', $id))->count();
        if ($count > 0) {
            $this->success('删除失败');exit;
        }
        $name=M('Columns');
        $pname=$name->where('id='.$id)->delete();
        if($pname){
            $this->success('删除成功');
        }else{
            $this->success('删除失败');
        }
    }

    public function ColumnistDel($id) {
        $count = M('Columns')->where(array('columnist_id', $id))->count();
        if ($count > 0) {
            $this->success('删除失败');exit;
        }
        $name=M('Columnist');
        $pname=$name->where('id='.$id)->delete();
        if($pname){
            $this->success('删除成功');
        }else{
            $this->success('删除失败');
        }
    }

    public function articleDel($id) {
        $name=M('ColumnsArticle');
        $pname=$name->where('id='.$id)->delete();
        if($pname){
            $this->success('删除成功');
        }else{
            $this->success('删除失败');
        }
    }


}