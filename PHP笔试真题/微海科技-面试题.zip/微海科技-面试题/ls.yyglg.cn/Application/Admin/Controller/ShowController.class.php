<?php
namespace Admin\Controller;

use Think\Controller;

class ShowController extends ExtendController
{

    //登录界面设置
    public function login()
    {
        $order = 'id desc';
        A('Public')->getList('html_login_content', '*', $where, $order, 8, 'login');
    }

    //登录界面修改
    public function loginEdit()
    {
        A('Public')->getEdit('html_login_content');
        $this->display('loginEdit');
    }

    public function Address()
    {
//        echo "test";

        $data = M('IndexAddresses')->where(array('id' => 1))->find();

//        var_dump($data);
        $this->assign("data",$data);
        $this->display();
    }

    public function AddressSubmit()
    {


        $ret = M('IndexAddresses')->where(array('id' => 1))->save($_POST);

        if ($ret != false) {
            $this->success('保存成功', "/Admin/Show/Address");
        } else {
            $this->error('保存成功', "/Admin/Show/Address");
        }

    }

    //预约成功界面设置
    public function successOne()
    {
        $order = 'id desc';
        $where['type'] = 'ShowSuccessOne';
        A('Public')->getList('html_system_text_setup', '*', $where, $order, 8, 'successOne');
    }

    //预约成功界面修改
    public function successOneEdit()
    {
        A('Public')->getEdit('html_system_text_setup');
        $this->display('successOneEdit');
    }

    //登录界面提示不能上课务必要请假
    public function login2()
    {
        $order = 'id desc';
        A('Public')->getList('html_login_submit', '*', $where, $order, 8, 'login2');
    }

    //登录界面提示不能上课务必要请假修改
    public function login2Edit()
    {
        A('Public')->getEdit('html_login_submit');
        $this->display('login2Edit');
    }


}