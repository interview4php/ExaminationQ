<?php
namespace Admin\Controller;
use Think\Controller;
class AdminController extends ExtendController {
   
//--------------------------------------------------------------------------------------------管理员列表
	//管理员列表
	public function admin(){



		$user_name 	 = !empty($_GET['user_name'])?$_GET['user_name']:'all';
		$true_name 	 = !empty($_GET['true_name'])?$_GET['true_name']:'all';
		$job_number 	 = !empty($_GET['job_number'])?$_GET['job_number']:'all';
		$mobile_phone 	 = !empty($_GET['mobile_phone'])?$_GET['mobile_phone']:'all';
		$group_id 	 = !empty($_GET['group_id'])?$_GET['group_id']:'all';
		$is_show 	 = !empty($_GET['is_show'])?$_GET['is_show']:'all';
		//用户名
		if($user_name!='all'){
			$where['user_name'] = array('like','%'.trim($user_name).'%');
			$this->assign('user_name',$user_name);
		}
		//昵称
		if($true_name!='all'){
			$where['true_name'] = array('like','%'.trim($true_name).'%');
			$this->assign('true_name',$true_name);
		}
		//工号
		if($job_number!='all'){
			$where['job_number'] = array('like','%'.trim($job_number).'%');
			$this->assign('job_number',$job_number);
		}
		//手机
		if($mobile_phone!='all'){
			$where['mobile_phone'] = array('like','%'.trim($mobile_phone).'%');
			$this->assign('mobile_phone',$mobile_phone);
		}
		//所属组
		if($group_id!='all'){
			$where['group_id'] = $group_id;
		}
		//使用状态
		if($is_show!='all'){
			switch($is_show){
				case 'a':$where['is_show'] = 1;break;
				case 'b':$where['is_show'] = 0;break;
			}
		}
		//所属组
		$this->assign('group_id',A('GetSelect')->getDtoS('admin_group',1,'sort desc,id desc','id','name',$group_id,'group_id',array(0,'所属组')));
		//使用状态
		$this->assign('is_show',A('GetSelect')->getStatusS_n(array('a'=>'使用','b'=>'禁用'),$is_show,'is_show','使用状态'));
	
		$order = 'sort desc,id desc';
		$data = A('Public')->getArray('admin','*',$where,$order,20,'admin');
		$this->assign('list',$data);
		$this->display('admin');
	}
	//管理员新增||修改
	public function adminEdit(){



		$editType = !empty($_GET['t']) ? 'update' : 'create';


		if ($editType == 'update') {

			$foodType = M("admin");

			$data = $foodType->find($_GET['t'] + 0);

			$this->assign('data', $data);


			$rights=explode(',',$data['rights']);


			$rightsData=array();
			foreach ($rights as $value)
			{
				$this->assign($value, 1);

				$rightsData[$value]=1;
				//$this->assign($mapping[$value], 1);
				//echo  'key='.$key."value=".$value;

			}


		}

		$this->assign('editType', $editType);



		$this->assign('is_show',A('GetSelect')->getIsShowS($this->data['is_show'],'is_show'));

		//所属分组
		$this->assign('group_id',A('GetSelect')->getDS('admin_group',array('deleted'=>0,'is_show'=>1),'sort desc,id desc','id','name','group_id',$this->data['group_id'],'选择分组'));
		$this->display();
	}
//-----------------------------------------------------------------------------------------管理员分组
	//分组列表
	public function adminGroup(){
		$name 	 = !empty($_GET['name'])?$_GET['name']:'all';
		$is_show 	 = !empty($_GET['is_show'])?$_GET['is_show']:'all';
		//分组名
		if($name!='all'){
			$where['name'] = array('like','%'.trim($name).'%');
			$this->assign('name',$name);
		}
		//使用状态
		if($is_show!='all'){
			switch($is_show){
				case 'a':$where['is_show'] = 1;break;
				case 'b':$where['is_show'] = 0;break;
			}
		}
		//使用状态
		$this->assign('is_show',A('GetSelect')->getStatusS_n(array('a'=>'使用','b'=>'禁用'),$is_show,'is_show','使用状态'));
	
		$order = 'sort desc,id desc';
		A('Public')->getList('admin_group','*',$where,$order,8,'adminGroup');	
	}
	//分组新增||修改
	public function adminGroupEdit(){	
		A('Public')->getEdit('admin_group');
		//是否显示
		$this->assign('is_show',A('GetSelect')->getIsShowS($this->data['is_show'],'is_show'));
		$this->display();
	}
	
	

   
}