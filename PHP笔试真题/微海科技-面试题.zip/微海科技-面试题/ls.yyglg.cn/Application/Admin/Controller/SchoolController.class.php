<?php
namespace Admin\Controller;

use Think\Controller;

//学院管理
class SchoolController extends ExtendController
{
	private $schoolListNum = 5;//学院每次显示个数
	private $teacherListNum = 10;//老师每次显示个数
	private $studentListNum = 10;//会员每次显示个数

	//学院列表
	public function schoolList()
	{
		$school_name = !empty($_GET['school_name']) ? $_GET['school_name'] : 'all';
		$time = !empty($_GET['time']) ? $_GET['time'] : 'all';
		$sort = !empty($_GET['sort']) ? $_GET['sort'] : 'all';
		//所属学院
		if ($school_name != 'all') {
			$where['id'] = $school_name;
		}
		//创建排序排序
		$this->assign('sort', A('GetSelect')->getStatusS_n(array('desc' => '排序降序', 'asc' => '排序升序'), $sort, 'sort', '排序顺序'));
		//创建时间排序
		$this->assign('time', A('GetSelect')->getStatusS_n(array('desc' => '添加时间升序', 'asc' => '添加时间降序'), $time, 'time', '添加时间排序'));
		//学院选择
		A('Public')->assignSchoolSelect($school_name);
		//获取排序
		$order = A('Public')->getOrder('sort desc,id desc', array('id' => $time, 'sort' => $sort), 'all');
		A('Public')->getList('school', '*', $where, $order, $this->schoolListNum, 'schoolList');
	}

	//学院新增、修改
	public function schoolListEdit()
	{
		A('Public')->getEdit('school');
		$this->display('schoolListEdit');
	}

	//老师列表
	public function teacherList()
	{
		$school_id = I('get.s');
		$search = !empty($_GET['search']) ? $_GET['search'] : 'all';
		//搜索老师名
		if ($search != 'all') {
			$where['st.teacher_name'] = array('like', '%' . trim($search) . '%');
			$this->assign('search', $search);
		}
		$this->assign('school_id', $school_id);
		$where['st.school_id'] = $school_id;
		$st = D('school_teacher');
		$join = 'as st left join ' . C('DB_PREFIX') . 'school as s on st.school_id = s.id';
		$count = $st->join($join)->where($where)->count();
		$Page = new \Think\Page($count, $this->teacherListNum);
		$show = $Page->show();
		$field = 'st.id,st.teacher_name,st.teacher_head_img,st.teacher_description,st.teacher_sex,st.position_id,st.admin_id,s.school_name';
		//获取排序
		$order = A('Public')->getOrder('st.id desc', array('st.id' => $time), 'all');
		$list = $st->relation('admin')->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();


		$this->assign('list', $list);
		$this->assign('page', $show);
		$this->display('teacherList');
	}

	//老师新增||修改
	public function teacherListEdit()
	{
		A('Public')->getEdit('school_teacher');
		$this->assign('school_id', I('get.s'));
		$this->display();
	}


}