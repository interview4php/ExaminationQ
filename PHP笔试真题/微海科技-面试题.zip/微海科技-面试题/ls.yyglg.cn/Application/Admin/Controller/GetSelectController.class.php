<?php
namespace Admin\Controller;

use Think\Controller;

//自动生成select
/**
 *    文档规则，
 * 单个大写A代表array数组
 * 单个大写S代表select选择框
 * 单个大写D代表database数据库
 *
 */
class GetSelectController extends Controller
{


	/**
	 * getAToS,将数组组合为select选择框,返回组建好的选择框
	 *
	 * 主要用于从数据库返回的数据中，判断某值是否存在，如果有则默认选择，没有则普通select
	 *
	 * @author 陈乃栾
	 * @param array $array 数组
	 * @param string $kk 需要变成select选择框的value的字段
	 * @param string $vv 需要变成select选择框的text的字段
	 * @param string $value 需要对比$kk的值，如果相等则 selected="selected"
	 * @param string $idAndName 组建的select选择框的name和id的名字
	 * @param array $default 组建的select选择框的第一个值，如0 “请选择”
	 * @param string $myclass 组建的select选择框的样式
	 * @return string
	 */
	function getAToS($array, $kk, $vv, $value, $idAndName, $default, $myclass)
	{
		if (!$default) {
			$default[0] = '';
			$default[1] = '请选择';
		}
		$str = '<select name="' . $idAndName . '" class="' . $myclass . '" id="' . $idAndName . '">';
		$str .= '<option value="' . $default[0] . '">' . $default[1] . '</option>';
		if (is_array($array)) {
			foreach ($array as $k => $v) {
				if (!empty($value)) {
					if ($value == $v[$kk]) {
						$str .= '<option value="' . $v[$kk] . '" selected="selected" >' . $v[$vv] . '</option>';
					} else {
						$str .= '<option value="' . $v[$kk] . '">' . $v[$vv] . '</option>';
					}
				} else {
					$str .= '<option value="' . $v[$kk] . '">' . $v[$vv] . '</option>';
				}
			}
		}
		$str .= '</select>';

		return $str;
	}

	/**
	 * getDtoS,获取数据库里面的数据组合为select选择框,返回组建好的选择框
	 *
	 * @author 陈乃栾
	 * @param string $table 数据库表明
	 * @param array $where 查询条件
	 * @param string $order 排序方式
	 * @param string $kk 需要变成select选择框的value的字段
	 * @param string $vv 需要变成select选择框的text的字段
	 * @param string $value 需要对比$kk的值，如果相等则 selected="selected"
	 * @param string $idAndName 组建的select选择框的name和id的名字
	 * @param array $default 组建的select选择框的第一个值，如0 “请选择”
	 * @param string $myclass 组建的select选择框的样式
	 * @return string
	 */
	function getDtoS($table, $where, $order, $kk, $vv, $value, $idAndName, $default = '', $myclass = '')
	{
		$array = M($table)->where($where)->order($order)->select();
		return $this->getAToS($array, $kk, $vv, $value, $idAndName, $default, $myclass);
	}

	/**
	 * getStatusS,将数组组合为select选择框，
	 *
	 * 主要用于状态，判断某值是否存在，如果有则默认选择，没有则普通select
	 *
	 * @author 陈乃栾
	 * @param array $arr 键为select的value ,值为select的text
	 * @param string $value 需要对比的值
	 * @param string $name select的name和ID
	 * @param array $default select的默认value和text
	 * @return string
	 */

	function getStatusS($arr, $value, $name, $default)
	{
		if (!$default) {
			$default[0] = '';
			$default[1] = '请选择';
		}
		$str = '<select name="' . $name . '" id="' . $name . '">';
		$str .= '<option value="' . $default[0] . '">' . $default[1] . '</option>';
		foreach ($arr as $k => $v) {
			if ($k == $value) {
				$str .= '<option value="' . $k . '" selected="selected">' . $v . '</option>';
			} else {
				$str .= '<option value="' . $k . '">' . $v . '</option>';
			}

		}
		$str .= '</select>';
		return $str;

	}

	//getStatusS的扩张，select的第一个值为0
	function getStatusS_0($arr, $value, $name, $default)
	{
		return $this->getStatusS($arr, $value, $name, array(0, $default));
	}

	//getStatusS的扩张，select的第一个值为-1
	function getStatusS_1($arr, $value, $name, $default)
	{
		return $this->getStatusS($arr, $value, $name, array(-1, $default));
	}

	//getStatusS的扩张，select的第一个值为''
	function getStatusS_n($arr, $value, $name, $default)
	{
		return $this->getStatusS($arr, $value, $name, array('', $default));
	}

	/**
	 * getIsShowS,将数组组合为select选择框，
	 *
	 * 主要用于是或者否，判断某值是否存在，如果有则默认选择，没有则普通select
	 *
	 * @author 陈乃栾
	 * @param string $name select的name和ID
	 * @param string $value Y或者N，Y代表是，N代表否
	 * @return string
	 */
	function getIsShowS($value, $name)
	{
		$Y = $value == '1' ? 'selected = "selected"' : '';
		$N = $value == '0' ? 'selected = "selected"' : '';
		$str .= '<select name="' . $name . '" id="' . $name . '">';
		$str .= '<option value="0" ' . $N . ' >不显示</option>';
		$str .= '<option value="1" ' . $Y . ' >显示</option>';
		$str .= '</select>';
		return $str;
	}

	/**
	 * getSex,将数组组合为select选择框，
	 *
	 * 主要用于性别，一男二女，判断某值是否存在，如果有则默认选择，没有则普通select
	 *
	 * @author 陈乃栾
	 * @param string $name select的name和ID
	 * @param string $value Y或者N，Y代表是，N代表否
	 * @return string
	 */
	function getSex($value, $name)
	{
		$Y = $value == '1' ? 'selected = "selected"' : '';
		$N = $value == '2' ? 'selected = "selected"' : '';
		$str .= '<select name="' . $name . '" id="' . $name . '">';
		$str .= '<option value="0">请选择</option>';
		$str .= '<option value="2" ' . $N . ' >女</option>';
		$str .= '<option value="1" ' . $Y . ' >男</option>';
		$str .= '</select>';
		return $str;
	}

	//使用方法跟 getIsShowS一样，显示内容从不显示，显示变为，是，否
	function getYesOrNoS($value, $name)
	{
		$Y = $value == '1' ? 'selected = "selected"' : '';
		$N = $value == '0' ? 'selected = "selected"' : '';
		$str .= '<select name="' . $name . '" id="' . $name . '">';
		$str .= '<option value="0" ' . $N . ' >否</option>';
		$str .= '<option value="1" ' . $Y . ' >是</option>';
		$str .= '</select>';
		return $str;
	}


	/**
	 * [getS 输出select]
	 * @param [arrat] $array 数组]
	 * @param [string or array] $kk option的值
	 * @param [string] $vv option的显示
	 * @param [string] $name name和id
	 * @param [string] $value 默认值，如果有相同则默认
	 *    return string select选择框
	 */
	function getS($array, $kk, $vv, $name, $value, $de = '请选择')
	{

		$str .= '<select name="' . $name . '" id="' . $name . '">';
		$str .= '<option value="0">' . $de . '</option>';
		if (is_array($array)) {
			foreach ($array as $k => $v) {
				if (!empty($value)) {
					if ($value == $v[$kk]) {
						$str .= '<option value="' . $v[$kk] . '" selected="selected" >' . $v[$vv] . '</option>';
					} else {
						$str .= '<option value="' . $v[$kk] . '">' . $v[$vv] . '</option>';
					}
				} else {
					$str .= '<option value="' . $v[$kk] . '">' . $v[$vv] . '</option>';
				}
			}
		}
		$str .= '</select>';
		return $str;

	}

	protected function getList($table, $where, $order)
	{
		return M($table)->where($where)->order($order)->select();
	}

	function getDS($table, $where, $order, $kk, $vv, $name, $value, $de)
	{
		return $this->getS($this->getList($table, $where, $order), $kk, $vv, $name, $value, $de);
	}


}