<?php
namespace Admin\Controller;

use Think\Controller;

class LawyerProfileController extends ExtendController
{
    public function index()
    {
        $admin = session('admindata');
        if ($admin == null || $admin == "") {
            echo "未登陆";
            exit();
        }
        $true_name = !empty($_GET['true_name']) ? $_GET['true_name'] : 'all';
        $school_student_number = !empty($_GET['school_student_number']) ? $_GET['school_student_number'] : 'all';
        $mobile_phone = !empty($_GET['mobile_phone']) ? $_GET['mobile_phone'] : 'all';
        $approval_status = !empty($_GET['approval_status']) ? $_GET['approval_status'] : 'all';   //默认搜索待审批

        //审批状态
        if ($approval_status != 'all') {

            $where['approval_status'] = $approval_status;

        }
        //姓名
        if ($true_name != 'all') {
            $where['true_name'] = array('like', '%' . trim($true_name) . '%');
            $this->assign('true_name', $true_name);
        }

        //手机
        if ($mobile_phone != 'all') {
            $where['mobile_phone'] = array('like', '%' . trim($mobile_phone) . '%');
            $this->assign('mobile_phone', $mobile_phone);
        }
        //工号
        if ($school_student_number != 'all') {
            $where['school_student_number'] = array('like', '%' . trim($school_student_number) . '%');
            $this->assign('school_student_number', $school_student_number);
        }
        $order = 'id desc';
        $data = A('Public')->getArray('student_lawyer_profile_approval', '*', $where, $order, 20, 'student_lawyer_profile_approval');
        $this->assign('list', $data);

        $this->assign('approval_status', A('GetSelect')->getStatusS_n(array('待审批' => '待审批', '审批通过' => '审批通过', '审批驳回' => '审批驳回'), $approval_status, 'approval_status', '审批状态'));
        $this->display();
    }


    public function approval()
    {
        $admin = session('admindata');

        if (empty($admin)) {
            echo "未登陆";
            exit();
        }
        $id = $_GET["id"];

        $info = D("student_lawyer_profile_approval")->where(array('id' => $id))->find();
        $this->assign('info', $info);
        $this->display();
    }

    public function submitApproval()
    {
        $id = $_POST['id'];
        $info = D("student_lawyer_profile_approval")->where(array('id' => $id))->find();

        if ($info['approval_status'] != "待审批") {
            echo "状态错误:只有待审核状态才能操作";
            exit();

        }
        $admin = session('admindata');

        if (empty($admin)) {
            echo "未登陆";
            exit();
        }
        $info['approval_status'] = $_POST['approval_status'];
        $info['approval_message'] = $_POST['approval_message'];
        $info['approval_datetime'] = time();
        $info['approval_user'] = $admin['user_name'];
       // $info['approval_status'] = '待审批';
        D("student_lawyer_profile_approval")->save($info);
        $mobile = $info['mobile_phone'];

        $info['id'] = null;
        $oldProfile = D("student_lawyer_profile")->where(array('mobile_phone' => $mobile))->find();

        if (!empty($oldProfile)) {
            D("student_lawyer_profile")->where(array('mobile_phone' => $mobile))->delete();
        }
        D("student_lawyer_profile")->save($info);

        $studentInfo=   D("student")->where(array('mobile_phone' => $mobile))->find();

        if (   $info['approval_status']=="审批通过")
        {
            $studentInfo['student_authenticated']="1";
            $content = "尊敬的{$studentInfo['true_name']}，您提交的律师资料已通过审核。";
           $re=    A('Public')->sendShortMsg($mobile, $content);

            D("student")->save($studentInfo);
        }
        if (   $info['approval_status']=="审批驳回")
        {
           // $studentInfo['student_authenticated']="0";
            $content = "尊敬的{$studentInfo['true_name']}，您提交的律师资料被驳回审核，审核信息为:{$info['approval_message']}。";
            A('Public')->sendShortMsg($mobile, $content);

        }

        redirect("/Admin/LawyerProfile/index");
        //  var_dump($info);
    }
}