<?php
namespace Admin\Controller;

use Think\Controller;

class PublicController extends ExtendController
{

	//百度地图
	public function selectMap()
	{

		$this->display();
	}

	//选择学院
	public function selectSchool()
	{
		$school_name = I('get.school_name');
		if (!empty($school_name)) {
			$where['school_name'] = array('like', '%' . trim($school_name) . '%');
		}

		$order = 'sort desc,id desc';
		$this->getList('school', '*', $where, $order, 6, 'selectSchool');
		//活动类型

	}

	//选择老师
	public function selectTeacher()
	{
		$teacher_name = I('get.teacher_name');
		$teacher_mobile_phone = I('get.teacher_mobile_phone');
		if (!empty($teacher_name)) {
			$where['teacher_name'] = array('like', '%' . trim($teacher_name) . '%');
		}
		if (!empty($teacher_mobile_phone)) {
			$where['teacher_mobile_phone'] = array('like', '%' . trim($teacher_mobile_phone) . '%');
		}

		$order = 'id desc';
		$this->getList('school_teacher', '*', $where, $order, 6, 'selectTeacher');
		//活动类型

	}

	//选择课程
	public function selectCourse()
	{
		$id = I('get.id');
		$name = I('get.name');
		if (!empty($id)) {
			$where['id'] = $id;
		}
		if (!empty($name)) {
			$where['name'] = array('like', '%' . trim($name) . '%');
		}

		$order = 'id desc';
		$this->getList('school_course', '*', $where, $order, 8, 'selectCourse');
		//活动类型

	}

	//发送短信
	public function sendShortMsg($mobile_phone, $content)
	{
		\Think\Log::write("send msg to $mobile_phone, content:{$content}", 'INFO');
		vendor('yzm.cShortMsg');
		return \cShortMsg::sendMsg($mobile_phone, $content);
	}
	/**
	 * [getEdit 新增修改]
	 * @param [string] $table 数据表，小写]
	 */
	public function getEdit($table)
	{
		$editType = !empty($_GET['t']) ? 'update' : 'create';

		if ($editType == 'update') {
			$foodType = M($table);
			$data = $foodType->find($_GET['t'] + 0);
		
				$this->assign('data', $data);
		}

		$this->assign('editType', $editType);
	}

	/**
	 * [getList 查询记录并分页]
	 * @param [string] $table 数据表，小写]
	 * @param [string or array] $where 条件
	 * @param [string or array] $order 排序
	 * @param [number] $limit 每页显示个数
	 * @param [string] $fun 方法名
	 */
	public function getList($table, $field, $where, $order, $limit, $fun)
	{
		$foodType = D($table);
		$count = $foodType->where($where)->count();
		$Page = new \Think\Page($count, $limit);
		$show = $Page->show();
		$list = $foodType->relation(true)->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();
		$this->assign('list', $list);
		$this->assign('page', $show);
		//dump($list);
		$this->display($fun);
	}

	/**
	 * [getJson 查询记录并分页]
	 * @param [string] $table 数据表，小写]
	 * @param [string or array] $where 条件
	 * @param [string or array] $order 排序
	 * @param [number] $limit 每页显示个数
	 */
	public function getJson($table, $field, $where, $order, $limit)
	{
		$foodType = D($table);
		$count = $foodType->where($where)->count();
		$Page = new \Think\Page($count, $limit);
		$show = $Page->show();
		$list = $foodType->relation(true)->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();
		return json_encode($list);

	}

	public function getArray($table, $field, $where, $order, $limit)
	{
		$foodType = D($table);
		$count = $foodType->where($where)->count();
		$Page = new \Think\Page($count, $limit);
		$show = $Page->show();
		$list = $foodType->relation(true)->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();
		$this->assign('page', $show);
		return $list;
	}

	public function arrayToJson($array)
	{
		return json_encode($array);
	}

	public function strToArr($str, $fuhao)
	{
		if ($str) {
			return explode($fuhao, $str);
		}

	}

	//查询某个表中的某些字段是否同时存在
	public function getRepeat($table, $array)
	{

		foreach ($array as $k => $v) {
			$where[$k] = $v;
		}
		$data = D($table)->where($where)->find();
		if ($data) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 *    排序
	 * @param [string] $moren 默认排序
	 * @param [array] $array 数组，键为表字段，值为排序
	 * @param [string] $array 如果没有对比的值
	 */
	public function getOrder($moren, $array, $all)
	{
		$order = '';
		foreach ($array as $k => $v) {
			if ($v != $all) {
				$order .= $k . ' ' . $v . ',';
			}
		}
		if ($order == '') {
			$order = $moren;
		} else {
			$order = trim($order, ',');
		}
		return $order;
	}

	//获取该用户的店铺
	public function getShop()
	{
		$user_id = $_POST['id'];
		$data = M('shop')->where(array('user_id' => $user_id))->select();
		echo json_encode($data);

	}


	//获取该数据有没有，如果有则复制给视图
	public function setValue($data, $name, $default)
	{

		if ($data) {
			$this->assign($name, $data);
		} else {
			$this->assign($name, $default);
		}

	}

	//所属学院下拉选择框
	public function assignSchoolSelect($group_id)
	{
		//所属组
		$this->assign('school_name', A('GetSelect')->getDtoS('school', 1, 'sort desc,id desc', 'id', 'school_name', $group_id, 'school_name', array(0, ' 学院选择 ')));
	}

	
	//开启推送
	public function cnlSocket()
	{
		header('Content-type:text/html;charset=utf-8');
		$course_id = I('get.course');
		//查询当前课程状态
		$retdata = M('school_course')->field('is_socket,is_open_socket')->where(array('id'=>$course_id))->find();


		//如果已经开启了则关闭
		if($retdata['is_socket']){
			$save['is_socket'] = 0;
			M('school_course')->where(array('id'=>$course_id))->save($save);
			echo  "现在已关闭";
			die;
		}else{
			$save['is_socket'] = 1;

			M('school_course')->where(array('id'=>$course_id))->save($save);

			echo  "现在已开启";
			//如果已经开启过socket则不重复开启
			if(!$retdata['is_open_socket']){
				//标记为已经开启过socket服务
				$save2['is_open_socket'] = 1;
				M('school_course')->where(array('id'=>$course_id))->save($save2);
				
//				$client = stream_socket_client('tcp://' . $this->get_server_ip() . ':7273');
//				if (!$client) exit("can  not connect");
//				ignore_user_abort();// 即使Client断开(如关掉浏览器)，PHP脚本也可以继续执行.
//				set_time_limit(0); // 执行时间为无限制，php默认的执行时间是30秒，通过set_time_limit(0)可以让程
//				$use_time = 0;
//				while ($use_time<(3600*24*30)) {
//					//查询一条信息
//					$data = D('school_course_send_msg')->getMsg($course_id);
//					if ($data) {
//						fwrite($client, '{"type":"send","course_id":"' . $course_id . '","content":"{ \"type\":\"courseMsg\",\"head_img\":\"' . $data['head_img'] . '\",\"user_id\":\"' . $data['student_id'] . '\",\"content\":\"' . $data['msg'] . '\"}"}' . "\n");
//						D('school_course_send_msg')->delMsg($course_id);
//					}
//					$use_time++;
//
//
//					sleep(1); //让循环每次睡眠一秒，防止服务器死掉
//				}
				$save['is_socket'] = 0;
				M('school_course')->where(array('id'=>$course_id))->save($save);
			}

			
			
		}
	}
	/**
	* 获取服务器端IP地址
	 * @return string
	 */
	public function get_server_ip() {
return '';
		//return '120.24.36.108';
		//return '123.56.232.35';

		if (isset($_SERVER)) { 
			if($_SERVER['SERVER_ADDR']) {
				$server_ip = $_SERVER['SERVER_ADDR']; 
			} else { 
				$server_ip = $_SERVER['LOCAL_ADDR']; 
			} 
		} else { 
			$server_ip = getenv('SERVER_ADDR');
		} 
		return $server_ip; 
	}

}