<?php
namespace Admin\Controller;

use Think\Controller;

//打赏管理
class RewardController extends ExtendController
{
	private $rewardNum = 20;//打赏列表每页显示个数
	private $rewardTeacherNum = 8;//打赏对象每页显示个数
	private $rewardLuckDrawNum = 8;//打赏抽奖奖品每页显示个数

//-----------------------------------------------------------------------------------------用户打赏列表
	/**
	 * 列举打赏列表
	 */
	public function reward()
	{
		$reward_id = I('get.t');
		$this->assign('reward_id', $reward_id);

		$begin_time = !empty($_GET['begin_time']) ? $_GET['begin_time'] : 'all';
		$end_time = !empty($_GET['end_time']) ? $_GET['end_time'] : 'all';
		$teacher_id = !empty($_GET['teacher_id']) ? $_GET['teacher_id'] : 'all';

		$moneyone = $_GET['moneyone'];
		$moneytwo = $_GET['moneytwo'];

		//时间区间查询
		if ($begin_time != 'all' && $begin_time != 'NaN' && $end_time != 'all' && $end_time != 'NaN') {
			$btime = getBeginTimeAndEndTime(chen_show_time($begin_time), chen_show_time($end_time));
			$where['this.time'] = array('between', $btime);
			$this->assign('begin_time', $begin_time);
			$this->assign('end_time', $end_time);
		}

		if (($moneyone === '0' || !empty($moneyone)) && !empty($moneytwo)) {
			$where['this.price'] = array('between', array($moneyone, $moneytwo));
			$this->assign('moneyone', $moneyone);
			$this->assign('moneytwo', $moneytwo);
		}

		if ($teacher_id != 'all') {
			$where['this.teacher_id'] = $teacher_id;
			$this->assign('teacher_id', $teacher_id);
		}


		//查询这个打赏的打赏对象
		$reward_obj_field = 'this.teacher_id,sc_t.teacher_name';
		$reward_obj_where['system_reward_id'] = $reward_id;
		$reward_obj_join = 'as this left join ' . C('DB_PREFIX') . 'school_teacher as sc_t on this.teacher_id = sc_t.id ';
		$reward_obj = M('system_reward_teacher')->join($reward_obj_join)->field($reward_obj_field)->where($reward_obj_where)->select();
		$this->assign('reward_obj', $reward_obj);

		$sc = D('school_course_reward');
		$join = 'as this left join ' . C('DB_PREFIX') . 'school_teacher as sc_t on this.teacher_id = sc_t.id ';
		$join .= ' left join ' . C('DB_PREFIX') . 'student_pay_record as pay on this.reward_id = pay.pay_info_id ';

		$where['this.system_reward_id'] = $reward_id;
		$field = 'this.price as reward_price,this.static_true_name as reward_static_true_name,this.static_mobile_phone as reward_static_mobile_phone,this.static_msg as reward_static_msg,this.course_id,this.teacher_id,sc_t.teacher_head_img,sc_t.teacher_name,this.time,pay.pay_number,pay.transaction_id';

		$count = $sc->join($join)->where($where)->count();
		$Page = new \Think\Page($count, $this->rewardNum);
		$show = $Page->show();
		$order = 'time desc';

		$list = $sc->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();

		if (empty($list)) {
			\Think\Log::record('Reward list is empty, sql:' . $sc->getLastSql() . " err:" . $sc->getDbError(), 'INFO');
		}

		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('reward');
	}

	//打赏学生列表
	public function rewardGroupStudent()
	{
		$reward_id = I('get.t');
		$this->assign('reward_id', $reward_id);
		
		$this->assign('course_id',M('system_reward')->where(array(
			'id'=>$reward_id
		))->getField('other_id'));

		$moneyone = $_GET['moneyone'];
		$moneytwo = $_GET['moneytwo'];
		$teacher_id = !empty($_GET['teacher_id']) ? $_GET['teacher_id'] : 'all';
		if (($moneyone === '0' || !empty($moneyone)) && !empty($moneytwo)) {
			$having = 'sum(this.price) >=' . $moneyone . ' and sum(this.price) <=' . $moneytwo;
			$this->assign('moneyone', $moneyone);
			$this->assign('moneytwo', $moneytwo);
		}
		
		if ($teacher_id != 'all') {
			$where['this.teacher_id'] = $teacher_id;
			$this->assign('teacher_id', $teacher_id);
		}
		//查询这个打赏的打赏对象
		$reward_obj_field = 'this.teacher_id,sc_t.teacher_name';
		$reward_obj_where['system_reward_id'] = $reward_id;
		$reward_obj_join = 'as this left join ' . C('DB_PREFIX') . 'school_teacher as sc_t on this.teacher_id = sc_t.id ';
		$reward_obj = M('system_reward_teacher')->join($reward_obj_join)->field($reward_obj_field)->where($reward_obj_where)->select();
		$this->assign('reward_obj', $reward_obj);
		

		$where['this.system_reward_id'] = $reward_id;
		$sc = D('school_course_reward');
		$join = 'as this left join ' . C('DB_PREFIX') . 'student as st on this.student_id = st.id ';
		$group = 'this.student_id';
		$field = 'this.price as reward_price,this.static_true_name as reward_static_true_name,this.static_mobile_phone as reward_static_mobile_phone,this.static_msg as reward_static_msg,this.course_id,this.teacher_id,this.time,st.school_student_number,st.company_name,this.student_id,count(this.reward_id) as reward_count,sum(this.price) as money';

		$count = count($sc->field('this.reward_id')->join($join)->where($where)->group($group)->having($having)->select());
		$Page = new \Think\Page($count, $this->rewardNum);
		$show = $Page->show();
		$order = 'money desc';

		$list = $sc->join($join)->field($field)->where($where)->group($group)->having($having)->order($order)->limit($Page->firstRow, $Page->listRows)->select();
		foreach($list as $k=>$v){
			//查询是否为抢座VIP
			if(D('student_course')->isRewardVip($v['course_id'],$v['student_id'])){
				$list[$k]['is_vip'] = 1;
			}else{
				$list[$k]['is_vip'] = 0;
			}
		}
		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('rewardGroupStudent');
	}


//-----------------------------------------------------------------------------------------打赏管理
	//打赏管理列表
	public function rewardSetup()
	{
		$sc = D('system_reward');
		$join = 'as this left join ' . C('DB_PREFIX') . 'school_course as sc_c on this.other_id = sc_c.id ';

		$field = 'this.id,this.name,this.description,this.cover,this.other_type,this.time,this.update_time,this.status,this.admin_id,sc_c.id as course_id,sc_c.name as course_name';

		$where = 1;
		$count = $sc->join($join)->where($where)->count();

		$Page = new \Think\Page($count, $this->rewardNum);
		$show = $Page->show();

		$order = 'id desc';

		$list = $sc->relation('admin')->join($join)->field($field)
			->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();

		//\Think\Log::record('rewardSetup, list:' . var_export($list, true), 'INFO');

		foreach ($list as $k => $v) {
			if (empty($v['course_id'])) {
				$v['course_id'] = 0;
			}
        
			$list[$k]['reward_qrcode'] = $this->createRewardQRCode($v['course_id'], $v['id']);
            
			$list[$k]['reward_url'] = S_URL . '/Bz/CourseReward/index/courseId/' . $v['course_id'] . '/rewardId/' . $v['id'];
			//计算该打赏总金额
			$list[$k]['all_money'] = (D('school_course_reward')->getOneRewardAllMoney($v['id'])) + 0;
			//计算该打赏的总人数
			$list[$k]['student_number'] = (D('school_course_reward')->getOneRewardAllStudent($v['id'])) + 0;
			//计算该打赏的总人次
			$list[$k]['all_count'] = (D('school_course_reward')->getOneRewardAllCount($v['id'])) + 0;
		}
		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('rewardSetup');
	}

	//打赏管理新增、修改
	public function rewardSetupEdit()
	{
		A('Public')->getEdit('system_reward');

		$s = M('school_course')->field('name')->where(array('id' => $this->data['other_id']))->find();

		$this->assign('course_name', $s['name']);

		$this->display('rewardSetupEdit');
	}


	//打赏对象列表----------------------------------------------------------------------------------------
	public function rewardTeacher()
	{
		$rewardId = I('get.t');
		$this->assign('reward_id', $rewardId);
		$this->assign('course_id', M('system_reward')->where(array('id' => $rewardId))->getField('other_id'));

		$where['this.system_reward_id'] = $rewardId;
		$st = D('system_reward_teacher');
		
		$join = 'as this left join ' . C('DB_PREFIX') . 'system_reward as sy on this.system_reward_id = sy.id ';
		$join .= 'left join ' . C('DB_PREFIX') . 'school_teacher as teacher on this.teacher_id = teacher.id';
		$count = $st->join($join)->where($where)->count();
		
		$Page = new \Think\Page($count, $this->rewardTeacherNum);
		$show = $Page->show();
		
		$field = 'this.id,this.money,this.count,this.time,this.update_time,this.admin_id,this.status,sy.name as system_reward_name,sy.other_id,teacher.teacher_name,teacher.teacher_head_img,this.teacher_id';
		
		$list = $st->relation('admin')->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();
		
		$this->assign('list', $list);
		$this->assign('page', $show);
		
		$this->display('rewardTeacher');
	}

	//打赏对象增加、编辑
	public function rewardTeacherEdit()
	{
		//打赏ID
		$rewardId = I('get.rewardId');
		$courseId = I('get.course');

		A('Public')->getEdit('system_reward_teacher');

		$this->assign('reward_id', $rewardId);
		$this->assign('course_id', $courseId);

		//查询老师名字
		if ($this->data['teacher_id']) {
			$teacher_info = M('school_teacher')->field('teacher_name,teacher_head_img')->find($this->data['teacher_id']);
			$this->assign('teacher_name', $teacher_info['teacher_name']);
			$this->assign('teacher_head_img', $teacher_info['teacher_head_img']);
		}

		//创建对象状态
		$this->assign('status', A('GetSelect')->getStatusS_n(array(0 => '禁用', 1 => '使用'), $this->data['status'], 'status', '请选择使用状态'));

		$this->assign('reward_type', A('GetSelect')->getStatusS_n(array(0 => '普通打赏', 1 => '打赏抢座'), $this->data['reward_type'], 'reward_type', '请选择打赏类型'));

		$this->display('rewardTeacherEdit');
	}


	//抽奖奖品列表----------------------------------------------------------------------------------------
	public function rewardLuckDraw()
	{
		$rewardId = I('get.t');
		$this->assign('reward_id', $rewardId);


		$where['this.system_reward_id'] = $rewardId;
		$st = D('system_reward_luck_draw');
		$join = 'as this left join ' . C('DB_PREFIX') . 'system_reward as sy on this.system_reward_id = sy.id ';
		$join .= ' left join ' . C('DB_PREFIX') . 'system_reward_teacher as tea on this.reward_obj_id = tea.id ';
		$count = $st->join($join)->where($where)->count();
		$Page = new \Think\Page($count, $this->rewardLuckDrawNum);
		$show = $Page->show();
		$field = 'this.id,this.draw_type,this.draw_cover,this.draw_name,this.draw_description,this.draw_all_number,this.draw_use_number,this.draw_status,this.admin_id,sy.name as reward_name,tea.teacher_id';
		$list = $st->relation('admin')->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();
		foreach($list as $k=>$v){
			$list[$k]['draw_teacher_name'] = M('school_teacher')->where(array('id'=>$v['teacher_id']))->getField('teacher_name');
		}
		$this->assign('list', $list);
		$this->assign('page', $show);
		$this->display('rewardLuckDraw');
	}

	//奖品增加、编辑
	public function rewardLuckDrawEdit()
	{
		//打赏ID
		$rewardId = I('get.rewardId');
		A('Public')->getEdit('system_reward_luck_draw');
		$this->assign('reward_id', $rewardId);
		//该打赏的打赏对象列表
		$this->assign('reward_obj',D('system_reward_teacher')->getRewardObjList($rewardId));
		//创建对象状态
		$this->assign('draw_status', A('GetSelect')->getStatusS_n(array(0 => '禁用', 1 => '使用'), $this->data['draw_status'], 'draw_status', '请选择使用状态'));
		//创建抽奖类型
		$this->assign('draw_type', A('GetSelect')->getStatusS_n(array('按打赏名次抽奖' => '按打赏名次抽奖', '从打赏人员中抽奖' => '从打赏人员中抽奖'), chen_is_empty($this->data['draw_type'], '按打赏名次抽奖'), 'draw_type', '请选择抽奖类型'));
		//创建是否可以重复抽奖
		$this->assign('draw_begin_money_status', A('GetSelect')->getStatusS_n(array(0 => '禁用', 1 => '使用'), $this->data['draw_begin_money_status'], 'draw_begin_money_status', '请选择是否可以重复抽奖'));
		$this->display('rewardLuckDrawEdit');
	}


	//用户得奖列表----------------------------------------------------------------------------------------
	public function rewardLuckDrawStudent()
	{
		$rewardId = I('get.t');
		$this->assign('reward_id', $rewardId);

		$where['this.system_reward_id'] = $rewardId;

		$st = D('system_reward_luck_draw');
		$join = 'as this left join ' . C('DB_PREFIX') . 'system_reward as sy on this.system_reward_id = sy.id ';
		$join .= 'left join ' . C('DB_PREFIX') . 'student_luck_draw as st_l on this.id = st_l.luck_draw_id ';
		$join .= 'left join ' . C('DB_PREFIX') . 'student as st on st_l.student_id = st.id ';

		$count = $st->join($join)->where($where)->count();
		$Page = new \Think\Page($count, 20);
		$show = $Page->show();

		$field = 'this.draw_cover,this.draw_name,sy.name as reward_name,st_l.id,st_l.student_id,st_l.system_reward_id,st_l.wl_number,
		st_l.wl_company,st_l.address,st_l.status,st_l.time,st_l.admin_id,st.true_name as student_true_name,st.mobile_phone as student_mobile_phone';
		$list = $st->relation('admin')->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();

		foreach ($list as $key => $value) {
			$cond = array('system_reward_id' => $value['system_reward_id'], 'student_id' => $value['student_id']);

			$list[$key]['student_true_name'] = M('school_course_reward')->where($cond)->getField('static_true_name');
			$list[$key]['student_mobile_phone'] = M('school_course_reward')->where($cond)->getField('static_mobile_phone');
		}

		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('rewardLuckDrawStudent');
	}

	//用户得奖修改
	public function rewardLuckDrawStudentEdit()
	{
		$rewardId = I('get.rewardId');
		$this->assign('reward_id', $rewardId);
		A('Public')->getEdit('student_luck_draw');
		//创建是否发货
		$this->assign('status', A('GetSelect')->getStatusS_n(array(0 => '未发货', 1 => '已发货'), $this->data['status'], 'status', '请选择发货状态'));
		$this->display('rewardLuckDrawStudentEdit');
	}

	//-----------------------------------------------------------------------------------------大屏显示设置
	//大屏配置
	public function rewardBigScreen()
	{
		$rewardId = I('get.t');
		if (!$rewardId) {
			die;
		}
		D('system_reward_big_screen')->createOne($rewardId);
		$this->assign('reward_id', $rewardId);
		//查询该配置
		$where['system_reward_id'] = $rewardId;
		$this->assign('data', D('system_reward_big_screen')->where($where)->find());
		$this->assign('list_new_show', explode('||', $this->data['list_new_show']));
		//dump($this->data);
		$this->display('rewardBigScreen');
	}

	//生成二维码
	private function createRewardQRCode($course_id, $reward_id)
	{
		$data = S_URL . '/Bz/CourseReward/index/courseId/' . $course_id . '/rewardId/' . $reward_id;
		$level = 'H';// 纠错级别：L、M、Q、H
		$size = 100;// 点的大小：1到10,用于手机端4就可以了
		$path = "./Public/RewardQRCode/" . $reward_id . "/";
		$fileName = $path . $size . '.png';
		A('ChenImg')->mydir($path);
		$short_path = '/Public/RewardQRCode/' . $reward_id . '/' . $size . '.png';
		$all_path = S_URL . $short_path;
		$logo = './Public/Bz/images/logo20160130.png';//准备好的logo图片   
		//if(!is_file($fileName)){

		vendor("phpqrcode.phpqrcode");

		\QRcode::png($data, $fileName, $level, $size);
		if (is_file($logo)) {
			$QR = imagecreatefromstring(file_get_contents($all_path));
			$logo = imagecreatefromstring(file_get_contents($logo));
			$QR_width = imagesx($QR);//二维码图片宽度
			$QR_height = imagesy($QR);//二维码图片高度
			$logo_width = imagesx($logo);//logo图片宽度
			$logo_height = imagesy($logo);//logo图片高度
			$logo_qr_width = $QR_width / 5;
			$scale = $logo_width / $logo_qr_width;
			$logo_qr_height = $logo_height / $scale;
			$from_width = ($QR_width - $logo_qr_width) / 2;
			//重新组合图片并调整大小
			imagecopyresampled($QR, $logo, $from_width, $from_width, 0, 0, $logo_qr_width,
				$logo_qr_height, $logo_width, $logo_height);
		}

		//输出图片
		imagepng($QR, $fileName);
		//}	    
		return $short_path;
	}

	//下载二维码
	function downloadFile()
	{
		$file = '.' . I('get.path');
		if (is_file($file)) {
			$length = filesize($file);
			$showname = ltrim(strrchr($file, '/'), '/');
			$showname = I('get.name') . '二维码' . $showname;
			header("Content-Description: File Transfer");
			header('Content-type: image/png');
			header('Content-Length:' . $length);
			if (preg_match('/MSIE/', $_SERVER['HTTP_USER_AGENT'])) { //for IE
				header('Content-Disposition: attachment; filename="' . rawurlencode($showname) . '"');
			} else {
				header('Content-Disposition: attachment; filename="' . $showname . '"');
			}
			readfile($file);
			exit;
		} else {
			exit('Does not exist');
		}
	}

	//数据统计
	public function rewardCount()
	{
		$rewardId = I('get.t');
		$this->assign('reward_id', $rewardId);

		//计算该打赏总金额
		$rewardCount['all_money'] = (D('school_course_reward')->getOneRewardAllMoney($rewardId)) + 0;
		//计算该打赏的总人数
		$rewardCount['student_number'] = (D('school_course_reward')->getOneRewardAllStudent($rewardId)) + 0;
		//计算该打赏的总人次
		$rewardCount['all_count'] = (D('school_course_reward')->getOneRewardAllCount($rewardId)) + 0;

		//微信支付
		$rewardCount['wx_all_money'] = (D('school_course_reward')->getOneRewardAllMoney($rewardId, '微信支付')) + 0;
		$rewardCount['wx_student_number'] = (D('school_course_reward')->getOneRewardAllStudent($rewardId, '微信支付')) + 0;
		$rewardCount['wx_all_count'] = (D('school_course_reward')->getOneRewardAllCount($rewardId, '微信支付')) + 0;

		//支付宝支付
		$rewardCount['zfb_all_money'] = (D('school_course_reward')->getOneRewardAllMoney($rewardId, '支付宝支付')) + 0;
		$rewardCount['zfb_student_number'] = (D('school_course_reward')->getOneRewardAllStudent($rewardId, '支付宝支付')) + 0;
		$rewardCount['zfb_all_count'] = (D('school_course_reward')->getOneRewardAllCount($rewardId, '支付宝支付')) + 0;

		$this->assign('rewardCount', $rewardCount);
		$this->display('rewardCount');
	}

	//返回AJAX数据
	public function getAjaxReward()
	{
		$begin_time = I('get.begin_time');
		$end_time = I('get.end_time');
		$number = I('get.number');
		$reward_id = I('get.reward_id');

		$where['system_reward_id'] = $reward_id;
		$where['time'] = array('between', array($begin_time, $end_time));
		$sc = D('school_course_reward');
		$group = 'student_id';
		$order = 'money desc';
		$field = 'static_true_name,static_mobile_phone,sum(price) as money,count(reward_id) as reward_count';
		$list = $sc->field($field)->where($where)->group($group)->order($order)->limit($number)->select();
		if ($list) {
			$this->ajaxReturn(array('ret' => 'true', 'list' => $list));
		} else {
			$this->ajaxReturn(array('ret' => 'false'));
		}

	}
	
	//设置打赏专座人员
	public function setRewardVip(){
		if (D('student_course')->setMoreVip()) {
			echo 'true';
		} else {
			echo 'false';
		}
	}
	
	//取消打赏专座人员
	public function delRewardVip(){
		if (D('student_course')->delMoreVip()) {
			echo 'true';
		} else {
			echo 'false';
		}
	}
	
	//添加打赏里面的老师
	public function teacherListEdit()
	{
		//课程ID
		$reward_id = I('get.rewardId');
		$this->assign('reward_id', $reward_id);
		$this->display('teacherListEdit');
	}

}