<?php
namespace Admin\Controller;

use Think\Controller;

class SubmitController extends ExtendController
{


    public function editColumns() {
        $where['id'] = I('post.id');

        $obj = D("Columns");

        $data = $obj->create();
        if (!$data) {
            $this->error($obj->getError());
        }

        if ($_POST['editType'] == 'update') {
            if ($obj->save()) {
                if (!true) {
                    $this->success('修改成功');
                } else {
                    $this->success('修改成功', '/Admin/' . 'Columns/columns');
                }
            } else {
                $this->error('修改失败');
            }
        } else if ($_POST['editType'] == 'create') {
            if ($obj->add()) {
                $this->success('新增成功', '/Admin/' . 'Columns/columns');
            } else {
                $this->error('新增失败');
            }
        }
    }

    public function editColumnist() {
        $obj = $this->chenUpload('./Upload/HeadImg/');
        $where['id'] = I('post.id');
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename2 = $datadir . '/' . $obj['file']['savename'];
            $savename = S_URL . '/Public/Upload/HeadImg/' . $datadir . '/' . $obj['file']['savename'];
            $yuan = './Public/Upload/HeadImg/' . $savename2;
            A('ChenImg')->imagecropper($yuan, $yuan, 200, 200);

            $this->chenEditImg('columnist', $where, 'Columns/columnist', array('columnist_head_img'), array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'columnist', $where, 'Columns/columnist', true);
        }
    }

    public function editColumnsArticle() {
        $obj = $this->chenUpload('./Upload/Article/');
        $where['id'] = I('post.id');
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename = S_URL . '/Public/Upload/Article/' . $datadir . '/' . $obj['file']['savename'];
            $this->chenEditImg('ColumnsArticle', $where, 'Columns/article', array('thumb'), array($savename), false);
        } else {
            $this->chengIsNoImg($obj, 'ColumnsArticle', $where, 'Columns/article', true, false);
        }
    }


//-----------------------------------------------------------------------------管理员 begin

    //管理员
    public function editAdmin()
    {

        $where['id'] = I('post.id');

        $obj = D("admin");

        $data = $obj->create();
        if (!$data) {
            $this->error($obj->getError());
        }
        $rights = implode(',', $_POST['rights']);

        $data["rights"] = $rights;


        if ($_POST['editType'] == 'update') {
            if ($obj->where($where)->save($data)) {
                if (!true) {
                    $this->success('修改成功');
                } else {
                    $this->success('修改成功', '/Admin/' . 'Admin/admin');
                }
            } else {
                $this->error('修改失败');
            }
        } else if ($_POST['editType'] == 'create') {
            if ($obj->add($data)) {
                $this->success('新增成功', '/Admin/' . 'Admin/admin');
            } else {
                $this->error('新增失败');
            }
        }


    }

    //管理员分组
    public function editAdminGroup()
    {
        $where['id'] = I('post.id');
        $this->chenEdit('admin_group', $where, 'Admin/adminGroup', true);
    }
//-----------------------------------------------------------------------------管理员 end


//-----------------------------------------------------------------------------页面设置 begin

    //登录界面
    public function editLogin()
    {
        $where['id'] = I('post.id');
        $this->chenEdit('html_login_content', $where, 'Show/login', true);
    }

    //登录界面提示不能上课务必要请假
    public function editLogin2()
    {
        $where['id'] = I('post.id');
        $this->chenEdit('html_login_submit', $where, 'Show/login2', true);
    }

    //预约成功界面
    public function editSuccessOne()
    {

        $obj = $this->chenUpload('./Upload/QRcode/');
        $where['id'] = I('post.id');
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename = S_URL . '/Public/Upload/QRcode/' . $datadir . '/' . $obj['file']['savename'];
            $this->chenEditImg('html_system_text_setup', $where, 'Show/successOne', array('img'), array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'html_system_text_setup', $where, 'Show/successOne', true);
        }

    }

//-----------------------------------------------------------------------------页面设置 end


//-----------------------------------------------------------------------------学院管理 begin
    //学院管理
    public function editSchoolList()
    {

        $obj = $this->chenUpload('./Upload/SchoolLogo/');
        $where['id'] = I('post.id');
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename = $datadir . '/' . $obj['file']['savename'];
            //生成缩略图，不保存原图默认大小为200*200
            $this->createSmallImg('./Public/Upload/SchoolLogo/' . $savename);
            $this->chenEditImg('school', $where, 'School/schoolList', array('school_logo'), array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'school', $where, 'School/schoolList', true);
        }

    }

    //老师管理
    public function editTeacherList()
    {
        $obj = $this->chenUpload('./Upload/HeadImg/');
        $where['id'] = I('post.id');
        $school_id = I('post.school_id');
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename2 = $datadir . '/' . $obj['file']['savename'];
            $savename = S_URL . '/Public/Upload/HeadImg/' . $datadir . '/' . $obj['file']['savename'];
            $yuan = './Public/Upload/HeadImg/' . $savename2;
            A('ChenImg')->imagecropper($yuan, $yuan, 200, 200);

            $this->chenEditImg('school_teacher', $where, 'School/teacherList/s/' . $school_id, array('teacher_head_img'), array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'school_teacher', $where, 'School/teacherList/s/' . $school_id, true);
        }

    }


//-----------------------------------------------------------------------------学院管理 end

//-----------------------------------------------------------------------------课程 begin

    //课程管理
    public function editCourseList()
    {
        $begin_time = I('post.begin_time');
        $end_time = I('post.end_time');
        if (strtotime($begin_time) > strtotime($end_time)) {
            $this->error('结束时间不能小于开始时间');
        }
        $where['id'] = I('post.id');
        $table = 'school_course';
        $obj = D($table);
        $url = 'Course/courseList';
        $isdumplist = true;
        if (!$obj->create()) {
            $this->error($obj->getError());
        }
        if (I('post.is_online')) {
            $obj->is_online = 1;
        } else {
            $obj->is_online = 0;
        }
        if (I('post.is_scene')) {
            $obj->is_scene = 1;
        } else {
            $obj->is_scene = 0;
        }
        if ($_POST['editType'] == 'update') {
            $use_number = I('post.use_number_hidden');
            $all_number = I('post.all_number');
            if ($all_number < $use_number) {
                $this->error('现场名额不能低于已经使用的名额');
            }
            if ($obj->where($where)->save()) {
                if (!$isdumplist) {
                    $this->success('修改成功');
                } else {
                    $this->success('修改成功', '/Admin/' . $url);
                }
            } else {
                $this->error('修改失败');
            }
        } else if ($_POST['editType'] == 'create') {
            if ($obj->add()) {
                $this->success('新增成功', '/Admin/' . $url);
            } else {
                $this->error('新增失败');
            }
        }


    }

    /**
     * add or edit activity
     *
     * @param $id
     */
    public function addOrEditActivity($id = 0)
    {
        $begin_time = I('post.begin_time');
        $end_time = I('post.end_time');
        $leave_begin_time = I('post.leave_begin_time');
        $leave_end_time = I('post.leave_end_time');

        $start_sign_up_time = I('post.start_sign_up_time');
        if (strtotime($begin_time) > strtotime($end_time)) {
            $this->error('结束时间不能小于开始时间');
        }
        if (strtotime($leave_begin_time) > strtotime($leave_end_time)) {
            $this->error('请假结束时间不能小于请假开始时间');
        }
        $begin_time = strtotime($begin_time);
        $end_time = strtotime($end_time);
        $leave_begin_time = strtotime($leave_begin_time);
        $leave_end_time = strtotime($leave_end_time);
        $start_sign_up_time = strtotime($start_sign_up_time);

        $name = I('post.name');
        $address = I('post.address');
        $detail_address = I('post.detail_address');
        $relate_course_id = I('post.relate_course_id');
        $activity_type = I('post.activity_type');
        $one_status = I('post.one_status');
        $school_course_status = I('post.school_course_status'); //2016-2-29 状态
        $description = I('post.description');
        $href_question_to_teacher = I('post.href_question_to_teacher'); //2016-2-29 向老师提问链接
        $href_course_score = I('post.href_course_score');   //2016-2-29 评分链接
        $href_do_homework = I('post.href_do_homework'); //2016-2-29 做作业链接
        $is_can_false = I('post.is_can_false'); //2016-2-29 请假
        $video_status = I('post.video_status');
        $black_list = I('post.black_list');

        $video_url = I('post.video_url');
        $video_title = I('post.video_title');
        $learning_objectives = I('post.learning_objectives');
        $suitable_object = I('post.suitable_object');
        $class_preview = I('post.class_preview');

        $growth_value = I('post.growth_value');


        if (I('post.is_online')) {
            $is_online = 1;
        } else {
            $is_online = 0;
        }
        if (I('post.is_scene')) {
            $is_scene = 1;
        } else {
            $is_scene = 0;
        }
        if (I('post.is_hold')) {
            $is_hold = 1;
        } else {
            $is_hold = 0;
        }


        if (empty($relate_course_id)) {
            $relate_course_id = 0;
        }

        if (empty($name) || empty($address) || empty($activity_type)) {
            $this->error('请输入必填的内容');
        }
        if (empty($one_status)) {
            $one_status = 0;
        }

        $cover_img = '';
        $up_info = $this->chenUpload('./Upload/activity/');

        $cover_img = $_POST['Logo'];
        $video_cover = $_POST['video_cover'];
        // if (is_array($up_info)) {
        // $datadir = date('Ym');
        // $cover_img = '/Public/Upload/activity/' . $datadir . '/' . $up_info['cover_img']['savename'];
        // $yuan = './Public/Upload/activity/' . $datadir . '/' . $up_info['cover_img']['savename'];
        // A('ChenImg')->imagecropper($yuan, $yuan, 508, 315);
        // }

        if (is_array($up_info)) {
            $datadir = date('Ym');
            if ($up_info['cover_img_file']) {
                $cover_img = '/Public/Upload/activity/' . $datadir . '/' . $up_info['cover_img_file']['savename'];
                $yuan = './Public/Upload/activity/' . $datadir . '/' . $up_info['cover_img_file']['savename'];
                A('ChenImg')->imagecropper($yuan, $yuan, 508, 315);
            }
            if ($up_info['video_cover_file']) {
                $video_cover = S_URL . '/Public/Upload/activity/' . $datadir . '/' . $up_info['video_cover_file']['savename'];
            }
        }

        $where['id'] = $id;
        $obj_sc = D('school_course');
//		$obj_sc = D('activity');    //修改，直接读取activity表 2016-2-29

        $is_update = empty($id) ? false : true;

        $place_list = $_POST['place_list'];

        $school_id = M('school_course')->where('id = ' . $relate_course_id)->getField('school_id');
//		$leave_end_time = I('post.leave_end_time');
//		$start_sign_up_time = I('post.start_sign_up_time');

        if (empty($id)) {
            $data = array(
                'name' => $name,
                'begin_time' => $begin_time,
                'end_time' => $end_time,
                'leave_begin_time' => $leave_begin_time,
                'leave_end_time' => $leave_end_time,
                'type' => 1,    // 0. 线下大课，1.活动
                'school_course_status' => $school_course_status,    //状态 2016-2-29
                'time' => time(),
                'address' => $address,
                'detail_address' => $detail_address,
                'relate_course_id' => $relate_course_id,
                'activity_type' => $activity_type,
                'one_status' => $one_status,  //是否开启当场购买
                'cover_img' => $cover_img,
                'description' => $description,
                'href_question_to_teacher' => $href_question_to_teacher,    //2016-2-29 向老师提问链接
                'href_course_score' => $href_course_score,  //2016-2-29 评分链接
                'href_do_homework' => $href_do_homework,    //2016-2-29 做作业链接
                'is_can_false' => $is_can_false,    //2016-2-29 请假
                'school_id' => $school_id,    //关联学院id
//                'one_status' => $one_status,    //是否开启当场购买
                'video_status' => $video_status,//直播状态
                'is_online' => $is_online,//是否直播
                'is_scene' => $is_scene,//是否现场
                'is_hold' => $is_hold,//是否火
                'black_list' => $black_list,

                'video_cover' => $video_cover,
                'video_url' => $video_url,
                'video_title' => $video_title,
                'learning_objectives' => $learning_objectives,
                'suitable_object' => $suitable_object,
                'class_preview' => $class_preview,
                'start_sign_up_time' => $start_sign_up_time,
                'growth_value'=>$growth_value,
            );

            $ins_id = $obj_sc->add($data);
            // update
            $this->update_activity_place($ins_id, $place_list);
        } else {
            $data = array(
                'update_time' => time(),
                'name' => $name,
                'leave_begin_time' => $leave_begin_time,
                'leave_end_time' => $leave_end_time,
                'begin_time' => $begin_time,
                'end_time' => $end_time,
                'address' => $address,
                'school_course_status' => $school_course_status,    //状态 2016-2-29
                'detail_address' => $detail_address,
                'relate_course_id' => $relate_course_id,
                'activity_type' => $activity_type,
                'one_status' => $one_status,  //是否开启当场购买
                'cover_img' => $cover_img,
                'description' => $description,
                'href_question_to_teacher' => $href_question_to_teacher,    //2016-2-29 向老师提问链接
                'href_course_score' => $href_course_score,  //2016-2-29 评分链接
                'href_do_homework' => $href_do_homework,    //2016-2-29 做作业链接
                'is_can_false' => $is_can_false,    //2016-2-29 请假
                'school_id' => $school_id,    //关联学院id
//                'one_status' => $one_status,    //是否开启当场购买
                'video_status' => $video_status,//直播状态
                'is_online' => $is_online,//是否直播
                'is_scene' => $is_scene,//是否现场
                'is_hold' => $is_hold,//是否火
                'black_list' => $black_list,

                'video_cover' => $video_cover,
                'video_url' => $video_url,
                'video_title' => $video_title,
                'learning_objectives' => $learning_objectives,
                'suitable_object' => $suitable_object,
                'class_preview' => $class_preview,
                'start_sign_up_time' => $start_sign_up_time,
                'growth_value'=>$growth_value,
            );

            $up_ret = $obj_sc->where($where)->save($data);

            // update
            $this->update_activity_place($id, $place_list);
        }

        if (empty($id)) {
            $id = $ins_id;
        }
        if (I('post.is_next')) {
            $url = "Activity/manage/id/$id";
        } else {
            $url = 'Activity/activity';
        }

        $isdumplist = true;


        if ($is_update) {
            if ($up_ret) {
                if (!$isdumplist) {
                    $this->success('修改成功');
                } else {
                    $this->success('修改成功', '/Admin/' . $url);
                }
            } else {
                $this->error('修改失败');
            }
        } else {
            if ($ins_id) {
                $this->success('新增成功', '/Admin/' . $url);
            } else {
                $this->error('新增失败');
            }
        }
    }

    /**
     * 修改活动分会场的名称和地址
     *
     * @param $id
     * @param $arr_name_address
     */
    public function update_activity_place($id, $arr_name_address)
    {
        if (empty($arr_name_address)) {
            \Think\Log::record(__FUNCTION__ . " id:{$id}, arr:" . var_export($arr_name_address), 'ERR');
        }

        $obj = M('activity_place');
        foreach ($arr_name_address as $key => $value) {
            $name_addr = explode('s|NaN|p', $value);


            //2016-2-29 修改
            $name_address = explode(',', $name_addr[0]);
            if (!empty($name_address[1])) {
                $name_addr[0] = $name_address[0];
                $name_addr[1] = $name_address[1];
            }


            $db_info = $obj->where(array('activity_id' => $id, 'name' => $name_addr[0]))->find();
            if (empty($db_info) || empty($db_info['id'])) {
                // insert
                $data = array(
                    'activity_id' => $id,
                    'name' => empty($name_addr[0]) ? '' : $name_addr[0],
                    'address' => empty($name_addr[1]) ? '' : $name_addr[1],
                );


                $data['type'] = 3;  //2016-2-29 改

                if ($value == '主会场') {
                    $data['type'] = 1;
                }
                if ($value == '直播') {
                    $data['type'] = 2;
                }

                $obj->add($data);
            } else {
                // update
                $data = array();

                if (!empty($name_addr[0])) {
                    $data['name'] = $name_addr[0];
                }

                if ($data['name'] == '主会场' || $data['name'] == '直播') {
                    continue;
                }

                if (!empty($name_addr[1])) {
                    $data['address'] = $name_addr[1];
                }

                if (!empty($data)) {
                    $obj->where(array('id' => $db_info['id'], 'name' => $db_info['name']))->save($data);
                }
            }
        }

        return;
    }

    //修改自定义分享信息
    public function editWxShare()
    {
        //dump($_POST);die;
        //if(empty($_FILES)){
        $obj = $this->chenUpload('./Upload/WxShare/');
        // }

        $where['school_course_id'] = I('post.school_course_id');

        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename2 = $datadir . '/' . $obj['file']['savename'];
            $savename = '/Public/Upload/WxShare/' . $datadir . '/' . $obj['file']['savename'];
            $yuan = './Public/Upload/WxShare/' . $savename2;

            A('ChenImg')->imagecropper($yuan, $yuan, 200, 200);

            $this->chenEditImg('school_course_wx_share', $where, 'Activity/promote/id/' . $where['school_course_id'], array('img'),
                array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'school_course_wx_share', $where, 'Activity/promote/id/' . $where['school_course_id'], true);
        }
    }


    //课程里面的老师管理
    public function editCourseTeacherList()
    {
        $course_id = I('post.course_id');
        $obj = D('school_course_teacher');
        if (!$obj->create()) {
            $this->error($obj->getError());
        }

        //查询该课程里面是否已经选了该老师了
        $where['course_id'] = $course_id;
        $where['teacher_id'] = I('post.teacher_id');
        if (M('school_course_teacher')->where($where)->count()) {
            $this->error('该老师已经在该课程里面了');
        }


        if ($obj->add()) {
            $this->success('新增成功', '/Admin/ActivityTeacher/teacherList/id/' . $course_id);
        } else {
            $this->error('新增失败');
        }

    }

    //课程里面的老师管理
    public function editRewardTeacherList()
    {

        $reward_id = I('post.reward_id');


       $obj = D('system_reward_teacher');

$teacherid= I('post.teacher_id');

        //查询该课程里面是否已经选了该老师了
        $where['system_reward_id'] = $reward_id;

        $where['teacher_id'] = I('post.teacher_id');
        $count=M('system_reward_teacher')->where($where)->count();

        if ($count) {
            $this->error('该老师已经在该打赏里面了');
        }




        //如果该对象设置为启用则更新其他该打赏的打赏对象的状态为禁用
        if ( $reward_id) {
            $savestatus['status'] = 0;
            $savestatus['update_time'] = time();
            $savestatus['admin_id'] = session('adminid');

            $wherestatus['system_reward_id'] = $reward_id;
            M('system_reward_teacher')->where($wherestatus)->save($savestatus);
        }

        $new=array();
        $new['status'] = 1;
        $new['update_time'] = time();
     $new['time'] = time();
        $new['admin_id'] = session('adminid');
        $new['teacher_id']=$teacherid;
        $new['system_reward_id']=$reward_id;


        if ($obj->add($new)) {
            $this->success('新增成功', '/Admin/Reward/rewardTeacher/t/' . $reward_id);
        } else {
            $this->error('新增失败');
        }

    }

    //PPT管理
    public function editPPTList()
    {
        $course_id = I('post.course_id');
        $obj = $this->chenUpload('./Upload/CoursePPT/');
        $where['id'] = I('post.id');
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename2 = $datadir . '/' . $obj['file']['savename'];
            $savename = S_URL . '/Public/Upload/CoursePPT/' . $datadir . '/' . $obj['file']['savename'];
            $yuan = './Public/Upload/CoursePPT/' . $savename2;
            A('ChenImg')->imagecropper($yuan, $yuan, 750, 433);

            $this->chenEditImg('school_course_ppt', $where, 'Course/pptList/course/' . $course_id, array('img'), array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'school_course_ppt', $where, 'Course/pptList/course/' . $course_id, true);
        }

    }


    //批量上传PPT
    public function editPPTListMore()
    {
        header('Content-type:text/html;charset=utf-8');
        $course_id = I('post.course_id');

        $obj = $this->chenUpload('./Upload/CoursePPT/');


        if (is_array($obj)) {
            $datadir = date('Ym');
            foreach ($obj as $k => $v) {
                $yuan = './Public/Upload/CoursePPT/' . $datadir . '/' . $v['savename'];
                A('ChenImg')->imagecropper($yuan, $yuan, 750, 433);
                $data[$k]['img'] = S_URL . '/Public/Upload/CoursePPT/' . $datadir . '/' . $v['savename'];
                $data[$k]['course_id'] = $course_id;
                $data[$k]['time'] = time();
                $data[$k]['admin_id'] = session('adminid');
            }

        } else {
            $this->error('请选择图片');
        }
        if (D('school_course_ppt')->addAll($data)) {
            $this->success('添加成功', '/Admin/Course/pptList/course/' . $course_id);
        } else {
            $this->error('添加失败');
        }


    }


    //课程的座位添加
    public function addCourseSeatList()
    {
        $obj = D('school_course_seat');
        if (!$obj->create()) {
            $this->error($obj->getError());
        }
        //生成座位号
        $one_number = I('post.one_number');
        $two_number = I('post.two_number');

        $data['course_id'] = I('post.course_id');
        $data['activity_place_id'] = I('post.activity_place_id');
        $data['one_number'] = $one_number;
        $data['two_number'] = $two_number;
        $data['status'] = I('post.status');
        $data['address'] = I('post.address');
        $data['address_time'] = strtotime(I('post.address_time'));
        $data['time'] = time();
        $data['admin_id'] = session('adminid');
        D()->startTrans();

        $id = D('school_course_seat')->add($data);
        for ($i = 1; $i <= $one_number; $i++) {
            for ($m = 1; $m <= $two_number; $m++) {
                $addData['one'] = $i;
                $addData['two'] = $m;
                $addData['address'] = $i . '排' . $m . '号';
                $addData['admin_id'] = session('adminid');
                $addData['school_course_seat_id'] = $id;
                $addData['update_time'] = time();
                $addAll[] = $addData;
            }
        }
        $ret1 = D('SchoolCourseSeatList')->addAll($addAll);
        if ($id && $ret1) {
            D()->commit();
            $this->success('添加成功', '/Admin/Course/courseSeatListEdit/t/' . $id);
        } else {
            D()->rollback();
            $this->error('添加失败');
        }


    }

    //课程的座位修改
    public function editCourseSeatList()
    {

        $id = I('post.school_course_seat_id');
        //查询该课程的位置
        $where['school_course_seat_id'] = $id;

        $save['seat_array'] = $seat_array;
        $save['status'] = I('post.status');
        $save['address'] = I('post.address');
        $save['address_time'] = strtotime(I('post.address_time'));
        $save['update_time'] = time();
        $save['admin_id'] = session('adminid');
        $ids = $_POST;
        D()->startTrans();
        $istrue = true;
        foreach ($ids as $k => $v) {
            if (is_numeric($k)) {
                $retids = D('SchoolCourseSeatList')->where(array(
                    'id' => $k
                ))->save(array(
                    'status' => $v,
                    'update_time' => time(),
                    'admin_id' => session('adminid')
                ));
                if (!$retids) {
                    $istrue = false;
                }

            }
        }

        $ret1 = D('school_course_seat')->where($where)->save($save);
        if ($istrue && $ret1) {
            D()->commit();
            $this->success('修改成功');
        } else {
            D()->rollback();
            $this->error('修改失败');
        }


    }

    //课程F码
    public function editStudentFcodeList()
    {
        $where['id'] = I('post.id');
        $this->chenEdit('student_course_fcode', $where, 'Course/studentFcodeList/course/' . I('post.course_id'), true);
    }

    //分配F码给学生
    public function editStudentFcodeDistribution()
    {
        $course_id = I('post.course_id');
        //查询该课程未使用的F码
        $fcode_data = D('school_course_fcode')->getFcodeList($course_id);
        if (!$fcode_data) {
            $this->error('抱歉，该课程查询不到可用的F码，请先导入');
            die;
        }
        //查询需要分配F码的学生
        $data = D('student_course')->getNeedFcodeStudent($course_id);
        foreach ($data as $k => $v) {
            if ($v['f_code']) {
                unset($data[$k]);
            }
        }
        if (!$data) {
            $this->success('分配成功', '/Admin/Course/studentFcodeList/course/' . $course_id);
            die;
        }
        shuffle($data);
        $count_fcode_data = count($fcode_data);
        $count_data = count($data);
        for ($i = 0; $i < $count_data && $i < $count_fcode_data; $i++) {
            $add[$i]['course_id'] = $course_id;
            $add[$i]['student_id'] = $data[$i]['student_id'];
            $add[$i]['f_code'] = $fcode_data[$i]['f_code'];
            $add[$i]['time'] = time();
            $add[$i]['admin_id'] = session('adminid');

            $saveid[$i] = $fcode_data[$i]['id'];
        }

        D()->startTrans();
        $save['status'] = 1;
        $save['update_time'] = time();
        $save['admin_id'] = session('adminid');
        $where['id'] = array('in', $saveid);
        $ret1 = D('school_course_fcode')->where($where)->save($save);
        $ret2 = D('student_course_fcode')->addAll($add);
        if ($ret1 && $ret2) {
            D()->commit();
            $need_number = $count_data - $count_fcode_data;
            if ($need_number > 0) {
                $errmsg = '成功分配F码给' . $count_fcode_data . '位学生，还缺少F码' . $need_number . '个，请导入！';
            } else {
                $errmsg = '分配成功';
            }
            $this->success($errmsg, '/Admin/Course/studentFcodeList/course/' . $course_id);
        } else {
            D()->rollback();
            $this->error('分配失败');
        }

        //dump($save);
        //dump($add);

    }

//-----------------------------------------------------------------------------课程 end

//-----------------------------------------------------------------------------类型管理 begin
    //行业管理
    public function editVocation()
    {
        $where['student_vocation_id'] = I('post.student_vocation_id');
        $this->chenEdit('student_vocation', $where, 'TypeSetup/vocation', true);
    }

    //职业管理
    public function editPosition()
    {
        $where['student_position_id'] = I('post.student_position_id');
        $this->chenEdit('student_position', $where, 'TypeSetup/position', true);
    }

    //入学模式管理
    public function editApply()
    {
        $where['student_apply_type_id'] = I('post.student_apply_type_id');


        $this->chenEdit('student_apply_type', $where, 'TypeSetup/apply', true);
    }

    //支付类型管理
    public function editPayType()
    {
        $where['student_pay_type_id'] = I('post.student_pay_type_id');
        $this->chenEdit('student_pay_type', $where, 'TypeSetup/payType', true);
    }

    //请假类型管理
    public function editLeaveType()
    {
        $where['student_leave_type_id'] = I('post.student_leave_type_id');
        $this->chenEdit('student_leave_type', $where, 'TypeSetup/leaveType', true);
    }

//-----------------------------------------------------------------------------类型管理 end

//-----------------------------------------------------------------------------课程问题管理 end
    //空调问题配置
    public function editServiceTemperature()
    {
        $obj = $this->chenUpload('./Upload/ServiceTemperatureCover/');
        $courseId = I('post.course_id');
        $where['course_id'] = $courseId;
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename2 = $datadir . '/' . $obj['file']['savename'];
            $savename = S_URL . '/Public/Upload/ServiceTemperatureCover/' . $datadir . '/' . $obj['file']['savename'];
            $yuan = './Public/Upload/ServiceTemperatureCover/' . $savename2;
            A('ChenImg')->imagecropper($yuan, $yuan, 70, 70);

            $this->chenEditImg('school_course_question_temperature', $where, 'Course/serviceList/id/' . $courseId, array('default_img'), array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'school_course_question_temperature', $where, 'Course/serviceList/id/' . $courseId, true);
        }

    }

    //灯光问题配置
    public function editServiceLamp()
    {
        $obj = $this->chenUpload('./Upload/ServiceLamp/');
        $courseId = I('post.course_id');
        $where['course_id'] = $courseId;
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename2 = $datadir . '/' . $obj['file']['savename'];
            $savename = S_URL . '/Public/Upload/ServiceLamp/' . $datadir . '/' . $obj['file']['savename'];
            $yuan = './Public/Upload/ServiceLamp/' . $savename2;
            A('ChenImg')->imagecropper($yuan, $yuan, 70, 70);

            $this->chenEditImg('school_course_question_lamp', $where, 'Course/serviceList/id/' . $courseId, array('default_img'), array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'school_course_question_lamp', $where, 'Course/serviceList/id/' . $courseId, true);
        }

    }

    //音响问题配置
    public function editServiceMusic()
    {
        $obj = $this->chenUpload('./Upload/ServiceMusic/');
        $courseId = I('post.course_id');
        $where['course_id'] = $courseId;
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename2 = $datadir . '/' . $obj['file']['savename'];
            $savename = S_URL . '/Public/Upload/ServiceMusic/' . $datadir . '/' . $obj['file']['savename'];
            $yuan = './Public/Upload/ServiceMusic/' . $savename2;
            A('ChenImg')->imagecropper($yuan, $yuan, 70, 70);

            $this->chenEditImg('school_course_question_music', $where, 'Course/serviceList/id/' . $courseId, array('default_img'), array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'school_course_question_music', $where, 'Course/serviceList/id/' . $courseId, true);
        }

    }

    //饮水问题配置
    public function editServiceWater()
    {
        $obj = $this->chenUpload('./Upload/ServiceWater/');
        $courseId = I('post.course_id');
        $where['course_id'] = $courseId;
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename2 = $datadir . '/' . $obj['file']['savename'];
            $savename = S_URL . '/Public/Upload/ServiceWater/' . $datadir . '/' . $obj['file']['savename'];
            $yuan = './Public/Upload/ServiceWater/' . $savename2;
            A('ChenImg')->imagecropper($yuan, $yuan, 70, 70);

            $this->chenEditImg('school_course_question_water', $where, 'Course/serviceList/id/' . $courseId, array('default_img'), array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'school_course_question_water', $where, 'Course/serviceList/id/' . $courseId, true);
        }

    }

    //用餐问题配置
    public function editServiceFood()
    {
        $obj = $this->chenUpload('./Upload/ServiceFood/');
        $courseId = I('post.course_id');
        $where['course_id'] = $courseId;
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename2 = $datadir . '/' . $obj['file']['savename'];
            $savename = S_URL . '/Public/Upload/ServiceFood/' . $datadir . '/' . $obj['file']['savename'];
            $yuan = './Public/Upload/ServiceFood/' . $savename2;
            A('ChenImg')->imagecropper($yuan, $yuan, 70, 70);

            $this->chenEditImg('school_course_question_food', $where, 'Course/serviceList/id/' . $courseId, array('default_img'), array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'school_course_question_food', $where, 'Course/serviceList/id/' . $courseId, true);
        }

    }


    //食品问题管理
    public function editFood()
    {
        $where['id'] = I('post.id');
        $course_id = I('post.course_id');
        $this->chenEdit('school_course_question_food', $where, 'CourseQuestion/food/course/' . $course_id, true);
    }

    //饮水问题管理
    public function editWater()
    {
        $where['id'] = I('post.id');
        $course_id = I('post.course_id');
        $this->chenEdit('school_course_question_water', $where, 'CourseQuestion/water/course/' . $course_id, true);
    }
//-----------------------------------------------------------------------------课程问题管理 end


//-----------------------------------------------------------------------------短信管理 begin
    //短信模板
    public function editShortMessageTemplateList()
    {
        $where['id'] = I('post.id');
        $this->chenEdit('system_short_message', $where, 'ShortMessage/shortMessageTemplateList', true);
    }

    //短信推送（主动）
    public function editShortMessageSendList()
    {
        header('Content-type:text/html;charset=utf-8');

        $editType = I('post.editType');
        $title = I('post.title');
        $send_obj = I('post.send_obj');
        $content = I('post.content');
        $send_time = I('post.send_time');

        \Think\Log::write(__FUNCTION__ . " send_obj={$send_obj}", 'INFO');


        if ($editType == 'create') {
            $student_data = D('student')->getSendMessageData($send_obj);
            $message_array = D('SystemShortMessageSendRecord')->getMessageListArr($student_data, $content);

            \Think\Log::write(__FUNCTION__ . " student_data=" . var_export($student_data, true), 'INFO');
            \Think\Log::write(__FUNCTION__ . " message_array=" . var_export($message_array, true), 'INFO');
        }


        vendor('yzm.cShortMsg');


        if ($send_time) {
            $timing = $send_time . ':00';
        } else {
            $timing = '';
        }

        $pagenum = 1000;//分批发送个数
        $needCount = ceil(count($message_array) / $pagenum);//分批发送次数
        $needCountBegin = 1;
        foreach ($message_array as $k => $v) {
            if ($k == $needCountBegin * $pagenum) {
                $needCountBegin++;
            }
            $needCountArray[$needCountBegin][] = $v;
        }
        $errorNum = 0;
        $successNum = 0;


        foreach ($needCountArray as $k => $v) {


            $datasend = \cShortMsg::getMessageListStr($v);


            $datasend['timing'] = $timing;
            \Think\Log::write(__FUNCTION__ . " message data to send=" . var_export($datasend, true), 'INFO');

            $send_ret_array = \cShortMsg::sendMsgMoreNew($v);

            \Think\Log::write(__FUNCTION__ . " message data sent ret=" . var_export($send_ret_array, true), 'INFO');

          
            $successNum += $send_ret_array['succeed'];
            $errorNum += $send_ret_array['error'];
            sleep(2);//分批隔时2秒
        }

        $dbdata['title'] = $title;
        $dbdata['content'] = $content;
        $dbdata['send_number'] = $errorNum + $successNum;
        $dbdata['send_time'] = !empty($timing) ? strtotime($timing) : time();//有点事则保持定时的时间，没有则当前时间
        if ($dbdata['send_time'] > time()) {
            $dbdata['status'] = 0;
        } else if ($successNum > 0) {
            $dbdata['status'] = 1;
        } else {
            $dbdata['status'] = 2;
        }

        $dbdata['admin_id'] = session('adminid');
        $dbdata['time'] = time();
        $dbdata['error_num'] = $errorNum;
        $dbdata['success_num'] = $successNum;

        if (M('system_short_message_send_record')->add($dbdata)) {
            $this->success('新增成功', '/Admin/ShortMessage/shortMessageSendList');
        } else {
            $this->error('新增失败');
        }
    }

    public function testgetMessageListStr()
    {
        vendor('yzm.cShortMsg');

        $message_array = array(
            array(
                'mobile_phone' => '1356045',
                'content' => 'test',
            )
        );

        $data = \cShortMsg::getMessageListStr($message_array);

        var_export($data);
    }
//-----------------------------------------------------------------------------短信管理 end


//-----------------------------------------------------------------------------打赏管理 begin
    //打赏列表
    public function editRewardSetup()
    {
        $other_id = I('post.other_id');
        if (empty($other_id)) {
            $this->error('请选择关联课程');
            exit();
            //$_POST['other_id'] = 0;
        }

        $obj = $this->chenUpload('./Upload/RewardCover/');
        $where['id'] = I('post.id');
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename2 = $datadir . '/' . $obj['file']['savename'];
            $savename = S_URL . '/Public/Upload/RewardCover/' . $datadir . '/' . $obj['file']['savename'];

            //生成缩略图，不保存原图默认大小为200*200
            //$this->createSmallImg('./Public/Upload/RewardCover/'.$savename2);

            //截图 500*500
            $yuan = './Public/Upload/RewardCover/' . $savename2;
            A('ChenImg')->imagecropper($yuan, $yuan, 800, 500);

            $this->chenEditImg('system_reward', $where, 'Reward/rewardSetup', array('cover'), array($savename), false);
        } else {
            $this->chengIsNoImg($obj, 'system_reward', $where, 'Reward/rewardSetup', false);
        }

    }

    //打赏大屏设置
    public function editRewardBigScreen()
    {
        header('Content-type:text/html;charset=utf-8');
        $reward_id = I('post.reward_id');

        $obj = $this->chenUpload('./Upload/RewardBigScreenbackground/');
        $editType = I('post.editType');
        if ($editType == 'update') {
            $where['id'] = I('post.id');
            $data['update_time'] = time();
            $data['admin_id'] = session('adminid');
        }
        $data['system_reward_id'] = I('post.reward_id');
        $data['background_type'] = I('post.background_type');
        $data['background_color'] = I('post.background_color');
        $data['show_type'] = I('post.show_type');
        $data['list_type'] = I('post.list_type');
        $data['banner_img'] = I('post.banner_img');
        $data['background_img'] = I('post.background_img');
        $data['list_new_show'] = implode('||', I('post.list_new_show'));
        $data['list_top_show'] = implode('||', I('post.list_top_show'));

        if (is_array($obj)) {
            $datadir = date('Ym');
            if ($obj[0]) {
                $data['banner_img'] = S_URL . '/Public/Upload/RewardBigScreenbackground/' . $datadir . '/' . $obj[0]['savename'];
            }
            if ($obj[1]) {
                $data['background_img'] = S_URL . '/Public/Upload/RewardBigScreenbackground/' . $datadir . '/' . $obj[1]['savename'];
            }
        }
        //dump($data);die; 
        if (M('system_reward_big_screen')->where($where)->save($data)) {
            $this->success('修改成功');
        } else {
            $this->error('修改失败');
        }


    }

    //打赏对象管理
    public function editRewardTeacher()
    {
        $where['id'] = I('post.id');
        $reward_id = I('post.system_reward_id');
        $teacher_id = I('post.teacher_id');
        $teacher_name = I('post.teacher_name');

        $obj = $this->chenUpload('./Upload/HeadImg/');

        $school_id = 0;
        $savename = '';
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename = '/Public/Upload/HeadImg/' . $datadir . '/' . $obj['file']['savename'];
            $yuan = './Public/Upload/HeadImg/' . $datadir . '/' . $obj['file']['savename'];

            A('ChenImg')->imagecropper($yuan, $yuan, 200, 200);
        }

        $obj_teacher = M('school_teacher');
        if (empty($teacher_id)) {
            // insert teacher
            $teacher_data = array(
                'school_id' => $school_id,
                'teacher_name' => $teacher_name,
                'teacher_head_img' => $savename,
                'teacher_sex' => 1,
                'time' => time(),
                'admin_id' => session('adminid')
            );
            $_POST['teacher_id'] = $obj_teacher->add($teacher_data);
        } else {
            $teacher_data = array(
                'teacher_name' => $teacher_name,
                'update_time' => time(),
                'admin_id' => session('adminid')
            );
            if (!empty($savename)) {
                $teacher_data['teacher_head_img'] = $savename;
            }

            $obj_teacher->where(array('id' => $teacher_id))->save($teacher_data);
        }

        //如果该对象设置为启用则更新其他该打赏的打赏对象的状态为禁用
        if (I('post.status') == 1 && $reward_id) {
            $savestatus['status'] = 0;
            $savestatus['update_time'] = time();
            $savestatus['admin_id'] = session('adminid');

            $wherestatus['system_reward_id'] = $reward_id;
            $wherestatus['id'] = array('neq', $where['id']);

            M('system_reward_teacher')->where($wherestatus)->save($savestatus);
        }

        //dump($reward_id);die;

        $obj = D('system_reward_teacher');

        if (!$obj->create()) {
            $this->error($obj->getError());
        }

        if ($_POST['editType'] == 'update') {
            if ($obj->where($where)->save()) {
                if (!true) {
                    $this->success('修改成功');
                } else {
                    $this->success('修改成功', '/Admin/' . 'Reward/rewardTeacher/t/' . $reward_id);
                }
            } else {
                $this->error('修改失败');
            }
        } else if ($_POST['editType'] == 'create') {
            if ($obj->add()) {
                $this->success('新增成功', '/Admin/' . 'Reward/rewardTeacher/t/' . $reward_id);
            } else {
                $this->error('新增失败');
            }
        }
    }

    //打赏的抽奖奖品管理
    public function editRewardLuckDraw()
    {
        $reward_id = I('post.system_reward_id');
        $obj = $this->chenUpload('./Upload/RewardLuckDrawCover/');
        $where['id'] = I('post.id');
        if (is_array($obj)) {
            $datadir = date('Ym');
            $savename2 = $datadir . '/' . $obj['file']['savename'];
            $savename = S_URL . '/Public/Upload/RewardLuckDrawCover/' . $datadir . '/' . $obj['file']['savename'];
            $yuan = './Public/Upload/RewardLuckDrawCover/' . $savename2;
            A('ChenImg')->imagecropper($yuan, $yuan, 500, 500);

            $this->chenEditImg('system_reward_luck_draw', $where, 'Reward/rewardLuckDraw/t/' . $reward_id, array('draw_cover'), array($savename), true);
        } else {
            $this->chengIsNoImg($obj, 'system_reward_luck_draw', $where, 'Reward/rewardLuckDraw/t/' . $reward_id, true, false);
        }

    }

    //中奖人员管理
    public function editRewardLuckDrawStudent()
    {
        $editTypeValue = I('post.editType');
        if ($editTypeValue == 'create') {
            die;
        }
        $where['id'] = I('post.id');
        $reward_id = I('post.system_reward_id');
        $this->chenEdit('student_luck_draw', $where, 'Reward/rewardLuckDrawStudent/t/' . $reward_id, true);
    }


//-----------------------------------------------------------------------------打赏管理 end


//-----------------------------------------------------------------------------学生座位 begin
    public function setStudentSeat($course_id, $mobile_phone, $one, $two)
    {
        //手机号是否存在
        $student_id = M('student')->where(array('mobile_phone' => $mobile_phone))->getField();
        if (!$student_id) {
            $this->error('手机号不存在');
        }

        //是否报名该课程
        $coursedata = M('student_course')->where(array(
            'school_course_id' => $course_id,
            'student_id' => $student_id,
            'see_type' => '现场',
            'status' => '1'
        ))->find();
        if (!$coursedata) {
            $this->error('未报名该课程');
        }

        //是否已经选座了座位
        $seat_address = M('student_course_seat')->where(array('course_id' => $course_id, 'student_id' => $student_id))->find();
        if ($seat_address) {
            $this->error('已经选择了座位');
        }

        //座位信息
        $seatData = M('school_course_seat')->where(array('course_id' => $course_id))->find();
        $seatArray = unserialize($seatData['seat_array']);
        //该座位的详细信息
        $seatInfo = $seatArray[$one][$two];
        //查看该位置是否有人
        if ($seatInfo['student_id']) {
            $this->error('该座位已经有人了');
        }
        if ($seatInfo['status'] === '0' || $seatInfo['status'] === '4') {
            $this->error('该座位为空地或者已锁定');
        }

        $seatArray[$one][$two]['student_id'] = $student_id;
        $ret1 = true;
        D()->startTrans();
        if (!D('StudentCourseSign')->isSign($student_id, $course_id)) {
            $ret1 = D('StudentCourseSign')->createOne($student_id, $course_id);
        }
        //更新座位
        $ret2 = D('SchoolCourseSeat')->updateSeatArray($course_id, serialize($seatArray));
        $ret3 = D('StudentCourseSeat')->createOne($student_id, $course_id, $seatInfo['address']);
        if ($ret1 && $ret2 && $ret3) {
            D()->commit();
            $this->success('选座成功', '/Admin/Course/studentSeatList/course/' . $course_id);
        } else {
            D()->rollback();
            $this->error('插入失败，请重试');
        }


    }
//-----------------------------------------------------------------------------学生座位 end


//-----------------------------------------------------------------------------用户管理 begin
    //用户分组管理
    public function editStudentGroupList()
    {
        $where['student_group_id'] = I('post.student_group_id');
        $this->chenEdit('student_group', $where, 'Student/studentGroupList', true);
    }

    //用户标签管理
    public function editStudentTagList()
    {
        $where['id'] = I('post.id');
        $this->chenEdit('student_tag', $where, 'Student/studentTagList', true);
    }

    /**
     * 用户线下汇款申请入学申请
     */
    public function editApplyList()
    {
        $isdumplist = true;
        $url = 'Student/applyList';
        $obj = D('SystemLinePayRecord');
        if (!$obj->create()) {
            $this->error($obj->getError());
        }

        if ($_POST['editType'] == 'update') {
            if ($obj->where($where)->save()) {
                if (!$isdumplist) {
                    $this->success('修改成功');
                } else {
                    $this->success('修改成功', '/Admin/' . $url);
                }
            } else {
                $this->error('修改失败');
            }
        } else if ($_POST['editType'] == 'create') {
            $mobile_phone = I('post.mobile_phone');
            $pay_true_name = I('post.pay_true_name');
            $apply_year_number = I('post.apply_year_number');
            $apply_type_id = I('post.apply_type_id');
            $end_time = strtotime("+" . $apply_year_number . " year");
            $school_student_number = D('HtmlSystemSetup')->createStudentNumber();

            //查询该手机是否已经给注册
            $where['mobile_phone'] = trim($mobile_phone);
            $student_info = M('student')->where($where)->find();
            if ($student_info['end_time'] && $student_info['apply_type_id']) {
                $this->error('该手机号已被注册');
            }

            D()->startTrans();

            if ($student_info) {
                $ret1 = $obj->where($where)->save();
            } else {
                $ret1 = $obj->add();
            }

            $ret2 = D('student')->createOne($mobile_phone, $pay_true_name, $apply_type_id, $end_time, $school_student_number);
            if ($ret1 && $ret2) {
                D()->commit();

                $this->success('新增成功', '/Admin/' . $url);
            } else {
                D()->rollback();

                $this->error('新增失败');
            }
        }
    }

    //用户升级配置管理
    public function editStudentOnlineToSceneSetupList()
    {
        $where['id'] = I('post.id');
        $this->chenEdit('system_online_to_scence_setup', $where, 'Student/studentOnlineToSceneSetupList', true);
    }

    //用户学号前缀配置
    public function editStudentNumberPrefixSetup()
    {
        $where['system_id'] = I('post.id');
        $this->chenEdit('html_system_setup', $where, 'Student/studentNumberPrefixSetup', true);
    }

    //管理员帮用户续费
    public function studentRenew()
    {
        $editType = I('post.editType');
        $id = I('post.id');
        $end_time = I('post.end_time');
        if ($editType == 'update' && !empty($id)) {
            //dump($_POST);
            $save['end_time'] = strtotime($end_time);
            $save['update_time'] = time();
            $save['admin_id'] = session('adminid');
            $where['id'] = $id;
            if (M('student')->where($where)->save($save)) {
                $this->success('修改成功', '/Admin/Student/studentList');
            } else {
                $this->error('续费失败');
            }
        }
    }

    //修改用户个人信息
    public function editStudentInfo()
    {
        $obj = D('student');
        if (!$obj->create()) {
            $this->error($obj->getError());
        }

        if ($obj->where($where)->save()) {
            $this->success('修改成功');
        } else {
            $this->error('修改失败');
        }
    }

//-----------------------------------------------------------------------------用户管理 end


//-----------------------------------------------------------------------------广告管理 begin 

    //微站活动首页广告
    public function editActivityIndex()
    {
        $obj = $this->chenUpload('./Upload/BannerActivityIndex/');
        $editType = I('post.editType');

        $data['title'] = I('post.title');
        $data['img'] = I('post.img');
        $data['url'] = I('post.url');
        $data['sort'] = I('post.sort');
        $data['status'] = I('post.status');
        $data['admin_id'] = session('adminid');
        if (is_array($obj)) {
            $datadir = date('Ym');
            if ($obj[0]) {
                $data['img'] = S_URL . '/Public/Upload/BannerActivityIndex/' . $datadir . '/' . $obj[0]['savename'];

                $savename = $datadir . '/' . $obj[0]['savename'];
                $yuan = './Public/Upload/BannerActivityIndex/' . $savename;
                A('ChenImg')->imagecropper($yuan, $yuan, 768, 443);
            }
        }

        if ($editType == 'update') {
            $data['update_time'] = time();
            $where['id'] = I('post.id');
            if (M('wxsite_banner')->where($where)->save($data)) {
                $this->success('更新成功', '/Admin/Banner/activityIndex');
            } else {
                $this->error('更新失败');
            }
        } else if ($editType == 'create') {
            $data['time'] = time();
            $data['address'] = 1;//微站首页广告
            if (M('wxsite_banner')->add($data)) {
                $this->success('添加成功', '/Admin/Banner/activityIndex');
            } else {
                $this->error('添加失败');
            }
        }

    }
//-----------------------------------------------------------------------------广告管理 end


    /**
     * [chenEdit 新增修改]
     * @param [string] $table 数据表，第一个字母要大写]
     * @param [string] $url 跳转的模块名与方法名
     * @param [boolean] $isdumplist 修改时是否跳转会url的地址，false为不跳转，true为跳转
     */
    protected function chenEdit($table, $where, $url, $isdumplist)
    {
        $obj = D($table);

        if (!$obj->create()) {
            $this->error($obj->getError());
        }

        if ($_POST['editType'] == 'update') {
            if ($obj->where($where)->save()) {
                if (!$isdumplist) {
                    $this->success('修改成功');
                } else {
                    $this->success('修改成功', '/Admin/' . $url);
                }
            } else {
                $this->error('修改失败');
            }
        } else if ($_POST['editType'] == 'create') {
            if ($obj->add()) {
                $this->success('新增成功', '/Admin/' . $url);
            } else {
                $this->error('新增失败');
            }
        }
    }

    protected function chenEditImg($table, $where, $url, $ziduan, $imgarr, $isdumplist)
    {
        $obj = D($table);
        if (!$obj->create()) {
            //$this->delUploadImg($table,$ziduan,$imgarr);//自动完成失败时删除上传的图片
            $this->error($obj->getError());
        }
        foreach ($ziduan as $k => $v) {
            $obj->$v = $imgarr[$k];
        }
        if ($_POST['editType'] == 'update') {
            if ($obj->where($where)->save()) {
                //$this->delImg($table,$_POST['img']);//修改成功则删除原图
                if (!$isdumplist) {
                    $this->success('修改成功');
                } else {
                    $this->success('修改成功', '/Admin/' . $url);
                }
            } else {
                //$this->delUploadImg($table,$ziduan,$imgarr);//修改失败时删除上传的图片
                $this->error('修改失败');
            }
        } else if ($_POST['editType'] == 'create') {
            if ($id = $obj->add()) {
                $this->success('新增成功', '/Admin/' . $url);
            } else {
                //$this->delUploadImg($table,$ziduan,$imgarr);//添加失败时删除上传的图片
                $this->error('新增失败');
            }
        }
    }

    //当没有文件上传时并未修改时调用
    protected function chengIsNoImg($obj, $table, $where, $url, $isdumplist, $isnf = true)
    {
        if ($obj != '没有文件被上传！') {
            $this->error($obj);
        } else {
            if ($_POST['editType'] == 'create' && $isnf) {
                $this->error('请选择图片文件');
            }
            $this->chenEdit($table, $where, $url, $isdumplist);
        }
    }

    protected function chenUpload($fsave)
    {
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize = 1024 * 1024 * 40;// 设置附件上传大小
        $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->savePath = $fsave; // 设置附件上传目录
        $upload->thumbRemoveOrigin = false; //上传图片后删除原图片
        // 上传文件
        $info = $upload->upload();
        if (!$info) {// 上传错误提示错误信息
            return $upload->getError();
        } else {// 上传成功
            return $info;
        }
    }

    protected function chenUploadApk($fsave)
    {
        $upload = new \Think\Upload();// 实例化上传类
        $upload->rootPath = './';
        $upload->autoSub = false;
        $upload->maxSize = 1024 * 1024 * 40;// 设置附件上传大小
        $upload->exts = array('apk');// 设置附件上传类型
        $upload->savePath = $fsave; // 设置附件上传目录
        $upload->thumbRemoveOrigin = false; //上传图片后删除原图片
        // 上传文件
        $info = $upload->upload();
        if (!$info) {// 上传错误提示错误信息
            return $upload->getError();
        } else {// 上传成功
            $oldname = $info['file']['savepath'] . $info['file']['savename'];
            $newname = $info['file']['savepath'] . $info['file']['name'];
            if (rename($oldname, $newname)) {
                $info['file']['savename'] = $info['file']['name'];
            }
            return $info;
        }

    }

    //修改成功则删除原图
    protected function delImg($table, $img)
    {
        switch ($table) {

            case 'System_banner':
                $fi = 'banner';
                break;

        }
        $this->chenUnlink('./Public/Upload/' . $fi . '/' . $img);//删除原图片
        //ECHO './Public/Upload/'.$fi.'/'.$img.':::'.$table;DIE;
    }

    //修改、添加失败则删除上传的图片
    protected function delUploadImg($table, $ziduan, $imgarr)
    {
        switch ($table) {

            case 'System_banner':
                $fi = 'banner';
                break;

        }
        foreach ($ziduan as $k => $v) {
            $this->chenUnlink('./Public/Upload/' . $fi . '/' . $imgarr[$k]);//删除上传的图片
        }


    }

    //删除指定文件
    protected function chenUnlink($file)
    {
        if (is_file($file)) {
            unlink($file);
        }
    }

    //生成缩略图，不保存原图
    public function createSmallImg($url, $width = 200, $height = 200)
    {
        $image = new \Think\Image();
        $image->open($url)->thumb($width, $height)->save($url);
    }


    //修改活动的门票设置 2016-3-1
    public function activityEditTicket($id)
    {
        $data = array();

        $data['one_status'] = I('post.is_sign_up') ? 1 : 0;
        $data['is_open_apply_join'] = I('post.is_apply_join') ? 1 : 0;

        if ('on' == I('post.is_sign_up_sms_msg')) {
            $data['is_sign_up_sms_msg'] = 1;
        } else {
            $data['is_sign_up_sms_msg'] = 0;
        }

        if ('on' == I('post.is_audit_sms_msg')) {
            $data['is_audit_sms_msg'] = 1;
        } else {
            $data['is_audit_sms_msg'] = 0;
        }

        if ('on' == I('post.is_audit_success_sms_msg')) {
            $data['is_audit_success_sms_msg'] = 1;
        } else {
            $data['is_audit_success_sms_msg'] = 0;
        }

        if ('on' == I('post.is_audit_fail_sms_msg')) {
            $data['is_audit_fail_sms_msg'] = 1;
        } else {
            $data['is_audit_fail_sms_msg'] = 0;
        }

        if ('on' == I('post.is_online_pay_sms_msg')) {
            $data['is_online_pay_sms_msg'] = 1;
        } else {
            $data['is_online_pay_sms_msg'] = 0;
        }

        if ('on' == I('post.is_offline_pay_sms_msg')) {
            $data['is_offline_pay_sms_msg'] = 1;
        } else {
            $data['is_offline_pay_sms_msg'] = 0;
        }

        if ('on' == I('post.is_eticket_used_sms_msg')) {
            $data['is_eticket_used_sms_msg'] = 1;
        } else {
            $data['is_eticket_used_sms_msg'] = 0;
        }

        $data['sign_up_sms_msg'] = I('post.sign_up_sms_msg');
        if (empty($data['sign_up_sms_msg'])) {
            unset($data['sign_up_sms_msg']);
        }
        $data['audit_sms_msg'] = I('post.audit_sms_msg');
        if (empty($data['audit_sms_msg'])) {
            unset($data['audit_sms_msg']);
        }
        $data['audit_success_sms_msg'] = I('post.audit_success_sms_msg');
        if (empty($data['audit_success_sms_msg'])) {
            unset($data['audit_success_sms_msg']);
        }
        $data['audit_fail_sms_msg'] = I('post.audit_fail_sms_msg');
        if (empty($data['audit_fail_sms_msg'])) {
            unset($data['audit_fail_sms_msg']);
        }
        $data['online_pay_sms_msg'] = I('post.online_pay_sms_msg');
        if (empty($data['online_pay_sms_msg'])) {
            unset($data['online_pay_sms_msg']);
        }
        $data['offline_pay_sms_msg'] = I('post.offline_pay_sms_msg');
        if (empty($data['offline_pay_sms_msg'])) {
            unset($data['offline_pay_sms_msg']);
        }
        $data['eticket_used_sms_msg'] = I('post.eticket_used_sms_msg');
        if (empty($data['eticket_used_sms_msg'])) {
            unset($data['eticket_used_sms_msg']);
        }

        foreach ($data as $key => $value) {
            if ($value === '' || !isset($value)) {
                unset($data[$key]);
            }
        }

        $data['update_time'] = time();

        $obj_sc = M('school_course');

        $result = $obj_sc->where(array('id' => $id))->save($data);


        if ($result != false) {
            $this->success("修改成功");
        } else {
            $this->success("修改失败");
        }
    }
}


