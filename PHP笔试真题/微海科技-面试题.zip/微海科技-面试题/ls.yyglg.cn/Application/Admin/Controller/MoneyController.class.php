<?php
namespace Admin\Controller;

use Think\Controller;

//财务管理
class MoneyController extends ExtendController
{

// 添加记录
	public  function  AddPayInfo()
	{
		$this->display();


	}
	public  function  AddPayInfoSubmit()
	{
			$post=$_POST;
		$post['pay_time']=time();

		$post['creater']=session('admindata');

		D('student_pay_record')->add($post);
		redirect("/Admin/Money/payInfoList");
	}
//-----------------------------------------------------------------------------------------收支明细
	//收支明细
	public function payInfoList()
	{
		$begin_time = !empty($_GET['begin_time']) ? $_GET['begin_time'] : 'all';
		$end_time = !empty($_GET['end_time']) ? $_GET['end_time'] : 'all';
		$searchtype = I('get.searchtype');
		$search = trim(I('get.search'));

		$moneyone = $_GET['moneyone'];
		$moneytwo = $_GET['moneytwo'];

		//时间区间查询
		if ($begin_time != 'all' && $begin_time != 'NaN' && $end_time != 'all' && $end_time != 'NaN') {
			$btime = getBeginTimeAndEndTime(chen_show_time($begin_time), chen_show_time($end_time));
			$where['this.pay_time'] = array('between', $btime);
			$this->assign('begin_time', $begin_time);
			$this->assign('end_time', $end_time);
		}

		if (($moneyone === '0' || !empty($moneyone)) && !empty($moneytwo)) {
			$where['this.pay_money'] = array('between', array($moneyone, $moneytwo));
			$this->assign('moneyone', $moneyone);
			$this->assign('moneytwo', $moneytwo);
		}

		if ($searchtype && $search) {
			if ($searchtype != 'all') {
				switch ($searchtype) {
					case 'pay_number':
						$wherefield = 'this.pay_number';
						break;
					case 'transaction_id':
						$wherefield = 'this.transaction_id';
						break;
					case 'pay_status':
						$wherefield = 'this.pay_status';
						break;
					case 'pay_type':
						$wherefield = 'this.pay_type';
						break;
					case 'true_name':
						$wherefield = 'this.true_name';
						break;
					case 'mobile_phone':
						$wherefield = 'this.mobile_phone';
						break;
					case 'school_student_number':
						$wherefield = 'this.student_number';
						break;
				}

				$where[$wherefield] = array('like', '%' . $search . '%');
			} else {
				$whereor['this.pay_number'] = array('like', '%' . $search . '%');
				$whereor['this.transaction_id'] = array('like', '%' . $search . '%');
				$whereor['this.pay_status'] = array('like', '%' . $search . '%');
				$whereor['this.pay_type'] = array('like', '%' . $search . '%');

				$whereor['this.student_number'] = array('like', '%' . $search . '%');
				$whereor['this.true_name'] = array('like', '%' . $search . '%');
				$whereor['this.mobile_phone'] = array('like', '%' . $search . '%');
				$whereor['_logic'] = 'or';
				$where['_complex'] = $whereor;
			}
			$this->assign('searchtype', $searchtype);
			$this->assign('search', $search);
		}

		$sc = D('student_pay_record');
		$join = 'as this left join ' . C('DB_PREFIX') . 'student as st on this.pay_student_id = st.id ';
		$field = 'this.pay_number,this.pay_money,this.pay_status,this.pay_info_id,this.pay_type,this.pay_time,this.transaction_id,this.true_name,this.student_number,this.mobile_phone,st.true_name as student_true_name,st.mobile_phone as student_mobile_phone,st.school_student_number';

		$count = $sc->join($join)->where($where)->count();
		$Page = new \Think\Page($count, 20);
		$show = $Page->show();
		$order = 'this.pay_id desc';

		$list = $sc->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();
		foreach ($list as $key => $value) {
			if (empty($value['school_student_number'])) {
				$list[$key]['school_student_number'] = $value['student_number'];
			}
			if (empty($value['student_mobile_phone'])) {
				$list[$key]['student_mobile_phone'] = $value['mobile_phone'];
			}
			if (empty($value['student_true_name'])) {
				$list[$key]['student_true_name'] = $value['true_name'];
			}
		}

		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('payInfoList');
	}


}