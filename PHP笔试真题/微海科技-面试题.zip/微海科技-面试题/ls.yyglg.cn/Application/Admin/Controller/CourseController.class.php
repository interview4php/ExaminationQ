<?php
namespace Admin\Controller;

use Think\Controller;

//课程管理
class CourseController extends ExtendController
{

	private $courseListNum = 10;//学院课程每页显示个数
	private $teacherListNum = 10;//学院课程里面的老师
	private $courseSeatListNum = 20;//学院课程里面的座位
	private $pptListNum = 100;//学院课程里面的PPT

	/**
	 * 课程列表
	 */
	public function courseList()
	{
		$where = array(
			'sc.type' => 0,    // 只列举活动
		);

		$search = !empty($_GET['search']) ? $_GET['search'] : 'all';
		$address = !empty($_GET['address']) ? $_GET['address'] : 'all';

		$school_name = !empty($_GET['school_name']) ? $_GET['school_name'] : 'all';
		$school_course_status = !empty($_GET['school_course_status']) ? $_GET['school_course_status'] : 'all';

		$time = !empty($_GET['time']) ? $_GET['time'] : 'all';
		$sort = !empty($_GET['sort']) ? $_GET['sort'] : 'all';

		$hidden_begin_time = !empty($_GET['hidden_begin_time']) ? $_GET['hidden_begin_time'] : 'all';
		$hidden_end_time = !empty($_GET['hidden_end_time']) ? $_GET['hidden_end_time'] : 'all';

		//时间区间查询
		if ($hidden_begin_time != 'all' && $hidden_begin_time != 'NaN'
			&& $hidden_end_time != 'all' && $hidden_end_time != 'NaN')
		{
			$btime = getBeginTimeAndEndTime(chen_show_time($hidden_begin_time), chen_show_time($hidden_end_time));
			$where['sc.begin_time'] = array('between', $btime);

			$this->assign('begin_time', $hidden_begin_time);
			$this->assign('end_time', $hidden_end_time);
		}

		//课题名字
		if ($search != 'all') {
			$where['sc.name'] = array('like', '%' . trim($search) . '%');
			$this->assign('search', $search);
		}
		//上课地点
		if ($address != 'all') {
			$where['sc.address'] = array('like', '%' . trim($address) . '%');
			$this->assign('address', $address);
		}
		//所属学院
		if ($school_name != 'all') {
			$where['sc.school_id'] = $school_name;
		}
		//课程状态
		if ($school_course_status != 'all') {
			$where['sc.school_course_status'] = $school_course_status;
		}

		//dump($where);
		//学院选择
		A('Public')->assignSchoolSelect($school_name);

		//创建排序排序
		$this->assign('sort', A('GetSelect')->getStatusS_n(array('desc' => '排序降序', 'asc' => '排序升序'), $sort, 'sort', '排序排序'));
		//创建课程状态
		$this->assign('school_course_status', A('GetSelect')->getStatusS_n(array(1 => '正常', 2 => '待预约', 3 => '已关闭'), $school_course_status, 'school_course_status', '课程状态'));
		//创建时间排序
		$this->assign('time', A('GetSelect')->getStatusS_n(array('desc' => '时间升序', 'asc' => '时间降序'), $time, 'time', '添加时间'));

		$sc = D('school_course');
		$join = 'as sc left join ' . C('DB_PREFIX') . 'school as s on sc.school_id = s.id';
		$count = $sc->join($join)->where($where)->count();

		$Page = new \Think\Page($count, $this->courseListNum);
		$show = $Page->show();

		$field = 'sc.id,sc.school_id,sc.name,sc.address,sc.admin_id,sc.begin_time,sc.end_time,sc.sort,s.school_name,sc.school_course_status,sc.is_online,sc.is_scene,sc.all_number,sc.use_number,sc.one_see_type,sc.one_money,sc.one_status,sc.cover_img,sc.is_socket';

		//获取排序
		$order = A('Public')->getOrder('sc.id desc', array('sc.id' => $time, 'sc.sort' => $sort), 'all');

		$list = $sc->relation('admin')->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();

		foreach ($list as $k => $v) {
			//查询每个课程的老师数量 
			$sctwhere['course_id'] = $v['id'];
			$list[$k]['teacher_count'] = M('school_course_teacher')->where($sctwhere)->count();

			//查询每个课程的PPT的数量
			$list[$k]['ppt_count'] = M('school_course_ppt')->where($sctwhere)->count();
			$list[$k]['course_one_url'] = S_URL . '/Bz/CourseOne/index/courseId/' . $v['id'];
			$wherecourse_student['school_course_id'] = $v['id'];
			$wherecourse_student['status'] = 1;
			$list[$k]['course_student'] = M('student_course')->where($wherecourse_student)->count();
		}

		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('courseList');
	}

	//课程新增、修改
	public function courseListEdit()
	{
		A('Public')->getEdit('school_course');

		$courseId = I('t');
		$this->assign('course_sign_url', S_URL . U("Bz/Kcqd/index/courseId/$courseId"));
		$this->assign('course_mode_url', S_URL . U("Bz/Classroom/index/courseId/$courseId"));

		$s = M('school')->field('school_name')->where(array('id' => $this->data['school_id']))->find();

		$this->assign('school_name', $s['school_name']);

		//创建课程状态
		$this->assign('school_course_status', A('GetSelect')->getStatusS_n(array(1 => '正常', 2 => '待预约', 3 => '已关闭'), chen_is_empty($this->data['school_course_status'], 1), 'school_course_status', '请选择课程状态'));
		//创建单场课程开启状态
		$this->assign('one_status', A('GetSelect')->getStatusS_n(array(0 => '关闭', 1 => '开启'), $this->data['one_status'], 'one_status', '请选择是否开启单场课程购买'));
		//创建课程是否可以请假状态
		//学院选择
		$this->assign('school_id', A('GetSelect')->getDtoS('school', 1, 'sort desc,id desc', 'id', 'school_name', $this->data['school_id'], 'school_id', array(0, '所属学院')));

		$is_can_false_value = ($this->editType) == 'create' ? 1 : $this->data['is_can_false'];
		$this->assign('is_can_false', A('GetSelect')->getStatusS_n(array(0 => '禁止请假', 1 => '可以请假'), $is_can_false_value, 'is_can_false', '课程是否可以请假'));

		//创建课程类型
		$this->assign('one_see_type', A('GetSelect')->getStatusS_n(array('线上' => '线上', '现场' => '现场'), $this->data['one_see_type'], 'one_see_type', '请选择开启单场课程购买类型'));

		$this->display('courseListEdit');
	}

	//课程里面的老师列表
	public function teacherList()
	{
		$course_id = I('get.course');

		//查询该课表的详细信息
		$courseDataWhere['id'] = $course_id;
		$this->assign('courseData', D('school_course')->relation('school')->where($courseDataWhere)->find());


		$where['course_id'] = $course_id;
		$order = 'sort desc,id desc';
		A('Public')->getList('school_course_teacher', '*', $where, $order, $this->teacherListNum, 'teacherList');
	}

	//添加课程里面的老师
	public function teacherListEdit()
	{
		//课程ID
		$course_id = I('get.courseId');
		$this->assign('course_id', $course_id);
		$this->display('teacherListEdit');
	}


//-----------------------------------------------------------------------------------------课程的ppt
	//课程里面的ppt列表
	public function pptList()
	{
		$course_id = I('get.course');

		//查询该课表的详细信息
		$courseDataWhere['id'] = $course_id;
		$this->assign('courseData', D('school_course')->relation('school')->where($courseDataWhere)->find());

		$key = 'chennailuan_course_ppt4561624154121';
		$type = 'repeatPPT';
		$md5value = md5(md5($key . $type));
		$this->assign('ctype', $type);
		$this->assign('cmd5', $md5value);
		//查询当前显示中的PPT
		$this->assign('is_show_now_ppt_id',D('school_course_ppt')->field('id')->where(array('course_id'=>$course_id,'is_show_now'=>1))->find());
		
		$where['course_id'] = $course_id;
		$order = 'sort desc,id asc';
		A('Public')->getList('school_course_ppt', '*', $where, $order, $this->pptListNum, 'pptList');
	}

	//添加课程里面的PPT
	public function pptListEdit()
	{
		//课程ID
		$course_id = I('get.courseId');
		$this->assign('course_id', $course_id);
		A('Public')->getEdit('school_course_ppt');
		$this->display('pptListEdit');
	}
	//批量添加课程里面的PPT
	public function pptListMoreEdit()
	{
		//课程ID
		$course_id = I('get.courseId');
		$this->assign('course_id', $course_id);
		$this->display('pptListMoreEdit');
	}
	
	//修改当前显示的PPT
	public function isShowNowPpt(){
		
		$course_id = I('post.course_id');
		$pptid = I('post.pptid');
		if(D('school_course_ppt')->isShowNowPpt($course_id,$pptid)){
			echo 'true';
		}else{
			echo 'false';
		}
		
	}
//-----------------------------------------------------------------------------------------课程的座位	

	//课程里面的座位跳转中转
	public function courseSeatIndex()
	{
		$course_id = I('get.course');
		$place_id = I('get.id');

			$cond = array('course_id' => $course_id);
		if (!empty($place_id)) {
			$cond['activity_place_id'] = $place_id;
		} else {
			$place_id = 0;
		}
		$seat_data = M('school_course_seat')->where($cond)->find();

		if ($seat_data) {
			$this->redirect("/Admin/Course/courseSeatListEdit/course/{$course_id}/t/{$seat_data['school_course_seat_id']}/place_id/{$place_id}");
		} else {
			$this->redirect("/Admin/Course/courseSeatListAdd/course/{$course_id}/place_id/{$place_id}");
		}
	}


	//添加课程里面的座位
	public function courseSeatListEdit()
	{
		$place_id = I('get.place_id');
		if (empty($place_id)) {
			$place_id = 0;
		}

		//$data = serialize($data);
		//$data = unserialize($data);
		A('Public')->getEdit('school_course_seat');
		$s = M('school_course')->field('name')->where(array('id' => $this->data['course_id']))->find();
		
		//查询学生座位
		$seat_list = M('school_course_seat_list')->where(array('school_course_seat_id'=>I('get.t')))->select();
		$seat_array = array();
		foreach($seat_list as $k=>$v){
			$seat_array[$v['one']][$v['two']] = $v;
		}


		$this->assign('course_name', $s['name']);
		$this->assign('status', A('GetSelect')->getIsShowS($this->data['status'], 'status'));
		$this->assign('seat_array', $seat_array);

		$this->display('courseSeatListEdit');
	}

	/**
	 * 删除会场座位，并且删除已选座的学生
	 *
	 * @param $id
	 */
	public function deleteSeat($id, $course_id, $place_id) {
		D()->startTrans();
		$ret1 = M('school_course_seat')->where(array('school_course_seat_id' => $id))->delete();
		$ret2 = M('student_course_seat')->where(array('course_id' => $course_id, 'activity_place_id' => $place_id))->delete();
		$ret3 = M('school_course_seat_list')->where(array('school_course_seat_id' => $id))->delete();
		if ($ret1 !== false && $ret2 !== false && $ret3 !== false) {
			D()->commit();
			$this->ajaxReturn(array('ret' => 'true'));
		} else {
			D()->rollback();
			$this->ajaxReturn(array('ret' => 'false'));
		}

	}

	//新增课程里面的座位
	public function courseSeatListAdd()
	{
		$place_id = I('get.place_id');
		if (empty($place_id)) {
			$place_id = 0;
		}

		$this->assign('course_id', I('get.course'));
		$this->assign('place_id', $place_id);
		$this->display('courseSeatListAdd');
	}


//-----------------------------------------------------------------------------------------课程的签到列表
	//签到列表
	public function studentSignList()
	{	
		$course_id = I('get.course');
		$searchtype = I('get.searchtype');
		$search = trim(I('get.search'));
		$begin_time = !empty($_GET['begin_time']) ? $_GET['begin_time'] : 'all';
		$end_time = !empty($_GET['end_time']) ? $_GET['end_time'] : 'all';
		if ($searchtype && $search) {
			if ($searchtype != 'all') {
				$where['st.'.$searchtype] = array('like', '%' . $search . '%');
			} else {
				$whereor['st.true_name'] = array('like', '%' . $search . '%');
				$whereor['st.mobile_phone'] = array('like', '%' . $search . '%');
				$whereor['st.school_student_number'] = array('like', '%' . $search . '%');
				$whereor['_logic'] = 'or';
				$where['_complex'] = $whereor;
			}

			$this->assign('searchtype', $searchtype);
			$this->assign('search', $search);
		}
		//时间区间查询
		if ($begin_time != 'all' && $begin_time != 'NaN' && $end_time != 'all' && $end_time != 'NaN') {
			$btime = getBeginTimeAndEndTime(chen_show_time($begin_time), chen_show_time($end_time));
			$where['this.time'] = array('between', $btime);
			$this->assign('begin_time', $begin_time);
			$this->assign('end_time', $end_time);
		}
	
		$sc = M('student_course_sign');
		$join = 'as this inner join ' . C('DB_PREFIX') . 'student as st on this.student_id = st.id ';
		$where['this.course_id'] = $course_id;
		$this->assign('course_id',$course_id);

		$field = 'st.true_name as student_true_name,st.mobile_phone as student_mobile_phone,this.time,st.school_student_number';
		$count = $sc->join($join)->where($where)->count();

		$Page = new \Think\Page($count, 20);
		$show = $Page->show();

		$order = 'time DESC';
		$list = $sc->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();

		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('studentSignList');
	}

	//-----------------------------------------------------------------------------------------课程的学生位置列表
	//学生位置
	public function studentSeatList($course)
	{
		$course_id = $course;
		$this->assign('course_id',$course_id);
		$searchtype = I('get.searchtype');
		$search = trim(I('get.search'));
		$begin_time = !empty($_GET['begin_time']) ? $_GET['begin_time'] : 'all';
		$end_time = !empty($_GET['end_time']) ? $_GET['end_time'] : 'all';
		if ($searchtype && $search) {
			if ($searchtype != 'all') {
				if($searchtype=='seat_address'){
					$where['this.seat_address'] = array('like', '%' . $search . '%');
				}else{
					$where['st.'.$searchtype] = array('like', '%' . $search . '%');
				}
			} else {
				$whereor['this.seat_address'] = array('like', '%' . $search . '%');
				$whereor['st.true_name'] = array('like', '%' . $search . '%');
				$whereor['st.mobile_phone'] = array('like', '%' . $search . '%');
				$whereor['st.school_student_number'] = array('like', '%' . $search . '%');
				$whereor['_logic'] = 'or';
				$where['_complex'] = $whereor;
			}

			$this->assign('searchtype', $searchtype);
			$this->assign('search', $search);
		}
		//时间区间查询
		if ($begin_time != 'all' && $begin_time != 'NaN' && $end_time != 'all' && $end_time != 'NaN') {
			$btime = getBeginTimeAndEndTime(chen_show_time($begin_time), chen_show_time($end_time));
			$where['this.time'] = array('between', $btime);
			$this->assign('begin_time', $begin_time);
			$this->assign('end_time', $end_time);
		}
	
		$db_prefix = GetDbPrefix();

		$sc = D('student_course_seat');
		$join = 'as this inner join ' . $db_prefix . 'student as st on this.student_id = st.id ';

		$where['this.course_id'] = $course;


		$field = 'st.true_name as student_true_name,st.mobile_phone as student_mobile_phone,this.course_id,this.time,this.update_time,this.admin_id,this.seat_address,this.student_course_seat_id,st.school_student_number';

		$count = $sc->join($join)->where($where)->count();

		$Page = new \Think\Page($count, $this->courseSeatListNum);
		$show = $Page->show();

		$order = 'this.time DESC';
		$list = $sc->relation('admin')->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();

		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('studentSeatList');
	}
	
	//为学生添加座位
	public function setStudentSeat($course){
		
		$this->assign('course_id',$course);
		$this->display('setStudentSeat');
		
	}

	//-----------------------------------------------------------------------------------------课程的学生F码列表
	//学生F码
	public function studentFcodeList()
	{

		$course_id = I('get.course');
		$this->assign('course_id', $course_id);
		
		$searchtype = I('get.searchtype');
		$search = trim(I('get.search'));
		$begin_time = !empty($_GET['begin_time']) ? $_GET['begin_time'] : 'all';
		$end_time = !empty($_GET['end_time']) ? $_GET['end_time'] : 'all';
		if ($searchtype && $search) {
			if ($searchtype != 'all') {
				if($searchtype=='fcode'){
					$where['this.f_code'] = array('like', '%' . $search . '%');
				}else{
					$where['st.'.$searchtype] = array('like', '%' . $search . '%');
				}
			} else {
				$whereor['st.true_name'] = array('like', '%' . $search . '%');
				$whereor['st.mobile_phone'] = array('like', '%' . $search . '%');
				$whereor['st.school_student_number'] = array('like', '%' . $search . '%');
				$whereor['this.f_code'] = array('like', '%' . $search . '%');
				$whereor['_logic'] = 'or';
				$where['_complex'] = $whereor;
			}

			$this->assign('searchtype', $searchtype);
			$this->assign('search', $search);
		}
		//时间区间查询
		if ($begin_time != 'all' && $begin_time != 'NaN' && $end_time != 'all' && $end_time != 'NaN') {
			$btime = getBeginTimeAndEndTime(chen_show_time($begin_time), chen_show_time($end_time));
			$where['this.time'] = array('between', $btime);
			$this->assign('begin_time', $begin_time);
			$this->assign('end_time', $end_time);
		}
		
		$sc = D('student_course_fcode');

		$join = 'as this inner join ' . C('DB_PREFIX') . 'student as st on this.student_id = st.id ';
		$where['this.course_id'] = $course_id;
		$field = 'this.student_id,this.id,this.f_code,this.time,this.update_time,this.admin_id,this.course_id,st.true_name as student_true_name,st.mobile_phone as student_mobile_phone,st.school_student_number as student_number';
		$count = $sc->join($join)->where($where)->count();
		$Page = new \Think\Page($count, 10);
		$show = $Page->show();

		$order = 'this.time DESC';
		$list = $sc->relation('admin')->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();

		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('studentFcodeList');
	}

	//学生F码修改、增加
	public function studentFcodeListEdit()
	{
		$id = I('get.t');
		$course_id = I('get.course_id');
		$student_id = I('get.student_id');
		if (!$id) {
			//新增一个Fcode码记录
			$id = D('student_course_fcode')->createOne($course_id, $student_id);
		}
		//查询该条记录
		$where['id'] = $id;
		$this->assign('data', D('student_course_fcode')->where($where)->find());
		$this->display('studentFcodeListEdit');
	}



	//-----------------------------------------------------------------------------------------课程的所有F码
	//课程的所有F码（导入的）
	public function courseFcodeList()
	{
		$course_id = I('get.course');
		$this->assign('course_id', $course_id);
		$where['course_id'] = $course_id;
		$sc = D('school_course_fcode');

		$count = $sc->where($where)->count();

		$Page = new \Think\Page($count, $this->courseSeatListNum);
		$show = $Page->show();

		$field = 'course_id,f_code,time,update_time,admin_id,status,id';
		$order = 'time DESC';
		$list = $sc->relation('admin')->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();

		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('courseFcodeList');
	}

	//设置课程F码为已分配
	public function setCourseFcodeStatus()
	{
		$id = I('post.id');
		$where['id'] = $id;
		$where['status'] = '0';
		$save['status'] = '1';
		$save['update_time'] = time();
		$save['admin_id'] = session('adminid');
		$ret = M('school_course_fcode')->where($where)->save($save);
		if ($ret) {
			echo 'true';
			die;
		} else {
			echo 'false';
			die;
		}

	}

	//-----------------------------------------------------------------------------------------课程打赏抢座VIP
	//打赏抢座Vip用户
	public function studentRewardVip()
	{
		$course_id = I('get.course');
		$place_id = I('get.place_id');


		$m = D('student_course');
		$where['this.see_type'] = array('in', array('主会场', '现场'));
		$where['is_reward_vip'] = 1;
		$where['this.school_course_id'] = $course_id;
		if (empty($place_id)) {
			$place_id = 0;
		} else {
			$where['this.activity_place_id'] = $place_id;
		}

		$join = 'as this inner join ' . C('DB_PREFIX') . 'student as st on this.student_id = st.id ';

		$count = $m->join($join)->where($where)->count();
		$Page = new \Think\Page($count, 20);
		$show = $Page->show();

		$field = 'this.id,this.school_course_id,st.true_name,st.mobile_phone,st.school_student_number';
		$order = 'this.id desc';
		$list = $m->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();

		//dump($list);
		$this->assign('list', $list);
		$this->assign('page', $show);

		$this->display('studentRewardVip');
	}

//----------------------------------------------------------------------------------------------服务小助手配置begin
	public function serviceList()
	{
		$courseId = I('get.id');
		//查询空调问题现在投票情况
		$this->assign('temperature_data', D('school_course_question_temperature')->getOneCourse($courseId, '*'));
		//查询灯光问题现在投票情况
		$this->assign('lamp_data', D('school_course_question_lamp')->getOneCourse($courseId, '*'));
		//查询音响问题现在投票情况
		$this->assign('music_data', D('school_course_question_music')->getOneCourse($courseId, '*'));
		//查询饮水文字
		$this->assign('water_data', D('school_course_question_water')->getOneCourse($courseId, '*'));
		//查询用餐问题
		$this->assign('food_data', D('school_course_question_food')->getOneCourse($courseId, '*'));

		$this->display('serviceList');
	}

	//设置服务小助手默认值
	public function serviceDefaultEdit()
	{
		$default_title = I('post.title');
		$default_img = I('post.img');
		$default_description = I('post.description');
		$table = I('post.type');
		if (empty($default_title) || empty($default_img) || empty($default_description)) {
			echo 'false';
			die;
		}

		$array_table = array('food', 'lamp', 'music', 'temperature', 'water');
		if (!in_array($table, $array_table)) {
			echo 'false';
			die;
		}

		$table = C('DB_PREFIX') . 'school_course_question_' . $table;
		$this->setDBdefault($table, 'default_title', $default_title);
		$this->setDBdefault($table, 'default_img', $default_img);
		$this->setDBdefault($table, 'default_description', $default_description);

		echo 'true';
		die;
	}

	//空调配置
	public function serviceTemperatureEdit()
	{
		$courseId = I('get.courseId');
		$this->assign('data', D('school_course_question_temperature')->getOneCourse($courseId, '*'));
		$this->display('serviceTemperatureEdit');
	}

	//灯光配置
	public function serviceLampEdit()
	{
		$courseId = I('get.courseId');
		$this->assign('data', D('school_course_question_lamp')->getOneCourse($courseId, '*'));
		$this->display('serviceLampEdit');
	}

	//音响配置
	public function serviceMusicEdit()
	{
		$courseId = I('get.courseId');
		$this->assign('data', D('school_course_question_music')->getOneCourse($courseId, '*'));
		$this->display('serviceMusicEdit');
	}

	//饮水配置
	public function serviceWaterEdit()
	{
		$courseId = I('get.courseId');
		$this->assign('data', D('school_course_question_water')->getOneCourse($courseId, '*'));
		$this->display('serviceWaterEdit');
	}

	//用餐配置
	public function serviceFoodEdit()
	{
		$courseId = I('get.courseId');
		$this->assign('data', D('school_course_question_food')->getOneCourse($courseId, '*'));
		$this->display('serviceFoodEdit');
	}

	//设置默认值
	private function setDBdefault($table, $field, $default)
	{
		return M()->execute("alter table {$table} alter column {$field} set default '{$default}'");
	}

//----------------------------------------------------------------------------------------------服务小助手配置end



	//设置某场课程的所有现场会员都为签到
	public function setStudentIsSign(){
		$course_id = I('get.course');

		//查询报名某个课程的正常用户
		$where1['school_course_id'] 	= $course_id;
		$where1['see_type'] 			= array('in', array('主会场', '现场'));
		$where1['status']			= 1;

		$student_data1 = M('student_course')->field('student_id')->where($where1)->select();
		if(is_array($student_data1)){
			foreach($student_data1 as $k=>$v){
				$student_data_array1[] = $v['student_id'];
			}
		}
		
		//查询某个课程已经签到的用户
		$where2['course_id'] = $course_id;
		$student_data2 = M('student_course_sign')->field('student_id')->where($where2)->select();
		if(is_array($student_data2)){
			foreach($student_data2 as $k=>$v){
				$student_data_array2[] = $v['student_id'];
			}
		}
		//返回还未签到的用户
		$student_data= array_diff($student_data_array1,$student_data_array2);
		if(is_array($student_data)){
			foreach($student_data as $k=>$v){
				$data[] = array(
					'student_id'=>$v,
					'course_id'=>$course_id,
					'time'=>time()
				);
			}
		}

		//帮助用户签到
		if(is_array($data)){
			if(D('StudentCourseSign')->addAll($data)){
				exit('success');
			}else{
				exit('error');
			}
		}else{
			exit('no student');
		}
		
		
	}

	
	//设置导入的用户为已签到
	public function setImportStudentIsSign($course){
		
		$this->assign('course_id',$course);
		$this->display('setImportStudentIsSign');
	}
	
	//修改座位名字
	public function updateSeatAddressName($id,$address){
		
		D()->startTrans();
		$save['address'] = $address;
		$save['update_time'] = time();
		$save['admin_id']	 = session('adminid');
		$ret1 = D('SchoolCourseSeatList')->where(array('id'=>$id))->save($save);
		//查询该座位是否已经有人选了有则更更新座位号
		$join = 'as this left join ' . C('DB_PREFIX') . 'school_course_seat as seat on this.school_course_seat_id = seat.school_course_seat_id';
		$field = 'seat.course_id,this.student_id';
		$data = M('SchoolCourseSeatList')->field($field)->join($join)->where(array('id'=>$id))->find();
		$ret2 = true;
		if($data['student_id']){
			$ret2 = M('StudentCourseSeat')->where(array(
				'student_id'=>$data['student_id'],
				'course_id'=>$data['course_id']
			))->save(array('seat_address'=>$address));
		}
		
		if($ret1 && $ret2){
			D()->commit();
			$this->ajaxReturn(array('ret'=>'true'));
		}else{
			D()->rollback();
			$this->ajaxReturn(array('ret'=>'false'));
		}
	}

}