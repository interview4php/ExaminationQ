<?php
namespace Admin\Controller;
use Think\Controller;
class ExtendController extends Controller {
	/**
	 * init
	 */
    Public function _initialize(){
		if($this->is_login()){
		
			/*
			if(!$this->checkRbac()){
				if($this->isAjax()){
					echo '抱歉，你无此操作权限！';
				}else{
					$this->error('您无此权限！！');				
				}
				die;
			}
			*/
			
		}else{
			redirect('/Admin/L/login');
			 // $this->error('请先登录！！',U('L/login'),1);
			die;
		}
	}
	
	//检测是否登录
	public function is_login(){
		$id= session('adminid');
		if(!isset($id)){
			return false;
		}else{
			return true;
		}
		
	}
	
	
}