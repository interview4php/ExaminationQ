<?php
namespace Admin\Controller;

use Think\Controller;

class MyWxSystemController extends ExtendController
{
	// 服务器微信配置
	private $wx_app_id;
	private $wx_app_secret;

	public function _initialize()
	{
		parent::_initialize();

		$this->wx_app_id = get_wx_app_id();
		$this->wx_app_secret = get_wx_app_secret();
	}

	public function index()
	{
		header('Content-type:text/html;charset=utf-8');
		//获取access_token
		$access_token = $this->getAccessTokenS();
		//发送模板消息
		$template_id_list = $this->sendTemplateMsg($access_token);
		dump($template_id_list);

	}


	//发送模板消息
	public function sendTemplateMsg($access_token)
	{
		$post_arr['touser'] = 'o8PLksuWa1HTOuVSa6tcVboUHkQs';
		$post_arr['template_id'] = "ngqIpbwh8bUfcSsECmogfXcV14J0tQlEpBO27izEYtY";
		$post_arr['url'] = "http://Bz.qq.com/download";
		$post_arr['data'] = array(
			'first' => array('value' => '恭喜你购买成功', 'color' => '#173177'),
			'keynote1' => array('value' => '巧克力', 'color' => '#173177'),
			'remark' => array('value' => '欢迎再次购买', 'color' => '#173177'),
		);
		$post_xml = $this->arrayToXml($post_arr);
		$post_json = $this->arrayToJson($post_arr);
		dump($post_xml);
		echo '<hr>';
		dump($post_json);
		$wx_ass = $this->http_post2('https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=' . $access_token, $post_json);
		$wx_ass_obj = json_decode($wx_ass, true);
		dump($wx_ass);
		dump($wx_ass_obj);


	}


	/**
	 *  获取access token
	 */
	private function getAccessToken()
	{
		$url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$this->wx_app_id&secret=$this->wx_app_secret";
		$atjson = file_get_contents($url);
		$result = json_decode($atjson, true);//json解析成数组
		if (!isset($result['access_token'])) {
			exit('获取access_token失败！');
		}
		return $result["access_token"];
	}

	//获取access_token，查询是否已经缓存，如果没有则重新获取
	private function getAccessTokenS()
	{
		$value = S('MyWxSystemAccessTokens');
		if ($value) {
			return $value;
		} else {
			$access_token = $this->getAccessToken();
			S('MyWxSystemAccessTokens', $access_token, 3600);
			return $access_token;
		}
	}


	//文件读取
	public function https_request($url, $data = null)
	{
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		if (!empty($data)) {
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$output = curl_exec($curl);
		curl_close($curl);
		return $output;
	}

	//http post数据
	public function http_post1($url, $post_data = '', $timeout = 5)
	{//curl
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		if ($post_data != '') {
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
		}
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_HEADER, false);
		$file_contents = curl_exec($ch);
		curl_close($ch);
		return $file_contents;
	}

	public function http_post2($url, $data)
	{//file_get_content
		$postdata = http_build_query($data);
		$opts = array('http' =>
			array(
				'method' => 'POST',
				'header' => 'Content-type: application/x-www-form-urlencoded',
				'content' => $postdata
			)
		);
		$context = stream_context_create($opts);
		$result = file_get_contents($url, false, $context);
		return $result;
	}

	/**
	 *    作用：array转xml
	 */
	public function arrayToXml($arr)
	{
		$xml = "<xml>";
		foreach ($arr as $key => $val) {
			if (is_numeric($val)) {
				$xml .= "<" . $key . ">" . $val . "</" . $key . ">";
			} else {
				$xml .= "<" . $key . "><![CDATA[" . $val . "]]></" . $key . ">";
			}
		}
		$xml .= "</xml>";

		return $xml;
	}

	//数组装JSON
	public function arrayToJson($arr, $type = true)
	{
		if ($type) {
			return json_encode($arr);
		} else {
			return json_decode($arr);
		}
	}
}

?>