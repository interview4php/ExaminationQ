<?php
namespace Admin\Controller;
use Think\Controller;
class ActivityTeacherController extends ExtendController {
	
	//老师列表
	public function teacherList($id){
		$foodType = M('school_course');
		$data = $foodType->find($id);
		$this->assign('data', $data);
		$where['this.course_id'] = $id;
		$sc = D('SchoolCourseTeacher');
		$join = 'as this left join ' . C('DB_PREFIX') . 'school_teacher as t on this.teacher_id = t.id ';
		$field = 't.teacher_name,t.teacher_head_img,t.teacher_description,this.id,this.sort,this.video_url,this.video_title,this.video_cover,this.teacher_id';
		$count = $sc->join($join)->where($where)->count();
		$Page = new \Think\Page($count,10);
		$show = $Page->show();
		$order = 'this.sort desc,this.id desc';
		$list = $sc->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();

		$this->assign('teacher',$list);
		$this->assign('page', $show);
		$this->assign('course_id',$id);
		$this->display('teacherList');
	}
	
	//老师修改
	public function teacherListEdit(){
		$id = $_GET['id'];
		$editType = !empty($id) ? 'update' : 'create';

		if ($editType == 'update') {
			$field = 't.teacher_name,t.teacher_head_img,t.teacher_description,t.teacher_info,this.id,this.sort,this.video_url,this.video_title,this.video_cover,this.learning_objectives,this.suitable_object,this.teacher_id';
			$join = 'as this left join ' . C('DB_PREFIX') . 'school_teacher as t on this.teacher_id = t.id ';
			$where['this.id'] = $id;
			$data = M('SchoolCourseTeacher')->join($join)->field($field)->where($where)->find();
			$this->assign('data',$data);
			
		}
		$this->assign('course_id',I('get.course_id'));
		$this->assign('editType', $editType);
		$this->display('teacherListEdit');
	}
	
	//修改老师提交
	public function editTeacherList(){
		header('Content-type:text/html;charset=utf-8');
		//dump($_POST);die;

		$obj = $this->chenUpload('./Upload/ActivityVideo/');
		$editType = I('post.editType');
		$course_id = I('course_id');
		$teacher['teacher_head_img'] 	= I('teacher_head_img');
		$teacher['teacher_name'] 		= I('teacher_name');
		$teacher['teacher_description'] = I('teacher_description');
		$teacher['teacher_info'] 		= I('teacher_info');
		
		$course_teacher['video_title'] 			= I('video_title');
		$course_teacher['video_cover'] 			= I('video_cover');
		$course_teacher['video_url'] 			= I('video_url');
		$course_teacher['sort'] 				= I('sort');
		$course_teacher['suitable_object'] 		= I('suitable_object');
		$course_teacher['learning_objectives'] 	= I('learning_objectives');
		$course_teacher['course_id'] 			= $course_id;
		
		
		if ($editType == 'update') {
			$where_course['id'] 			= I('post.id');	
			$teacher['update_time'] 		= time();
			
			$where_teacher['id'] 			= I('teacher_id');
			$course_teacher['update_time'] 	= time();
		}else if($editType == 'create'){
		
			$teacher['time'] 				= time();
			$course_teacher['time'] 		= time();		
		}
			$teacher['admin_id'] 			= session('adminid');
			$course_teacher['admin_id'] 	= session('adminid');
		
		if (is_array($obj)) {
			$datadir = date('Ym');
			if ($obj[0]) {
				$teacher['teacher_head_img'] = S_URL . '/Public/Upload/ActivityVideo/' . $datadir . '/' . $obj[0]['savename'];
			}
			if ($obj[1]) {
				$course_teacher['video_cover'] = S_URL . '/Public/Upload/ActivityVideo/' . $datadir . '/' . $obj[1]['savename'];
			}
		}
		
		if($editType == 'update'){
			D()->startTrans();
			$ret1 = D('SchoolTeacher')->where($where_teacher)->save($teacher);
			$ret2 = D('SchoolCourseTeacher')->where($where_course)->save($course_teacher);
			if($ret1 && $ret2){
				D()->commit();
				$this->success('更新成功','/Admin/ActivityTeacher/teacherList/id/'.$course_id);
			}else{
				D()->rollback();
				$this->error('修改失败');
			}
		}else if($editType == 'create'){
			D()->startTrans();
			$ret1 = D('SchoolTeacher')->add($teacher);
			$course_teacher['teacher_id'] = $ret1;
			$ret2 = D('SchoolCourseTeacher')->add($course_teacher);
			if($ret1 && $ret2){
				D()->commit();
				$this->success('添加成功','/Admin/ActivityTeacher/teacherList/id/'.$course_id);
			}else{
				D()->rollback();
				$this->error('添加失败');
			}	
		}
	}
	
	//老师回放视频列表
	public function teacherVideoList($course_id,$teacher_id){
		$foodType = M('school_course');
		$data = $foodType->find($course_id);
		$this->assign('data', $data);

		$sc = D('ActivityVideoDir');
		$where['activity_id'] = $course_id;
		$where['teacher_id'] = $teacher_id;
		$count = $sc->where($where)->count();
		$Page = new \Think\Page($count,10);
		$show = $Page->show();
		$order = 'sort desc,id desc';
		$field = 'id,cover,title_level,title,film_length,url,sort,activity_id,teacher_id';
		$list = $sc->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();
		$this->assign('video',$list);
		$this->assign('page', $show);
		//dump($list);
		$this->assign('course_id',$course_id);
		$this->assign('teacher_id',$teacher_id);
		$this->display('teacherVideoList');
	}
	
	
	//老师回放视频列表修改
	public function teacherVideoListEdit($course_id,$teacher_id){
		$id = $_GET['id'];
		$editType = !empty($id) ? 'update' : 'create';
		if ($editType == 'update') {
			$where['id'] = $id;
			$data = M('ActivityVideoDir')->where($where)->find();
			$this->assign('data',$data);
			
		}
		//dump($data);
		$this->assign('course_id',$course_id);
		$this->assign('teacher_id',$teacher_id);
		$this->assign('editType', $editType);
		$this->display('teacherVideoListEdit');
	}
	
	//老师回放视频列表修改提交
	public function editTeacherVideoList($course_id,$teacher_id){
		
		$obj = $this->chenUpload('./Upload/ActivityVideoCover/');
		$editType = I('post.editType');
		$data['activity_id'] 	= $course_id;
		$data['teacher_id'] 	= $teacher_id;
		$data['cover'] 			= I('post.cover');
		$data['title_level'] 	= I('post.title_level');
		$data['title'] 			= I('post.title');
		$data['film_length'] 	= I('post.film_length');
		$data['url'] 			= I('post.url');
		$data['sort'] 			= I('post.sort');
		
		$data['admin_id'] 		= session('adminid');
		
		if (is_array($obj)) {
			$datadir = date('Ym');
			if ($obj[0]) {
				$data['cover'] = S_URL . '/Public/Upload/ActivityVideoCover/' . $datadir . '/' . $obj[0]['savename'];
			}
		}
		
		if ($editType == 'update') {	
			$data['update_time']= time();
			$where['id'] = I('post.id');
			if(M('ActivityVideoDir')->where($where)->save($data)){
				$this->success('更新成功','/Admin/ActivityTeacher/teacherVideoList/course_id/'.$course_id.'/teacher_id/'.$teacher_id);
			}else{
				$this->error('更新失败');
			}
		}else if($editType == 'create'){	
			$data['time'] 		= time();
			
			if(M('ActivityVideoDir')->add($data)){
				$this->success('添加成功','/Admin/ActivityTeacher/teacherVideoList/course_id/'.$course_id.'/teacher_id/'.$teacher_id);
			}else{
				$this->error('添加失败');
			}
		}
		
		
	}
	
	
	
	protected function chenUpload($fsave){
		$upload = new \Think\Upload();// 实例化上传类    
		$upload->maxSize = 1024 * 1024 * 40;// 设置附件上传大小
		$upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
		$upload->savePath = $fsave; // 设置附件上传目录
		$upload->thumbRemoveOrigin = false; //上传图片后删除原图片
		// 上传文件     
		$info = $upload->upload();
		if (!$info) {// 上传错误提示错误信息
			return $upload->getError();
		} else {// 上传成功
			return $info;
		}
	}
    
     public function activitydel($id){
       $name=M('school_course');
       $pname=$name->where('id='.$id)->delete();
       if($pname){
       	$this->success('删除成功');
       }else{
       	$this->success('删除失败');
       }
    }

     public function teacherListdelete(){
       $delete = M('school_course_teacher');
       $result = $delete ->where(array('course_id'=>$_GET['course_id'],'id'=>$_GET['id']))->delete();
       if($result){
       	$this->success('删除成功');
       }else{
       	$this->success('删除失败');
       }
     }

}