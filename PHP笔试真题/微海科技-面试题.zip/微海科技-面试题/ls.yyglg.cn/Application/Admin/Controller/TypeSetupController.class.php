<?php
namespace Admin\Controller;

use Think\Controller;

class TypeSetupController extends ExtendController
{

	//行业类型列表-------------------------------------------------------------------------
	public function vocation()
	{
		$search = !empty($_GET['search']) ? $_GET['search'] : 'all';
		//行业类型名字
		if ($search != 'all') {
			$where['student_vocation_name'] = array('like', '%' . trim($search) . '%');
			$this->assign('search', $search);
		}
		$order = 'student_vocation_id desc';
		A('Public')->getList('student_vocation', '*', $where, $order, 20, 'vocation');
	}

	//行业类型列表 新增、编辑
	public function vocationEdit()
	{
		A('Public')->getEdit('student_vocation');
		$this->assign('status', A('GetSelect')->getIsShowS($this->data['status'], 'status'));
		$this->display('vocationEdit');
	}


	//职业类型列表-------------------------------------------------------------------------
	public function position()
	{
		$search = !empty($_GET['search']) ? $_GET['search'] : 'all';
		//行业类型名字
		if ($search != 'all') {
			$where['student_position_name'] = array('like', '%' . trim($search) . '%');
			$this->assign('search', $search);
		}
		$order = 'student_position_id desc';
		A('Public')->getList('student_position', '*', $where, $order, 20, 'position');
	}

	//职业类型列表 新增、编辑
	public function positionEdit()
	{
		A('Public')->getEdit('student_position');
		$this->assign('status', A('GetSelect')->getIsShowS($this->data['status'], 'status'));
		$this->display('positionEdit');
	}


	//入学类型列表-------------------------------------------------------------------------
	public function apply()
	{
		$search = !empty($_GET['search']) ? $_GET['search'] : 'all';
		//入学类型名字
		if ($search != 'all') {
			$where['student_apply_type_name'] = array('like', '%' . trim($search) . '%');
			$this->assign('search', $search);
		}
		$order = 'student_apply_type_id desc';
		A('Public')->getList('student_apply_type', '*', $where, $order, 20, 'apply');
	}

	//入学类型列表 新增、编辑
	public function applyEdit()
	{
		A('Public')->getEdit('student_apply_type');
		$this->assign('status', A('GetSelect')->getIsShowS($this->data['status'], 'status'));
		$this->display('applyEdit');
	}

	//支付类型列表-------------------------------------------------------------------------
	public function payType()
	{
		$search = !empty($_GET['search']) ? $_GET['search'] : 'all';
		//支付类型名字
		if ($search != 'all') {
			$where['student_pay_type_name'] = array('like', '%' . trim($search) . '%');
			$this->assign('search', $search);
		}

		$order = 'student_pay_type_id desc';

		A('Public')->getList('student_pay_type', '*', $where, $order, 20, 'payType');
	}

	//支付类型列表 新增、编辑
	public function payTypeEdit()
	{
		A('Public')->getEdit('student_pay_type');
		$this->assign('status', A('GetSelect')->getIsShowS($this->data['status'], 'status'));
		$this->display('payTypeEdit');
	}

	//请假类型列表-------------------------------------------------------------------------
	public function leaveType()
	{
		$search = !empty($_GET['search']) ? $_GET['search'] : 'all';
		//支付类型名字
		if ($search != 'all') {
			$where['student_leave_type_name'] = array('like', '%' . trim($search) . '%');
			$this->assign('search', $search);
		}
		$order = 'student_leave_type_id desc';
		A('Public')->getList('student_leave_type', '*', $where, $order, 20, 'leaveType');
	}

	//支付类型列表 新增、编辑
	public function leaveTypeEdit()
	{
		A('Public')->getEdit('student_leave_type');
		$this->assign('status', A('GetSelect')->getIsShowS($this->data['status'], 'status'));
		$this->display('leaveTypeEdit');
	}


}