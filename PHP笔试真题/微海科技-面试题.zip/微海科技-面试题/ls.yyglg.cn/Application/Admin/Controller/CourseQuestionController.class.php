<?php
namespace Admin\Controller;
use Think\Controller;
class CourseQuestionController extends ExtendController {
   private $temperatureNum = 20;//空调问题每页显示个数
   private $lampNum = 20;//灯光问题每页显示个数
   private $musicNum = 20;//音响问题每页显示个数
   private $otherQuestionNum = 20;//其他问题每页显示个数
//-----------------------------------------------------------------------------------------空调问题
	//空调问题
	public function temperature(){
		$course_id = I('get.course');
		$this->assign('course_id',$course_id);

		$sc = D('student_course_question_temperature');
		$join = 'as tem inner join '.C('DB_PREFIX').'student as st on tem.student_id = st.id ';
		$where['tem.course_id'] = $course_id;
		$field = 'tem.course_id,st.true_name as student_true_name,st.mobile_phone as student_mobile_phone,tem.type as question_type,tem.time as question_time,tem.seat_number as question_seat_number';

		$count      = $sc->join($join)->where($where)->count();
		$Page       = new \Think\Page($count,$this->temperatureNum);
		$show       = $Page->show();

		$list = $sc->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('list',$list);
		$this->assign('page',$show);

		$this->display('temperature');
	}
	
	//灯光问题
	public function lamp(){
		$course_id = I('get.course');
		$this->assign('course_id',$course_id);
	
		$sc = D('student_course_question_lamp');
		$join = 'as tem inner join '.C('DB_PREFIX').'student as st on tem.student_id = st.id ';
		$where['tem.course_id'] = $course_id;
		$field = 'tem.course_id,st.true_name as student_true_name,st.mobile_phone as student_mobile_phone,tem.type as question_type,tem.time as question_time,tem.seat_number as question_seat_number';

		$count      = $sc->join($join)->where($where)->count();
		$Page       = new \Think\Page($count,$this->lampNum);
		$show       = $Page->show();

		$list = $sc->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('list',$list);
		$this->assign('page',$show);

		$this->display('lamp');
	}
	
	//音响问题
	public function music(){
		$course_id = I('get.course');
		$this->assign('course_id',$course_id);
	
		$sc = D('student_course_question_music');
		$join = 'as tem inner join '.C('DB_PREFIX').'student as st on tem.student_id = st.id ';
		$where['tem.course_id'] = $course_id;
		$field = 'tem.course_id,st.true_name as student_true_name,st.mobile_phone as student_mobile_phone,tem.type as question_type,tem.time as question_time,tem.seat_number as question_seat_number';
		$count      = $sc->join($join)->where($where)->count();
		$Page       = new \Think\Page($count,$this->musicNum);
		$show       = $Page->show();
		$list = $sc->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('list',$list);
		$this->assign('page',$show);
		$this->display('music');
	}

	
	
	//其他问题
	public function otherQuestion(){
		$course_id = I('get.course');
		$this->assign('course_id',$course_id);
	
		$sc = D('school_course_question_other');
		$join = 'as tem inner join '.C('DB_PREFIX').'student as st on tem.student_id = st.id ';
		$where['tem.course_id'] = $course_id;
		$field = 'tem.course_id,st.true_name as student_true_name,st.mobile_phone as student_mobile_phone,tem.msg as question_msg,tem.time as question_time,tem.seat_number as question_seat_number';

		$count      = $sc->join($join)->where($where)->count();
		$Page       = new \Think\Page($count,$this->otherQuestionNum);
		$show       = $Page->show();

		$list = $sc->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('list',$list);
		$this->assign('page',$show);

		$this->display('otherQuestion');
	}
	
	
	//用餐问题--------------------------------------------------------------------------------------------
	public function food(){
		$course_id = I('get.course');
		//查询该课程的用餐问题是否存在
		if(!M('school_course_question_food')->where(array('course_id'=>$course_id))->find()){
			$this->redirect('/Admin/CourseQuestion/foodEdit/course/'.$course_id);
		}
		
		
		$this->assign('course_id',$course_id);
	
		$sc = D('school_course_question_food');
		$where['course_id'] = $course_id;
		$field = 'href,time,update_time,admin_id,course_id,id';
		$count      = $sc->where($where)->count();
		$Page       = new \Think\Page($count,$this->temperatureNum);
		$show       = $Page->show();
		$list = $sc->relation('admin')->field($field)->where($where)->order($order)->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('list',$list);
		$this->assign('page',$show);
		$this->display('food');
	}
	//用餐问题新增||修改
	public function foodEdit(){	
		A('Public')->getEdit('school_course_question_food');
		$s = M('school_course')->field('name')->where(array('id'=>$this->data['course_id']))->find();
		$this->assign('course_name',$s['name']);
		$this->assign('course_id',I('get.course'));
		$this->display('foodEdit');
	}
	
   
   
   
   
	//饮水问题--------------------------------------------------------------------------------------------
	public function water(){
		$course_id = I('get.course');
		//查询该课程的饮水题是否存在
		if(!M('school_course_question_water')->where(array('course_id'=>$course_id))->find()){
			$this->redirect('/Admin/CourseQuestion/waterEdit/course/'.$course_id);
		}
		$this->assign('course_id',$course_id);
		$sc = D('school_course_question_water');
		$where['course_id'] = $course_id;
		$field = 'content,time,update_time,admin_id,course_id,id';
		$count      = $sc->where($where)->count();
		$Page       = new \Think\Page($count,$this->temperatureNum);
		$show       = $Page->show();
		$list = $sc->relation('admin')->field($field)->where($where)->order($order)->limit($Page->firstRow.','.$Page->listRows)->select();
		$this->assign('list',$list);
		$this->assign('page',$show);
		$this->display('water');
	}
	//饮水问题新增||修改
	public function waterEdit(){	
		A('Public')->getEdit('school_course_question_water');
		$s = M('school_course')->field('name')->where(array('id'=>$this->data['course_id']))->find();
		$this->assign('course_name',$s['name']);
		$this->assign('course_id',I('get.course'));
		$this->display('waterEdit');
	}
   
   
   
   
   
}