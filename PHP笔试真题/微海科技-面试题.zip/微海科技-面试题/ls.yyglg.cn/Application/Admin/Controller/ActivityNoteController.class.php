<?php
namespace Admin\Controller;
use Think\Controller;
class ActivityNoteController extends ExtendController {
	
	//学生笔记列表
	public function noteList($id){

		$sc = D('ActivityNote');
		$field = '';
		$where['activity_id'] = $id;
		$where['user_type'] = 1;
		$count = $sc->where($where)->count();
		$Page = new \Think\Page($count,10);
		$show = $Page->show();
		$order = 'is_top desc,top_number desc';
		$list = $sc->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();

		$this->assign('list',$list);
		$this->assign('page', $show);	
		
		$this->assign('activity_id',$id);
		$this->display('noteList');
	}
	
	
	//官方笔记列表
	public function systemNoteList($id){

		$sc = D('ActivityNote');
		$field = '';
		$where['activity_id'] = $id;
		$where['user_type'] = 2;
		$count = $sc->where($where)->count();
		$Page = new \Think\Page($count,10);
		$show = $Page->show();
		$order = 'is_top desc,top_number desc';
		$list = $sc->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();

		$this->assign('list',$list);
		$this->assign('page', $show);	
		
		$this->assign('activity_id',$id);
		$this->display('systemNoteList');
	}

	/**
	 * 官方笔记修改
	 *
	 * @param $activity_id
	 */
	public function systemNoteListEdit($activity_id){
		$id = $_GET['note_id'];
		$editType = !empty($id) ? 'update' : 'create';

		if ($editType == 'update') {
			$field = '*';

			$where['id'] = $id;
			$data = M('ActivityNote')->field($field)->where($where)->find();

			$this->assign('data',$data);
		}

		$this->assign('activity_id',$activity_id);
		$this->assign('editType', $editType);

		$this->display('systemNoteListEdit');
	}
	
	//官方笔记修改提交
	public function editSystemNoteList($editType,$activity_id){
		
		$obj = $this->chenUpload('./Upload/SystemNoteHeadImg/');

		$data['statics_name'] 		= I('post.statics_name');
		$data['statics_head_img'] 	= I('post.statics_head_img');
		$data['content'] 			= I('post.content');
		$data['activity_id'] 		= $activity_id;
		$data['user_type'] 			= 2;
		
		$data['admin_id'] 			= session('adminid');
		$data['jump_href'] 			= I('post.jump_href');
		
		if (is_array($obj)) {
			$datadir = date('Ym');
			if ($obj[0]) {
				$data['statics_head_img'] = S_URL . '/Public/Upload/SystemNoteHeadImg/' . $datadir . '/' . $obj[0]['savename'];
			}
		}
		
		if ($editType == 'update') {	
			$data['update_time']= time();

			$where['id'] = I('post.id');

			if(M('ActivityNote')->where($where)->save($data)){
				$this->success('更新成功','/Admin/ActivityNote/systemNoteList/id/'.$activity_id);
			}else{
				$this->error('更新失败');
			}
		}else if($editType == 'create'){	
			$data['time'] 		= time();
			
			if(M('ActivityNote')->add($data)){
				$this->success('添加成功','/Admin/ActivityNote/systemNoteList/id/'.$activity_id);
			}else{
				$this->error('添加失败');
			}
		}
		
		
	}
	
	
	
	//笔记置顶
	public function setTop($id,$type){
		$where['id'] =$id;
		$save['is_top'] = $type;
		$save['update_time'] = time();
		$save['admin_id'] = session('adminid');
		if(D('ActivityNote')->where($where)->save($save)){
			$this->ajaxReturn(array('ret'=>'true'));
		}else{
				
			$this->ajaxReturn(array('ret'=>'false'));
		}
	}
	
	
	
	
	protected function chenUpload($fsave){
		$upload = new \Think\Upload();// 实例化上传类    
		$upload->maxSize = 1024 * 1024 * 40;// 设置附件上传大小
		$upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
		$upload->savePath = $fsave; // 设置附件上传目录
		$upload->thumbRemoveOrigin = false; //上传图片后删除原图片
		// 上传文件     
		$info = $upload->upload();
		if (!$info) {// 上传错误提示错误信息
			return $upload->getError();
		} else {// 上传成功
			return $info;
		}
	}
	
}