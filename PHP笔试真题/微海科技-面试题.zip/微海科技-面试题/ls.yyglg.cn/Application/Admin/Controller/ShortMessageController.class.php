<?php
namespace Admin\Controller;

use Think\Controller;

class ShortMessageController extends ExtendController
{


//-----------------------------------------------------------------------------------------短信模板管理
	//短信模板列表
	public function shortMessageTemplateList()
	{
		$where = 1;
		$order = 'update_time DESC';
		A('Public')->getList('system_short_message', '*', $where, $order, 20, 'shortMessageTemplateList');
	}

	//分组新增||修改
	public function shortMessageTemplateListEdit()
	{
		A('Public')->getEdit('system_short_message');

		$this->assign('status', A('GetSelect')->getIsShowS($this->data['status'], 'status'));

		$this->display();
	}

//-----------------------------------------------------------------------------------------短信推送记录（主动）
	//短信推送记录（主动）
	public function shortMessageSendList()
	{
		$where = 1;
		$order = 'id desc';
		A('Public')->getList('system_short_message_send_record', '*', $where, $order, 20, 'shortMessageSendList');
	}

	//添加一条推送
	public function shortMessageSendListEdit()
	{
		//查询会员标签
		$this->assign('templateList', M('system_short_message')->field('title,content')->select());
		$this->assign('tagList', M('student_tag')->field('id,name')->select());
		$this->assign('editType', 'create');
		$this->display('shortMessageSendListEdit');
	}


}