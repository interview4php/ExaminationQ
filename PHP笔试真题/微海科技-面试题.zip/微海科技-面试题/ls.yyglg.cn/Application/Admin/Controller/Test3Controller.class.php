<?php
namespace Admin\Controller;
use Think\Controller;

/**
 * Class Test3Controller
 * @package Admin\Controller
 */
class Test3Controller extends Controller {
	/**
	 *
	 */
   public function dump_wx_send_param() {
	   $obj = M('wx_template_send_list');

	   $send_data = $obj->where(array('id' => 121))->getField('send_data');

	   $send_data = unserialize($send_data);

	   dump($send_data);
   }
}