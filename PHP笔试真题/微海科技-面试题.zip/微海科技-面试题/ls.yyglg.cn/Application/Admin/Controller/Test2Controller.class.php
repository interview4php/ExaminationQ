<?php
namespace Admin\Controller;

use Think\Controller;

class Test2Controller extends Controller
{

	public function load_student_course() {
		$sql = "SELECT * FROM `y_student_course` where (time >  unix_timestamp('2016-03-26 11:20:00')
or (update_time >  unix_timestamp('2016-03-26 11:20:00') and status > 1))";

		//  and student_id in (select id from y_student where id>47836)

		$data = M('school_course')->query($sql);

		$ret = file_put_contents('latest_student_course1.txt', serialize($data));

		var_dump($ret);
	}

	public function insert_update_student_course() {
		$data = file_get_contents('latest_student_course1.txt');

		$obj_sc = M('student_course');

		$arr_data = unserialize($data);
		foreach ($arr_data as $value) {

			if (47837 == $value['student_id']) {
				$value['student_id'] = 47978;
			} elseif (47845 == $value['student_id']) {
				$value['student_id'] = 47986;
			} elseif (47849 == $value['student_id']) {
				$value['student_id'] = 47990;
			}

			$cond = array(
				'school_course_id' => $value['school_course_id'],
				'student_id' => $value['student_id'],
				'activity_place_id' => $value['activity_place_id']
			);
			$result = $obj_sc->where($cond)->find();

			if (empty($result)) {
				// insert student course sign record

				echo "insert {$result['id']}<br />";

				unset($value['id']);

				$ret = $obj_sc->add($value);
			} elseif ($result['update_time'] < $value['update_time']) {
				$data = array(
					'status' => $value['status'],
					'msg' => $value['msg'],
					'update_time' => $value['update_time'],
				);
				$ret = $obj_sc->where($cond)->save($data);

				echo "update {$result['id']}<br />";
			} else {
				echo "no update or insert<br />";
			}
		}

	}
}