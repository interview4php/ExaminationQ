<?php
namespace Admin\Controller;

use Think\Controller;

class CommunityController extends ExtendController
{
  public function index(){
  	if($_GET['search']){
  		$User=M('community_space');
  		$count = $User->where("title like'".$_GET['search'].'%'."'")->count();
		$Page = new \Think\Page($count, 5);
		$Page->setConfig('theme', '%HEADER% %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%');
		$show = $Page->show();
		$user_list = $User->where("title like'".$_GET['search'].'%'."'")->order('id desc')->limit($Page->firstRow . ',' . $Page->listRows)->select();
        $k=count($user_list)-1;
	  	for($i=0;$i<=$k;$i++){
	      $course=M('school_course')->where('id='.$user_list[$i]['school_course_id'])->find();
	      $user_list[$i]['activity']=$course['name'];
	  	}
	  	$this->assign('list',$user_list);
	  	$this->assign('page',$show);
  	}else{
  		$User=M('community_space');
  		$count = $User->count();
		$Page = new \Think\Page($count, 5);
		$Page->setConfig('theme', '%HEADER% %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%');
		$show = $Page->show();
		$user_list = $User->order('id desc')->limit($Page->firstRow . ',' . $Page->listRows)->select();
	  	$k=count($user_list)-1;
	  	for($i=0;$i<=$k;$i++){
	      $course=M('school_course')->where('id='.$user_list[$i]['school_course_id'])->find();
	      $user_list[$i]['activity']=$course['name'];
	  	}
	  	$this->assign('list',$user_list);
	  	$this->assign('page',$show);
  	}
  	
  	$this->display();
  }
  
  public function useradd(){
  	if($_POST){
     $com=M('community_space');
     $com->time=$_POST['time'];
     $com->title=$_POST['title'];
     $com->content=$_POST['content'];
     $com->school_course_id=$_POST['courseid'];

	$admindata=session('admindata');
		$username=$admindata['user_name'];

     $com->admin_name=$username;
     $result=$com->add();
     if($result){
      $this->success('添加成功！',"/admin/community/index");
     }else{
     $this->success('添加失败！');
     }
  	}else{
  		$course=M('school_course')->select();
  		$this->assign('data',$course);
  	}
  	$this->display();
  }

  public function useredit(){
  	if($_POST){
     $com=M('community_space');
     if($_POST['time']){
     	$com->time=$_POST['time'];
     }
     if($_POST['title']){
     	$com->title=$_POST['title'];
     }
     if($_POST['content']){
     	$com->content=$_POST['content'];
     }
     if($_POST['courseid']){
     	$com->school_course_id=$_POST['courseid'];
     }
     $result=$com->where('id='.$_POST['id'])->save();
     if($result){
      $this->success('编辑成功！',"/admin/community/index");
     }else{
     $this->success('编辑失败！');
     }
  	}else{
  		$comrel=M('community_space')->where('id='.$_GET['id'])->find();
  		$courseall=M('school_course')->where('id='.$comrel['school_course_id'])->find();
  		$comrel['name']=$courseall['name'];
         $this->assign('list',$comrel);
  		$course=M('school_course')->select();
  		$this->assign('data',$course);
  	}
  	$this->display();
  }


  public function delete(){
  	$com=M('community_space');
  	$result=$com->where('id='.$_GET['id'])->delete();
     if($result){
      $this->success('删除成功！');
     }else{
     $this->success('删除失败！');
     }
  }
}