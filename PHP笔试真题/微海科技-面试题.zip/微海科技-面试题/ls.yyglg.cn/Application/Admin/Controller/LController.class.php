<?php
namespace Admin\Controller;
use Think\Controller;
class LController extends Controller {
    
	public function loginsubmit(){
		if(!empty($_POST)){
			if($this->isLogin($_POST['name'],$_POST['pass'])){
				redirect('/Admin/Index/index');
			}else{
				$this->error('登录失败');
			}
		}
	}
	protected function isLogin($name,$password){
		
		$where['user_name'] = trim($name);
		$where['password'] = md5(trim($password));
		$data = M('admin')->where($where)->find();
//		dump($data);exit;
		if($data){
			session('adminid',$data['id']);
			session('admindata',$data);

			return true;
		}else{
			return false;
		}
		
		
	}
	
	public function userloginout(){
	
		$_SESSION = array(); //清除SESSION值.
         if(isset($_COOKIE[session_name()])){  //判断客户端的cookie文件是否存在,存在的话将其设置为过期.
			setcookie(session_name(),'',time()-1,'/');
		}
		session_destroy();  //清除服务器的sesion文件
		$this->redirect('L/login');
		
	}
	//修改密码
	public function editPassword(){
		if($_POST['newp']==$_POST['newp2']){
			if(preg_match("/^[0-9a-zA-z]\w{5,15}$/",$_POST['newp'])){
				$adminid=session('adminid');
				$data = M('admin')->where(array('id'=>$adminid,'password'=>md5($_POST['password'])))->find();
				if($data){
					if(M('admin')->where(array('id'=>$adminid))->save(array('password'=>md5($_POST['newp'])))){
						$this->success('密码修改成功，请牢记密码！');
					}else{
						$this->error('服务器繁忙，请稍后再试');
					}
				}else{
					$this->error('密码错误');
				}
			}else{
				$this->error('密码由6-15个字母或数字组成');		  
			} 
		}else{
			$this->error('两次密码不相符');
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}