<?php
namespace Admin\Controller;

use Think\Controller;

class IndexController extends ExtendController
{
    public function index()
    {

        $this->display();
    }

    public function header()
    {

        $this->assign('admindata', session('admindata'));
        $this->display();
    }

    public function menu()
    {
        $data=session('admindata');
        $rights=$data['rights'];
        $rights = explode(',',$rights);


        $rightsData = array();
        foreach ($rights as $value) {
            $this->assign($value, 1);

            $rightsData[$value] = 1;


        }
        $this->assign('admindata', session('admindata'));
        $this->display();
    }

    public function main()
    {
        //查询会员总数量
//        $this->assign('all_vip', M('student')->where(array('student_type' => '会员'))->count());
                $this->assign('all_vip', M('student')->count());
        //查询课程总数量
        $this->assign('all_course', M('school_course')->where(array('type' => 0))->count());
        //查询学院总数量
        $this->assign('all_school', M('school')->count());

        //查询课程总数量
        $this->assign('all_activity', M('school_course')->where(array('type' => 1))->count());

        //查询总打赏
        //$this->assign('all_reward_money',M('school_course_reward')->sum('price'));

        $this->assign('admindata', session('admindata'));
        $this->display();
    }


}