<?php
namespace Admin\Controller;

use Think\Controller;

class DelController extends ExtendController
{

	//删除管理员
	public function delAdmin()
	{
		$where['id'] = I('post.id');
		$this->del('admin', $where);
	}

	//删除管理员分组
	public function delAdminGroup()
	{
		$where['id'] = I('post.id');
		$this->del('admin_group', $where);
	}

	//删除学院课程里面的老师
	public function delSCourseTeacher()
	{
		$where['id'] = I('post.id');
		$this->del('school_course_teacher', $where);
	}

	//删除学生座位（学生想换做的时候）
	public function delStudentSeat()
	{

		$where['student_course_seat_id'] = I('post.id');
		//查询该位置的课程号和座位号
		$data = D('student_course_seat')->field('course_id,student_id')->where($where)->find();

		D()->startTrans();
		$ret1 = D('student_course_seat')->where($where)->delete();
		//回复该座位号的状态
		$ret2 = D('school_course_seat')->delOneSeatStatus($data['course_id'], $data['student_id']);
		if ($ret1) {
			D()->commit();
			echo 'true';
		} else {
			D()->rollback();
			echo 'false';
		}
	}

	//删除打赏里面的打赏对象（老师）
	public function delRewardTeacher()
	{
		$where['id'] = I('post.id');
		$where['money'] = 0;
		$where['count'] = 0;
		$this->del('system_reward_teacher', $where);
	}

	//删除打赏里面的抽奖(只有未有抽出数并且状态为禁用才可以删除)
	public function delRewardLuckDraw()
	{
		$where['id'] = I('post.id');
		$where['draw_use_number'] = 0;
		$where['draw_status'] = 0;
		$this->del('system_reward_luck_draw', $where);
	}

	//删除课程里面的PPT
	public function delSCoursePPT()
	{
		$where['id'] = I('post.id');
		$this->del('school_course_ppt', $where);
	}


	//删除操作
	private function del($table, $where)
	{

		$User = M($table);
		if ($User->where($where)->delete()) {
			echo 'true';
		} else {
			echo 'false';
		}

	}

	//是否店铺假删除
	private function falseDel($table, $where, $field = 'is_delete')
	{
		$User = M($table);
		$data[$field] = 1;
		if ($User->where($where)->save($data)) {
			echo 'true';
		} else {
			echo 'false';
		}
	}


	//删除活动  2016-2-29
	public function delActivity()
	{
		$id = I('post.id');

        $activity_model = M('activity');
        $activity_place_model = M('activity_place');

        $y_activity_bool = $activity_model->where('id = '.$id)->delete();
        if ($y_activity_bool)
        {
            echo 'true';
        }else{
            echo 'false';
        }

	}
	
	//删除笔记
	public function delNote(){
			
		$where['id'] = I('post.id');
		$this->del('activity_note', $where);
		
		
	}
	
	
}