<?php
namespace Admin\Controller;

use Think\Controller;

class MyImportExcelController extends ExtendController
{
	/**方法**/
	function  index()
	{
		$this->display();
	}

	/**
	 * 导入F码
	 */
	function impFcode()
	{
		set_time_limit(3600);

		if (!empty($_FILES)) {
			$course_id = I('post.course_id');
			$upload = new \Think\Upload();// 实例化上传类    
			$upload->maxSize = 1024 * 1024 * 100;// 设置附件上传大小
			$upload->exts = array('xls');// 设置附件上传类型
			$upload->savePath = '/Upload/excel/'; // 设置附件上传目录
			$info = $upload->upload();
			if (!$info) {// 上传错误提示错误信息
				$this->error($upload->getError());
			}

			vendor("PHPExcel.PHPExcel");
			$file_name = './Public' . $info['file']['savepath'] . $info['file']['savename'];
			$objReader = \PHPExcel_IOFactory::createReader('Excel5');
			$objPHPExcel = $objReader->load($file_name, $encode = 'utf-8');
			$sheet = $objPHPExcel->getSheet(0);
			$highestRow = $sheet->getHighestRow(); // 取得总行数
			$highestColumn = $sheet->getHighestColumn(); // 取得总列数

			for ($j = 0, $i = 2; $i <= $highestRow; $i++, $j++) {
				$data[$j]['course_id'] = $course_id;
				$data[$j]['f_code'] = $objPHPExcel->getActiveSheet()->getCell("A" . $i)->getValue();
				$data[$j]['time'] = time();
				$data[$j]['admin_id'] = session('adminid');
			}

			if (M('school_course_fcode')->addAll($data)) {
				$this->success('导入成功！', U('Admin/Course/courseFcodeList/course/' . $course_id));
			} else {
				$this->error('导入失败');
			}

		} else {
			$this->error("请选择上传的文件");
		}


	}


	/**
	 * 导入学生
	 */
	function impStudentWaitting()
	{
		set_time_limit(3600);

		header('Content-type:text/html;charset=utf-8');

		if (!empty($_FILES)) {
			$upload = new \Think\Upload();// 实例化上传类
			$upload->maxSize = 1024 * 1024 * 100;// 设置附件上传大小
			$upload->exts = array('xls');// 设置附件上传类型
			$upload->savePath = '/Upload/excel/'; // 设置附件上传目录
			$info = $upload->upload();
			if (!$info) {// 上传错误提示错误信息
				$this->error($upload->getError());
			}

			vendor("PHPExcel.PHPExcel");

			$file_name = './Public' . $info['file']['savepath'] . $info['file']['savename'];
			$objReader = \PHPExcel_IOFactory::createReader('Excel5');
			$objPHPExcel = $objReader->load($file_name, $encode = 'utf-8');
			$sheet = $objPHPExcel->getSheet(0);
			$highestRow = $sheet->getHighestRow(); // 取得总行数
			$highestColumn = $sheet->getHighestColumn(); // 取得总列数
			$errorNum = 0;
			$successNum = 0;

			$student_data = array();
			for ($j = 0, $i = 2; $i <= $highestRow; $i++, $j++) {
				$student_data['true_name'] = $objPHPExcel->getActiveSheet()->getCell("A" . $i)->getValue();
				$student_data['mobile_phone'] = $objPHPExcel->getActiveSheet()->getCell("B" . $i)->getValue();
				$student_data['student_number'] = $objPHPExcel->getActiveSheet()->getCell("C" . $i)->getValue();
				$student_data['end_time'] = $objPHPExcel->getActiveSheet()->getCell("D" . $i)->getValue();
//				$student_data['is_past_due'] = strtotime($objPHPExcel->getActiveSheet()->getCell("E" . $i)->getValue());
//				$student_data['is_past_due'] = '未过期' == $student_data['is_past_due'] ? 0 : 1;
				if (empty($student_data['end_time'])) {
					$student_data['end_time'] = time();
				} else {
					$student_data['end_time'] = strtotime($student_data['end_time']);
				}

				$student_data['money'] = $objPHPExcel->getActiveSheet()->getCell("F" . $i)->getValue();

				if (empty($student_data['mobile_phone'])) {
					dump('导入失败：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '",原因:手机号不允许为空');
					$errorNum++;
					continue;
				} else {
					//查询手机是否已经存在
					$cond = array('mobile_phone' => $student_data['mobile_phone']);
					$student_id = M('student_waitting')->where($cond)->getField('id');
					if ($student_id) {
						// update
						$ret = M('student_waitting')->where($cond)->save($student_data);

//						dump('导入失败：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '",原因:手机号已存在');
//						$errorNum++;
//						continue;
					} else {
						$ret = M('student_waitting')->add($student_data);
						$student_id = $ret;
					}
				}


				if ($ret !== false) {
					dump('导入成功：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '"');
					$successNum++;
					continue;
				} else {
					dump('导入失败：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '",原因:插入数据库失败');
					$errorNum++;
					continue;
				}
			}

			$strAll = '总行数：' . ($successNum + $errorNum) . '\n\r';
			$strSuc = '成功次数：' . $successNum . '\n\r';
			$strErr = '失败次数：' . $errorNum . '\n\r';

			$this->show("<script type='text/javascript'>alert('{$strAll}{$strSuc}{$strErr}');</script>");
		} else {
			$this->error("请选择上传的文件");
		}
	}

	/**
	 * 导入学生
	 */
	function impStudent()
	{
		set_time_limit(3600);

		header('Content-type:text/html;charset=utf-8');

		if (!empty($_FILES)) {
			$upload = new \Think\Upload();// 实例化上传类    
			$upload->maxSize = 1024 * 1024 * 100;// 设置附件上传大小
			$upload->exts = array('xls');// 设置附件上传类型
			$upload->savePath = '/Upload/excel/'; // 设置附件上传目录
			$info = $upload->upload();
			if (!$info) {// 上传错误提示错误信息
				$this->error($upload->getError());
			}

			vendor("PHPExcel.PHPExcel");

			$file_name = './Public' . $info['file']['savepath'] . $info['file']['savename'];
			$objReader = \PHPExcel_IOFactory::createReader('Excel5');
			$objPHPExcel = $objReader->load($file_name, $encode = 'utf-8');
			$sheet = $objPHPExcel->getSheet(0);
			$highestRow = $sheet->getHighestRow(); // 取得总行数
			$highestColumn = $sheet->getHighestColumn(); // 取得总列数
			$errorNum = 0;
			$successNum = 0;

			$student_data = array();
			for ($j = 0, $i = 2; $i <= $highestRow; $i++, $j++) {
				$student_data['school_student_number'] = $objPHPExcel->getActiveSheet()->getCell("A" . $i)->getValue();
				$student_data['apply_type_id'] = $objPHPExcel->getActiveSheet()->getCell("B" . $i)->getValue();
				$student_data['true_name'] = $objPHPExcel->getActiveSheet()->getCell("C" . $i)->getValue();
				$student_data['user_name'] = $student_data['true_name'];
				$student_data['mobile_phone'] = $objPHPExcel->getActiveSheet()->getCell("D" . $i)->getValue();
				$student_data['time'] = strtotime($objPHPExcel->getActiveSheet()->getCell("E" . $i)->getValue());
				if (empty($student_data['time'])) {
					$student_data['time'] = time();
				}

				$str_end_time = $objPHPExcel->getActiveSheet()->getCell("F" . $i)->getValue();

				$student_data['end_time'] = strtotime($str_end_time);

//				if (empty($student_data['end_time'])) {
//					exit("str end_time={$str_end_time}");
//				}

				$student_data['student_email'] = $objPHPExcel->getActiveSheet()->getCell("G" . $i)->getValue();
				$student_data['student_qq'] = $objPHPExcel->getActiveSheet()->getCell("H" . $i)->getValue();
				$student_data['student_wx'] = $objPHPExcel->getActiveSheet()->getCell("I" . $i)->getValue();
				$student_data['student_birthday'] = strtotime($objPHPExcel->getActiveSheet()->getCell("J" . $i)->getValue());
				$student_data['student_frozen_time'] = $objPHPExcel->getActiveSheet()->getCell("K" . $i)->getValue();
				$student_data['student_invoice_title'] = $objPHPExcel->getActiveSheet()->getCell("L" . $i)->getValue();
				$student_data['student_invoice_address'] = $objPHPExcel->getActiveSheet()->getCell("M" . $i)->getValue();
				$student_data['student_address'] = $objPHPExcel->getActiveSheet()->getCell("N" . $i)->getValue();
				$student_data['company_name'] = $objPHPExcel->getActiveSheet()->getCell("O" . $i)->getValue();
				$student_data['company_address'] = $objPHPExcel->getActiveSheet()->getCell("P" . $i)->getValue();
				$student_data['company_tel'] = $objPHPExcel->getActiveSheet()->getCell("Q" . $i)->getValue();
				$student_data['company_fax'] = $objPHPExcel->getActiveSheet()->getCell("R" . $i)->getValue();
				$student_data['company_vocation_id'] = $objPHPExcel->getActiveSheet()->getCell("S" . $i)->getValue();
				$student_data['company_position_id'] = $objPHPExcel->getActiveSheet()->getCell("T" . $i)->getValue();
				$student_data['recommend_from'] = $objPHPExcel->getActiveSheet()->getCell("U" . $i)->getValue();
				$student_data['account_binding_wxid'] = $objPHPExcel->getActiveSheet()->getCell("V" . $i)->getValue();
				$student_data['is_disable'] = $objPHPExcel->getActiveSheet()->getCell("W" . $i)->getValue();
				$student_data['wx_nick_name'] = $objPHPExcel->getActiveSheet()->getCell("X" . $i)->getValue();
				if (empty($student_data['wx_nick_name'])) {
					$student_data['wx_nick_name'] = '';
				}
				$student_data['wx_province_name'] = $objPHPExcel->getActiveSheet()->getCell("Y" . $i)->getValue();
				if (empty($student_data['wx_province_name'])) {
					$student_data['wx_province_name'] = '';
				}
				$student_data['wx_city_name'] = $objPHPExcel->getActiveSheet()->getCell("Z" . $i)->getValue();
				if (empty($student_data['wx_city_name'])) {
					$student_data['wx_city_name'] = '';
				}

				$grps_name = trim($objPHPExcel->getActiveSheet()->getCell("AA" . $i)->getValue());
				$tags_name = trim($objPHPExcel->getActiveSheet()->getCell("AB" . $i)->getValue());

				$student_data['exclusive_admin_name'] = $objPHPExcel->getActiveSheet()->getCell("AC" . $i)->getValue();
				$student_data['exclusive_admin_wechat'] = $objPHPExcel->getActiveSheet()->getCell("AD" . $i)->getValue();
				if (empty($student_data['exclusive_admin_name'])) {
					$student_data['exclusive_admin_name'] = '';
				}
				if (empty($student_data['exclusive_admin_wechat'])) {
					$student_data['exclusive_admin_wechat'] = '';
				}

				$student_data['admin_id'] = session('adminid');

				if (empty($student_data['school_student_number'])) {
					dump('导入失败：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '",原因:学号不允许为空');
					$errorNum++;
					continue;
				}
				else {
					//查询学号是否已经存在
					if (M('student')->where(array('school_student_number' => $student_data['school_student_number']))->count()) {
						dump('导入失败：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '",原因:学号已存在');
						$errorNum++;
						continue;
					}
				}

				if (empty($student_data['apply_type_id']) || !in_array($student_data['apply_type_id'], array("临时会员","线下会员","线上会员"))) {
					dump('导入失败：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '",原因:学生类型不能为空并且只能是 临时会员 ，线下会员 ，线上会员中的一个');
					$errorNum++;
					continue;
				}
				if ($student_data['apply_type_id'] == '临时会员') {
					$student_data['apply_type_id'] = -1;
				}
				if ($student_data['apply_type_id'] == '线下会员') {
					$student_data['apply_type_id'] = 1;
				}
				if ($student_data['apply_type_id'] == '线上会员') {
					$student_data['apply_type_id'] = 2;
				}
//				if (!in_array($student_data['is_disable'], array(0, 1))) {
//					dump('导入失败：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '",原因:状态只能传入1或者0，空则为默认为1，1为禁用、0为正常');
//					$errorNum++;
//					continue;
//				}
				$student_data['is_disable'] = 1 == $student_data['is_disable'] ? 1 : 0;
				$student_data['company_vocation_id'] = is_numeric($student_data['company_vocation_id']) ? $student_data['company_vocation_id'] : 0;
				switch(trim($student_data['company_position_id'])) {
					case '创始人/合伙人':
						$student_data['company_position_id'] = 1;
						break;
					case '股东/董事':
						$student_data['company_position_id'] = 2;
						break;
					case '投资人':
						$student_data['company_position_id'] = 3;
						break;
					case '总裁/负责人':
						$student_data['company_position_id'] = 4;
						break;
					case '高层管理':
						$student_data['company_position_id'] = 5;
						break;
					case '中层管理':
						$student_data['company_position_id'] = 6;
						break;
					case '一般管理':
						$student_data['company_position_id'] = 7;
						break;
					case '职员':
						$student_data['company_position_id'] = 8;
						break;
					default:
						$student_data['company_position_id'] = 9;
						break;
				}

				if (empty($student_data['mobile_phone'])) {
					dump('导入失败：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '",原因:手机号不允许为空');
					$errorNum++;
					continue;
				} else {
					//查询手机是否已经存在
					$cond = array('mobile_phone' => $student_data['mobile_phone']);
					$student_id = M('student')->where($cond)->getField('id');
					if ($student_id) {
						// update
						$ret = M('student')->where($cond)->save($student_data);

						dump('导入失败：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '",原因:手机号已存在');
						$errorNum++;
						continue;
					} else {
						$ret = M('student')->add($student_data);
						$student_id = $ret;
					}

					// update group or tags
					$this->update_student_group($student_id, $grps_name);
					$this->update_student_tag($student_id, $tags_name);
				}


				if ($ret !== false) {
					dump('导入成功：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '"');
					$successNum++;
					continue;
				} else {
					dump('导入失败：当前行:"' . $i . ',手机号：' . $student_data['mobile_phone'] . '",原因:插入数据库失败');
					$errorNum++;
					continue;
				}
			}

			$strAll = '总行数：' . ($successNum + $errorNum) . '\n\r';
			$strSuc = '成功次数：' . $successNum . '\n\r';
			$strErr = '失败次数：' . $errorNum . '\n\r';

			$this->show("<script type='text/javascript'>alert('{$strAll}{$strSuc}{$strErr}');</script>");
		} else {
			$this->error("请选择上传的文件");
		}
	}
	
	/**
	 * 导入手机号，设置某个课程的已导入手机号为已签到
	 */
	function impSetPhoneIsSign($course_id)
	{
		set_time_limit(3600);
		header('Content-type:text/html;charset=utf-8');
		if (!empty($_FILES)) {
			$upload = new \Think\Upload();// 实例化上传类    
			$upload->maxSize = 1024 * 1024 * 100;// 设置附件上传大小
			$upload->exts = array('xls');// 设置附件上传类型
			$upload->savePath = '/Upload/excel/'; // 设置附件上传目录
			$info = $upload->upload();
			if (!$info) {// 上传错误提示错误信息
				$this->error($upload->getError());
			}

			vendor("PHPExcel.PHPExcel");
			$file_name = './Public' . $info['file']['savepath'] . $info['file']['savename'];
			$objReader = \PHPExcel_IOFactory::createReader('Excel5');
			$objPHPExcel = $objReader->load($file_name, $encode = 'utf-8');
			$sheet = $objPHPExcel->getSheet(0);
			$highestRow = $sheet->getHighestRow(); // 取得总行数
			$highestColumn = $sheet->getHighestColumn(); // 取得总列数

			
			$num_no_student = 0;
			$num_no_sign_up = 0;
			$num_have_leave = 0;
			$num_is_sign = 0;
			$num_success = 0;
			$num_error = 0;
			for ($j = 0, $i = 2; $i <= $highestRow; $i++, $j++) {
				$mobile_phone = $objPHPExcel->getActiveSheet()->getCell("A" . $i)->getValue();
				//查询学生ID
				$student_id = M('student')->where(array('mobile_phone'=>$mobile_phone))->getField('id');
				if($student_id){
					//查询改学生是否报名了该课程
					$course = M('student_course')->where(array(
						'school_course_id'=>$course_id,
						'student_id'=>$student_id,
						'see_type'=>'现场'
					))->find();
					if(!$course){
						$num_no_sign_up++;
						dump('手机号：'.$mobile_phone.'未报名该课程');
					}else{
						if($course['status']=='2'){
							$num_have_leave++;
							dump('手机号：'.$mobile_phone.'已请假');
						}else{
							//查看改手机号是否已签到
							$is_sign = M('student_course_sign')->where(array(
								'course_id'=>$course_id,
								'student_id'=>$student_id
							))->find();
							
							if($is_sign){
								$num_is_sign++;
								dump('手机号：'.$mobile_phone.'已签到');
							}else{
								//帮助用户签到
								$adddata['course_id'] = $course_id;
								$adddata['student_id'] = $student_id;
								$adddata['time'] = time();
								if(M('student_course_sign')->add($adddata)){
									$num_success++;
									dump('手机号：'.$mobile_phone.'签到成功');
								}else{
									$num_error++;
									dump('手机号：'.$mobile_phone.'签到失败');
								}	
							}
						}	
					}
					
				}else{
					//该手机号不存在
					$num_no_student++;
					dump('手机号：'.$mobile_phone.'不存在');
				}
			}
			dump('手机号不存在：'.$num_no_student);
			dump('未报名：'.$num_no_sign_up);
			dump('已请假：'.$num_have_leave);
			dump('已签到：'.$num_is_sign);
			dump('签到成功：'.$num_success);
			dump('签到失败：'.$num_error);
		} else {
			$this->error("请选择上传的文件");
		}


	}

	/**
	 * 导入课程报名的学生
	 *
	 * 姓名	手机	社区编号	邮箱	公司	职位	行业	是否签到	是否支付	座位号	直播码	报名时间	请假状态
	 */
	function impCourseStudent()
	{
		set_time_limit(3600);

		header('Content-type:text/html;charset=utf-8');

		$activity_id = I('post.activity_id');
		if (empty($activity_id)) {
			$this->error('输入出错没有活动信息');
		}

		if (!empty($_FILES)) {
			$upload = new \Think\Upload();// 实例化上传类
			$upload->maxSize = 1024 * 1024 * 100;// 设置附件上传大小
			$upload->exts = array('xls');// 设置附件上传类型
			$upload->savePath = '/Upload/excel/'; // 设置附件上传目录
			$info = $upload->upload();
			if (!$info) {// 上传错误提示错误信息
				$this->error($upload->getError());
			}

			vendor("PHPExcel.PHPExcel");

			$file_name = './Public' . $info['file']['savepath'] . $info['file']['savename'];
			$objReader = \PHPExcel_IOFactory::createReader('Excel5');
			$objPHPExcel = $objReader->load($file_name, $encode = 'utf-8');
			$sheet = $objPHPExcel->getSheet(0);
			$highestRow = $sheet->getHighestRow(); // 取得总行数
			$highestColumn = $sheet->getHighestColumn(); // 取得总列数

			$errorNum = 0;
			$successNum = 0;

			$sign_up_data = array();

			//先设置所有单元格为文本类型
			// for ($j = 0, $i = 0; $i <= $highestRow,$j<$highestColumn; $i++, $j++) {
			// 	setCellType($sheet,$i,$j);
			// }

			for ($j = 0, $i = 2; $i <= $highestRow; $i++, $j++) {
				$sign_up_data['true_name'] = $objPHPExcel->getActiveSheet()->getCell("A" . $i)->getValue();
				$sign_up_data['mobile_phone'] = $objPHPExcel->getActiveSheet()->getCell("B" . $i)->getValue();
				$sign_up_data['student_number'] = $objPHPExcel->getActiveSheet()->getCell("C" . $i)->getValue();
				$sign_up_data['is_sign'] = $objPHPExcel->getActiveSheet()->getCell("D" . $i)->getValue();
				$sign_up_data['is_pay'] = $objPHPExcel->getActiveSheet()->getCell("E" . $i)->getValue();
				$sign_up_data['seat_address'] = $objPHPExcel->getActiveSheet()->getCell("F" . $i)->getValue();
				$sign_up_data['f_code'] = $objPHPExcel->getActiveSheet()->getCell("G" . $i)->getValue();
				$sign_up_data['see_type'] = $objPHPExcel->getActiveSheet()->getCell("H" . $i)->getValue();


				if (empty($sign_up_data['mobile_phone'])) {
					dump('导入失败：当前行:"' . $i . ',手机号：' . $sign_up_data['mobile_phone'] . '",原因:手机号不允许为空');
					$errorNum++;
					continue;
				}

				if (empty($sign_up_data['see_type'])) {
					dump('导入失败：当前行:"' . $i . ',手机号：' . $sign_up_data['mobile_phone'] . '",原因:分会场不允许为空');
					$errorNum++;
					continue;
				}

				//查询手机是否已经存在,不存在则插入
				$cond = array('mobile_phone' => $sign_up_data['mobile_phone']);
				$student_id = M('student')->where($cond)->getField('id');
				if (!$student_id) {
					$new_stu_data = array();
					$new_stu_data['true_name'] = $sign_up_data['true_name'];
					$new_stu_data['user_name'] = $sign_up_data['true_name'];
					$new_stu_data['mobile_phone'] = $sign_up_data['mobile_phone'];
					$new_stu_data['student_type'] = '非会员';
					$new_stu_data['apply_type_id'] = -1;
					
					$new_stu_data['time'] = time();

					$student_id = M('student')->add($new_stu_data);
					if (empty($student_id)) {
						dump('导入失败：当前行:"' . $i . ',手机号：' . $sign_up_data['mobile_phone'] . '",原因:新增用户记录出错');
						$errorNum++;
						continue;
					}
				}

				echo $student_id;

				$sign_up_data['student_id'] = $student_id;

				$cur_time = time();
				$arr_ret = $this->add_student_sign_record($activity_id, $sign_up_data, $cur_time);

				if ($arr_ret !== false && 0 === $arr_ret['code']) {
					dump('导入成功：当前行:"' . $i . ',手机号：' . $sign_up_data['mobile_phone'] . '"');
					$successNum++;
					continue;
				} else {
					dump("导入失败：当前行:{$i},手机号：{$sign_up_data['mobile_phone']},原因:{$arr_ret['code']}.{$arr_ret['msg']}");
					$errorNum++;
					continue;
				}
			}

			$strAll = '总行数：' . ($successNum + $errorNum) . '\n\r';
			$strSuc = '成功次数：' . $successNum . '\n\r';
			$strErr = '失败次数：' . $errorNum . '\n\r';

			$this->show("<script type='text/javascript'>alert('{$strAll}{$strSuc}{$strErr}');</script>");
		} else {
			$this->error("请选择上传的文件");
		}
	}

	/**
	 * 导入一条学生报名记录
	 *
	 * @param @$activity_id
	 * @param $sign_up_data
	 */
	protected function add_student_sign_record($activity_id, $sign_up_data, $cur_time) {
		$obj_place = M('activity_place');

		$cond = array('activity_id' => $activity_id, 'name' => $sign_up_data['see_type']);
		$activity_place_id = $obj_place->where($cond)->getField('id');

		if (empty($activity_place_id)) {
			return array('code' => -1, 'msg' => '分会场为空');
		}


		$obj_sc = M('student_course');
		$cond = array(
			'school_course_id' => $activity_id,
			'student_id' => $sign_up_data['student_id'],
			'activity_place_id' => $activity_place_id
		);
		$result = $obj_sc->where($cond)->find();

		if (empty($result)) {
			// insert student course sign record
			$data = array(
				'school_course_id' => $activity_id,
				'student_id' => $sign_up_data['student_id'],
				'activity_place_id' => $activity_place_id,
				'time' => $cur_time,
				'update_time' => $cur_time,
				'status' => 1,
				'see_type' => $sign_up_data['see_type'],
				'auth_type' => '有权限',
				'number' => 1,
				'is_check' => 1,
				'pay_status' => $sign_up_data['is_pay'] ? 1 : 0,
			);

			$ret = $obj_sc->add($data);
		} else {
			$ret = $obj_sc->where($cond)->save(array(
					'status' => 1,
					'pay_status' => $sign_up_data['is_pay'] ? 1 : 0,
					'update_time' => $cur_time,
				)
			);
		}
		if (!$ret) {
			return array('code' => -1, 'msg' => '报名失败');
		}

		//座位号
		if ($sign_up_data['seat_address']) {
			$obj_seat = M('student_course_seat');
			$cond = array(
				'course_id' => $activity_id,
				'student_id' => $sign_up_data['student_id'],
				'activity_place_id' => $activity_place_id
			);

			$results = $obj_seat->where($cond)->find();
			if (empty($results)) {
				$obj_seat->student_id = $sign_up_data['student_id'];
				$obj_seat->course_id = $activity_id;
				$obj_seat->activity_place_id = $activity_place_id;
				$obj_seat->seat_address = $sign_up_data['seat_address'];
				$obj_seat->time = $cur_time;

				$ret = $obj_seat->add();
			} else {
				$ret = $obj_seat->where($cond)->save(array('seat_address' => $sign_up_data['seat_address'], 'time' => $cur_time));
			}

			if (!$ret) {
				return array('code' => -1, 'msg' => '更新座位号失败');
			}
		}

		//直播码
		if ($sign_up_data['f_code']) {
			$obj_fcode = M('student_course_fcode');
			$cond = array(
				'course_id' => $activity_id,
				'student_id' => $sign_up_data['student_id'],
			);

			$ookj = $obj_fcode->where($cond)->find();
			if (empty($ookj)) {
				$obj_fcode->student_id = $sign_up_data['student_id'];
				$obj_fcode->course_id = $activity_id;
				$obj_fcode->f_code = $sign_up_data['f_code'];
				$obj_fcode->admin_id = 3;
				$obj_fcode->time = $cur_time;
				$ret = $obj_fcode->add();
			} else {
				$ret = $obj_seat->where($cond)->save(array('f_code' => $sign_up_data['f_code'], 'time' => $cur_time));
			}

			if (!$ret) {
				return array('code' => -1, 'msg' => '更新直播码失败');
			}
		}

		//是否签到
		if ($sign_up_data['is_sign']) {
			$obj_sign = M('student_course_sign');

			$cond = array(
				'course_id' => $activity_id,
				'student_id' => $sign_up_data['student_id'],
				'activity_place_id' => $activity_place_id
			);
			$ookjs = $obj_sign->where($cond)->find();

			if (!empty($ookjs)) {
				if (!$sign_up_data['is_sign']) {
					$ret = $obj_sign->where(array('sign_id' => $ookjs['sign_id']))->delete();
				} else {
					$ret = true;
				}
			} else {
				$obj_sign->course_id = $activity_id;
				$obj_sign->activity_place_id = 0;
				$obj_sign->student_id = $sign_up_data['student_id'];
				$obj_sign->time = $cur_time;

				$ret = $obj_sign->add();
			}

			if (!$ret) {
				return array('code' => -1, 'msg' => '签到失败');
			}
		}

		return array('code' => 0, 'msg' => 'OK');
	}

	/**
	 * update student group
	 *
	 * @param $student_id
	 * @param $group_names
	 */
	protected function update_student_group($student_id, $group_names) {
		if (empty($group_names)) {
			return ;
		}

		$obj_grp = M('student_group');
		$obj_grp_list = M('student_group_list');
		if (strpos($group_names, ' ') === false) {
			// only one
			$this->handle_one_group($student_id, $group_names, $obj_grp, $obj_grp_list);
		} else {
			$arr_grp = explode(' ', $group_names);
			foreach ($arr_grp as $value) {
				$this->handle_one_group($student_id, $value, $obj_grp, $obj_grp_list);
			}
		}
	}

	protected function handle_one_group($student_id, $group_names, $obj_grp, $obj_grp_list) {
		$tag_id = $obj_grp->where(array('student_group_name' => $group_names))->getField('student_group_id');
		if (empty($tag_id)) {
			$time = time();
			$data = array(
				'student_group_name' => $group_names,
				'time' => $time,
			);
			$ret = $obj_grp->add($data);
			if (empty($ret)) {
				return;
			}
			$id = $obj_grp_list->where(array('group_id' => $ret, 'student_id' => $student_id))->getField('id');
			if (empty($id)) {
				$data = array(
					'group_id' => $ret,
					'student_id' => $student_id,
					'time' => $time,
				);
				$obj_grp->add($data);
			}
		}
	}

	protected function update_student_tag($student_id, $tag_names) {
		if (empty($tag_names)) {
			return ;
		}

		$obj_tag = M('student_tag');
		$obj_tag_list = M('student_tag_list');
		if (strpos($tag_names, ' ') === false) {
			// only one
			$this->handle_one_tag($student_id, $tag_names, $obj_tag, $obj_tag_list);
		} else {
			$arr_tag = explode(' ', $tag_names);
			foreach ($arr_tag as $value) {
				$this->handle_one_tag($student_id, $value, $obj_tag, $obj_tag_list);
			}
		}
	}

	protected function handle_one_tag($student_id, $tag_names, $obj_tag, $obj_tag_list) {
		$tag_id = $obj_tag->where(array('name' => $tag_names))->getField('id');
		if (empty($tag_id)) {
			$time = time();
			$data = array(
				'name' => $tag_names,
				'time' => $time,
			);
			$ret = $obj_tag->add($data);
			if (empty($ret)) {
				return;
			}
			$id = $obj_tag_list->where(array('tag_id' => $ret, 'student_id' => $student_id))->getField('id');
			if (empty($id)) {
				$data = array(
					'tag_id' => $ret,
					'student_id' => $student_id,
					'time' => $time,
				);
				$obj_tag_list->add($data);
			}
		}
	}

	protected function myBreak($content)
	{
		dump($content);
	}

	protected function setCellType($sheet,$rowIndex,$colIndex){
		$colCode = get_Char($colIndex);
		$sheet->getStyle($colCode . $rowIndex)
					->getNumberFormat()
					->setFormatCode(
						PHPExcel_Style_NumberFormat::FORMAT_TEXT
					);
	}

	protected function get_Char($colIndex){
		// $array=array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
		$array=array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
		// $len=strlen($char);
		// for($i=0;$i<$len;$i++){
		// 	$index=array_search($char[$i],$array);
		// 	$sum+=($index+1)*pow(26,$len-$i-1);
		// }
		//return $sum;
		return strtoupper($array[$colIndex]);
	}
}