<?php
namespace Admin\Controller;

use Think\Controller;

class StudentController extends ExtendController
{
    private $courseListNum = 20;//学生预约的课程每页显示个数
    private $studentListNum = 20;//学生列表每页显示个数
    private $studentOnlineToSceneSetupListNum = 8;//升级配置

    /**
     * 学生预约列表
     */
    public function courseList()
    {
        /**
         *        st_c  学生预约表（student_course）
         *        st_ 学生表（student）
         *        sc_c 学院课程表 （school_course_id）
         *        sc_学校表（school）
         */
        $school_name = !empty($_GET['school_name']) ? $_GET['school_name'] : 'all';
        $course_name = !empty($_GET['course_name']) ? $_GET['course_name'] : 'all';
        $course_address = !empty($_GET['course_address']) ? $_GET['course_address'] : 'all';
        $student_user_name = !empty($_GET['student_user_name']) ? $_GET['student_user_name'] : 'all';
        $student_mobile_phone = !empty($_GET['student_mobile_phone']) ? $_GET['student_mobile_phone'] : 'all';
        $student_status = !empty($_GET['student_status']) ? $_GET['student_status'] : 'all';
        $see_type = !empty($_GET['see_type']) ? $_GET['see_type'] : 'all';
        //所属学院
        if ($school_name != 'all') {
            $where['sc_c.school_id'] = $school_name;
            $this->assign('school_id', $school_name);
        }

        //课题名字
        if ($course_name != 'all') {
            $where['sc_c.name'] = array('like', '%' . trim($course_name) . '%');
            $this->assign('course_name', $course_name);
        }

        //上课地点
        if ($course_address != 'all') {
            $where['sc_c.address'] = array('like', '%' . trim($course_address) . '%');
            $this->assign('course_address', $course_address);
        }

        //学生账号
        if ($student_user_name != 'all') {
            $where['st_.user_name'] = array('like', '%' . trim($student_user_name) . '%');
            $this->assign('student_user_name', $student_user_name);
        }

        //学生手机
        if ($student_mobile_phone != 'all') {
            $where['st_.mobile_phone'] = array('like', '%' . trim($student_mobile_phone) . '%');
            $this->assign('student_mobile_phone', $student_mobile_phone);
        }

        //状态
        if ($student_status != 'all') {
            $where['st_c.status'] = $student_status;
            $this->assign('student_status_id', $student_status);
        }

        //预约类型
        if ($see_type != 'all') {
            $where['st_c.see_type'] = $see_type;
            $this->assign('see_type_id', $see_type);
        }

        //学院选择
        A('Public')->assignSchoolSelect($school_name);

        //创建学生预约课题状态
        $this->assign('student_status', A('GetSelect')->getStatusS_n(array(1 => '正常', 2 => '已请假'), $student_status, 'student_status', '状态筛选'));
        //创建学校预约类型
        $this->assign('see_type', A('GetSelect')->getStatusS_n(array('直播' => '直播', '现场' => '现场'), $see_type, 'see_type', '预约类型'));

        $sc = D('student_course');
        $join = 'as st_c inner join ' . C('DB_PREFIX') . 'student as st_ on st_c.student_id = st_.id left join ' . C('DB_PREFIX') . 'school_course as sc_c on st_c.school_course_id = sc_c.id  left join ' . C('DB_PREFIX') . 'school as sc_ on sc_c.school_id = sc_.id';

        $count = $sc->join($join)->where($where)->count();

        $Page = new \Think\Page($count, $this->courseListNum);
        $show = $Page->show();

        $field = 'sc_.school_name,sc_.school_logo,sc_c.name as course_name,sc_c.address as course_address,st_.user_name,st_.true_name,st_.mobile_phone,st_c.time,st_c.id,st_c.status,st_c.msg,st_c.see_type,st_c.school_course_id,st_c.auth_type,st_c.auth_type_pay_money';
        $order = 'st_c.id desc';
        $list = $sc->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();

        //dump($list);
        $this->assign('list', $list);
        $this->assign('page', $show);

        $this->display('courseList');
    }



    //---------------------------------------------------------------用户列表（student表）
    /**
     * 学生列表
     */
    public function studentList()
    {
        $searchtype = I('get.searchtype');
        $search = trim(I('get.search'));
        $apply_type_id = !empty($_GET['apply_type_id']) ? $_GET['apply_type_id'] : 'all';
        $vip_status = trim(I('get.vip_status'));    //过期状态查询
        $search_reg_time = !empty($_GET['search_reg_time']) ? $_GET['search_reg_time'] : 'all';
        $end_time = !empty($_GET['end_time']) ? $_GET['end_time'] : 'all';

        $search_reg_time2 = !empty($_GET['search_reg_time2']) ? $_GET['search_reg_time2'] : 'all';
        $end_time2 = !empty($_GET['end_time2']) ? $_GET['end_time2'] : 'all';
        $search_tag_id = !empty($_GET['search_tag_id']) ? $_GET['search_tag_id'] : 'all';
        $search_student_group_id = !empty($_GET['search_student_group_id']) ? $_GET['search_student_group_id'] : 'all';
        //dump($_GET);

        //如果有标签则查询有该标签的用户
        $is_tag_search = false;
        if ($search_tag_id && $search_tag_id != 'all') {
            $student_have_tag_ids = M('student_tag_list')->field('student_id')->where(array('tag_id' => $search_tag_id))->select();
            foreach ($student_have_tag_ids as $k => $v) {
                $student_have_tag_ids_arr[] = $v['student_id'];
            }
            if (empty($student_have_tag_ids_arr)) {
                $student_have_tag_ids_arr = array(0);
            }
            $where['id'] = array('in', $student_have_tag_ids_arr);
            $is_tag_search = true;
        }

        //如果有分组则查询有该分组的用户
        $is_group_search = false;
        if ($search_student_group_id && $search_student_group_id != 'all') {
            $student_have_group_ids = M('student_group_list')->field('student_id')->where(array('group_id' => $search_student_group_id))->select();
            foreach ($student_have_group_ids as $k => $v) {
                $student_have_group_ids_arr[] = $v['student_id'];
            }
            if (empty($student_have_group_ids_arr)) {
                $student_have_group_ids_arr = array(0);
            }
            $where['id'] = array('in', $student_have_group_ids_arr);
            $is_group_search = true;
        }
        //如果标签跟分组都需要的话则合并该数组
        if ($is_tag_search && $is_group_search) {
            $tag_and_group_ids = array_intersect($student_have_tag_ids_arr, $student_have_group_ids_arr);
            if ($tag_and_group_ids) {
                $where['id'] = array('in', $tag_and_group_ids);
            } else {
                $where['id'] = false;
            }
        }


        $cur_time = time();

        //2016-2-25修改
        if ($search_reg_time != 'all' && $search_reg_time != 'NaN' && $search_reg_time != '' && $search_reg_time2 != 'all' && $search_reg_time2 != 'NaN' && $search_reg_time2 != '') {
            $search_reg_time_begin = strtotime($search_reg_time);
            $search_reg_time_end = strtotime($search_reg_time2);

            $where['time'] = array('between', array($search_reg_time_begin, $search_reg_time_end));

            $this->assign('search_reg_time', $search_reg_time);
            $this->assign('search_reg_time2', $search_reg_time2);

        } elseif ($search_reg_time != 'all' && $search_reg_time != 'NaN' && $search_reg_time != '' && ($search_reg_time2 == 'all' || $search_reg_time2 == 'NaN')) {

            $search_reg_time_begin = strtotime($search_reg_time);
            $search_reg_time_end = $search_reg_time_begin + 86400;

            $where['time'] = array('between', array($search_reg_time_begin, $search_reg_time_end));

            $this->assign('search_reg_time', $search_reg_time);
        }

        //2016-2-19修改
        // check reg time end time

        /*if ($search_reg_time != 'all' && $search_reg_time != 'NaN' && $search_reg_time != '') {
            $search_reg_time_begin = strtotime($search_reg_time);
            $search_reg_time_end = $search_reg_time_begin + 86400;

            $where['time'] = array('between', array($search_reg_time_begin, $search_reg_time_end));

            $this->assign('search_reg_time', $search_reg_time);
        }*/

        if (!empty($vip_status)) {
            switch ($vip_status) {
                //正常
                case 'normal':
                    $where['end_time'] = array('egt', $cur_time);
                    break;
                //过期
                case 'expired':
                    $where['end_time'] = array(array('lt', $cur_time), array('egt', 0));
                    break;
                default:
                    break;
            }
            $this->assign('vip_status', $vip_status);
        }

        /*if ($end_time != 'all' && $end_time != 'NaN' && $end_time != '') {
            $end_time_begin = strtotime($end_time);
            $end_time_end = $end_time_begin + 86400;

            $where['end_time'] = array('between', array($end_time_begin, $end_time_end));

            $this->assign('end_time', $end_time);
        } else {
            if (empty($where['end_time'])) {
                $where['end_time'] = array('egt', 0);
            }
        }*/


//        修改 2016-2-25

        if ($end_time != 'all' && $end_time != 'NaN' && $end_time != '' && $end_time2 != 'all' && $end_time2 != 'NaN' && $end_time2 != '') {
            $end_time_begin = strtotime($end_time);
            $end_time_end = strtotime($end_time2);

            $where['end_time'] = array('between', array($end_time_begin, $end_time_end));

            $this->assign('end_time', $end_time);
            $this->assign('end_time2', $end_time2);
        } elseif ($end_time != 'all' && $end_time != 'NaN' && $end_time != '' && ($end_time2 == 'all' || $end_time2 == 'NaN')) {
            $end_time_begin = strtotime($end_time);
            $end_time_end = $end_time_begin + 86400;

            $where['end_time'] = array('between', array($end_time_begin, $end_time_end));

            $this->assign('end_time', $end_time);
        }


        if ($searchtype && $search) {
            if ($searchtype != 'all') {
                $where[$searchtype] = array('like', '%' . $search . '%');
            } else {
                $whereor['id'] = $search;
                $whereor['true_name'] = array('like', '%' . $search . '%');
                $whereor['mobile_phone'] = array('like', '%' . $search . '%');
                $whereor['school_student_number'] = array('like', '%' . $search . '%');
                $whereor['_logic'] = 'or';
                $where['_complex'] = $whereor;
            }

            $this->assign('searchtype', $searchtype);
            $this->assign('search', $search);
        }

        //会员类型
        if ($apply_type_id != 'all') {
//			$where['apply_type_id'] = array($apply_type_id, array('gt', 0));

            $where['apply_type_id'] = array('eq', $apply_type_id);  //修改2016-2-25

            $this->assign('apply_type_id_value', $apply_type_id);
        } else {
            // salty 修改 临时会员为-1
            //$where['apply_type_id'] = array('gt', 0);
        }

//        会员标签，无select 2015-2-25
        $assign_tag = M('student_tag')->select();
        $this->assign('student_tag', $assign_tag);
        //会员分组
        $assign_group = M('student_group')->select();
        $this->assign('student_group', $assign_group);


        //会员标签
        $this->assign('tag_id', A('GetSelect')->getDtoS('student_tag', array('status' => 1), 'sort desc,id asc', 'id', 'name', '', 'tag_id', array('', '选择标签')));

        //会员标签搜索条件
        $this->assign('search_tag_id', A('GetSelect')->getDtoS('student_tag', array('status' => 1), 'sort desc,id asc', 'id', 'name', $search_tag_id, 'search_tag_id', array('', '选择标签')));

        //会员分组
        $this->assign('student_group_id', A('GetSelect')->getDtoS('student_group', array('status' => 1), 'sort desc,student_group_id asc', 'student_group_id', 'student_group_name', '', 'student_group_id', array('', '选择分组')));

        //会员分组搜索条件
        $this->assign('search_student_group_id', A('GetSelect')->getDtoS('student_group', array('status' => 1), 'sort desc,student_group_id asc', 'student_group_id', 'student_group_name', $search_student_group_id, 'search_student_group_id', array('', '选择分组')));

        $this->assign('apply_type_id', A('GetSelect')->getStatusS_n(array(1 => '直播', 2 => '现场'), $apply_type_id, 'apply_type_id', '会员类型'));

        $field = 'id,school_student_number,end_time,student_head_img,true_name,user_name,mobile_phone,student_email,student_qq,student_wx,student_birthday,time,is_disable,apply_type_id';

        $order = "id DESC";

        $foodType = D('student');
        $count = $foodType->where($where)->count();

        if (I('list_number') > 0) {
            $this->studentListNum = I('list_number');
            $this->assign('list_number', $this->studentListNum);
        }

        $Page = new \Think\Page($count, $this->studentListNum);
        $show = $Page->show();

        $list = $foodType->relation(true)->field($field)->where($where)->order($order)->limit($Page->firstRow, $Page->listRows)->select();
//        dump($foodType->getLastSql());die;

        $db_prefix = GetDbPrefix();
        $obj_stu_grp = M('student_group_list');
        $obj_stu_tag = M('student_tag_list');
        foreach ($list as $key => $value) {
            // 获取用户标签和分组
            $stu_grp_list = $obj_stu_grp->table("{$db_prefix}student_group_list l")
                ->join("{$db_prefix}student_group g on(l.group_id=g.student_group_id)")
                ->field('g.student_group_name')
                ->where(array('l.student_id' => $value['id'], 'g.status' => 1))->select();

            $list[$key]['group_name'] = '';
            foreach ($stu_grp_list as $gkey => $gvalue) {
                $list[$key]['group_name'] .= $gvalue['student_group_name'] . '<br />';
            }

            $stu_tag_list = $obj_stu_tag->table("{$db_prefix}student_tag_list l")
                ->join("{$db_prefix}student_tag g on(l.tag_id=g.id)")
                ->field('g.name')
                ->where(array('l.student_id' => $value['id'], 'g.status' => 1))->select();

            $list[$key]['tag_name'] = '';
            foreach ($stu_tag_list as $gkey => $gvalue) {
                $list[$key]['tag_name'] .= $gvalue['name'] . '<br />';
            }
        }

        $this->assign('list', $list);
        $this->assign('page', $show);

        //dump($list);
        $this->display('studentList');
    }


    //学生分组-------------------------------------------------------------------------
    public function studentGroupList()
    {
        $search = !empty($_GET['search']) ? $_GET['search'] : 'all';
        //行业类型名字
        if ($search != 'all') {
            $where['student_group_name'] = array('like', '%' . trim($search) . '%');
            $this->assign('search', $search);
        }
        $order = 'student_group_id desc';
        A('Public')->getList('student_group', '*', $where, $order, 8, 'studentGroupList');
    }

    //学生分组列表 新增、编辑
    public function studentGroupListEdit()
    {
        A('Public')->getEdit('student_group');
        $this->assign('status', A('GetSelect')->getIsShowS($this->data['status'], 'status'));
        $this->display('studentGroupListEdit');
    }


    //学生标签------------------------------------------------------------------------------------------------
    public function studentTagList()
    {
        $search = !empty($_GET['search']) ? $_GET['search'] : 'all';
        //行业类型名字
        if ($search != 'all') {
            $where['name'] = array('like', '%' . trim($search) . '%');
            $this->assign('search', $search);
        }
        $order = 'id desc';
        A('Public')->getList('student_tag', '*', $where, $order, 8, 'studentTagList');
    }

    //学生标签列表 新增、编辑
    public function studentTagListEdit()
    {
        A('Public')->getEdit('student_tag');
        $this->assign('status', A('GetSelect')->getIsShowS($this->data['status'], 'status'));
        $this->display('studentTagListEdit');
    }

    //线上学习记录
    public function onlineList(){
        $searchtype = I('get.searchtype');
        $search = trim(I('get.search'));
//-----------salty begin

        $mobilePhone=!empty($search) && $searchtype == "mobile_phone" ? $search : '';
        $courseName=!empty($search) && $searchtype == "courseName" ? $search : '';;
        // echo $mobilePhone;
        // echo $courseName;
        //等char赋值

        $db_prefix = GetDbPrefix();
        $field = ' this.play_seconds,this.play_datetime,this.is_live ,this.vedio_id,this.course_id,this.student_id,stu.true_name,course.name as courseName,stu.mobile_phone ';
        $join = 'as this inner join ' . $db_prefix . 'school_course as course on this.course_id = course.id inner  join ' . $db_prefix . 'student stu on this.student_id=stu.id';

        if ($courseName) {
            $whereSelect['course.name'] = array('like', '%' . trim($courseName) . '%');
        }
        if ($mobilePhone) {
            $whereSelect['stu.mobile_phone'] = array('like', '%' . trim($mobilePhone) . '%');
        }
        $order = 'this.play_datetime desc';

        $record= D('vedio_play_time');
        $count = $record->join($join)->where($whereSelect)->count();
        $Page = new \Think\Page($count, 20);

        $list= $record->field($field)->join($join)->where($whereSelect)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();

        $show = $Page->show();

        //var_dump ($record);

//-----------salty end

        $this->assign('searchtype', $searchtype);
        $this->assign('search', $search);
        $this->assign('list', $list);
        $this->assign('page', $show);

        $this->display('onlineList');
    }
    //线下学习记录
    public function offlineList(){
        $searchtype = I('get.searchtype');
        $search = trim(I('get.search'));

        $mobilePhone=!empty($search) && $searchtype == "mobile_phone" ? $search : '';
        $courseName=!empty($search) && $searchtype == "name" ? $search : '';

        $db_prefix = GetDbPrefix();
         $field = 'this.student_id,this.id,this.school_course_id,this.activity_place_id,this.status,place.name as see_type,stu.true_name,stu.mobile_phone,course.name,
        course.begin_time,course.relate_course_id,course.is_can_false,course.video_status';
        $join = 'as this inner join ' . $db_prefix . 'school_course as course on this.school_course_id = course.id  inner  join ' . $db_prefix . 'student stu on this.student_id=stu.id';
        $join=$join." inner join y_activity_place place on this.activity_place_id=place.id ";
        $whereSelect['this.pay_status'] = '1';
        $whereSelect['course.type'] = 1;
        $whereSelect['this.status'] = array('gt', 0);

        if ($mobilePhone) {
            $whereSelect['stu.mobile_phone'] = array('like', '%' . trim($mobilePhone) . '%');
        }
        if ($courseName) {
            $whereSelect['course.name'] = array('like', '%' . trim($courseName) . '%');
        }
        $order = 'course.begin_time desc';

        $record= D('student_course');
        $count = $record->join($join)->where($whereSelect)->count();
        $Page = new \Think\Page($count, 20);
        

        $list= $record->field($field)->join($join)->where($whereSelect)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();
//var_dump($list);
        $show = $Page->show();

        $this->assign('searchtype', $searchtype);
        $this->assign('search', $search);
        $this->assign('list', $list);
        $this->assign('page', $show);

        $this->display('offlineList');

    }

    //申请入学列表-------------------------------------------------------------------------
    public function applyList()
    {
        $sc = D('SystemLinePayRecord');
        $field = '*';
        $where = '1';
        $count = $sc->where($where)->count();
        $Page = new \Think\Page($count, 20);
        $show = $Page->show();

        $order = 'time DESC';
        $list = $sc->relation('admin')->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();
        $this->assign('list', $list);
        $this->assign('page', $show);

        $this->display('applyList');
    }

    //申请入学列表 新增、编辑
    public function applyListEdit()
    {
        A('Public')->getEdit('SystemLinePayRecord');
        //创建会员类型
        $this->assign('apply_type_id', A('GetSelect')->getStatusS_n(array(1 => '直播', 2 => '现场'), chen_is_empty($this->data['apply_type_id'], 1), 'apply_type_id', '请选择会员类型'));
        $this->display('applyListEdit');
    }

    //管理员帮用户请假
    public function courseListEditFalse()
    {
        $id = I('post.id');
        $course_id = I('post.course_id');
        if (D('StudentCourse')->delOne($id, $course_id)) {
            echo 'true';
            die;
        } else {
            echo 'false';
            die;
        }

    }

    //用户升级配置列表
    public function studentOnlineToSceneSetupList()
    {
        A('Public')->getList('system_online_to_scence_setup', $field, $where, $order, $this->studentOnlineToSceneSetupListNum, 'studentOnlineToSceneSetupList');
    }

    //用户升级配置更新
    public function studentOnlineToSceneSetupListEdit()
    {
        A('Public')->getEdit('system_online_to_scence_setup');
        $this->display('studentOnlineToSceneSetupListEdit');
    }

    //管理员给用户续费
    public function studentRenew()
    {
        A('Public')->getEdit('student');

        $this->display('studentRenew');
    }

    //禁用用户
    public function setDisable()
    {
        $student_id = I('post.id');
        if (empty($student_id)) {
            echo 'false';
        }
        $where['id'] = $student_id;
        $save['is_disable'] = 1;
        $save['admin_id'] = session('adminid');
        $save['update_time'] = time();
        if (M('student')->where($where)->save($save)) {
            echo 'true';
        } else {
            echo 'false';
        }
    }

    //禁用用户
    public function setEnable()
    {
        $student_id = I('post.id');
        if (empty($student_id)) {
            echo 'false';
        }

        $where['id'] = $student_id;
        $save['is_disable'] = 0;
        $save['admin_id'] = session('adminid');
        $save['update_time'] = time();
        if (M('student')->where($where)->save($save)) {
            echo 'true';
        } else {
            echo 'false';
        }
    }

    //禁用用户
    public function deleteStudent()
    {
        $student_id = I('post.id');
        if (empty($student_id)) {
            echo 'false';
        }

        $student_info = M('student')->find($student_id);
        if (empty($student_info)) {
            echo 'false';
        }

        $student_info['student_id'] = $student_info['id'];
        unset($student_info['id']);
        $student_info['deleted_time'] = time();

        $ret = M('student_deleted')->add($student_info);
        //删审核记录
        D("student_lawyer_profile")->where(array('student_id' => $student_id))->delete();
        D("student_lawyer_profile_approval")->where(array('student_id' => $student_id))->delete();
        if (M('student')->where(array('id' => $student_id))->delete()) {
            echo 'true';
        } else {
            echo 'false';
        }
    }

    //用户修改
    public function studentEdit()
    {
        A('Public')->getEdit('student');

        //查询该学生最后一次报名
        $where['student_id'] = $this->data['id'];
        $this->assign('last_registration', M('student_course')->where($where)->order('time desc')->getField('time'));

        //查询该学生最后一次签到时间
        $this->assign('last_sign', M('student_course_sign')->where($where)->order('time desc')->getField('time'));

        //查询该学生报名次数
        $this->assign('registration_count', M('student_course')->where($where)->count());

        // 行业
        $this->assign('company_vocation_id', A('GetSelect')->getDtoS('student_vocation', 1, 'sort desc,student_vocation_id desc', 'student_vocation_id', 'student_vocation_name', $this->data['company_vocation_id'], 'company_vocation_id', array(0, ' 请选择行业 ')));

        // 职位
        $this->assign('company_position_id', A('GetSelect')->getDtoS('student_position', 1, 'sort desc,student_position_id desc', 'student_position_id', 'student_position_name', $this->data['company_position_id'], 'company_position_id', array(0, ' 请选择职位 ')));

        $obj_pay_record = M('student_pay_record');

        // 入社金额
        $whereJoin = array(
            'pay_student_id' => $this->data['id'],
            'pay_status' => array('like', '%入社%'),
        );
        $apply_money = $obj_pay_record->where($whereJoin)->getField('sum(pay_money)');
        if (empty($apply_money)) {
            $apply_money = 0.0;
        }
        $this->assign('apply_money', $apply_money);

        // 打赏金额
        $cond = array(
            'pay_student_id' => $this->data['id'],
            'pay_status' => array('like', '%打赏%'),
        );
        $reward_money = $obj_pay_record->where($cond)->getField('sum(pay_money)');
        if (empty($reward_money)) {
            $reward_money = 0.0;
        }
        $this->assign('reward_money', $reward_money);

        // 消费总金额
        $cond = array(
            'pay_student_id' => $this->data['id'],
            //	'mobile_phone' => $this->data['mobile_phone'],
          //  '_logic' => 'OR'
        );
        $total_money = $obj_pay_record->where($cond)->getField('sum(pay_money)');
        if (empty($total_money)) {
            $total_money = 0.0;
        }

        $this->assign('total_money', $total_money);

        $this->display('studentEdit');
    }

    //学员记录
    public function studentStudyRecord()
    {
        $student_id = I('get.t');
        $sc = D('student_course');
        $where['this.student_id'] = $student_id;
        $join = 'as this left join ' . C('DB_PREFIX') . 'school_course as course on this.school_course_id = course.id';
        $count = $sc->join($join)->where($where)->count();
        $Page = new \Think\Page($count, 20);
        $show = $Page->show();
        $field = 'course.name,course.address,this.time';
        $list = $sc->join($join)->field($field)->where($where)->order($order)->limit($Page->firstRow . ',' . $Page->listRows)->select();
        $this->assign('list', $list);
        $this->assign('page', $show);
        $this->assign('student_id', $student_id);
        $this->display('studentStudyRecord');
    }

    //会员标签
    public function studentInfoTagList()
    {
        $student_id = I('get.t');
        $sc = D('student_tag_list');
        $where['this.student_id'] = $student_id;
        $join = 'as this left join ' . C('DB_PREFIX') . 'student_tag as tag on this.tag_id = tag.id';
        $field = 'this.tag_id,tag.name';
        $list = $sc->join($join)->field($field)->where($where)->select();
        $this->assign('list', $list);
        foreach ($list as $k => $v) {
            $arr[] = $v['tag_id'];
        }
        $this->assign('student_id', $student_id);
        if ($arr) {
            $tag_where['id'] = array('not in', $arr);
        }

        $tag_where['status'] = 1;
        $this->assign('tagall', M('student_tag')->field('id,name')->where($tag_where)->order('sort desc,id asc')->select());
        $this->display('studentInfoTagList');
    }

    //添加会员标签
    public function addInfoTag()
    {
        $data['student_id'] = I('post.student_id');
        $data['tag_id'] = I('post.tag_id');
        $data['time'] = time();
        $data['admin_id'] = session('adminid');
        if (M('student_tag_list')->add($data)) {
            echo 'true';
        } else {
            echo 'false';
        }
    }

    //删除会员标签
    public function delInfoTag()
    {
        $where['student_id'] = I('post.student_id');
        $where['tag_id'] = I('post.tag_id');
        if (M('student_tag_list')->where($where)->delete()) {
            echo 'true';
        } else {
            echo 'false';
        }
    }

    //会员分组
    public function studentInfoGroupList()
    {
        $student_id = I('get.t');
        $sc = D('student_group_list');
        $where['this.student_id'] = $student_id;
        $join = 'as this left join ' . C('DB_PREFIX') . 'student_group as stgroup on this.group_id = stgroup.student_group_id';
        $field = 'this.group_id,stgroup.student_group_name as name';
        $list = $sc->join($join)->field($field)->where($where)->select();
        $this->assign('list', $list);
        foreach ($list as $k => $v) {
            $arr[] = $v['group_id'];
        }
        $this->assign('student_id', $student_id);
        if ($arr) {
            $group_where['student_group_id'] = array('not in', $arr);
        }
        $group_where['status'] = 1;
        $this->assign('groupall', M('student_group')->field('student_group_id as id,student_group_name as name')->where($group_where)->order('sort desc,id asc')->select());
        $this->display('studentInfoGroupList');
    }

    //添加会员分组
    public function addInfoGroup()
    {
        $data['student_id'] = I('post.student_id');
        $data['group_id'] = I('post.group_id');
        $data['time'] = time();
        $data['admin_id'] = session('adminid');
        if (M('student_group_list')->add($data)) {
            echo 'true';
        } else {
            echo 'false';
        }
    }

    //删除会员分组
    public function delInfoGroup()
    {
        $where['student_id'] = I('post.student_id');
        $where['group_id'] = I('post.group_id');
        if (M('student_group_list')->where($where)->delete()) {
            echo 'true';
        } else {
            echo 'false';
        }
    }

    //会员前缀配置
    public function studentNumberPrefixSetup()
    {
        A('Public')->getList('html_system_setup', $field, $where, $order, 1, 'studentNumberPrefixSetup');
    }

    //会员前缀配置更新
    public function studentNumberPrefixSetupEdit()
    {
        A('Public')->getEdit('html_system_setup');
        $this->display('studentNumberPrefixSetupEdit');
    }

    //批量添加标签
    public function setMoreTag()
    {
        if (D('student')->setMoreTag()) {
            echo 'true';
        } else {
            echo 'false';
        }
    }

    //批量添加分组
    public function setMoreGroup()
    {
        if (D('student')->setMoreGroup()) {
            echo 'true';
        } else {
            echo 'false';
        }
    }

//    2016-2-25 新增
    public function delMoreTag()
    {
        if (D('student')->delMoreTag()) {
            echo 'true';
        } else {
            echo 'false';
        }
    }

    public function delMoreGroup()
    {
        if (D('student')->delMoreGroup()) {
            echo 'true';
        } else {
            echo 'false';
        }
    }

}