<?php
namespace Admin\Controller;

use Think\Controller;

class StudentWaittingController extends ExtendController
{
	private $courseListNum = 20;//学生预约的课程每页显示个数
	private $studentListNum = 20;//学生列表每页显示个数
	private $studentOnlineToSceneSetupListNum = 8;//升级配置

	//---------------------------------------------------------------用户列表（student表）
	/**
	 * 学生列表
	 */
	public function index()
	{
		$this->display('Student/studentWaitting');
	}

}