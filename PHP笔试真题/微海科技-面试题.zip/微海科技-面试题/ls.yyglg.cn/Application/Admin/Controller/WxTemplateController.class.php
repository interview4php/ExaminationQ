<?php
namespace Admin\Controller;

use Think\Controller;

class WxTemplateController extends ExtendController
{
	// 正式服务器的微信配置
	private $wx_app_id;
	private $wx_app_secret;

	private $template_id_begin_course;//课程开课通知模板ID
	private $template_id_begin_activity;//活动即将开始通知ID
	private $template_id_announcement_notice;//公告发布通知ID

	public function _initialize() {
		parent::_initialize();

		$this->wx_app_id = get_wx_app_id();
		$this->wx_app_secret = get_wx_app_secret();

		$this->template_id_begin_course = C('template_id_begin_course');//课程开课通知模板ID
		$this->template_id_begin_activity = C('template_id_begin_activity');//活动即将开始通知ID
		$this->template_id_announcement_notice = C('template_id_announcement_notice');//公告发布通知ID
	}

	//模板消息发送列表
	public function wxTemplateSendList()
	{
		$search = !empty($_GET['search']) ? $_GET['search'] : 'all';
		$hidden_begin_time = !empty($_GET['hidden_begin_time']) ? $_GET['hidden_begin_time'] : 'all';
		$hidden_end_time = !empty($_GET['hidden_end_time']) ? $_GET['hidden_end_time'] : 'all';

		$where = array();
		//模板名字
		if ($search != 'all') {
			$where['template_name'] = array('like', '%' . trim($search) . '%');
			$this->assign('search', $search);
		}

		//时间区间查询
		if ($hidden_begin_time != 'all' && $hidden_begin_time != 'NaN' && $hidden_end_time != 'all' && $hidden_end_time != 'NaN') {
			$btime = getBeginTimeAndEndTime(chen_show_time($hidden_begin_time), chen_show_time($hidden_end_time));
			$where['begin_time'] = array('between', $btime);
			$this->assign('begin_time', $hidden_begin_time);
			$this->assign('end_time', $hidden_end_time);
		}

		if (empty($where)) {
			$where = 1;
		}
		$order = 'id desc';

		A('Public')->getList('wx_template_send_list', '*', $where, $order, 20, 'wxTemplateSendList');
	}

	//课程开课通知
	public function beginCourse()
	{
		$this->assign('tagList', M('student_tag')->field('id,name')->select());
		$this->display('beginCourse');
	}

	//活动即将开始
	public function beginActivit()
	{
		$this->assign('tagList', M('student_tag')->field('id,name')->select());
		$this->display('beginActivit');
	}

	/**
	 * 广告发布通知页面
	 */
	public function announcementNotice()
	{
		$this->assign('tagList', M('student_tag')->field('id,name')->select());
		$this->display('announcementNotice');
	}


	/**
	 * 提交课程开课通知微信模板消息推送
	 */
	public function submitBeginCourse()
	{
		ignore_user_abort();// 即使Client断开(如关掉浏览器)，PHP脚本也可以继续执行.
		set_time_limit(0); // 执行时间为无限制，php默认的执行时间是30秒，通过set_time_limit(0)可以让程	
		$send_obj = I('post.send_obj');
		$true_name = I('post.true_name');
		$course_name = I('post.course_name');
		$begin_time = I('post.begin_time');
		$content = I('post.content');
		$url = I('post.url');

		$send_data = serialize($_POST);

		//查询需要推送的学生信息
		$field = 'id,mobile_phone,wxid,account_binding_wxid';
		$student_data = D('student')->getSendMessageData($send_obj, $field);
		$template_name = '课程开课通知';//模板名字
		$id = D('WxTemplateSendList')->beginOne($template_name, count($student_data), $send_data);

		$nobinding = 0;
		$error = 0;
		$success = 0;

		foreach ($student_data as $k => $v) {
			if ($v['account_binding_wxid']) {
				$openid = $v['account_binding_wxid'];
			} else if ($v['wxid']) {
				$openid = $v['account_binding_wxid'];
			} else {
				$nobinding++;
				D('WxTemplateSendList')->updateOne($id,'number_no_binding',$template_name,$v);
				continue;
			}

			$ret = $this->sendBeginCourse($openid, $course_name, $begin_time, $true_name, $url, $content);
			if (!$ret || $ret['errcode'] != 0 || $ret['errmsg'] != 'ok') {
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else if ($ret['errcode'] == '40001') {
				S('MyWxSystemAccessTokens', Null);
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else {
				$success++;
				D('WxTemplateSendList')->updateOne($id,'number_success',$template_name,$v);
			}
		}

		//推送结束
		D('WxTemplateSendList')->endOne($id, $success, $error, $nobinding);

		$this->success('推送成功', '/Admin/WxTemplate/wxTemplateSendList');
	}

	/**
	 * @param $id
	 */
	public function resumeSend($id) {
		$template_data = M('wx_template_send_list')->find($id);

		$sent_student = M('wx_template_send_list_status')->field('student_id')->where(array('template_id' => $id))
		->select();

		$student_ids = array();
		foreach ($sent_student as $student) {
			$student_ids[$student['student_id']] = 1;
		}

		switch ($template_data['template_name']) {
			case '课程开课通知':
				$this->resumeCourse($id, $template_data['send_data'], $student_ids);
				break;
			case '活动即将开始':
				$this->resumeActivity($id, $template_data['send_data'], $student_ids);
				break;
			case '公告发布通知':
				$this->resumeAnnouncementNotice($id, $template_data['send_data'], $student_ids);
				break;
		}
	}

	/**
	 * 重发课程开课通知微信模板消息推送
	 */
	public function resumeCourse($id, $send_data, $student_ids)
	{
		ignore_user_abort();// 即使Client断开(如关掉浏览器)，PHP脚本也可以继续执行.
		set_time_limit(0); // 执行时间为无限制，php默认的执行时间是30秒，通过set_time_limit(0)可以让程

		$_POST = unserialize($send_data);

		$send_obj = $_POST['send_obj'];
		$true_name = $_POST['true_name'];
		$course_name = $_POST['course_name'];
		$begin_time = $_POST['begin_time'];
		$content = $_POST['content'];
		$url = $_POST['url'];

		//查询需要推送的学生信息
		$field = 'id,mobile_phone,wxid,account_binding_wxid';
		$student_data = D('student')->getSendMessageData($send_obj, $field);
		$template_name = '课程开课通知';//模板名字

		$nobinding = 0;
		$error = 0;
		$success = 0;

		foreach ($student_data as $k => $v) {
			if (!empty($student_ids[$v['id']])) {
				continue;
			}

			if ($v['account_binding_wxid']) {
				$openid = $v['account_binding_wxid'];
			} else if ($v['wxid']) {
				$openid = $v['account_binding_wxid'];
			} else {
				$nobinding++;
				D('WxTemplateSendList')->updateOne($id,'number_no_binding',$template_name,$v);
				continue;
			}

			$ret = $this->sendBeginCourse($openid, $course_name, $begin_time, $true_name, $url, $content);
			if (!$ret || $ret['errcode'] != 0 || $ret['errmsg'] != 'ok') {
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else if ($ret['errcode'] == '40001') {
				S('MyWxSystemAccessTokens', Null);
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else {
				$success++;
				D('WxTemplateSendList')->updateOne($id,'number_success',$template_name,$v);
			}
		}

		//推送结束
		D('WxTemplateSendList')->update_resume_ret($id);

		$this->success('推送成功', '/Admin/WxTemplate/wxTemplateSendList');
	}


	/**
	 * 提交活动即将开始微信模板消息
	 */
	public function submitBeginActivit()
	{
		header('Content-type:text/html;charset=utf-8');
		ignore_user_abort();// 即使Client断开(如关掉浏览器)，PHP脚本也可以继续执行.
		set_time_limit(0); // 执行时间为无限制，php默认的执行时间是30秒，通过set_time_limit(0)可以让程	
		$send_obj = I('post.send_obj');
		$head = I('post.head');
		$title = I('post.title');
		$begin_time = I('post.begin_time');
		$content = I('post.content');
		$url = I('post.url');

		$send_data = serialize($_POST);

		//查询需要推送的学生信息
		$field = 'id,mobile_phone,wxid,account_binding_wxid';
		$student_data = D('student')->getSendMessageData($send_obj, $field);
		$template_name = '活动即将开始';//模板名字
		$id = D('WxTemplateSendList')->beginOne($template_name, count($student_data), $send_data);
		$nobinding = 0;
		$error = 0;
		$success = 0;
		foreach ($student_data as $k => $v) {
			if ($v['account_binding_wxid']) {
				$openid = $v['account_binding_wxid'];
			} else if ($v['wxid']) {
				$openid = $v['account_binding_wxid'];
			} else {
				$nobinding++;
				D('WxTemplateSendList')->updateOne($id,'number_no_binding',$template_name,$v);
				continue;
			}
			$ret = $this->sendBeginActivity($openid, $head, $title, $begin_time, $content, $url);
			if (!$ret || $ret['errcode'] != 0 || $ret['errmsg'] != 'ok') {
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else if ($ret['errcode'] == '40001') {
				S('MyWxSystemAccessTokens', Null);
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else {
				$success++;
				D('WxTemplateSendList')->updateOne($id,'number_success',$template_name,$v);
			}
		}
		//推送结束
		D('WxTemplateSendList')->endOne($id, $success, $error, $nobinding);
		$this->success('推送成功', '/Admin/WxTemplate/wxTemplateSendList');
	}

	/**
	 * 提交活动即将开始微信模板消息
	 */
	public function resumeActivity($id, $send_data, $student_ids)
	{
		header('Content-type:text/html;charset=utf-8');
		ignore_user_abort();// 即使Client断开(如关掉浏览器)，PHP脚本也可以继续执行.
		set_time_limit(0); // 执行时间为无限制，php默认的执行时间是30秒，通过set_time_limit(0)可以让程

		$_POST = unserialize($send_data);

		$send_obj = I('post.send_obj');
		$head = I('post.head');
		$title = I('post.title');
		$begin_time = I('post.begin_time');
		$content = I('post.content');
		$url = I('post.url');

		//查询需要推送的学生信息
		$field = 'id,mobile_phone,wxid,account_binding_wxid';
		$student_data = D('student')->getSendMessageData($send_obj, $field);
		$template_name = '活动即将开始';//模板名字

		$nobinding = 0;
		$error = 0;
		$success = 0;

		foreach ($student_data as $k => $v) {
			if (!empty($student_ids[$v['id']])) {
				continue;
			}

			if ($v['account_binding_wxid']) {
				$openid = $v['account_binding_wxid'];
			} else if ($v['wxid']) {
				$openid = $v['account_binding_wxid'];
			} else {
				$nobinding++;
				D('WxTemplateSendList')->updateOne($id,'number_no_binding',$template_name,$v);
				continue;
			}

			$ret = $this->sendBeginActivity($openid, $head, $title, $begin_time, $content, $url);
			if (!$ret || $ret['errcode'] != 0 || $ret['errmsg'] != 'ok') {
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else if ($ret['errcode'] == '40001') {
				S('MyWxSystemAccessTokens', Null);
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else {
				$success++;
				D('WxTemplateSendList')->updateOne($id,'number_success',$template_name,$v);
			}
		}

		//推送结束
		D('WxTemplateSendList')->update_resume_ret($id);

		$this->success('推送成功', '/Admin/WxTemplate/wxTemplateSendList');
	}

	//公告发布通知
	public function submitAnnouncementNotice()
	{
		header('Content-type:text/html;charset=utf-8');
		ignore_user_abort();// 即使Client断开(如关掉浏览器)，PHP脚本也可以继续执行.
		set_time_limit(0); // 执行时间为无限制，php默认的执行时间是30秒，通过set_time_limit(0)可以让程
		$send_obj = I('post.send_obj');
		$head = I('post.head');
		$author = I('post.author');
		$title = I('post.title');
		$begin_time = I('post.begin_time');
		$content = I('post.content');
		$url = I('post.url');

		$send_data = serialize($_POST);

		//查询需要推送的学生信息
		$field = 'id,mobile_phone,wxid,account_binding_wxid';
		$student_data = D('student')->getSendMessageData($send_obj, $field);



		$template_name = '公告发布通知';//模板名字
		$id = D('WxTemplateSendList')->beginOne($template_name, count($student_data), $send_data);
		$nobinding = 0;
		$error = 0;
		$success = 0;

		foreach ($student_data as $k => $v) {
			if ($v['account_binding_wxid']) {
				$openid = $v['account_binding_wxid'];
			} else if ($v['wxid']) {
				$openid = $v['account_binding_wxid'];
			} else {
				$nobinding++;
				D('WxTemplateSendList')->updateOne($id,'number_no_binding',$template_name,$v);
				continue;
			}

			$ret = $this->sendAnnouncementNotice($openid, $head, $author, $begin_time, $title, $content, $url);
			if (!$ret || $ret['errcode'] != 0 || $ret['errmsg'] != 'ok') {
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else if ($ret['errcode'] == '40001') {
				S('MyWxSystemAccessTokens', Null);
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else {
				$success++;
				D('WxTemplateSendList')->updateOne($id,'number_success',$template_name,$v);
			}
		}

		//推送结束
		D('WxTemplateSendList')->endOne($id, $success, $error, $nobinding);

		$this->success('推送成功', '/Admin/WxTemplate/wxTemplateSendList');
	}

	//公告发布通知
	public function resumeAnnouncementNotice($id, $send_data, $student_ids)
	{
		header('Content-type:text/html;charset=utf-8');
		ignore_user_abort();// 即使Client断开(如关掉浏览器)，PHP脚本也可以继续执行.
		set_time_limit(0); // 执行时间为无限制，php默认的执行时间是30秒，通过set_time_limit(0)可以让程

		$_POST = unserialize($send_data);

		$send_obj = I('post.send_obj');
		$head = I('post.head');
		$author = I('post.author');
		$title = I('post.title');
		$begin_time = I('post.begin_time');
		$content = I('post.content');
		$url = I('post.url');

		//查询需要推送的学生信息
		$field = 'id,mobile_phone,wxid,account_binding_wxid';
		$student_data = D('student')->getSendMessageData($send_obj, $field);
		$template_name = '公告发布通知';//模板名字

		$nobinding = 0;
		$error = 0;
		$success = 0;

		//dump($student_data);die;
		foreach ($student_data as $k => $v) {
			if (!empty($student_ids[$v['id']])) {
				continue;
			}

			if ($v['account_binding_wxid']) {
				$openid = $v['account_binding_wxid'];
			} else if ($v['wxid']) {
				$openid = $v['account_binding_wxid'];
			} else {
				$nobinding++;
				D('WxTemplateSendList')->updateOne($id,'number_no_binding',$template_name,$v);
				continue;
			}

			$ret = $this->sendAnnouncementNotice($openid, $head, $author, $begin_time, $title, $content, $url);
			if (!$ret || $ret['errcode'] != 0 || $ret['errmsg'] != 'ok') {
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else if ($ret['errcode'] == '40001') {
				S('MyWxSystemAccessTokens', Null);
				$error++;
				D('WxTemplateSendList')->updateOne($id,'number_error',$template_name,$v);
			} else {
				$success++;
				D('WxTemplateSendList')->updateOne($id,'number_success',$template_name,$v);
			}
		}

		//推送结束
		D('WxTemplateSendList')->update_resume_ret($id);

		$this->success('推送成功', '/Admin/WxTemplate/wxTemplateSendList');
	}

	/**
	 *发送课程开课通知
	 * @param string $openid 微信用户的openid
	 * @param string $course_name 课程名字
	 * @param date $course_begin_time 课程开始时间，日期格式
	 * @param string $student_name 学生名字
	 * @param string $url 模板点击的链接
	 * @param string $footer 如：请您准时到达，不见不散。
	 * @param string $color 颜色
	 * return 发送状态 json格式
	 */
	protected function sendBeginCourse($openid, $course_name, $course_begin_time, $student_name, $url, $footer = '', $color = '#3A5FCD')
	{
		$touser = $openid;
		$template_id = $this->template_id_begin_course;//课程开课通知模板ID
		$data = array(
			'userName' => array('value' => $student_name, 'color' => $color),
			'courseName' => array('value' => $course_name, 'color' => $color),
			'date' => array('value' => $course_begin_time, 'color' => $color),
			'remark' => array('value' => $footer, 'color' => $color),
		);

		return $this->doSend($touser, $template_id, $url, $data, $color);
	}

	/**
	 *发送活动即将开始通知
	 * @param string $openid 微信用户的openid
	 * @param string $header 如：您好，kantzou。您报名参加的徐家汇万圣节活动即将开始，特此通知。
	 * @param string $title 主题：徐家汇万圣节
	 * @param date $time 时间：2014-12-15 10:00
	 * @param string $footer 如：请您准时到达，不见不散。
	 * @param string $url 模板点击的链接
	 * @param string $color 颜色
	 * return 发送状态 json格式
	 */
	protected function sendBeginActivity($openid, $header, $title, $time, $footer, $url, $color = '#3A5FCD')
	{
		$touser = $openid;
		$template_id = $this->template_id_begin_activity;//活动即将开始通知ID
		$data = array(
			'first' => array('value' => $header, 'color' => $color),
			'keyword1' => array('value' => $title, 'color' => $color),
			'keyword2' => array('value' => $time, 'color' => $color),
			'remark' => array('value' => $footer, 'color' => $color),
		);

		return $this->doSend($touser, $template_id, $url, $data, $color);
	}

	/**
	 * 发送发布公告通知
	 * @param string $openid 微信用户的openid
	 * @param string $header 如：您好，kantzou。您报名参加的徐家汇万圣节活动即将开始，特此通知。
	 * @param string $author 发布人：徐园长
	 * @param date $time 发布时间：2014-12-15 10:00
	 * @param string $title 公告主题：重要！6月18日学生进行毕业典礼，请准时参加！
	 * @param string $footer 如：请您准时到达，不见不散。
	 * @param string $url 模板点击的链接
	 * @param string $color 颜色
	 * return 发送状态 json格式
	 */
	protected function sendAnnouncementNotice($openid, $header, $author, $time, $title, $footer, $url, $color = '#3A5FCD')
	{
		$touser = $openid;
		$template_id = $this->template_id_announcement_notice;//发布公告通知模板ID
		$data = array(
			'first' => array('value' => $header, 'color' => $color),
			'keyword1' => array('value' => $author, 'color' => $color),
			'keyword2' => array('value' => $time, 'color' => $color),
			'keyword3' => array('value' => $title, 'color' => $color),
			'remark' => array('value' => $footer, 'color' => $color),
		);

		return $this->doSend($touser, $template_id, $url, $data, $color);
	}

	/**
	 * 发送自定义的模板消息
	 * @param $touser
	 * @param $template_id
	 * @param $url
	 * @param $data
	 * @param string $topcolor
	 * @return bool
	 */

	protected function doSend($touser, $template_id, $url, $data, $topcolor = '#7B68EE')
	{
		$template = array(
			'touser' => $touser,
			'template_id' => $template_id,
			'url' => $url,
			'topcolor' => $topcolor,
			'data' => $data
		);
		$json_template = json_encode($template);

		$url = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=" . $this->getAccessTokenS();
		$data = $this->http_post1($url, $json_template);
		//dump($url);

		\Think\Log::write("wxtemplate Send:{$json_template}, recv:{$data}", 'INFO');

		$arr_ret = json_decode($data, true);
		if ($arr_ret['errcode'] == '40001') {
			S('MyWxSystemAccessTokens', Null);

			// 重试
			$url = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=" . $this->getAccessTokenS();
			$data = $this->http_post1($url, $json_template);
			\Think\Log::write("wxtemplate Send:{$json_template}, recv:{$data}", 'INFO');

			return json_decode($data, true);
		} else {
			return $arr_ret;
		}
	}


	/**
	 *  获取access token
	 */
	private function getAccessToken()
	{
		$url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$this->wx_app_id&secret=$this->wx_app_secret";
		$atjson = file_get_contents($url);
		$result = json_decode($atjson, true);//json解析成数组
		if (!isset($result['access_token'])) {
			exit('获取access_token失败！');
		}
		return $result["access_token"];
	}

	//获取access_token，查询是否已经缓存，如果没有则重新获取
	private function getAccessTokenS()
	{
		$value = S('MyWxSystemAccessTokens');
		if ($value) {
			return $value;
		} else {
			$access_token = $this->getAccessToken();
			S('MyWxSystemAccessTokens', $access_token, 3600);
			return $access_token;
		}
	}


	//文件读取
	public function https_request($url, $data = null)
	{
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		if (!empty($data)) {
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$output = curl_exec($curl);
		curl_close($curl);
		return $output;
	}

	/**
	 * 发送post请求
	 * @param string $url
	 * @param string $param
	 * @return bool|mixed
	 */
	public function http_post($url = '', $param = '')
	{
		if (empty($url) || empty($param)) {
			return false;
		}
		$postUrl = $url;
		$curlPost = $param;
		$ch = curl_init(); //初始化curl
		curl_setopt($ch, CURLOPT_URL, $postUrl); //抓取指定网页
		curl_setopt($ch, CURLOPT_HEADER, 0); //设置header
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //要求结果为字符串且输出到屏幕上
		curl_setopt($ch, CURLOPT_POST, 1); //post提交方式
		curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
		$data = curl_exec($ch); //运行curl
		curl_close($ch);
		return $data;
	}

	//http post数据
	public function http_post1($url, $post_data = '', $timeout = 5)
	{//curl
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		if ($post_data != '') {
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
		}
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_HEADER, false);
		$file_contents = curl_exec($ch);
		curl_close($ch);
		return $file_contents;
	}

	public function http_post2($url, $data)
	{//file_get_content
		$postdata = http_build_query($data);
		$opts = array('http' =>
			array(
				'method' => 'POST',
				'header' => 'Content-type: application/x-www-form-urlencoded',
				'content' => $postdata
			)
		);
		$context = stream_context_create($opts);
		$result = file_get_contents($url, false, $context);
		return $result;
	}

	/**
	 *    作用：array转xml
	 */
	public function arrayToXml($arr)
	{
		$xml = "<xml>";
		foreach ($arr as $key => $val) {
			if (is_numeric($val)) {
				$xml .= "<" . $key . ">" . $val . "</" . $key . ">";
			} else {
				$xml .= "<" . $key . "><![CDATA[" . $val . "]]></" . $key . ">";
			}
		}
		$xml .= "</xml>";
		return $xml;
	}

	//数组装JSON
	public function arrayToJson($arr, $type = true)
	{
		if ($type) {
			return json_encode($arr);
		} else {
			return json_decode($arr);
		}

	}
}

?>