<?php
namespace Api\Model;
use Think\Model;

class TestModel extends Model {
    
    public function list_content($user_id){
        $field = 'id, name';
    	return $this->field($field)->order('sort')->limit(1000)->select();
    }
}