<?php
namespace Api\Controller;
use Think\Controller;

class PhoneController extends Controller {
    public function index(){

    }

	/**
	 * 检查用户是否存在，有效期，和用户类型
	 *
	 * 0成功，10002：appid或可以错误，10003：用户不存在，20002：输入参数错误
	 */
	public function check_user() {
		//$mobile_phone, $appid, $secret
		// appid:luojisiwei, key:89cbc75b10ae6639a4cd5d287d7fa656323762ae
		// {"code":"0","msg":"","type_name":"普通|铁杆","expire_time":"1472564845"}

		$mobile_phone = I('mobile_phone');
		$appid = I('appid');
		$secret = I('secret');
		if (empty($appid) || empty($secret)) {
			exit_permission_denied(0);
		}

		if ($appid != 'luojisiwei' || $secret != '89cbc75b10ae6639a4cd5d287d7fa656323762ae') {
			exit_permission_denied(0);
		}

		if (empty($mobile_phone)) {
			exit_input_data_error(0);
		}

		$cond = array('mobile_phone' => $mobile_phone);
		$ret = M('student')->field('apply_type_id,end_time')->where($cond)->find();
		if (empty($ret)) {
			exit_user_not_exists(0);
		}

		$arr_more = array(
			'type_name' => (2 == $ret['apply_type_id']) ? '铁杆会员' : '普通会员',
			'expire_time' => $ret['end_time'],
		);

		exit_success(0, $arr_more);
	}
}