<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="wclassth=device-wclassth, initial-scale=1" />
<title>管理中心 V1.0</title>

<!-- 内容样式 -->
<link href="/Public/Admin3/css/main.css" rel="stylesheet" type="text/css" />
<!-- 顶部二级菜单显示 -->
<script type="text/javascript" src="/Public/Admin2/js/zzsc.js"></script>
</head>

<body>
<!-- 头部 -->
	<div class="top_body">
	<div class="logo">
		<!--<img src="/Public/Admin3/images/logo.png" />-->
	</div>
		<ul class="top_menu_l">
			<li><a href="javascript:;" target="main">当前用户：<?php echo ($admindata['user_name']); ?> </a>
			</li>
			<li><a href="/admin/L/passwordEdit" target="main">修改密码</a>
			</li>
			<li style="padding:0;text-align: left;">
			<a href="/admin/L/userloginout" style="width:60px;position:relative;" target="_top">退出<i class="fa-quit"></i>
			</a>
			</li>
		</ul>
	</div>
</body>
</html>