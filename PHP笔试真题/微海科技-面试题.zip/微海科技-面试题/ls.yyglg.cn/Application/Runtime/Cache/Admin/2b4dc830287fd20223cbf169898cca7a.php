<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/admin.css" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/page.css" />
<script type="text/javascript" src="/Public/PublicJs/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="/Public/layer/layer.js"></script>
<script type="text/javascript" src="/Public/PublicJs/showimgMore.js"></script>
<!-- 内容样式 -->
<link href="/Public/Admin3/css/main.css" rel="stylesheet" type="text/css" />
<style type="text/css">
	#imghead,#imghead1,#imghead2 {filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=image);}
	.addMoreImgCount{border:1px solid #cccccc;margin:10px;}
	.addMoreImgCount .del{width:100px;height:36px;line-height:20px;}
</style>
</head>
  
  <body>
  
	
	<div class="edit">
				<div class="rewardt">
					<h4>批量添加PPT</h4>
				</div>
				<form action="/admin/Submit/editPPTListMore" method="post" enctype="multipart/form-data">
				<input type="hidden" name="course_id" id="course_id" value="<?php echo ($course_id); ?>" />
					<table class="edittable2">
						<tbody>
							<tr>
								<td>PPT图片</td>
								<td>
									<p id="moreimgdiv">　　请手动设置好图片大小，最佳像素，750*433 超出将裁减</p>
									<input type="button" onclick="addMoreImg()" value="继续添加" />
									
								</td>
							</tr>
						</tbody>
					</table>
					<input type="submit" class="btn-primary" onclick="return issubmit()" value="提交" />
					<input type="reset" class="btn-primary" value="重置" />
				</form>
			</div>
			<script type="text/javascript">
			function issubmit(){
				var course_id = document.getElementById('course_id').value;
				if(course_id.length==0){
				
					layer.alert('带*号的不能为空', {
						icon: 2,
						skin: 'layer-ext-moon'
					});	return false;
				}
				
				return true;
			}
			var nowimgcount = 1;
			function addMoreImg(){
				var str = '<div class="addMoreImgCount" id="addMoreImgCount'+nowimgcount+'"><div class="btn btn-style-6">';
					str+=	'<label for="file'+nowimgcount+'" class="file-label" title="上传图片">浏览</label>';
					str+=	'<input type="file" name="file[]" id="file'+nowimgcount+'" value="" style="width:60px;" onchange="previewImage(this,\'preview'+nowimgcount+'\',\'imghead'+nowimgcount+'\',\'divhead'+nowimgcount+'\')" />';
					str+=	'</div>';
					str+=	'<input class="del" type="button" onclick="delMoreImg('+nowimgcount+')" value="删除" />';
					str+=	'<div id="preview'+nowimgcount+'"></div></div>';
				$('#moreimgdiv').before(str);
				nowimgcount++;
			}
			function delMoreImg(id){
				$('#addMoreImgCount'+id).remove();
			}
			addMoreImg();
		</script>
		 <script src="/Public/Admin3/js/public.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
	function delF(id,url){
		layer.confirm('您确定要删除该条数据吗？', {
			//skin: 'layer-ext-moon',
			btn: ['确定','取消'], //按钮
			shade: false //不显示遮罩
		}, function(){
			layer.closeAll();
			layer.load(1, {
				shade: [0.1,'#fff'] //0.1透明度的白色背景
			});
			$.post('/admin/Del/'+url,{ 'id':id},function(data){
				layer.closeAll();
				if(data=='true'){
					$('#tr_'+id).remove();
					layer.msg('删除成功', {icon: 1}, function()
					{
						setTimeout(location.href = location.href);
					});

				}else{
					layer.msg('删除失败', {icon: 2});
				}
			});
			
			
		});
	}
	function layerOpenUrl(url,title){
				
		layer.open({
			type: 2,
			title:title,
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			area: ['100%', '100%'],
			content: url
		});
	}
	function layerOpenSchool(){
				
		layer.open({
			type: 2,
			//title: false,
			area: ['700px', '440px'],
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			content: '/admin/Public/selectSchool'
		});
	}
	function layerOpenTeacher(){
				
		layer.open({
			type: 2,
			//title: false,
			area: ['700px', '440px'],
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			content: '/admin/Public/selectTeacher'
		});
	}
	function layerOpenCourse(){
				
		layer.open({
			type: 2,
			//title: false,
			area: ['700px', '440px'],
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			content: '/admin/Public/selectCourse'
		});
	}
</script>
<script type="text/javascript" src="/Public/PublicJs/chenpublic.js"></script>
  </body>
</html>