<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/admin.css" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/page.css" />
<script type="text/javascript" src="/Public/PublicJs/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="/Public/layer/layer.js"></script>
<script type="text/javascript" src="/Public/PublicJs/showimg.js"></script>

<!-- 内容样式 -->
<link href="/Public/Admin3/css/main.css" rel="stylesheet" type="text/css"/>
<style>
    .edittable{
        min-width:867px;
    }

    .edittable table:last-child label{
        display: block;
        height: 45px;
        line-height: 45px;
    }

    .edittable table:last-child label span{
        font-size: 14px !important;
    }
    .edittable table:last-child td{
        padding: 7px 5px;
        vertical-align: middle;
    }

</style>
<script type="text/javascript">

    function deletes() {
        $(".qing").attr("value", "");
    }

</script>
</head>

<body>

<div class="edit">
    <div class="bt">
        <h4>
            <?php if(($editType) == "update"): ?>更新
                <?php else: ?>
                新增<?php endif; ?>
            专栏
        </h4>
    </div>
    <form action="/admin/Submit/editColumnist" method="post" enctype="multipart/form-data">
        <input type="hidden" name="editType" value="<?php echo ($editType); ?>"/>
        <?php if(($editType) == "update"): ?><input type="hidden" name="id" value="<?php echo ($data["id"]); ?>"/><?php endif; ?>
        <table class="edittable">
            <tbody>
            <tr>
                <td>头像</td>
                <td>
                    <div class="btn btn-style-6">
                        <label for="file" class="file-label" title="上传图片">浏览</label>
                        <input type="hidden"  value="<?php echo ($data["columnist_head_img"]); ?>" name="img" />
                        <input type="file" id="file" name="file" value="" style="width:60px;" onchange="previewImage(this)" />

                    </div>
                    <span class="daxiao">请手动设置好图片大小，最佳像素200*200 ，超出部分将裁剪</span>

                    <div id="preview">
                        <img id="imghead" border=0 src="<?php echo (chen_is_empty($data["columnist_head_img"],'/Public/Admin3/images/succeed.png')); ?>" width="180" />
                    </div>
                </td>
            </tr>
            <tr>
                <td>作家名字<span style="color:red;"> *</span>
                </td>
                <td><input type="text" placeholder="请输入作家名字" name="columnist_name" id="columnist_name" value="<?php echo ($data["columnist_name"]); ?>"/>
                </td>
            </tr>
            <tr>
                <td>手机<span style="color:red;"> *</span>
                </td>
                <td><input type="text" placeholder="请输入手机" name="columnist_mobile_phone" id="columnist_mobile_phone" value="<?php echo ($data["columnist_mobile_phone"]); ?>"/>
                </td>
            </tr>
            <tr>
                <td>简介<span style="color:red;"> *</span></td>
                <td>
                    <textarea  placeholder="请输入简介" name="columnist_description" id="columnist_description">
                        <?php echo ($data["columnist_description"]); ?>
                    </textarea>
                </td>
            </tr>
            <tr>
                <td>性别
                </td>
                <td>
                    <input type="radio" name="columnist_sex"
                    <?php if(($data["columnist_sex"]) == "2"): ?>checked="checked"<?php endif; ?>
                    value="2" class="radiobox"/>
                    <span class="nature">女</span>
                    <input type="radio" name="columnist_sex"
                    <?php if(($data["columnist_sex"]) == "1"): ?>checked="checked"<?php endif; ?>
                    value="1" class="radiobox"/>
                    <span class="nature">男</span>
                </td>
            </tr>

            </tbody>
        </table>
        <input type="submit" class="btn-primary" value="保存"/>
        <input type="reset" class="btn-primary" value="重置"/>
    </form>
</div>

<script type="text/javascript">
</script>

<script src="/Public/Admin3/js/public.js" type="text/javascript" charset="utf-8"></script>
</body>
</html>