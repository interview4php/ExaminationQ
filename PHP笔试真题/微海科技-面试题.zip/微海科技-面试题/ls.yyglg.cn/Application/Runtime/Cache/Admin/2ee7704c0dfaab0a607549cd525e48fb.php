<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/admin.css" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/page.css" />
<script type="text/javascript" src="/Public/PublicJs/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="/Public/layer/layer.js"></script>
<script type="text/javascript" src="/Public/PublicJs/showimg.js"></script>
<!-- 内容样式 -->
<link href="/Public/Admin3/css/main.css" rel="stylesheet" type="text/css"/>
<style>
    .edittable{
        min-width:867px;
    }

    .edittable table:last-child label{
        display: block;
        height: 45px;
        line-height: 45px;
    }

    .edittable table:last-child label span{
        font-size: 14px !important;
    }
    .edittable table:last-child td{
        padding: 7px 5px;
        vertical-align: middle;
    }

</style>
</head>

<body>

<div class="edit">
    <div class="bt">
        <h4>
            <?php if(($editType) == "update"): ?>更新
                <?php else: ?>
                新增<?php endif; ?>
            专栏
        </h4>
    </div>
    <form action="/admin/Submit/editColumnsArticle" method="post" enctype="multipart/form-data">
        <input type="hidden" name="editType" value="<?php echo ($editType); ?>"/>
        <?php if(($editType) == "update"): ?><input type="hidden" name="id" value="<?php echo ($data["id"]); ?>"/><?php endif; ?>
        <table class="edittable">
            <tbody>
            <tr>
                <td>所属专栏<span style="color:red;"> *</span>
                </td>
                <td>
                    <div class="ui-select kaitong-r">
                        <div class="mysDivs"></div>
                        <?php echo ($columns_id); ?>
                    </div>
                </td>
            </tr>
            <tr>
                <td>标题<span style="color:red;"> *</span>
                </td>
                <td><input type="text" placeholder="请输入标题" name="title" id="title" value="<?php echo ($data["title"]); ?>"/>
                </td>
            </tr>
            <tr>
                <td>摘要<span style="color:red;"> *</span></td>
                <td>
                    <textarea  placeholder="请输入摘要" name="description" id="description">
                        <?php echo ($data["description"]); ?>
                    </textarea>
                </td>
            </tr>
            <tr>
                <td>缩略图</td>
                <td>
                    <div class="btn btn-style-6">
                        <label for="file" class="file-label" title="上传图片">浏览</label>
                        <input type="hidden"  value="<?php echo ($data["thumb"]); ?>" name="img" />
                        <input type="file" id="file" name="file" value="" style="width:60px;" onchange="previewImage(this)" />
                    </div>
                    <span class="daxiao">(最佳分辨率508*315)</span>

                    <div id="preview">
                        <img id="imghead" border=0 src="<?php echo ($data["thumb"]); ?>" width="180" />
                    </div>
                </td>
            </tr>
            <tr>
                <td>内容<span style="color:red;"> *</span></td>
                <td>
                    <script id="content" name="content" type="text/plain">
										<?php echo (htmlspecialchars_decode($data["content"])); ?>
									</script>
                </td>
            </tr>
            <tr>
                <td>试读
                </td>
                <td>
                    <input type="radio" name="is_trial"
                    <?php if(($data["is_trial"]) == "0"): ?>checked="checked"<?php endif; ?>
                    value="0" class="radiobox"/>
                    <span class="nature">否</span>
                    <input type="radio" name="is_trial"
                    <?php if(($data["is_trial"]) == "1"): ?>checked="checked"<?php endif; ?>
                    value="1" class="radiobox"/>
                    <span class="nature">是</span>
                </td>
            </tr>
            </tbody>
        </table>
        <input type="submit" class="btn-primary" value="保存"/>
        <input type="reset" class="btn-primary" value="重置"/>
    </form>
</div>

<script type="text/javascript" src="/Public/ueditor/ueditor.config.js"></script>
<script type="text/javascript" src="/Public/ueditor/editor_api.js"></script>
<script type="text/javascript">
    UE.getEditor('content',{    //ceo是id名
        //这里可以选择自己需要的工具按钮名称,此处仅选择如下五个
        //focus时自动清空初始化时的内容
        toolbars: [[
            'source', '|', 'undo', 'redo', '|',
            'bold', 'italic', 'underline', 'fontborder', 'strikethrough', '|','superscript', 'subscript', 'pasteplain', '|', 'forecolor', 'backcolor', 'insertorderedlist', 'insertunorderedlist', 'selectall', 'cleardoc', '|',
            'rowspacingtop', 'rowspacingbottom', 'lineheight', '|',
            'customstyle', 'paragraph', 'fontfamily', 'fontsize', '|',
            'directionalityltr', 'directionalityrtl', 'indent', '|',
            'justifyleft', 'justifycenter', 'justifyright', 'justifyjustify', '|', 'touppercase', 'tolowercase', '|',
            'link', 'unlink', 'anchor', '|', 'imagenone', 'imageleft', 'imageright', 'imagecenter', '|',
            'simpleupload', 'insertimage', 'emotion', 'scrawl','fixedpic'
        ]],
        autoClearinitialContent:false,
        //关闭字数统计
        wordCount:true,
        //关闭elementPath
        elementPathEnabled:true,
        //默认的编辑区域高度
        initialFrameHeight:400,
        initialFrameWidth:640
        //更多其他参数，请参考ueditor.config.js中的配置项
    });
</script>

<script src="/Public/Admin3/js/public.js" type="text/javascript" charset="utf-8"></script>
</body>
</html>