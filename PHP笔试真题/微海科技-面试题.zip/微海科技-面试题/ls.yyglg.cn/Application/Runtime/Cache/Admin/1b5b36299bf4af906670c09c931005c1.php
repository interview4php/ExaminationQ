<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/admin.css" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/page.css" />
<script type="text/javascript" src="/Public/PublicJs/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="/Public/layer/layer.js"></script>

<!-- 内容样式 -->
<link href="/Public/Admin3/css/main.css" rel="stylesheet" type="text/css"/>
</head>

<body>
<div class="widget-head">
    <ul class="topmenu">
        <li><a href="/Admin/Show/login"><i></i><span>登录界面设置</span>
        </a>
        </li>
        <li><a href="/Admin/Show/successOne"><i></i><span>预约成功</span>
        </a>
        </li>
        <li><a href="/Admin/Show/login2"><i></i><span>务必请假提示</span>
        </a>
        </li>
        <li class="active"><a href="/Admin/Show/Address"><i></i><span>首页链接</span>
        </a>
        </li>
    </ul>
</div>

<div >
    <form action="AddressSubmit" method="post">
        <table class="edittable" >

            <tr>
                <td>课程表链接
                </td>
                <td><input type="text" name="classTable" id="classTable" value="<?php echo ($data["classTable"]); ?>" />
                </td>
            </tr>
            <tr>
                <td>课程攻略链接
                </td>
                <td><input type="text" name="classPlanning" id="classPlanning" value="<?php echo ($data["classPlanning"]); ?>" />
                </td>
            </tr>
            <tr>
                <td>明星讲师链接
                </td>
                <td><input type="text" name="starTeacher" id="starTeacher" value="<?php echo ($data["starTeacher"]); ?>" />
                </td>
            </tr>
        </table>
        <input type="submit" class="btn-primary" value="保存"  />
        <input            type="reset" class="btn-primary" value="重置" />
    </form>


</div>

</body>
</html>