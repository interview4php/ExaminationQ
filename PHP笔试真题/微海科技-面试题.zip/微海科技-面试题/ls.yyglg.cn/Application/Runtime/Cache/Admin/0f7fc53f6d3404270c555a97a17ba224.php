<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/admin.css" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/page.css" />
<script type="text/javascript" src="/Public/PublicJs/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="/Public/layer/layer.js"></script>

<!-- 内容样式 -->
<link href="/Public/Admin3/css/main.css" rel="stylesheet" type="text/css" />
</head>

<body>
	<div class="widget-head">
		<ul class="topmenu">
			<li><a href="/Admin/TypeSetup/vocation"><i></i><span>行业类型</span></a></li>
			<li><a href="/Admin/TypeSetup/position"><i></i><span>职业类型</span></a></li>
			<li class="active"><a href="/Admin/TypeSetup/apply"><i></i><span>入学类型</span></a></li>
			<li><a href="/Admin/TypeSetup/payType"><i></i><span>支付类型</span></a></li>
			<li><a href="/Admin/TypeSetup/leaveType"><i></i><span>请假类型</span></a></li>
			<li><a href="/Admin/Student/studentTagList"><i></i><span>用户标签</span></a></li>
			<li><a href="/Admin/Student/studentGroupList"><i></i><span>用户分组</span></a></li>
		</ul>
	</div>
	<div class="choose">
		<form action="/admin/TypeSetup/apply" method="get">
			<input type="text" value="<?php echo ($search); ?>" class="input-primary" name="search" placeholder="按入学模式搜索" />
			<input type="submit" class="a-primary" value="搜索" />
		</form>
		<div style="clear: both;"></div>
	</div>
	<div class="userlist">
		<table>
			<thead>
				<tr>
					<th width=20%>入学模式名字</th>
					<th width=10%>所需金额/年</th>
					<th width=10%>使用状态</th>
					<th width=10%>排序</th>
					<th width=15%>添加时间</th>						
					<th width=15%>修改时间</th>						
					<th width=10%>管理员</th>						
					<th width=10%>操作</th>
				</tr>
			</thead>
			<tbody>
			<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?><tr id="tr_<?php echo ($list['student_apply_type_id']); ?>">
				<td><?php echo ($list['student_apply_type_name']); ?></td>
				<td><?php echo ($list['student_apply_type_price']); ?></td>
				<td><?php echo (chen_is_show($list['status'])); ?></td>
				<td><?php echo ($list['sort']); ?></td>
				<td><?php echo (chen_show_time($list['time'])); ?></td>
				<td><?php echo (chen_show_time($list['update_time'])); ?></td>
				<td><input onclick="alertAdmin('<?php echo ($list['admin_user_name']); ?>','<?php echo ($list['admin_true_name']); ?>','<?php echo ($list['admin_mobile_phone']); ?>','<?php echo ($list['admin_email']); ?>','<?php echo ($list['admin_job_number']); ?>')" value="<?php echo ($list['admin_user_name']); ?>" type="button" />
				</td>
				<td><a href="/Admin/TypeSetup/applyEdit/t/<?php echo ($list['student_apply_type_id']); ?>" class="xiahua">编辑</a>
				</td>
			</tr><?php endforeach; endif; else: echo "" ;endif; ?>
		</tbody>
		</table>
		<div class="yahoo2"><?php echo ($page); ?></div>
	</div>
<script type="text/javascript">
	function delF(id,url){
		layer.confirm('您确定要删除该条数据吗？', {
			//skin: 'layer-ext-moon',
			btn: ['确定','取消'], //按钮
			shade: false //不显示遮罩
		}, function(){
			layer.closeAll();
			layer.load(1, {
				shade: [0.1,'#fff'] //0.1透明度的白色背景
			});
			$.post('/admin/Del/'+url,{ 'id':id},function(data){
				layer.closeAll();
				if(data=='true'){
					$('#tr_'+id).remove();
					layer.msg('删除成功', {icon: 1}, function()
					{
						setTimeout(location.href = location.href);
					});

				}else{
					layer.msg('删除失败', {icon: 2});
				}
			});
			
			
		});
	}
	function layerOpenUrl(url,title){
				
		layer.open({
			type: 2,
			title:title,
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			area: ['100%', '100%'],
			content: url
		});
	}
	function layerOpenSchool(){
				
		layer.open({
			type: 2,
			//title: false,
			area: ['700px', '440px'],
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			content: '/admin/Public/selectSchool'
		});
	}
	function layerOpenTeacher(){
				
		layer.open({
			type: 2,
			//title: false,
			area: ['700px', '440px'],
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			content: '/admin/Public/selectTeacher'
		});
	}
	function layerOpenCourse(){
				
		layer.open({
			type: 2,
			//title: false,
			area: ['700px', '440px'],
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			content: '/admin/Public/selectCourse'
		});
	}
</script>
<script type="text/javascript" src="/Public/PublicJs/chenpublic.js"></script>
</body>
</html>