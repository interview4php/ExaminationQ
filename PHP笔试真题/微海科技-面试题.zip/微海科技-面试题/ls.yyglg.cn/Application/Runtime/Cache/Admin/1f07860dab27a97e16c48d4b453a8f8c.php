<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/admin.css" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/page.css" />
<script type="text/javascript" src="/Public/PublicJs/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="/Public/layer/layer.js"></script>
<script type="text/javascript" src="/Public/PublicJs/showimg.js"></script>
<link href="/Public/Admin3/css/main.css" rel="stylesheet" type="text/css" />
<script src="/Public/Admin3/js/jquery-1.7.2.min.js" type="text/javascript"
        charset="utf-8"></script>
</head>

<body>
<div class="edit">
    <div class="bt">
        <h4>新增财务流水</h4>
    </div>
    <form action="/admin/Money/AddPayInfoSubmit" method="post" enctype="multipart/form-data">


        <table class="edittable2">
            <tbody>
            <tr>
                <td>金额<span style="color:red;">*</span>
                </td>
                <td><input type="text" name="pay_money" id="pay_money" value="" />
                </td>
            </tr>

            <tr>
                <td>学生名字<span style="color:red;">*</span>
                </td>
                <td><input type="text" name="true_name" id="true_name" value="" />
                </td>
            </tr>
            <tr>
                <td>学生手机<span style="color:red;">*</span>
                </td>
                <td><input type="text" name="mobile_phone" id="mobile_phone" value="" />
                </td>
            </tr>
            <tr>
                <td>学生学号<span style="color:red;">*</span>
                </td>
                <td><input type="text" name="student_number" id="student_number" value="" />
                </td>
            </tr>
            <tr>
                <td>交易方式<span style="color:red;">*</span>
                </td>
                <td><input type="text" name="pay_status" id="pay_status" value="（人工增加流水）" />
                </td>
            </tr>
            <tr>
                <td>支付方式<span style="color:red;">*</span>
                </td>
                <td><input type="text" name="pay_type" id="pay_type" value="线下汇款" />
                </td>
            </tr>




            <tr>
                <td>支付订单号	<span style="color:red;">*</span>
                </td>
                <td><input type="text" name="transaction_id" id="transaction_id" value="" />
                </td>
            </tr>
            <tr>
                <td>备注	<span style="color:red;">*</span>
                </td>
                <td>
                    <textarea name="pay_msg" id="pay_msg"> </textarea>


                </td>
            </tr>
            </tbody>
        </table>
        <input type="submit" class="btn-primary" value="提交" />
        <input type="reset" class="btn-primary" value="重置" />
    </form>
</div>
<script src="/Public/Admin3/js/public.js" type="text/javascript" charset="utf-8"></script>
</body>
</html>