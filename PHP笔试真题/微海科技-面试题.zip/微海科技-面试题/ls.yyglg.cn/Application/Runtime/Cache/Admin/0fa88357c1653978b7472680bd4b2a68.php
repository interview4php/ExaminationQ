<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/admin.css" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/page.css" />
<script type="text/javascript" src="/Public/PublicJs/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="/Public/layer/layer.js"></script>

<!-- 内容样式 -->
<link href="/Public/Admin3/css/main.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="/Public/timejs/jquery.datetimepicker.css" />
<style>
    .input-int{
        float: left;
        display: inline-block;
        width: 7%;
        height: 31px;
        padding: 0 5px;
        margin-right: 5px;
        background: #fff none repeat scroll 0% 0%;
        color: #8F908A;
        border: 1px solid #DDD;
        margin-bottom: 10px;
        font-size: 13px;
    }
    .r{
        background-color: #e7e0d6;
    }
</style>
<script type="text/javascript" src="/Public/timejs/jquery.datetimepicker.js"></script>
<script>
    function paddingZero(num) {
        if (num < 10) {
            return "0" + num;
        }
        return num;
    }

    function formatDate(date) {
        var d = new Date(date * 1000);
        return d.getFullYear() + "-" + paddingZero(d.getMonth() + 1) + "-" + paddingZero(d.getDate()) + " " + paddingZero(d.getHours()) + ":" + paddingZero(d.getMinutes());
    }
    </script>
</head>

<body>
	<div class="widget-head">
		<ul class="topmenu">
			<li><a href="/Admin/Student/studentList"><i></i><span>用户列表</span></a></li>
			<li class="active"><a href="/Admin/Student/onlineList"><i></i><span>线上学习记录</span></a></li>
			<li><a href="/Admin/Student/offlineList"><i></i><span>线下学习记录</span></a></li>
			<li><a href="/Admin/Student/courseList"><i></i><span>学生预约列表</span></a></li>
			<li><a href="/Admin/Student/applyList"><i></i><span>申请入学</span></a></li>
			<li><a href="/Admin/Student/studentOnlineToSceneSetupList"><i></i><span>学生升级线下</span></a></li>
			<li><a href="/Admin/Student/studentNumberPrefixSetup"><i></i><span>学号前缀配置</span></a></li>
		</ul>
	</div>
	<div class="choose">
        <form action="/Admin/Student/onlineList" method="get">
			<div class="ui-select kaitong-r" style="float:left;">
				<div class="mysDivs"><?php echo (chen_is_empty($searchtype,'搜索所有')); ?></div>
				<select name="searchtype" id="">
				<option value="mobile_phone" <?php if(($searchtype) == "mobile_phone"): ?>selected="selected"<?php endif; ?> >手机</option>
				<option value="courseName" <?php if(($searchtype) == "courseName"): ?>selected="selected"<?php endif; ?> >课程名称</option>
				</select>
			</div>
			<input type="text" class="input-primary" value="<?php echo ($search); ?>" name="search" />
			<input type="submit" value="搜索" class="a-primary" style="height:33px;"/>
			<!-- <a href="/Admin/MyExcel/studentStudentList?searchtype=<?php echo ($searchtype); ?>&search=<?php echo ($search); ?>&apply_type_id=<?php echo ($apply_type_id_value); ?>" class="a-primary">导出</a> -->
			<a href="/Admin/MyExcel/onlineList?searchtype=<?php echo ($searchtype); ?>&search=<?php echo ($search); ?>" class="a-primary">导出</a>
		</form>

		<div style="clear: both;"></div>

	</div>
	<div class="userlist">
		<table>
			<thead>
				<tr>
					<th width=20%>姓名</th>
					<th width=20%>手机</th>
					<th width=20%>课程名称</th>
					<th width=5%>课程类型</th>
					<th width=10%>播放时长</th>
                    <th width=20%>最后播放时间</th>
				</tr>
			</thead>
			<tbody>
			<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?><tr>
				<td><?php echo ($list['true_name']); ?></td>
				<td><?php echo ($list['mobile_phone']); ?></td>
				<td><?php echo ($list['courseName']); ?></td>
				<td>
					<?php
 if($list['is_live'] == "1"){ echo "直播"; } else{ echo "点播"; } ?>
				</td>
				<td><?php echo ($list['play_seconds']); ?></td>
				<td>
					<script>
						document.write(formatDate(<?php echo ($list['play_datetime']); ?>));
					</script>
				</td>
				
			</tr><?php endforeach; endif; else: echo "" ;endif; ?>
		</tbody>
		</table>
		<div class="yahoo2"><?php echo ($page); ?></div>
	</div>
	<script src="/Public/Admin3/js/public.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
	function delF(id,url){
		layer.confirm('您确定要删除该条数据吗？', {
			//skin: 'layer-ext-moon',
			btn: ['确定','取消'], //按钮
			shade: false //不显示遮罩
		}, function(){
			layer.closeAll();
			layer.load(1, {
				shade: [0.1,'#fff'] //0.1透明度的白色背景
			});
			$.post('/admin/Del/'+url,{ 'id':id},function(data){
				layer.closeAll();
				if(data=='true'){
					$('#tr_'+id).remove();
					layer.msg('删除成功', {icon: 1}, function()
					{
						setTimeout(location.href = location.href);
					});

				}else{
					layer.msg('删除失败', {icon: 2});
				}
			});
			
			
		});
	}
	function layerOpenUrl(url,title){
				
		layer.open({
			type: 2,
			title:title,
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			area: ['100%', '100%'],
			content: url
		});
	}
	function layerOpenSchool(){
				
		layer.open({
			type: 2,
			//title: false,
			area: ['700px', '440px'],
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			content: '/admin/Public/selectSchool'
		});
	}
	function layerOpenTeacher(){
				
		layer.open({
			type: 2,
			//title: false,
			area: ['700px', '440px'],
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			content: '/admin/Public/selectTeacher'
		});
	}
	function layerOpenCourse(){
				
		layer.open({
			type: 2,
			//title: false,
			area: ['700px', '440px'],
			fix: false, //不固定
			maxmin: true,
			shadeClose: true,
			content: '/admin/Public/selectCourse'
		});
	}
</script>
<script type="text/javascript" src="/Public/PublicJs/chenpublic.js"></script>

</body>
</html>